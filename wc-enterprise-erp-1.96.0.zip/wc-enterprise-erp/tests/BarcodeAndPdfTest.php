<?php

use PHPUnit\Framework\TestCase;

final class BarcodeAndPdfTest extends TestCase {

	/* ---------------- Code 39 SVG ---------------- */

	public function test_barcode_svg_structure() {
		$svg = WCEERP_Module_Barcode::barcode_svg( 'SKU-1234' );

		$this->assertStringStartsWith( '<svg', $svg );
		$this->assertStringContainsString( '</svg>', $svg );
		$this->assertStringContainsString( '<rect', $svg );
	}

	public function test_barcode_sanitises_unsupported_characters() {
		// Lowercase becomes uppercase, unsupported chars become '-'.
		$dirty = WCEERP_Module_Barcode::barcode_svg( 'abc_ç#12' );
		$clean = WCEERP_Module_Barcode::barcode_svg( 'ABC--12' );
		$this->assertSame( $clean, $dirty );
	}

	public function test_barcode_height_is_respected() {
		// The SVG adds 16pt below the bars for the human-readable text.
		$svg = WCEERP_Module_Barcode::barcode_svg( '99', 72 );
		$this->assertStringContainsString( 'height="88"', $svg );
		$this->assertStringContainsString( 'height="72"', $svg ); // bar rects.
	}

	/* ---------------- PDF writer ---------------- */

	public function test_pdf_output_has_valid_envelope() {
		$pdf = new WCEERP_PDF();
		$pdf->add_page();
		$pdf->set_font( 12, true )->text( 40, 50, 'Mushak-6.3 Test' );
		$pdf->line( 40, 60, 500, 60 );
		$data = $pdf->output();

		$this->assertStringStartsWith( '%PDF-1.4', $data );
		$this->assertStringEndsWith( '%%EOF', $data );
		$this->assertStringContainsString( 'xref', $data );
		$this->assertStringContainsString( '/Type /Catalog', $data );
		$this->assertStringContainsString( '/BaseFont /Helvetica', $data );
	}

	public function test_pdf_pages_count_matches() {
		$pdf = new WCEERP_PDF();
		$pdf->add_page()->text( 40, 50, 'one' );
		$pdf->add_page()->text( 40, 50, 'two' );
		$data = $pdf->output();

		$this->assertStringContainsString( '/Count 2', $data );
		$this->assertSame( 2, substr_count( $data, '/Type /Page ' ) );
	}

	public function test_pdf_escapes_parentheses_in_text() {
		$pdf = new WCEERP_PDF();
		$pdf->add_page()->text( 40, 50, 'Total (net)' );
		$data = $pdf->output();

		$this->assertStringContainsString( '(Total \\(net\\))', $data );
	}

	public function test_pdf_latinises_taka_sign() {
		$this->assertSame( 'Tk 500', WCEERP_PDF::latinise( '৳500' ) );
	}

	public function test_pdf_xref_offsets_point_at_objects() {
		$pdf = new WCEERP_PDF();
		$pdf->add_page()->text( 40, 50, 'offset check' );
		$data = $pdf->output();

		preg_match_all( '/^(\d{10}) 00000 n /m', $data, $m );
		$this->assertNotEmpty( $m[1] );
		foreach ( $m[1] as $i => $offset ) {
			$at = (int) $offset;
			$this->assertMatchesRegularExpression(
				'/^\d+ 0 obj/',
				substr( $data, $at, 20 ),
				"xref entry $i does not point at an object"
			);
		}
	}
}
