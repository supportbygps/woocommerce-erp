<?php

use PHPUnit\Framework\TestCase;

final class AccountingTest extends TestCase {

	protected function setUp(): void {
		// Fresh wpdb stub that "knows" a couple of accounts.
		$wpdb = new WCEERP_Test_WPDB();
		// resolve_account() looks up ids by numeric id or by code.
		$wpdb->vars = array(
			'/WHERE id = 1\b/'      => 1,
			'/WHERE id = 2\b/'      => 2,
			"/WHERE code = '1000'/" => 1,
			"/WHERE code = '4000'/" => 2,
			"/WHERE code = '9999'/" => 0, // unknown account.
		);
		$GLOBALS['wpdb'] = $wpdb;
		$GLOBALS['__wp_options'] = array();
	}

	public function test_unbalanced_journal_is_rejected() {
		$result = WCEERP_Accounting::post(
			array( 'memo' => 'broken' ),
			array(
				array( 'account' => '1000', 'debit' => 100 ),
				array( 'account' => '4000', 'credit' => 90 ),
			)
		);
		$this->assertInstanceOf( WP_Error::class, $result );
		$this->assertSame( 'wceerp_journal', $result->get_error_code() );
	}

	public function test_single_line_journal_is_rejected() {
		$result = WCEERP_Accounting::post(
			array(),
			array( array( 'account' => '1000', 'debit' => 100 ) )
		);
		$this->assertInstanceOf( WP_Error::class, $result );
	}

	public function test_unknown_account_is_rejected() {
		$result = WCEERP_Accounting::post(
			array(),
			array(
				array( 'account' => '9999', 'debit' => 100 ),
				array( 'account' => '4000', 'credit' => 100 ),
			)
		);
		$this->assertInstanceOf( WP_Error::class, $result );
	}

	public function test_balanced_journal_posts_header_and_lines() {
		global $wpdb;

		$journal_id = WCEERP_Accounting::post(
			array( 'memo' => 'Cash sale', 'ref_type' => 'test' ),
			array(
				array( 'account' => '1000', 'debit' => 115 ),
				array( 'account' => '4000', 'credit' => 100 ),
				array( 'account' => 2, 'credit' => 15 ),
			)
		);

		$this->assertIsInt( $journal_id );
		$this->assertGreaterThan( 0, $journal_id );

		// 1 journal header + 3 lines.
		$this->assertCount( 4, $wpdb->inserts );

		list( $table, $header ) = $wpdb->inserts[0];
		$this->assertStringContainsString( 'erp_journals', $table );
		$this->assertSame( 'posted', $header['status'] );
		$this->assertSame( 'test', $header['ref_type'] );

		$debits  = 0;
		$credits = 0;
		foreach ( array_slice( $wpdb->inserts, 1 ) as $insert ) {
			$this->assertStringContainsString( 'erp_journal_lines', $insert[0] );
			$debits  += $insert[1]['debit'];
			$credits += $insert[1]['credit'];
			$this->assertSame( $journal_id, $insert[1]['journal_id'] );
		}
		$this->assertEqualsWithDelta( $debits, $credits, 0.001 );
	}

	public function test_rounding_differences_within_a_paisa_still_balance() {
		$journal_id = WCEERP_Accounting::post(
			array(),
			array(
				array( 'account' => '1000', 'debit' => 33.333 ),
				array( 'account' => '4000', 'credit' => 33.331 ),
			)
		);
		// 33.33 == 33.33 after 2dp rounding → allowed.
		$this->assertIsInt( $journal_id );
	}
}
