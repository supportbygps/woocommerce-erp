<?php

use PHPUnit\Framework\TestCase;

final class HelpersTest extends TestCase {

	/* ---------------- lakh/crore grouping ---------------- */

	public function test_lakh_format_groups_indian_style() {
		$this->assertSame( '1,23,45,678.00', wceerp_lakh_format( 12345678 ) );
		$this->assertSame( '12,34,56,789.50', wceerp_lakh_format( 123456789.5 ) );
	}

	public function test_lakh_format_small_numbers_unchanged() {
		$this->assertSame( '999.00', wceerp_lakh_format( 999 ) );
		$this->assertSame( '1,000.00', wceerp_lakh_format( 1000 ) );
	}

	public function test_lakh_format_negative_and_zero_decimals() {
		$this->assertSame( '-1,00,000', wceerp_lakh_format( -100000, 0 ) );
	}

	/* ---------------- Bangla digits ---------------- */

	public function test_bangla_digit_conversion() {
		$this->assertSame( '১২৩', wceerp_to_bangla_digits( '123' ) );
		$this->assertSame( '৳ ১,২৩,৪৫৬.০০', wceerp_to_bangla_digits( '৳ 1,23,456.00' ) );
	}

	/* ---------------- July–June fiscal year ---------------- */

	public function test_fiscal_year_before_july_belongs_to_previous_year() {
		$fy = wceerp_fiscal_year( '2026-06-30' );
		$this->assertSame( '2025-07-01', $fy['start'] );
		$this->assertSame( '2026-06-30', $fy['end'] );
		$this->assertSame( '2025-26', $fy['label'] );
	}

	public function test_fiscal_year_starts_first_of_july() {
		$fy = wceerp_fiscal_year( '2026-07-01' );
		$this->assertSame( '2026-07-01', $fy['start'] );
		$this->assertSame( '2027-06-30', $fy['end'] );
		$this->assertSame( '2026-27', $fy['label'] );
	}

	/* ---------------- document numbering ---------------- */

	public function test_doc_numbers_are_sequential_per_fiscal_year() {
		$first  = wceerp_next_doc_number( 'test' );
		$second = wceerp_next_doc_number( 'test' );

		$this->assertStringStartsWith( 'TEST-', $first );
		$this->assertMatchesRegularExpression( '/^TEST-\d{4}-\d{6}$/', $first );

		$n1 = (int) substr( $first, -6 );
		$n2 = (int) substr( $second, -6 );
		$this->assertSame( $n1 + 1, $n2 );
	}

	/* ---------------- decimal parsing ---------------- */

	public function test_dec_strips_thousand_separators() {
		$this->assertSame( 12345.67, wceerp_dec( '12,345.67' ) );
		$this->assertSame( 0.0, wceerp_dec( '' ) );
	}
}
