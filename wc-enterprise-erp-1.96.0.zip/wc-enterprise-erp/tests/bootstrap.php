<?php
/**
 * PHPUnit bootstrap: minimal WordPress stubs.
 *
 * These tests target pure logic (money formatting, fiscal year, the
 * double-entry validator, barcode SVG, the PDF writer) without booting
 * WordPress. Integration tests against a real WP/WC stack belong in
 * wp-env / wp-browser and are out of scope here.
 */

define( 'ABSPATH', sys_get_temp_dir() . '/' );
define( 'DAY_IN_SECONDS', 86400 );
define( 'HOUR_IN_SECONDS', 3600 );

/* ---------------- option store ---------------- */
$GLOBALS['__wp_options'] = array();

function get_option( $name, $default = false ) {
	return array_key_exists( $name, $GLOBALS['__wp_options'] ) ? $GLOBALS['__wp_options'][ $name ] : $default;
}
function update_option( $name, $value, $autoload = null ) {
	$GLOBALS['__wp_options'][ $name ] = $value;
	return true;
}

/* ---------------- i18n / escaping ---------------- */
function __( $text, $domain = null ) { return $text; }
function _n( $single, $plural, $number, $domain = null ) { return 1 == $number ? $single : $plural; }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_url( $url ) { return (string) $url; }
function wp_kses_post( $text ) { return $text; }
function number_format_i18n( $number, $decimals = 0 ) { return number_format( (float) $number, $decimals ); }

/* ---------------- sanitisation ---------------- */
function sanitize_key( $key ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $key ) ); }
function sanitize_text_field( $str ) { return trim( preg_replace( '/[\r\n\t ]+/', ' ', strip_tags( (string) $str ) ) ); }
function sanitize_textarea_field( $str ) { return trim( strip_tags( (string) $str ) ); }
function sanitize_email( $email ) { return filter_var( $email, FILTER_SANITIZE_EMAIL ); }
function sanitize_file_name( $name ) { return preg_replace( '/[^A-Za-z0-9._\-]/', '-', (string) $name ); }
function absint( $n ) { return abs( (int) $n ); }
function wp_unslash( $value ) { return is_string( $value ) ? stripslashes( $value ) : $value; }
function wp_strip_all_tags( $text ) { return trim( strip_tags( (string) $text ) ); }
function remove_accents( $text ) {
	$out = @iconv( 'UTF-8', 'ASCII//TRANSLIT//IGNORE', (string) $text );
	return false === $out ? preg_replace( '/[^\x20-\x7E]/', '', (string) $text ) : $out;
}

/* ---------------- hooks (no-op) ---------------- */
function add_action( ...$args ) {}
function add_filter( ...$args ) {}
function do_action( ...$args ) {}
function apply_filters( $tag, $value, ...$args ) { return $value; }
function wp_parse_args( $args, $defaults = array() ) { return array_merge( (array) $defaults, (array) $args ); }

/* ---------------- time / misc ---------------- */
function current_time( $type ) {
	if ( 'mysql' === $type ) { return gmdate( 'Y-m-d H:i:s' ); }
	if ( 'timestamp' === $type ) { return time(); }
	return gmdate( $type );
}
function get_current_user_id() { return 1; }
function get_the_title( $id ) { return 'Product #' . $id; }
function untrailingslashit( $s ) { return rtrim( (string) $s, '/\\' ); }
function get_woocommerce_currency() { return 'BDT'; }
function get_woocommerce_currency_symbol() { return '৳'; }

/* ---------------- WP_Error ---------------- */
class WP_Error {
	protected $code;
	protected $message;
	public function __construct( $code = '', $message = '' ) { $this->code = $code; $this->message = $message; }
	public function get_error_code() { return $this->code; }
	public function get_error_message() { return $this->message; }
}
function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

/* ---------------- $wpdb stub ---------------- */
class WCEERP_Test_WPDB {
	public $prefix    = 'wp_';
	public $posts     = 'wp_posts';
	public $insert_id = 0;
	public $inserts   = array(); // [ [table, data], … ]
	public $updates   = array();
	public $rows      = array(); // canned get_row results keyed by regex.
	public $vars      = array(); // canned get_var results keyed by regex.

	public function insert( $table, $data, $format = null ) {
		$this->insert_id++;
		$this->inserts[] = array( $table, $data );
		return 1;
	}
	public function update( $table, $data, $where ) {
		$this->updates[] = array( $table, $data, $where );
		return 1;
	}
	public function prepare( $query, ...$args ) {
		if ( 1 === count( $args ) && is_array( $args[0] ) ) { $args = $args[0]; }
		$query = str_replace( '%s', "'%s'", $query );
		return vsprintf( str_replace( array( '%d', '%f' ), array( '%d', '%F' ), $query ), $args );
	}
	protected function canned( $store, $query, $default ) {
		foreach ( $store as $pattern => $value ) {
			if ( preg_match( $pattern, $query ) ) { return $value; }
		}
		return $default;
	}
	public function get_row( $query, $output = OBJECT ) { return $this->canned( $this->rows, $query, null ); }
	public function get_var( $query ) { return $this->canned( $this->vars, $query, null ); }
	public function get_results( $query, $output = OBJECT ) { return array(); }
	public function get_col( $query ) { return array(); }
	public function query( $query ) { return 1; }
	public function esc_like( $s ) { return addcslashes( (string) $s, '_%\\' ); }
}
if ( ! defined( 'OBJECT' ) ) { define( 'OBJECT', 'OBJECT' ); }
$GLOBALS['wpdb'] = new WCEERP_Test_WPDB();

/* ---------------- plugin files under test ---------------- */
define( 'WCEERP_TESTS_DIR', __DIR__ );
define( 'WCEERP_PLUGIN_DIR', dirname( __DIR__ ) );

require_once WCEERP_PLUGIN_DIR . '/includes/helpers.php';
require_once WCEERP_PLUGIN_DIR . '/includes/class-erp-pdf.php';
require_once WCEERP_PLUGIN_DIR . '/includes/class-erp-accounting.php';
require_once WCEERP_PLUGIN_DIR . '/includes/abstracts/class-erp-module.php';
require_once WCEERP_PLUGIN_DIR . '/includes/modules/class-module-barcode.php';
