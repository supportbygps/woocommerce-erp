/* WC Enterprise ERP — admin behaviours */
(function ($) {
	'use strict';

	var i18n = window.wceerp && window.wceerp.i18n ? window.wceerp.i18n : {};

	/**
	 * "+ Add row" buttons: clone the last row of the nearest .wceerp-items
	 * table, clear its values, and append a remove link.
	 */
	$(document).on('click', '#wceerp-add-row, .wceerp-add-row', function (e) {
		e.preventDefault();

		var $table = $(this).closest('form').find('table.wceerp-items').first();
		if (!$table.length) {
			return;
		}

		var $row = $table.find('tbody tr').last().clone();

		$row.find('input').each(function () {
			var $input = $(this);
			if ($input.is('[type=number]') && $input.attr('name') && $input.attr('name').indexOf('wastage') !== -1) {
				$input.val('0');
			} else {
				$input.val('');
			}
		});
		$row.find('select').prop('selectedIndex', 0);

		// Reset any selectWoo-enhanced product search in the cloned row.
		$row.find('.select2-container').remove();
		$row.find('select.wceerp-product-search')
			.removeClass('select2-hidden-accessible enhanced')
			.removeAttr('data-select2-id aria-hidden tabindex')
			.empty();

		$row.find('.wceerp-row-remove').remove();

		var label = i18n.rowRemove || 'Remove';
		$row.children('td').last().append(
			' <a href="#" class="wceerp-row-remove" aria-label="' + label + '">&times; ' + label + '</a>'
		);

		$table.find('tbody').append($row);

		// Re-initialise WooCommerce enhanced selects for the new row.
		$(document.body).trigger('wc-enhanced-select-init');
	});

	$(document).on('click', '.wceerp-row-remove', function (e) {
		e.preventDefault();
		var $tbody = $(this).closest('tbody');
		if ($tbody.find('tr').length > 1) {
			$(this).closest('tr').remove();
		}
	});

	/**
	 * Destructive actions ask before submitting.
	 */
	$(document).on('click', '.wceerp-confirm, .wceerp-danger[data-confirm]', function (e) {
		var message = $(this).data('confirm') || i18n.confirmDelete || 'Are you sure?';
		if (!window.confirm(message)) {
			e.preventDefault();
			e.stopImmediatePropagation();
		}
	});
})(jQuery);
