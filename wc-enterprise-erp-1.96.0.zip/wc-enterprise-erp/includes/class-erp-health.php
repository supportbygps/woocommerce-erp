<?php
/**
 * System health.
 *
 * Checks the things that silently break an install: missing tables, missing
 * columns after a partial upgrade, chart-of-accounts entries that modules
 * depend on, unseeded lookup data, and cron.
 *
 * Written because a module can be entirely correct and still fail on a
 * particular site — reading the code cannot tell you whether a table exists
 * on someone else's server.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Health {

	/** Accounts that specific features fail without. */
	public static function required_accounts() {
		return array(
			'1000' => __( 'Cash in Hand — POS, expenses', 'wc-enterprise-erp' ),
			'1100' => __( 'Accounts Receivable — credit sales, dues', 'wc-enterprise-erp' ),
			'1110' => __( 'Courier COD Receivable — all COD', 'wc-enterprise-erp' ),
			'1200' => __( 'Inventory — stock value', 'wc-enterprise-erp' ),
			'2100' => __( 'VAT Payable', 'wc-enterprise-erp' ),
			'3200' => __( 'Opening Balance Equity — opening entries', 'wc-enterprise-erp' ),
			'4000' => __( 'Sales Revenue — every sale', 'wc-enterprise-erp' ),
			'5000' => __( 'Cost of Goods Sold', 'wc-enterprise-erp' ),
			'5600' => __( 'Delivery & Courier Charges — payouts', 'wc-enterprise-erp' ),
		);
	}

	/** Run every check. */
	public static function run() {
		return array(
			'tables'     => self::check_tables(),
			'accounts'   => self::check_accounts(),
			'lookups'    => self::check_lookups(),
			'cron'       => self::check_cron(),
			'writes'     => self::check_write(),
			'categories' => self::check_category_accounts(),
			'phantom'    => self::check_phantom_collections(),
			'emptypay'   => self::check_empty_payouts(),
			'orphanret'  => self::check_orphan_returns(),
			'unalloc'    => self::check_unallocated_charges(),
			'credits'    => self::check_floating_credits(),
		);
	}

	/** Every table the installer defines, and whether it exists. */
	public static function check_tables() {
		global $wpdb;

		$source = file_get_contents( WCEERP_PATH . 'includes/class-erp-installer.php' );
		preg_match_all( '/CREATE TABLE \{\$p\}([a-z_]+)/', (string) $source, $m );
		$expected = array_unique( $m[1] ?? array() );

		$missing = array();
		foreach ( $expected as $name ) {
			$table = wceerp_table( $name );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
				$missing[] = $name;
			}
		}
		return array(
			'expected' => count( $expected ),
			'missing'  => $missing,
			'ok'       => empty( $missing ),
		);
	}

	public static function check_accounts() {
		global $wpdb;
		$table   = wceerp_table( 'accounts' );
		$missing = array();

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return array( 'ok' => false, 'missing' => array_keys( self::required_accounts() ), 'total' => 0 );
		}

		foreach ( self::required_accounts() as $code => $label ) {
			$found = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE code = %s", $code ) );
			if ( ! $found ) {
				$missing[ $code ] = $label;
			}
		}
		return array(
			'ok'      => empty( $missing ),
			'missing' => $missing,
			'total'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
		);
	}

	/** Lookup data a screen is unusable without. */
	public static function check_lookups() {
		global $wpdb;
		$out = array();

		foreach ( array(
			'expense_categories' => __( 'Expense categories — Expenses cannot be saved without one', 'wc-enterprise-erp' ),
			'warehouses'         => __( 'Warehouses — stock cannot move without one', 'wc-enterprise-erp' ),
		) as $name => $why ) {
			$table = wceerp_table( $name );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
				$out[ $name ] = array( 'count' => null, 'why' => $why );
				continue;
			}
			$out[ $name ] = array(
				'count' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
				'why'   => $why,
			);
		}
		return $out;
	}

	/**
	 * Do the expense categories point at accounts that exist?
	 *
	 * This is the failure that produced "Unknown account in journal line":
	 * a category referencing a code the chart never received.
	 */
	public static function check_category_accounts() {
		global $wpdb;
		$cats = wceerp_table( 'expense_categories' );
		$acc  = wceerp_table( 'accounts' );

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $cats ) ) !== $cats ) {
			return array( 'ok' => true, 'broken' => array() );
		}

		$broken = (array) $wpdb->get_results(
			"SELECT c.name, c.account_code
			 FROM {$cats} c
			 LEFT JOIN {$acc} a ON a.code = c.account_code
			 WHERE c.account_code <> '' AND a.id IS NULL"
		);
		return array( 'ok' => empty( $broken ), 'broken' => $broken );
	}

	/**
	 * Consignments whose collection was written by a courier sync rather
	 * than by a real payout.
	 *
	 * A genuine settlement always stamps payout_id. A row with money in
	 * collected_amount and no payout_id can only have come from the sync,
	 * which used to overwrite that column -- and which made the parcel look
	 * paid so its money could never be recorded.
	 */
	public static function check_phantom_collections() {
		global $wpdb;
		$t = wceerp_table( 'consignments' );

		$rows = (array) $wpdb->get_results(
			"SELECT id, doc_no, cod_amount, collected_amount, status
			 FROM {$t}
			 WHERE payout_id IS NULL AND collected_amount > 0.004
			 ORDER BY id"
		);
		$total = 0;
		foreach ( $rows as $r ) {
			$total += (float) $r->collected_amount;
		}
		return array( 'ok' => empty( $rows ), 'rows' => $rows, 'total' => $total );
	}

	/**
	 * Move those amounts to the courier-reported column and clear the
	 * settled one, so the money becomes claimable again.
	 *
	 * Never touches a consignment that has a payout behind it.
	 */
	public static function repair_phantom_collections() {
		global $wpdb;
		$t = wceerp_table( 'consignments' );

		$moved = $wpdb->query(
			"UPDATE {$t}
			 SET remote_collected = COALESCE(remote_collected, collected_amount),
			     remote_charge    = COALESCE(remote_charge, NULLIF(delivery_charge,0)),
			     collected_amount = 0,
			     delivery_charge  = 0,
			     status           = CASE WHEN status = 'paid' THEN 'delivered' ELSE status END
			 WHERE payout_id IS NULL AND collected_amount > 0.004"
		);
		if ( $moved && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'courier', 'repair_phantom_cod', 0, $moved . ' consignment(s) made claimable again' );
		}
		return (int) $moved;
	}

	/**
	 * Courier-reported charges that cannot be real.
	 *
	 * A short-lived bug derived the charge as "collected minus what the
	 * courier will remit" without checking that the second figure had been
	 * worked out yet. Where it was still zero the charge came out as the
	 * whole COD, which then pre-filled the payout form — and a charge equal
	 * to the parcel value would post straight into Delivery charges.
	 */
	public static function check_bad_charges() {
		global $wpdb;
		$t = wceerp_table( 'consignments' );

		$rows = (array) $wpdb->get_results(
			"SELECT id, doc_no, remote_collected, remote_charge
			 FROM {$t}
			 WHERE remote_charge IS NOT NULL
			   AND remote_collected IS NOT NULL
			   AND remote_charge > remote_collected * 0.5
			 ORDER BY id"
		);
		return array( 'ok' => empty( $rows ), 'rows' => $rows );
	}

	/** Blank them, so the payout form asks rather than suggests nonsense. */
	public static function repair_bad_charges() {
		global $wpdb;
		$t = wceerp_table( 'consignments' );

		$fixed = $wpdb->query(
			"UPDATE {$t} SET remote_charge = NULL
			 WHERE remote_charge IS NOT NULL
			   AND remote_collected IS NOT NULL
			   AND remote_charge > remote_collected * 0.5"
		);
		if ( $fixed && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'courier', 'repair_bad_charges', 0, $fixed . ' cleared' );
		}
		return (int) $fixed;
	}

	/**
	 * Payouts that settled no parcels.
	 *
	 * Created before the guards existed, usually by a form submitted twice.
	 * Each one posted money into the books against nothing, so the cash or
	 * bank balance is overstated by their total — worth finding, because it
	 * is real money that never arrived.
	 */
	public static function check_empty_payouts() {
		global $wpdb;
		$po = wceerp_table( 'courier_payouts' );
		$cn = wceerp_table( 'consignments' );

		$rows = (array) $wpdb->get_results(
			"SELECT p.id, p.doc_no, p.payout_date, p.courier, p.net_amount
			 FROM {$po} p
			 WHERE NOT EXISTS ( SELECT 1 FROM {$cn} c WHERE c.payout_id = p.id )
			 ORDER BY p.id DESC"
		);
		$total = 0;
		foreach ( $rows as $r ) {
			$total += (float) $r->net_amount;
		}
		return array( 'ok' => empty( $rows ), 'rows' => $rows, 'total' => $total );
	}

	/**
	 * Supplier returns that never reached a supplier.
	 *
	 * Adjustments made before the supplier picker existed posted to a
	 * general account with no party attached. The books balanced, so nothing
	 * looked wrong — but the supplier's own ledger never moved and what you
	 * owe them is still overstated by the value of goods you sent back.
	 *
	 * They cannot be repaired automatically: only you know which supplier
	 * each return went to. They are listed so you can reverse and re-enter
	 * them against the right one.
	 */
	public static function check_orphan_returns() {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );
		$a  = wceerp_table( 'accounts' );

		$rows = (array) $wpdb->get_results(
			"SELECT j.id, j.doc_no, j.journal_date, j.memo,
			        SUM( l.debit + l.credit ) AS amount
			 FROM {$j} j
			 INNER JOIN {$jl} l ON l.journal_id = j.id
			 INNER JOIN {$a} ac ON ac.id = l.account_id
			 WHERE j.status = 'posted'
			   AND j.ref_type = 'stock_adjustment'
			   AND ac.code IN ('2050','2000')
			   AND l.party_id IS NULL
			 GROUP BY j.id
			 ORDER BY j.journal_date DESC
			 LIMIT 100"
		);
		$total = 0;
		foreach ( $rows as $r ) {
			$total += (float) $r->amount;
		}
		return array( 'ok' => empty( $rows ), 'rows' => $rows, 'total' => $total );
	}

	/**
	 * Payouts whose charge was never spread across their parcels.
	 *
	 * A lump-sum or early import recorded one charge total and left every
	 * parcel at zero, so the per-parcel column had to fall back to whatever
	 * the courier reported — a different figure, which is how a payout
	 * showing 1,157.80 of charges sat above rows summing to 8,631.45.
	 *
	 * This is repairable without judgement: the payout knows its own total,
	 * and pro-rata by collected amount is the same rule used when settling.
	 */
	public static function check_unallocated_charges() {
		global $wpdb;
		$po = wceerp_table( 'courier_payouts' );
		$cn = wceerp_table( 'consignments' );

		$rows = (array) $wpdb->get_results(
			"SELECT p.id, p.doc_no, p.note, p.payout_date, p.charges,
			        COUNT(c.id) AS parcels,
			        COALESCE(SUM(c.delivery_charge),0) AS allocated
			 FROM {$po} p
			 INNER JOIN {$cn} c ON c.payout_id = p.id
			 WHERE p.charges > 0.004
			 GROUP BY p.id
			 HAVING ABS( allocated - p.charges ) > 0.5
			 ORDER BY p.id DESC"
		);
		return array( 'ok' => empty( $rows ), 'rows' => $rows );
	}

	/** Spread each payout's recorded charge across the parcels it settled. */
	public static function repair_unallocated_charges() {
		global $wpdb;
		$cn    = wceerp_table( 'consignments' );
		$check = self::check_unallocated_charges();
		$fixed = 0;

		foreach ( (array) $check['rows'] as $p ) {
			$parcels = (array) $wpdb->get_results( $wpdb->prepare(
				"SELECT id, collected_amount FROM {$cn} WHERE payout_id = %d ORDER BY id ASC",
				(int) $p->id
			) );
			if ( ! $parcels ) {
				continue;
			}

			$base = 0.0;
			foreach ( $parcels as $c ) {
				$base += (float) $c->collected_amount;
			}

			$total = round( (float) $p->charges, 2 );
			$left  = $total;
			$last  = count( $parcels ) - 1;

			foreach ( $parcels as $i => $c ) {
				if ( $base > 0.004 ) {
					$share = ( $i === $last )
						? $left
						: round( $total * ( (float) $c->collected_amount / $base ), 2 );
				} else {
					// Nothing collected: split evenly rather than skewing to one.
					$share = ( $i === $last ) ? $left : round( $total / count( $parcels ), 2 );
				}
				$left = round( $left - $share, 2 );
				$wpdb->update( $cn, array( 'delivery_charge' => $share ), array( 'id' => (int) $c->id ) );
			}
			$fixed++;
		}

		if ( $fixed && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'courier', 'repair_charge_allocation', 0, $fixed . ' payouts' );
		}
		return $fixed;
	}

	/**
	 * Payments credited to a receivable that was never raised.
	 *
	 * The dues screen used to take a payment against a party without
	 * checking whether anything was owed, so money could be credited to a
	 * receivable with no matching debit. The books still balanced — cash
	 * went up, the receivable went down — but the customer now "owes"
	 * a negative amount, which is not a thing.
	 *
	 * Listed rather than repaired automatically, because only the shop
	 * knows which is true: the payment was recorded twice and should be
	 * voided, or the sale behind it never posted and should be created.
	 * Guessing between those would be inventing revenue.
	 */
	public static function check_floating_credits() {
		global $wpdb;

		$ar = WCEERP_Accounting::account_by_subtype( 'receivable' );
		if ( ! $ar ) {
			return array( 'ok' => true, 'rows' => array(), 'total' => 0 );
		}

		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );

		/* Group by party: a single party in credit is the symptom, and the
		 * individual entries under it are what needs looking at. */
		$rows = (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT l.party_type, l.party_id,
			        SUM( l.debit - l.credit ) AS balance,
			        COUNT(*) AS entries
			 FROM {$jl} l
			 INNER JOIN {$j} j ON j.id = l.journal_id
			 WHERE j.status = 'posted'
			   AND l.account_id = %d
			   AND l.party_type IS NOT NULL
			 GROUP BY l.party_type, l.party_id
			 HAVING balance < -0.005
			 ORDER BY balance ASC",
			$ar->id
		) );

		$total = 0;
		foreach ( $rows as $r ) {
			$total += (float) $r->balance;
		}

		return array( 'ok' => empty( $rows ), 'rows' => $rows, 'total' => $total, 'account' => (int) $ar->id );
	}

	public static function check_cron() {
		$hooks = array(
			'wceerp_courier_sync'  => __( 'Courier status polling', 'wc-enterprise-erp' ),
			'wceerp_daily_checks'  => __( 'Daily checks', 'wc-enterprise-erp' ),
		);
		$out = array();
		foreach ( $hooks as $hook => $label ) {
			$out[ $hook ] = array(
				'label' => $label,
				'next'  => wp_next_scheduled( $hook ),
			);
		}
		$out['_disabled'] = ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );
		return $out;
	}

	/**
	 * Prove the ledger can actually accept a posting.
	 *
	 * Posts a zero-effect balanced journal and voids it immediately. This is
	 * the only check that exercises the real path an expense or sale takes,
	 * which is exactly where a silent database problem shows up.
	 */
	public static function check_write() {
		global $wpdb;

		$cash = WCEERP_Accounting::resolve_account( '1000' );
		$misc = WCEERP_Accounting::resolve_account( '5900' ) ?: WCEERP_Accounting::resolve_account( '5000' );
		if ( ! $cash || ! $misc ) {
			return array( 'ok' => false, 'message' => __( 'Cannot run — required accounts are missing.', 'wc-enterprise-erp' ) );
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => current_time( 'Y-m-d' ),
				'ref_type'     => 'health_check',
				'memo'         => 'System health self-test',
			),
			array(
				array( 'account' => $misc, 'debit' => 1, 'memo' => 'self-test' ),
				array( 'account' => $cash, 'credit' => 1, 'memo' => 'self-test' ),
			)
		);

		if ( is_wp_error( $journal ) ) {
			return array( 'ok' => false, 'message' => $journal->get_error_message() );
		}

		// Remove it completely — a self-test must not leave a mark on the books.
		$wpdb->delete( wceerp_table( 'journal_lines' ), array( 'journal_id' => (int) $journal ) );
		$wpdb->delete( wceerp_table( 'journals' ), array( 'id' => (int) $journal ) );

		return array( 'ok' => true, 'message' => __( 'The ledger accepted and released a test posting.', 'wc-enterprise-erp' ) );
	}

	/** Repair what can safely be repaired. */
	public static function repair() {
		$done = array();

		if ( class_exists( 'WCEERP_Installer' ) ) {
			WCEERP_Installer::activate();
			$done[] = __( 'Re-ran the installer: tables, accounts and default categories.', 'wc-enterprise-erp' );
		}

		$spread = self::repair_unallocated_charges();
		if ( $spread ) {
			$done[] = sprintf(
				/* translators: %d: payouts. */
				__( 'Spread the recorded charge across the parcels of %d payout(s), so the per-parcel column now agrees with the payout total.', 'wc-enterprise-erp' ),
				$spread
			);
		}

		$cleared = self::repair_bad_charges();
		if ( $cleared ) {
			$done[] = sprintf(
				/* translators: %d: consignments. */
				__( 'Cleared an impossible courier charge on %d parcel(s) — the figure was the whole COD, not a fee.', 'wc-enterprise-erp' ),
				$cleared
			);
		}

		$freed = self::repair_phantom_collections();
		if ( $freed ) {
			$done[] = sprintf(
				/* translators: %d: number of consignments. */
				_n(
					'Made %d parcel claimable again — its COD had been marked collected by a courier sync rather than by a payout.',
					'Made %d parcels claimable again — their COD had been marked collected by a courier sync rather than by a payout.',
					$freed,
					'wc-enterprise-erp'
				),
				$freed
			);
		}

		wceerp_log( 'settings', 'health_repair', 0 );
		return $done;
	}

	/* ------------------------------------------------------------------
	 * Screen
	 * ---------------------------------------------------------------- */

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$r = self::run();
		?>
		<hr>
		<h2><?php esc_html_e( 'System health', 'wc-enterprise-erp' ); ?></h2>
		<p class="description" style="max-width:760px">
			<?php esc_html_e( 'Checks the things that break an install quietly — a table that never got created, an account a module depends on, or lookup data that was never seeded. If a screen "does nothing when I save", start here.', 'wc-enterprise-erp' ); ?>
		</p>

		<?php if ( isset( $_GET['repaired'] ) ) : ?>
			<div class="notice notice-success"><p><?php esc_html_e( 'Repair finished. Re-check the results below.', 'wc-enterprise-erp' ); ?></p></div>
		<?php endif; ?>

		<table class="widefat striped" style="max-width:860px">
			<tbody>
				<!-- Tables -->
				<tr>
					<td style="width:150px"><strong><?php esc_html_e( 'Database tables', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['tables']['ok'] ) : ?>
							<span style="color:#00652b">&#10003;</span>
							<?php printf( esc_html__( 'All %d tables present.', 'wc-enterprise-erp' ), (int) $r['tables']['expected'] ); ?>
						<?php else : ?>
							<span style="color:#b32d2e">&#10007;</span>
							<strong><?php printf( esc_html__( '%d missing:', 'wc-enterprise-erp' ), count( $r['tables']['missing'] ) ); ?></strong>
							<code><?php echo esc_html( implode( ', ', $r['tables']['missing'] ) ); ?></code>
							<br><small><?php esc_html_e( 'Press Repair below. If they stay missing, the database user probably lacks CREATE permission.', 'wc-enterprise-erp' ); ?></small>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Accounts -->
				<tr>
					<td><strong><?php esc_html_e( 'Chart of accounts', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['accounts']['ok'] ) : ?>
							<span style="color:#00652b">&#10003;</span>
							<?php printf( esc_html__( '%d accounts, all required codes present.', 'wc-enterprise-erp' ), (int) $r['accounts']['total'] ); ?>
						<?php else : ?>
							<span style="color:#b32d2e">&#10007;</span>
							<strong><?php esc_html_e( 'Missing accounts:', 'wc-enterprise-erp' ); ?></strong>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( $r['accounts']['missing'] as $code => $label ) : ?>
									<li><code><?php echo esc_html( $code ); ?></code> — <?php echo esc_html( $label ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Lookups -->
				<tr>
					<td><strong><?php esc_html_e( 'Required data', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php foreach ( $r['lookups'] as $name => $info ) : ?>
							<?php $bad = ( null === $info['count'] || $info['count'] < 1 ); ?>
							<div style="margin-bottom:4px">
								<span style="color:<?php echo $bad ? '#b32d2e' : '#00652b'; ?>"><?php echo $bad ? '&#10007;' : '&#10003;'; ?></span>
								<code><?php echo esc_html( $name ); ?></code>:
								<?php
								echo null === $info['count']
									? esc_html__( 'table missing', 'wc-enterprise-erp' )
									: esc_html( sprintf( _n( '%d row', '%d rows', (int) $info['count'], 'wc-enterprise-erp' ), (int) $info['count'] ) );
								?>
								<?php if ( $bad ) : ?>
									<br><small style="color:#b32d2e"><?php echo esc_html( $info['why'] ); ?></small>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</td>
				</tr>

				<!-- Receivables in credit -->
				<tr>
					<td><strong><?php esc_html_e( 'Customer balances', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['credits']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'No account is in credit.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#C0392B">&#10007;</span>
							<strong><?php
								printf(
									/* translators: 1: count, 2: amount. */
									esc_html__( '%1$d account(s) are in credit by %2$s in total.', 'wc-enterprise-erp' ),
									count( $r['credits']['rows'] ),
									wp_kses_post( wceerp_money( abs( $r['credits']['total'] ) ) )
								);
							?></strong>
							<p class="description">
								<?php esc_html_e( 'More has been credited to the receivable than was ever charged to it. Either a payment was recorded twice, or the sale behind it never posted to the ledger. This cannot be repaired automatically — choosing wrongly between those two would invent revenue.', 'wc-enterprise-erp' ); ?>
							</p>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( array_slice( $r['credits']['rows'], 0, 20 ) as $cr ) : ?>
									<li>
										<?php echo esc_html( ucfirst( $cr->party_type ) ); ?> #<?php echo (int) $cr->party_id; ?>
										— <?php echo wp_kses_post( wceerp_money( abs( $cr->balance ) ) ); ?>
										<span class="wceerp-sub"><?php
											printf(
												/* translators: %d: entries. */
												esc_html__( '%d entries', 'wc-enterprise-erp' ),
												(int) $cr->entries
											);
										?></span>
									</li>
								<?php endforeach; ?>
							</ul>
							<p class="description">
								<?php
								printf(
									/* translators: %s: ledger link. */
									esc_html__( 'Open %s, find the credits with no matching sale, and void them — the reason you give stays with each one.', 'wc-enterprise-erp' ),
									'<a href="' . esc_url( admin_url( 'admin.php?page=wceerp-accounting&tab=ledger&account=' . (int) $r['credits']['account'] ) ) . '">' . esc_html__( 'the receivable ledger', 'wc-enterprise-erp' ) . '</a>'
								);
								?>
							</p>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Supplier returns with no supplier -->
				<tr>
					<td><strong><?php esc_html_e( 'Supplier returns', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['orphanret']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'Every supplier return names its supplier.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#C0392B">&#10007;</span>
							<strong><?php
								printf(
									/* translators: 1: count, 2: amount. */
									esc_html__( '%1$d return(s) worth %2$s were posted without naming a supplier.', 'wc-enterprise-erp' ),
									count( $r['orphanret']['rows'] ),
									wp_kses_post( wceerp_money( $r['orphanret']['total'] ) )
								);
							?></strong>
							<p class="description">
								<?php esc_html_e( 'Made before the supplier picker existed. The books balance, but the supplier ledger never moved — so what you owe them is still overstated by the value of the goods you sent back, and their Due column reads zero.', 'wc-enterprise-erp' ); ?>
							</p>
							<p class="description">
								<?php esc_html_e( 'These cannot be corrected automatically, because only you know which supplier each one went to. Void each journal below, then redo the adjustment choosing the supplier.', 'wc-enterprise-erp' ); ?>
							</p>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( array_slice( $r['orphanret']['rows'], 0, 20 ) as $orow ) : ?>
									<li>
										<code><?php echo esc_html( $orow->doc_no ); ?></code>
										<?php echo esc_html( $orow->journal_date ); ?> ·
										<?php echo wp_kses_post( wceerp_money( $orow->amount ) ); ?>
										<?php if ( $orow->memo ) : ?>
											<span class="wceerp-sub"><?php echo esc_html( $orow->memo ); ?></span>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Payout charges not spread across parcels -->
				<tr>
					<td><strong><?php esc_html_e( 'Charge allocation', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['unalloc']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'Every payout charge is spread across the parcels it settled.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#B7791F">!</span>
							<strong><?php
								printf(
									/* translators: %d: payouts. */
									esc_html__( '%d payout(s) recorded a charge that was never split across their parcels.', 'wc-enterprise-erp' ),
									count( $r['unalloc']['rows'] )
								);
							?></strong>
							<p class="description">
								<?php esc_html_e( 'The per-parcel column then falls back to whatever the courier reported, which is a different figure — so the rows appear to disagree with the payout above them. Repair spreads each payout total across its own parcels, pro-rata by what was collected.', 'wc-enterprise-erp' ); ?>
							</p>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( array_slice( $r['unalloc']['rows'], 0, 20 ) as $ua ) : ?>
									<li>
										<code><?php echo esc_html( $ua->doc_no ); ?></code>
										<?php echo esc_html( $ua->payout_date ); ?>
										<?php echo $ua->note ? ' · ' . esc_html( $ua->note ) : ''; ?> ·
										<?php
										printf(
											/* translators: 1: recorded, 2: allocated, 3: parcels. */
											esc_html__( 'recorded %1$s, allocated %2$s across %3$d parcels', 'wc-enterprise-erp' ),
											wp_kses_post( wceerp_money( $ua->charges ) ),
											wp_kses_post( wceerp_money( $ua->allocated ) ),
											(int) $ua->parcels
										);
										?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Payouts settling nothing -->
				<tr>
					<td><strong><?php esc_html_e( 'Courier payouts', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['emptypay']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'Every payout settled at least one parcel.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#C0392B">&#10007;</span>
							<strong><?php
								printf(
									/* translators: 1: count, 2: amount. */
									esc_html__( '%1$d payout(s) worth %2$s settled no parcels at all.', 'wc-enterprise-erp' ),
									count( $r['emptypay']['rows'] ),
									wp_kses_post( wceerp_money( $r['emptypay']['total'] ) )
								);
							?></strong>
							<p class="description">
								<?php esc_html_e( 'Almost always the same payment recorded twice — a form submitted again before the first finished. Each one put money into your books against nothing, so your cash or bank balance is overstated by that total.', 'wc-enterprise-erp' ); ?>
							</p>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( array_slice( $r['emptypay']['rows'], 0, 20 ) as $ep ) : ?>
									<li>
										<code><?php echo esc_html( $ep->doc_no ); ?></code>
										<?php echo esc_html( $ep->payout_date ); ?> ·
										<?php echo esc_html( ucfirst( $ep->courier ) ); ?> ·
										<?php echo wp_kses_post( wceerp_money( $ep->net_amount ) ); ?>
									</li>
								<?php endforeach; ?>
							</ul>
							<p class="description">
								<?php
								printf(
									/* translators: %s: link. */
									esc_html__( 'Reverse them from %s — that voids the journal and takes the money back out.', 'wc-enterprise-erp' ),
									'<a href="' . esc_url( admin_url( 'admin.php?page=wceerp-courier&tab=payouts' ) ) . '">' . esc_html__( 'COD payouts', 'wc-enterprise-erp' ) . '</a>'
								);
								?>
							</p>
						<?php endif; ?>
					</td>
				</tr>

				<!-- COD written by sync rather than by a payout -->
				<tr>
					<td><strong><?php esc_html_e( 'Courier COD', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['phantom']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'Every settled parcel has a payout behind it.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#C0392B">&#10007;</span>
							<strong><?php
								printf(
									/* translators: 1: number of parcels, 2: amount. */
									esc_html__( '%1$d parcel(s) holding %2$s are marked collected but have no payout behind them.', 'wc-enterprise-erp' ),
									count( $r['phantom']['rows'] ),
									wp_kses_post( wceerp_money( $r['phantom']['total'] ) )
								);
							?></strong>
							<p class="description">
								<?php esc_html_e( 'A courier sync wrote what the courier collected from your customer into the column that means "paid to you". Those parcels look settled, so their money cannot be recorded and never reaches your cash book. Repair moves the figures to the courier-reported column and makes the parcels claimable again on the COD payouts tab.', 'wc-enterprise-erp' ); ?>
							</p>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Category accounts -->
				<tr>
					<td><strong><?php esc_html_e( 'Expense categories', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( $r['categories']['ok'] ) : ?>
							<span style="color:#0F7B5A">&#10003;</span>
							<?php esc_html_e( 'Every category points at an account that exists.', 'wc-enterprise-erp' ); ?>
						<?php else : ?>
							<span style="color:#C0392B">&#10007;</span>
							<strong><?php esc_html_e( 'These categories point at accounts that are missing, so saving an expense in them fails:', 'wc-enterprise-erp' ); ?></strong>
							<ul style="margin:6px 0 0 18px;list-style:disc">
								<?php foreach ( $r['categories']['broken'] as $b ) : ?>
									<li><?php echo esc_html( $b->name ); ?> &rarr; <code><?php echo esc_html( $b->account_code ); ?></code></li>
								<?php endforeach; ?>
							</ul>
							<small><?php esc_html_e( 'Press Repair below — it restores any missing account without touching your own.', 'wc-enterprise-erp' ); ?></small>
						<?php endif; ?>
					</td>
				</tr>

				<!-- Ledger write test -->
				<tr>
					<td><strong><?php esc_html_e( 'Ledger write test', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<span style="color:<?php echo $r['writes']['ok'] ? '#00652b' : '#b32d2e'; ?>"><?php echo $r['writes']['ok'] ? '&#10003;' : '&#10007;'; ?></span>
						<?php echo esc_html( $r['writes']['message'] ); ?>
					</td>
				</tr>

				<!-- Cron -->
				<tr>
					<td><strong><?php esc_html_e( 'Scheduled tasks', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php if ( ! empty( $r['cron']['_disabled'] ) ) : ?>
							<span style="color:#996800">&#9888;</span>
							<?php esc_html_e( 'WP-Cron is disabled in wp-config. Courier status will not update unless a real cron job runs wp-cron.php.', 'wc-enterprise-erp' ); ?><br>
						<?php endif; ?>
						<?php foreach ( $r['cron'] as $hook => $info ) : ?>
							<?php if ( '_disabled' === $hook ) { continue; } ?>
							<div>
								<span style="color:<?php echo $info['next'] ? '#00652b' : '#996800'; ?>"><?php echo $info['next'] ? '&#10003;' : '&#9888;'; ?></span>
								<?php echo esc_html( $info['label'] ); ?>:
								<?php echo $info['next'] ? esc_html( gmdate( 'Y-m-d H:i', $info['next'] ) ) : esc_html__( 'not scheduled', 'wc-enterprise-erp' ); ?>
							</div>
						<?php endforeach; ?>
					</td>
				</tr>

				<!-- Versions -->
				<tr>
					<td><strong><?php esc_html_e( 'Versions', 'wc-enterprise-erp' ); ?></strong></td>
					<td>
						<?php
						printf(
							'ERP %s &nbsp;·&nbsp; DB %s &nbsp;·&nbsp; WP %s &nbsp;·&nbsp; PHP %s &nbsp;·&nbsp; WooCommerce %s',
							esc_html( WCEERP_VERSION ),
							esc_html( get_option( 'wceerp_version', '—' ) ),
							esc_html( get_bloginfo( 'version' ) ),
							esc_html( PHP_VERSION ),
							esc_html( defined( 'WC_VERSION' ) ? WC_VERSION : '—' )
						);
						?>
						<?php if ( get_option( 'wceerp_version' ) !== WCEERP_VERSION ) : ?>
							<br><small style="color:#b32d2e"><?php esc_html_e( 'The database is behind the plugin. Press Repair.', 'wc-enterprise-erp' ); ?></small>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px">
			<?php wp_nonce_field( 'wceerp_health_repair' ); ?>
			<input type="hidden" name="action" value="wceerp_health_repair">
			<button class="button button-primary"><?php esc_html_e( 'Repair', 'wc-enterprise-erp' ); ?></button>
			<span class="description"><?php esc_html_e( 'Re-runs the installer. Safe to press at any time — it only creates what is missing and never deletes or overwrites your data.', 'wc-enterprise-erp' ); ?></span>
		</form>
		<?php
	}
}
