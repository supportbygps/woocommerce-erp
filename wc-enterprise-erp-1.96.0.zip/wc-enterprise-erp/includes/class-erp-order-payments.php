<?php
/**
 * Order payments.
 *
 * Money received against an order that does NOT come through the courier:
 * advances taken before dispatch, part payments, and balances collected
 * after delivery.
 *
 * The accounting model is deliberately plain double entry:
 *
 *   Sale posts    Dr 1110 Courier COD (the courier's collectible)
 *                 Dr 1100 A/R        (everything else still owed)
 *                 Cr 4000 Sales, Cr 2100 VAT
 *
 *   A receipt     Dr cash/bank/bKash
 *                 Cr 1100 A/R  (against the customer or dealer)
 *
 *   A payout      Dr bank + Dr 5600 charges / Cr 1110
 *
 * An advance recorded before the sale posts simply puts the customer's A/R
 * temporarily in credit; the sale then debits it and the two net off. That
 * is why no special ordering logic is needed.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Order_Payments {

	/** Payment methods offered in the UI, mapped to account codes. */
	public static function methods() {
		return apply_filters( 'wceerp_payment_methods', array(
			'cash'   => array( 'label' => __( 'Cash', 'wc-enterprise-erp' ), 'account' => '1000' ),
			'bkash'  => array( 'label' => 'bKash', 'account' => '1020' ),
			'nagad'  => array( 'label' => 'Nagad', 'account' => '1021' ),
			'bank'   => array( 'label' => __( 'Bank transfer', 'wc-enterprise-erp' ), 'account' => '1010' ),
			'card'   => array( 'label' => __( 'Card', 'wc-enterprise-erp' ), 'account' => '1010' ),
			'other'  => array( 'label' => __( 'Other', 'wc-enterprise-erp' ), 'account' => '1000' ),
		) );
	}

	/** Total received against an order, excluding courier remittances. */
	public static function paid( $order_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(amount),0) FROM ' . wceerp_table( 'order_payments' ) . ' WHERE order_id = %d',
			(int) $order_id
		) );
	}

	/** Every receipt against an order, newest first. */
	public static function receipts( $order_id ) {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'order_payments' ) . ' WHERE order_id = %d ORDER BY paid_on DESC, id DESC',
			(int) $order_id
		) );
	}

	/** COD amount still sitting with a courier for this order. */
	public static function cod_outstanding( $order_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(cod_amount - collected_amount),0) FROM ' . wceerp_table( 'consignments' ) . "
			 WHERE order_id = %d AND order_source = 'local' AND status NOT IN ('cancelled','returned')",
			(int) $order_id
		) );
	}

	/** COD already collected by couriers for this order. */
	public static function cod_collected( $order_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(collected_amount),0) FROM ' . wceerp_table( 'consignments' ) . "
			 WHERE order_id = %d AND order_source = 'local'",
			(int) $order_id
		) );
	}

	/**
	 * The full payment picture for an order.
	 *
	 * @return array{total:float,paid:float,cod_pending:float,cod_collected:float,due:float}
	 */
	public static function picture( $order ) {
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( (int) $order );
		}
		if ( ! $order ) {
			return array( 'total' => 0.0, 'paid' => 0.0, 'cod_pending' => 0.0, 'cod_collected' => 0.0, 'due' => 0.0 );
		}
		$id            = $order->get_id();
		$total         = wceerp_dec( $order->get_total() );
		$paid          = self::paid( $id );
		$cod_pending   = self::cod_outstanding( $id );
		$cod_collected = self::cod_collected( $id );

		return array(
			'total'         => $total,
			'paid'          => $paid,
			'cod_pending'   => $cod_pending,
			'cod_collected' => $cod_collected,
			// What the customer still owes once couriers have remitted.
			'due'           => max( 0, round( $total - $paid - $cod_pending - $cod_collected, 2 ) ),
		);
	}

	/**
	 * Record a receipt and post it.
	 *
	 * @param array $args order_id, amount, method, paid_on, note, kind.
	 * @return int|WP_Error Payment row id.
	 */
	public static function add( $args ) {
		global $wpdb;

		$order_id = (int) ( $args['order_id'] ?? 0 );
		$amount   = wceerp_dec( $args['amount'] ?? 0 );
		$method   = sanitize_key( $args['method'] ?? 'cash' );
		$kind     = sanitize_key( $args['kind'] ?? 'advance' );
		$note     = sanitize_text_field( $args['note'] ?? '' );
		$paid_on  = (string) ( $args['paid_on'] ?? '' );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $paid_on ) ) {
			$paid_on = current_time( 'Y-m-d' );
		}
		if ( $amount <= 0 ) {
			return new WP_Error( 'wceerp_payment', __( 'Enter an amount greater than zero.', 'wc-enterprise-erp' ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_Error( 'wceerp_payment', __( 'Order not found.', 'wc-enterprise-erp' ) );
		}
		if ( function_exists( 'wceerp_is_pre_golive' ) && wceerp_is_pre_golive( $order ) ) {
			return new WP_Error( 'wceerp_payment', __( 'This order predates your books start date, so it has no receivable to settle. Use the Opening COD screen instead.', 'wc-enterprise-erp' ) );
		}

		$methods = self::methods();
		$code    = isset( $methods[ $method ] ) ? $methods[ $method ]['account'] : '1000';
		$code    = sanitize_text_field( $args['account_code'] ?? $code );

		// Never let recorded receipts exceed what the customer actually owes.
		$pic = self::picture( $order );
		if ( $amount > $pic['due'] + $pic['cod_pending'] + 0.004 ) {
			return new WP_Error( 'wceerp_payment', sprintf(
				/* translators: %s: outstanding amount. */
				__( 'That is more than this order still has outstanding (%s).', 'wc-enterprise-erp' ),
				wp_strip_all_tags( wceerp_money( $pic['due'] + $pic['cod_pending'] ) )
			) );
		}

		/* Credit the customer's receivable. Dealers carry their balance on
		 * their own party ledger so statements and credit limits work. */
		$party = array( 'party_type' => 'customer', 'party_id' => (int) $order->get_customer_id() );
		if ( class_exists( 'WCEERP_Module_Dealers' ) && $order->get_customer_id() ) {
			$dealer = WCEERP_Module_Dealers::by_user( (int) $order->get_customer_id() );
			if ( $dealer ) {
				$party = array( 'party_type' => 'dealer', 'party_id' => (int) $dealer->id );
			}
		}

		$ar = WCEERP_Accounting::account_by_subtype( 'receivable' );
		if ( ! $ar ) {
			return new WP_Error( 'wceerp_payment', __( 'No receivable account is configured.', 'wc-enterprise-erp' ) );
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $paid_on,
				'ref_type'     => 'order_payment',
				'ref_id'       => $order_id,
				'memo'         => sprintf( __( 'Payment received — order #%d', 'wc-enterprise-erp' ), $order_id ),
			),
			array(
				array( 'account' => $code, 'debit' => $amount, 'memo' => sprintf( __( 'Received via %s', 'wc-enterprise-erp' ), $method ) ),
				array_merge(
					array( 'account' => $ar->id, 'credit' => $amount, 'memo' => sprintf( __( 'Order #%d settled', 'wc-enterprise-erp' ), $order_id ) ),
					$party
				),
			)
		);
		if ( is_wp_error( $journal ) ) {
			return $journal;
		}

		$wpdb->insert( wceerp_table( 'order_payments' ), array(
			'order_id'     => $order_id,
			'order_source' => 'local',
			'amount'       => $amount,
			'method'       => $method,
			'account_code' => $code,
			'kind'         => $kind,
			'paid_on'      => $paid_on,
			'journal_id'   => (int) $journal,
			'note'         => $note,
			'created_by'   => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
		) );

		$id = (int) $wpdb->insert_id;
		$order->add_order_note( sprintf(
			/* translators: 1: amount, 2: method. */
			__( 'ERP: payment of %1$s recorded via %2$s.', 'wc-enterprise-erp' ),
			wp_strip_all_tags( wceerp_money( $amount ) ),
			$method
		) );
		wceerp_log( 'payments', 'received', $id, '#' . $order_id . ' ' . $amount . ' ' . $method );

		return $id;
	}
}
