<?php
/**
 * Double-entry accounting engine.
 *
 * Every financial event in the ERP (purchase received, sale completed,
 * payment in/out, production, manual journal) becomes a balanced journal
 * with debit/credit lines. All financial reports (ledger, cash book,
 * bank book, trial balance, P&L, balance sheet, dues) are derived from
 * these lines — there is one source of truth.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Accounting {

	/**
	 * Post a balanced journal.
	 *
	 * @param array $args  { journal_date, ref_type, ref_id, memo }
	 * @param array $lines Each: { account (code or id), debit, credit, party_type, party_id, memo }
	 * @return int|WP_Error Journal ID.
	 */
	public static function post( $args, $lines ) {
		global $wpdb;

		$debit  = 0;
		$credit = 0;
		$clean  = array();

		foreach ( $lines as $line ) {
			$account_id = self::resolve_account( isset( $line['account'] ) ? $line['account'] : 0 );
			if ( ! $account_id ) {
				/* Naming the account turns a mystery into something the
				 * shop can act on — usually a missing chart entry, which
				 * System health → Repair restores. */
				return new WP_Error(
					'wceerp_journal',
					sprintf(
						/* translators: %s: account code. */
						__( 'Account "%s" does not exist in your chart of accounts. Run ERP → Modules & Settings → System health → Repair to restore missing accounts.', 'wc-enterprise-erp' ),
						esc_html( (string) ( $line['account'] ?? '?' ) )
					)
				);
			}
			$d = wceerp_dec( isset( $line['debit'] ) ? $line['debit'] : 0 );
			$c = wceerp_dec( isset( $line['credit'] ) ? $line['credit'] : 0 );
			if ( $d <= 0 && $c <= 0 ) {
				continue;
			}
			$debit  += $d;
			$credit += $c;
			$clean[] = array(
				'account_id' => $account_id,
				'debit'      => $d,
				'credit'     => $c,
				'party_type' => isset( $line['party_type'] ) ? sanitize_key( $line['party_type'] ) : null,
				'party_id'   => isset( $line['party_id'] ) ? (int) $line['party_id'] : null,
				'memo'       => isset( $line['memo'] ) ? sanitize_text_field( $line['memo'] ) : null,
			);
		}

		if ( count( $clean ) < 2 ) {
			return new WP_Error( 'wceerp_journal', __( 'A journal needs at least two lines.', 'wc-enterprise-erp' ) );
		}
		if ( round( $debit, 2 ) !== round( $credit, 2 ) ) {
			return new WP_Error(
				'wceerp_journal',
				sprintf(
					/* translators: 1: debit total 2: credit total */
					__( 'Journal is not balanced (Dr %1$s ≠ Cr %2$s).', 'wc-enterprise-erp' ),
					$debit,
					$credit
				)
			);
		}

		$wpdb->insert( wceerp_table( 'journals' ), array(
			'doc_no'       => wceerp_next_doc_number( 'jv' ),
			'journal_date' => isset( $args['journal_date'] ) ? sanitize_text_field( $args['journal_date'] ) : current_time( 'Y-m-d' ),
			'branch_id'    => isset( $args['branch_id'] ) ? max( 1, (int) $args['branch_id'] ) : 1,
			'ref_type'     => isset( $args['ref_type'] ) ? sanitize_key( $args['ref_type'] ) : 'manual',
			'ref_id'       => isset( $args['ref_id'] ) ? (int) $args['ref_id'] : 0,
			'memo'         => isset( $args['memo'] ) ? sanitize_text_field( $args['memo'] ) : '',
			'status'       => 'posted',
			'created_by'   => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
		) );
		$journal_id = (int) $wpdb->insert_id;

		foreach ( $clean as $line ) {
			$line['journal_id'] = $journal_id;
			$wpdb->insert( wceerp_table( 'journal_lines' ), $line );
		}

		do_action( 'wceerp_journal_posted', $journal_id, $args, $clean );
		return $journal_id;
	}

	/**
	 * Void a journal by hand.
	 *
	 * Kept for the audit trail and excluded from every report — the row
	 * never disappears, it is marked. That is what makes a correction
	 * itself auditable, rather than a second silent edit to the books.
	 *
	 * This has always existed, called internally by payout reversal and
	 * expense deletion, but nothing in the accounting screen ever called
	 * it — there was no way to void a journal by hand at all. A shop with
	 * a genuine mis-posting had no route to fix it except a correcting
	 * entry stacked on top, which works but leaves the wrong line sitting
	 * there for ever, uncorrected, only offset.
	 *
	 * @param int    $journal_id
	 * @param string $reason      Required. A void with no reason is a
	 *                            mystery the day someone next opens this
	 *                            ledger — the one thing worth insisting on.
	 * @return true|WP_Error
	 */
	public static function void( $journal_id, $reason = '' ) {
		global $wpdb;
		$journal_id = (int) $journal_id;

		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT id, status, doc_no FROM ' . wceerp_table( 'journals' ) . ' WHERE id = %d',
			$journal_id
		) );
		if ( ! $row ) {
			return new WP_Error( 'wceerp_not_found', __( 'That journal does not exist.', 'wc-enterprise-erp' ) );
		}
		if ( 'void' === $row->status ) {
			// Already gone. Not an error — the end state is what was asked for.
			return true;
		}
		if ( '' === trim( (string) $reason ) ) {
			return new WP_Error( 'wceerp_reason_required', __( 'A reason is required to void a journal.', 'wc-enterprise-erp' ) );
		}

		$wpdb->update(
			wceerp_table( 'journals' ),
			array( 'status' => 'void' ),
			array( 'id' => $journal_id )
		);

		wceerp_log( 'accounting', 'void_journal', $journal_id, $row->doc_no . ' — ' . sanitize_text_field( $reason ) );

		return true;
	}

	/** Accept an account id, code, or system subtype and return its id. */
	/**
	 * Accept an account id, code, or system subtype and return its id.
	 *
	 * The code is tried FIRST, and this ordering is the whole point.
	 * Account codes are numeric strings — '1000', '5200' — so an
	 * is_numeric() test passes and the old version looked up account *id*
	 * 1000, which never exists. Every posting that referred to an account
	 * by code therefore failed with "Unknown account in journal line",
	 * which is why expenses could not be saved at all.
	 *
	 * A numeric id is still accepted, but only once no account carries
	 * that value as its code.
	 */
	public static function resolve_account( $account ) {
		global $wpdb;
		$table = wceerp_table( 'accounts' );

		$account = is_string( $account ) ? trim( $account ) : $account;
		if ( '' === $account || null === $account ) {
			return 0;
		}

		// Code first — this is how almost every caller refers to accounts.
		$by_code = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE code = %s",
			(string) $account
		) );
		if ( $by_code ) {
			return $by_code;
		}

		// Then a genuine row id.
		if ( is_numeric( $account ) && (int) $account > 0 ) {
			$by_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$table} WHERE id = %d",
				(int) $account
			) );
			if ( $by_id ) {
				return $by_id;
			}
		}

		// Finally a system subtype, e.g. 'receivable' or 'sales'.
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE subtype = %s ORDER BY id LIMIT 1",
			sanitize_key( (string) $account )
		) );
	}

	public static function account_by_subtype( $subtype ) {
		global $wpdb;
		$table = wceerp_table( 'accounts' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE subtype = %s AND status='active' ORDER BY id ASC LIMIT 1", $subtype ) );
	}

	public static function accounts( $type = '' ) {
		global $wpdb;
		$table = wceerp_table( 'accounts' );
		if ( $type ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE type = %s AND status='active' ORDER BY code", $type ) );
		}
		return $wpdb->get_results( "SELECT * FROM $table WHERE status='active' ORDER BY code" );
	}

	/**
	 * Ledger rows for one account within a date range, with running balance.
	 */
	public static function ledger( $account_id, $from, $to, $party_type = '', $party_id = 0 ) {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );

		$where  = 'l.account_id = %d AND j.status = "posted" AND j.journal_date BETWEEN %s AND %s';
		$params = array( (int) $account_id, $from, $to );

		if ( $party_type ) {
			$where   .= ' AND l.party_type = %s AND l.party_id = %d';
			$params[] = $party_type;
			$params[] = (int) $party_id;
		}

		/* j.id travels with every row now — voiding a journal from the
		 * ledger screen needs it, and there was previously no way to reach
		 * it from here at all. */
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT j.id AS journal_id, j.doc_no, j.journal_date, j.ref_type, j.ref_id, j.memo AS jmemo,
			        l.debit, l.credit, l.memo
			 FROM $jl l INNER JOIN $j j ON j.id = l.journal_id
			 WHERE $where
			 ORDER BY j.journal_date ASC, j.id ASC, l.id ASC",
			$params
		) );
	}

	/** Opening balance of an account before a given date (Dr − Cr). */
	public static function opening_balance( $account_id, $before_date, $party_type = '', $party_id = 0 ) {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );

		$where  = 'l.account_id = %d AND j.status = "posted" AND j.journal_date < %s';
		$params = array( (int) $account_id, $before_date );
		if ( $party_type ) {
			$where   .= ' AND l.party_type = %s AND l.party_id = %d';
			$params[] = $party_type;
			$params[] = (int) $party_id;
		}

		return (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(l.debit - l.credit),0) FROM $jl l INNER JOIN $j j ON j.id = l.journal_id WHERE $where",
			$params
		) );
	}

	/**
	 * Trial balance: one row per account with period debit/credit sums.
	 */
	public static function trial_balance( $from, $to ) {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );
		$a  = wceerp_table( 'accounts' );

		/* The journal conditions belong in WHERE, not in a LEFT JOIN's ON
		 * clause. Written as a LEFT JOIN, a line whose journal fails the
		 * test still survives -- only the journal columns come back NULL --
		 * so its debit and credit were summed anyway. Voided journals and
		 * lines dated outside the period were therefore counted in every
		 * report built on this: profit and loss, balance sheet and the
		 * trial balance itself. Deleting an expense voided its journal but
		 * the amount stayed in the accounts.
		 *
		 * INNER JOIN is correct here because the HAVING clause already
		 * drops accounts with no movement. */
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT a.id, a.code, a.name, a.type,
			        COALESCE(SUM(l.debit),0)  AS debit,
			        COALESCE(SUM(l.credit),0) AS credit
			 FROM $a a
			 INNER JOIN $jl l ON l.account_id = a.id
			 INNER JOIN $j  j ON j.id = l.journal_id
			 WHERE a.status='active'
			   AND j.status='posted'
			   AND j.journal_date BETWEEN %s AND %s
			 GROUP BY a.id
			 HAVING debit <> 0 OR credit <> 0
			 ORDER BY a.code",
			$from, $to
		) );
	}

	/**
	 * Net balance per account type over a period (for P&L / balance sheet).
	 * Assets & expenses are debit-normal; income, liability, equity credit-normal.
	 */
	public static function type_balances( $from, $to ) {
		$rows = self::trial_balance( $from, $to );
		$out  = array();
		foreach ( $rows as $row ) {
			$net = (float) $row->debit - (float) $row->credit; // Dr-normal sign.
			if ( in_array( $row->type, array( 'income', 'liability', 'equity' ), true ) ) {
				$net = -$net; // present credit-normal accounts as positive.
			}
			$out[ $row->type ][] = array(
				'id'     => (int) $row->id,
				'code'   => $row->code,
				'name'   => $row->name,
				'amount' => $net,
			);
		}
		return $out;
	}

	/** Total dues per party (customer receivable / supplier payable). */
	public static function party_balances( $party_type, $account_subtype ) {
		global $wpdb;
		$account = self::account_by_subtype( $account_subtype );
		if ( ! $account ) {
			return array();
		}
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );

		return $wpdb->get_results( $wpdb->prepare(
			"SELECT l.party_id, SUM(l.debit - l.credit) AS balance
			 FROM $jl l INNER JOIN $j j ON j.id = l.journal_id
			 WHERE j.status='posted' AND l.account_id = %d AND l.party_type = %s AND l.party_id IS NOT NULL
			 GROUP BY l.party_id
			 HAVING ABS(balance) > 0.005
			 ORDER BY ABS(balance) DESC",
			$account->id, $party_type
		) );
	}

	/**
	 * Record a payment (cash book / bank book entry + due settlement).
	 * Direction 'in' debits the money account; 'out' credits it.
	 */
	public static function record_payment( $args ) {
		global $wpdb;

		$defaults = array(
			'payment_date' => current_time( 'Y-m-d' ),
			'direction'    => 'in',
			'party_type'   => 'other',
			'party_id'     => 0,
			'account_id'   => 0,     // money account: cash/bank/bKash…
			'method'       => 'cash',
			'amount'       => 0,
			'ref_type'     => null,
			'ref_id'       => null,
			'txn_no'       => '',
			'note'         => '',
			'contra'       => null,  // offset account; default AR/AP by party type.
		);
		$args   = wp_parse_args( $args, $defaults );
		$amount = wceerp_dec( $args['amount'] );

		if ( $amount <= 0 || ! $args['account_id'] ) {
			return new WP_Error( 'wceerp_payment', __( 'Payment needs an amount and a cash/bank account.', 'wc-enterprise-erp' ) );
		}

		if ( ! $args['contra'] ) {
			if ( in_array( $args['party_type'], array( 'customer', 'dealer' ), true ) ) {
				$contra = self::account_by_subtype( 'receivable' );
			} elseif ( in_array( $args['party_type'], array( 'supplier', 'reseller' ), true ) ) {
				$contra = self::account_by_subtype( 'supplier' === $args['party_type'] ? 'payable' : null );
				if ( 'reseller' === $args['party_type'] ) {
					$contra = self::account_by_subtype( 'payable' );
					$row    = $wpdb->get_row( "SELECT * FROM " . wceerp_table( 'accounts' ) . " WHERE code='2200'" );
					if ( $row ) { $contra = $row; }
				}
			} else {
				$contra = self::account_by_subtype( 'income' === $args['direction'] ? 'sales' : null );
			}
			if ( ! $contra ) {
				return new WP_Error( 'wceerp_payment', __( 'No offset account found — choose one explicitly.', 'wc-enterprise-erp' ) );
			}
			$args['contra'] = $contra->id;
		}

		$money  = (int) $args['account_id'];
		$contra = self::resolve_account( $args['contra'] );
		$party  = array( 'party_type' => $args['party_type'], 'party_id' => (int) $args['party_id'] );

		$lines = ( 'in' === $args['direction'] )
			? array(
				array_merge( array( 'account' => $money,  'debit' => $amount ), array( 'memo' => $args['note'] ) ),
				array_merge( array( 'account' => $contra, 'credit' => $amount ), $party ),
			)
			: array(
				array_merge( array( 'account' => $contra, 'debit' => $amount ), $party ),
				array_merge( array( 'account' => $money,  'credit' => $amount ), array( 'memo' => $args['note'] ) ),
			);

		$journal = self::post( array(
			'journal_date' => $args['payment_date'],
			'ref_type'     => 'payment',
			'memo'         => $args['note'] ? $args['note'] : ucfirst( $args['direction'] ) . ' payment',
		), $lines );

		if ( is_wp_error( $journal ) ) {
			return $journal;
		}

		$wpdb->insert( wceerp_table( 'payments' ), array(
			'doc_no'       => wceerp_next_doc_number( 'pay' ),
			'payment_date' => $args['payment_date'],
			'direction'    => $args['direction'],
			'party_type'   => $args['party_type'],
			'party_id'     => (int) $args['party_id'],
			'account_id'   => $money,
			'method'       => sanitize_key( $args['method'] ),
			'amount'       => $amount,
			'ref_type'     => $args['ref_type'],
			'ref_id'       => $args['ref_id'] ? (int) $args['ref_id'] : null,
			'txn_no'       => sanitize_text_field( $args['txn_no'] ),
			'note'         => sanitize_text_field( $args['note'] ),
			'created_by'   => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
		) );
		$payment_id = (int) $wpdb->insert_id;

		// Link journal back to the payment record.
		$wpdb->update( wceerp_table( 'journals' ), array( 'ref_id' => $payment_id ), array( 'id' => $journal ) );

		do_action( 'wceerp_payment_recorded', $payment_id, $args );
		return $payment_id;
	}
}
