<?php
/**
 * Installer: creates every module's tables, default chart of accounts,
 * default warehouse and roles.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Installer {

	/**
	 * Multi-company via WordPress Multisite: network-activate and every
	 * site (= company) gets its own complete, isolated ERP — separate
	 * chart of accounts, inventory, warehouses, users, tax and reports
	 * by construction, because each site has its own table set.
	 */
	public static function activate( $network_wide = false ) {
		if ( is_multisite() && $network_wide ) {
			$site_ids = get_sites( array( 'fields' => 'ids', 'number' => 200 ) );
			foreach ( $site_ids as $site_id ) {
				switch_to_blog( $site_id );
				self::install_single();
				restore_current_blog();
			}
			return;
		}
		self::install_single();
	}

	protected static function install_single() {
		self::create_tables();
		WCEERP_Capabilities::install_roles();
		self::seed_defaults();
		self::seed_upgrade_accounts();
		update_option( 'wceerp_version', WCEERP_VERSION );
		// Remember first activation so the go-live default is the day the
		// customer actually started, not the day of a later upgrade.
		if ( ! get_option( 'wceerp_installed_on' ) ) {
			add_option( 'wceerp_installed_on', current_time( 'Y-m-d' ) );
		}
		flush_rewrite_rules();
	}

	/** Provision a brand-new company (site) when it's created. */
	public static function on_new_site( $new_site ) {
		if ( ! is_plugin_active_for_network( plugin_basename( WCEERP_FILE ) ) ) {
			return;
		}
		switch_to_blog( (int) $new_site->blog_id );
		self::install_single();
		restore_current_blog();
	}

	public static function deactivate() {
		flush_rewrite_rules();
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$p       = $wpdb->prefix . 'erp_';

		$sql = array();

		/* ---------------- Warehouses & Inventory ---------------- */
		$sql[] = "CREATE TABLE {$p}warehouses (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			branch_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
			name VARCHAR(191) NOT NULL,
			code VARCHAR(50) NOT NULL,
			address TEXT NULL,
			phone VARCHAR(50) NULL,
			manager_id BIGINT UNSIGNED NULL,
			is_default TINYINT(1) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY code (code)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}stock (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL DEFAULT 0,
			avg_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			reorder_level DECIMAL(18,4) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			PRIMARY KEY (id),
			UNIQUE KEY prod_wh (product_id, warehouse_id),
			KEY warehouse_id (warehouse_id),
			KEY status (status)
		) $charset;";

		/* Scoped API credentials for third-party integrations.
		 *
		 * Deliberately separate from WordPress Application Passwords: an
		 * Application Password grants everything its user can do, forever,
		 * with no visibility. An integrator needs a narrow, revocable,
		 * auditable credential instead. */
		$sql[] = "CREATE TABLE {$p}api_keys (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			key_id VARCHAR(40) NOT NULL,
			secret_hash CHAR(64) NOT NULL,
			label VARCHAR(120) NOT NULL DEFAULT '',
			scopes TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			rate_limit SMALLINT UNSIGNED NOT NULL DEFAULT 120,
			acts_as BIGINT UNSIGNED NOT NULL DEFAULT 0,
			request_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
			last_used_at DATETIME NULL,
			last_ip VARCHAR(45) NULL,
			expires_on DATE NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY key_id (key_id),
			KEY status (status)
		) $charset;";

		/* Money received against an order, outside the courier COD flow:
		 * advances, part payments, and balances collected after delivery.
		 * The courier's own remittances are NOT recorded here -- those run
		 * through courier_payouts so COD stays reconcilable separately. */
		$sql[] = "CREATE TABLE {$p}order_payments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED NOT NULL,
			order_source VARCHAR(20) NOT NULL DEFAULT 'local',
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			method VARCHAR(40) NOT NULL DEFAULT 'cash',
			account_code VARCHAR(20) NOT NULL DEFAULT '',
			kind VARCHAR(20) NOT NULL DEFAULT 'advance',
			paid_on DATE NOT NULL,
			journal_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY order_id (order_id),
			KEY kind (kind),
			KEY paid_on (paid_on)
		) $charset;";

		/* Tiered selling prices (retail / dealer / wholesale) per product.
		 * A missing row means "fall back to the group discount %", which is
		 * why this is a sparse table rather than columns on the product. */
		$sql[] = "CREATE TABLE {$p}product_prices (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			tier VARCHAR(20) NOT NULL,
			price DECIMAL(18,4) NOT NULL DEFAULT 0,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY prod_tier (product_id, tier),
			KEY tier (tier)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}stock_moves (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL,
			unit_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			direction ENUM('in','out') NOT NULL,
			ref_type VARCHAR(40) NOT NULL,
			ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			batch_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY product_id (product_id),
			KEY warehouse_id (warehouse_id),
			KEY ref (ref_type, ref_id)
		) $charset;";

		/* ---------------- Batches & Serials ---------------- */
		$sql[] = "CREATE TABLE {$p}batches (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			batch_no VARCHAR(100) NOT NULL,
			mfg_date DATE NULL,
			exp_date DATE NULL,
			qty DECIMAL(18,4) NOT NULL DEFAULT 0,
			unit_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY product_id (product_id),
			KEY batch_no (batch_no),
			KEY exp_date (exp_date)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}serials (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			batch_id BIGINT UNSIGNED NULL,
			serial_no VARCHAR(191) NOT NULL,
			status ENUM('in_stock','sold','returned','defective') NOT NULL DEFAULT 'in_stock',
			order_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY serial_prod (serial_no, product_id),
			KEY product_id (product_id),
			KEY status (status)
		) $charset;";

		/* ---------------- Suppliers & Purchasing ---------------- */
		$sql[] = "CREATE TABLE {$p}suppliers (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			company VARCHAR(191) NULL,
			email VARCHAR(191) NULL,
			phone VARCHAR(50) NULL,
			address TEXT NULL,
			bin_no VARCHAR(50) NULL,
			tin_no VARCHAR(50) NULL,
			nid_no VARCHAR(50) NULL,
			payment_terms VARCHAR(100) NULL,
			rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
			rating_note VARCHAR(255) NULL,
			opening_balance DECIMAL(18,4) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY name (name(50))
		) $charset;";

		$sql[] = "CREATE TABLE {$p}purchases (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			supplier_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			status ENUM('draft','ordered','received','partial','cancelled') NOT NULL DEFAULT 'draft',
			approval_status ENUM('none','pending','approved','rejected') NOT NULL DEFAULT 'none',
			subtotal DECIMAL(18,4) NOT NULL DEFAULT 0,
			tax_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			discount DECIMAL(18,4) NOT NULL DEFAULT 0,
			shipping DECIMAL(18,4) NOT NULL DEFAULT 0,
			grand_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			paid DECIMAL(18,4) NOT NULL DEFAULT 0,
			purchase_date DATE NOT NULL,
			expected_date DATE NULL,
			note TEXT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY supplier_id (supplier_id),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}purchase_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			purchase_id BIGINT UNSIGNED NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL,
			received_qty DECIMAL(18,4) NOT NULL DEFAULT 0,
			unit_cost DECIMAL(18,4) NOT NULL,
			tax_rate DECIMAL(8,4) NOT NULL DEFAULT 0,
			line_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			batch_no VARCHAR(100) NULL,
			exp_date DATE NULL,
			PRIMARY KEY (id),
			KEY purchase_id (purchase_id)
		) $charset;";

		/* ---------------- Accounting (double entry) ---------------- */
		$sql[] = "CREATE TABLE {$p}accounts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(20) NOT NULL,
			name VARCHAR(191) NOT NULL,
			type ENUM('asset','liability','equity','income','expense') NOT NULL,
			subtype VARCHAR(50) NULL,
			parent_id BIGINT UNSIGNED NULL,
			is_system TINYINT(1) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			PRIMARY KEY (id),
			UNIQUE KEY code (code),
			KEY type (type)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}journals (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			branch_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
			doc_no VARCHAR(50) NOT NULL,
			journal_date DATE NOT NULL,
			ref_type VARCHAR(40) NOT NULL DEFAULT 'manual',
			ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			memo VARCHAR(255) NULL,
			status ENUM('posted','void') NOT NULL DEFAULT 'posted',
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY journal_date (journal_date),
			KEY ref (ref_type, ref_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}journal_lines (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			journal_id BIGINT UNSIGNED NOT NULL,
			account_id BIGINT UNSIGNED NOT NULL,
			debit DECIMAL(18,4) NOT NULL DEFAULT 0,
			credit DECIMAL(18,4) NOT NULL DEFAULT 0,
			party_type VARCHAR(20) NULL,
			party_id BIGINT UNSIGNED NULL,
			memo VARCHAR(255) NULL,
			PRIMARY KEY (id),
			KEY journal_id (journal_id),
			KEY account_id (account_id),
			KEY party (party_type, party_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}payments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			payment_date DATE NOT NULL,
			direction ENUM('in','out') NOT NULL,
			party_type ENUM('customer','supplier','reseller','other') NOT NULL DEFAULT 'other',
			party_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			account_id BIGINT UNSIGNED NOT NULL,
			method VARCHAR(40) NOT NULL DEFAULT 'cash',
			amount DECIMAL(18,4) NOT NULL,
			ref_type VARCHAR(40) NULL,
			ref_id BIGINT UNSIGNED NULL,
			txn_no VARCHAR(100) NULL,
			note VARCHAR(255) NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY party (party_type, party_id),
			KEY payment_date (payment_date)
		) $charset;";

		/* ---------------- Resellers & Commission ---------------- */
		$sql[] = "CREATE TABLE {$p}resellers (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			name VARCHAR(191) NOT NULL,
			phone VARCHAR(50) NULL,
			email VARCHAR(191) NULL,
			area VARCHAR(191) NULL,
			commission_type ENUM('percent','flat') NOT NULL DEFAULT 'percent',
			commission_rate DECIMAL(8,4) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}commissions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			reseller_id BIGINT UNSIGNED NOT NULL,
			order_id BIGINT UNSIGNED NOT NULL,
			order_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			status ENUM('pending','approved','paid','cancelled') NOT NULL DEFAULT 'pending',
			paid_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY reseller_order (reseller_id, order_id),
			KEY status (status)
		) $charset;";

		/* ---------------- Manufacturing ---------------- */
		$sql[] = "CREATE TABLE {$p}boms (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			product_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(191) NOT NULL,
			output_qty DECIMAL(18,4) NOT NULL DEFAULT 1,
			overhead_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			labour_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY product_id (product_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}bom_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			bom_id BIGINT UNSIGNED NOT NULL,
			component_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL,
			wastage_pct DECIMAL(8,4) NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY bom_id (bom_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}productions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			bom_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL,
			total_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			status ENUM('planned','in_progress','completed','cancelled') NOT NULL DEFAULT 'planned',
			production_date DATE NOT NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status)
		) $charset;";

		/* ---------------- HR & Payroll ---------------- */
		$sql[] = "CREATE TABLE {$p}employees (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			name VARCHAR(191) NOT NULL,
			phone VARCHAR(50) NULL,
			nid_no VARCHAR(50) NULL,
			designation VARCHAR(100) NULL,
			department VARCHAR(100) NULL,
			branch_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
			join_date DATE NULL,
			basic_salary DECIMAL(18,4) NOT NULL DEFAULT 0,
			allowances DECIMAL(18,4) NOT NULL DEFAULT 0,
			pay_channel ENUM('cash','bank','bkash','nagad','rocket') NOT NULL DEFAULT 'cash',
			pay_number VARCHAR(50) NULL,
			status ENUM('active','left') NOT NULL DEFAULT 'active',
			left_date DATE NULL,
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}attendance (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			att_date DATE NOT NULL,
			status ENUM('present','absent','leave','half_day','holiday') NOT NULL DEFAULT 'present',
			note VARCHAR(100) NULL,
			PRIMARY KEY (id),
			UNIQUE KEY emp_date (employee_id, att_date)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}leaves (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			from_date DATE NOT NULL,
			to_date DATE NOT NULL,
			days DECIMAL(5,1) NOT NULL DEFAULT 1,
			type ENUM('casual','sick','annual','unpaid') NOT NULL DEFAULT 'casual',
			status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
			note VARCHAR(255) NULL,
			acted_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY employee_id (employee_id),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}salary_advances (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			repaid_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			advance_date DATE NOT NULL,
			account_id BIGINT UNSIGNED NOT NULL,
			journal_id BIGINT UNSIGNED NULL,
			status ENUM('open','settled') NOT NULL DEFAULT 'open',
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY employee_id (employee_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}payroll_runs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			period CHAR(7) NOT NULL,
			gross DECIMAL(18,4) NOT NULL DEFAULT 0,
			deductions DECIMAL(18,4) NOT NULL DEFAULT 0,
			net DECIMAL(18,4) NOT NULL DEFAULT 0,
			journal_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			UNIQUE KEY period (period)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}payroll_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			run_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			basic DECIMAL(18,4) NOT NULL DEFAULT 0,
			allowances DECIMAL(18,4) NOT NULL DEFAULT 0,
			overtime DECIMAL(18,4) NOT NULL DEFAULT 0,
			bonus DECIMAL(18,4) NOT NULL DEFAULT 0,
			absent_deduction DECIMAL(18,4) NOT NULL DEFAULT 0,
			advance_deduction DECIMAL(18,4) NOT NULL DEFAULT 0,
			other_deduction DECIMAL(18,4) NOT NULL DEFAULT 0,
			net DECIMAL(18,4) NOT NULL DEFAULT 0,
			pay_channel VARCHAR(20) NOT NULL DEFAULT 'cash',
			PRIMARY KEY (id),
			KEY run_id (run_id)
		) $charset;";

		/* ---------------- CRM ---------------- */
		$sql[] = "CREATE TABLE {$p}leads (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			name VARCHAR(191) NOT NULL,
			company VARCHAR(191) NULL,
			phone VARCHAR(50) NULL,
			email VARCHAR(100) NULL,
			source VARCHAR(100) NULL,
			value_estimate DECIMAL(18,4) NOT NULL DEFAULT 0,
			stage ENUM('new','contacted','qualified','proposal','won','lost') NOT NULL DEFAULT 'new',
			assigned_to BIGINT UNSIGNED NULL,
			next_follow_up DATE NULL,
			won_order_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY stage (stage),
			KEY next_follow_up (next_follow_up)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}crm_activities (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			lead_id BIGINT UNSIGNED NOT NULL,
			kind ENUM('call','meeting','whatsapp','email','note') NOT NULL DEFAULT 'note',
			summary VARCHAR(255) NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY lead_id (lead_id)
		) $charset;";

		/* ---------------- Service management ---------------- */
		$sql[] = "CREATE TABLE {$p}service_projects (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			name VARCHAR(191) NOT NULL,
			kind ENUM('project','contract','amc') NOT NULL DEFAULT 'project',
			customer_name VARCHAR(191) NOT NULL,
			customer_phone VARCHAR(50) NULL,
			amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			billing ENUM('one_time','monthly','yearly') NOT NULL DEFAULT 'one_time',
			start_date DATE NULL,
			end_date DATE NULL,
			next_invoice_date DATE NULL,
			assigned_employee_id BIGINT UNSIGNED NULL,
			status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status),
			KEY next_invoice_date (next_invoice_date)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}service_tickets (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			project_id BIGINT UNSIGNED NULL,
			customer_name VARCHAR(191) NOT NULL,
			phone VARCHAR(50) NULL,
			subject VARCHAR(191) NOT NULL,
			detail TEXT NULL,
			priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
			status ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
			assigned_employee_id BIGINT UNSIGNED NULL,
			minutes_logged INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			resolved_at DATETIME NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status),
			KEY project_id (project_id)
		) $charset;";

		/* ---------------- POS ---------------- */
		$sql[] = "CREATE TABLE {$p}pos_shifts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uuid VARCHAR(40) NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			warehouse_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			opened_at DATETIME NOT NULL,
			closed_at DATETIME NULL,
			opening_float DECIMAL(18,4) NOT NULL DEFAULT 0,
			expected_cash DECIMAL(18,4) NOT NULL DEFAULT 0,
			counted_cash DECIMAL(18,4) NULL,
			note VARCHAR(255) NULL,
			status ENUM('open','closed') NOT NULL DEFAULT 'open',
			PRIMARY KEY (id),
			UNIQUE KEY uuid (uuid),
			KEY user_id (user_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}pos_sales (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uuid VARCHAR(40) NOT NULL,
			shift_uuid VARCHAR(40) NULL,
			order_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			total DECIMAL(18,4) NOT NULL DEFAULT 0,
			pay_method VARCHAR(30) NOT NULL DEFAULT 'cash',
			sold_at DATETIME NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uuid (uuid),
			KEY shift_uuid (shift_uuid)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}pos_refunds (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uuid VARCHAR(40) NOT NULL,
			shift_uuid VARCHAR(40) NULL,
			order_id BIGINT UNSIGNED NOT NULL,
			refund_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL,
			total DECIMAL(18,4) NOT NULL DEFAULT 0,
			pay_method VARCHAR(30) NOT NULL DEFAULT 'cash',
			journal_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uuid (uuid),
			KEY order_id (order_id),
			KEY shift_uuid (shift_uuid)
		) $charset;";

		/* ---------------- Branches ---------------- */
		$sql[] = "CREATE TABLE {$p}branches (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(20) NOT NULL,
			name VARCHAR(191) NOT NULL,
			address TEXT NULL,
			phone VARCHAR(50) NULL,
			status ENUM('active','inactive') NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY code (code)
		) $charset;";

		/* ---------------- Dealers (wholesale) ---------------- */
		$sql[] = "CREATE TABLE {$p}dealers (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(191) NOT NULL,
			company VARCHAR(191) NULL,
			phone VARCHAR(50) NULL,
			territory VARCHAR(100) NULL,
			group_type VARCHAR(20) NOT NULL DEFAULT 'dealer',
			discount_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
			credit_limit DECIMAL(18,4) NOT NULL DEFAULT 0,
			status ENUM('active','suspended') NOT NULL DEFAULT 'active',
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY user_id (user_id)
		) $charset;";

		/* ---------------- Procurement (RFQ + approvals) ---------------- */
		$sql[] = "CREATE TABLE {$p}rfqs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			title VARCHAR(191) NOT NULL,
			needed_by DATE NULL,
			status ENUM('open','awarded','closed') NOT NULL DEFAULT 'open',
			awarded_quote_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}rfq_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			rfq_id BIGINT UNSIGNED NOT NULL,
			product_id BIGINT UNSIGNED NOT NULL,
			qty DECIMAL(18,4) NOT NULL DEFAULT 0,
			spec VARCHAR(255) NULL,
			PRIMARY KEY (id),
			KEY rfq_id (rfq_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}rfq_quotes (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			rfq_id BIGINT UNSIGNED NOT NULL,
			supplier_id BIGINT UNSIGNED NOT NULL,
			quote_date DATE NOT NULL,
			valid_until DATE NULL,
			delivery_days INT UNSIGNED NOT NULL DEFAULT 0,
			total DECIMAL(18,4) NOT NULL DEFAULT 0,
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY rfq_id (rfq_id),
			KEY supplier_id (supplier_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}rfq_quote_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			quote_id BIGINT UNSIGNED NOT NULL,
			rfq_item_id BIGINT UNSIGNED NOT NULL,
			unit_price DECIMAL(18,4) NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY quote_id (quote_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}purchase_approvals (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			purchase_id BIGINT UNSIGNED NOT NULL,
			level TINYINT UNSIGNED NOT NULL DEFAULT 1,
			status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
			user_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			acted_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY purchase_id (purchase_id),
			KEY status (status)
		) $charset;";

		/* ---------------- Courier & COD ---------------- */
		$sql[] = "CREATE TABLE {$p}consignments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			order_id BIGINT UNSIGNED NOT NULL,
			order_source VARCHAR(20) NOT NULL DEFAULT 'local',
			customer_name VARCHAR(191) NULL,
			customer_phone VARCHAR(60) NULL,
			customer_address TEXT NULL,
			courier VARCHAR(40) NOT NULL DEFAULT 'manual',
			remote_id VARCHAR(100) NULL,
			tracking_code VARCHAR(100) NULL,
			recipient_name VARCHAR(191) NOT NULL,
			recipient_phone VARCHAR(50) NOT NULL,
			recipient_address TEXT NULL,
			cod_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			collected_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			delivery_charge DECIMAL(18,4) NOT NULL DEFAULT 0,
			remote_cod_amount DECIMAL(18,4) NULL,
			remote_collected DECIMAL(18,4) NULL,
			remote_payment_state VARCHAR(40) NULL,
			discount_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			charge_delivery DECIMAL(18,4) NULL,
			charge_cod DECIMAL(18,4) NULL,
			accrued_charge DECIMAL(18,4) NULL,
			accrued_at DATETIME NULL,
			reversed_at DATETIME NULL,
			restocked_at DATETIME NULL,
			remote_charge DECIMAL(18,4) NULL,
			status ENUM('pending','booked','in_transit','delivered','returned','cancelled','paid') NOT NULL DEFAULT 'pending',
			payout_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			last_sync DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY order_id (order_id),
			KEY status (status),
			KEY courier (courier)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}courier_payouts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			courier VARCHAR(40) NOT NULL,
			payout_date DATE NOT NULL,
			gross_cod DECIMAL(18,4) NOT NULL DEFAULT 0,
			charges DECIMAL(18,4) NOT NULL DEFAULT 0,
			net_amount DECIMAL(18,4) NOT NULL DEFAULT 0,
			account_id BIGINT UNSIGNED NOT NULL,
			journal_id BIGINT UNSIGNED NULL,
			note VARCHAR(255) NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no)
		) $charset;";

		/* ---------------- Bank reconciliation ---------------- */
		$sql[] = "CREATE TABLE {$p}bank_statement_lines (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			account_id BIGINT UNSIGNED NOT NULL,
			txn_date DATE NOT NULL,
			description VARCHAR(255) NULL,
			ref_no VARCHAR(100) NULL,
			debit DECIMAL(18,4) NOT NULL DEFAULT 0,
			credit DECIMAL(18,4) NOT NULL DEFAULT 0,
			matched_line_id BIGINT UNSIGNED NULL,
			status ENUM('unmatched','matched') NOT NULL DEFAULT 'unmatched',
			batch VARCHAR(50) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY account_id (account_id),
			KEY status (status),
			KEY txn_date (txn_date)
		) $charset;";

		/* ---------------- Fixed assets ---------------- */
		$sql[] = "CREATE TABLE {$p}assets (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			name VARCHAR(191) NOT NULL,
			category VARCHAR(100) NULL,
			purchase_date DATE NOT NULL,
			purchase_cost DECIMAL(18,4) NOT NULL DEFAULT 0,
			salvage_value DECIMAL(18,4) NOT NULL DEFAULT 0,
			useful_life_months INT UNSIGNED NOT NULL DEFAULT 60,
			accum_depreciation DECIMAL(18,4) NOT NULL DEFAULT 0,
			status ENUM('active','fully_depreciated','disposed') NOT NULL DEFAULT 'active',
			disposal_date DATE NULL,
			disposal_amount DECIMAL(18,4) NULL,
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}asset_depreciation (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			asset_id BIGINT UNSIGNED NOT NULL,
			period CHAR(7) NOT NULL,
			amount DECIMAL(18,4) NOT NULL,
			journal_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY asset_period (asset_id, period)
		) $charset;";

		/* ---------------- Quotations ---------------- */
		$sql[] = "CREATE TABLE {$p}quotations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(50) NOT NULL,
			customer_user_id BIGINT UNSIGNED NULL,
			customer_name VARCHAR(191) NOT NULL,
			phone VARCHAR(50) NULL,
			email VARCHAR(191) NULL,
			address TEXT NULL,
			status ENUM('draft','sent','accepted','rejected','expired','converted') NOT NULL DEFAULT 'draft',
			subtotal DECIMAL(18,4) NOT NULL DEFAULT 0,
			tax_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			discount DECIMAL(18,4) NOT NULL DEFAULT 0,
			grand_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			valid_until DATE NULL,
			order_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY doc_no (doc_no),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}quotation_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			quotation_id BIGINT UNSIGNED NOT NULL,
			product_id BIGINT UNSIGNED NULL,
			description VARCHAR(255) NOT NULL,
			qty DECIMAL(18,4) NOT NULL,
			unit_price DECIMAL(18,4) NOT NULL,
			tax_rate DECIMAL(8,4) NOT NULL DEFAULT 0,
			line_total DECIMAL(18,4) NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY quotation_id (quotation_id)
		) $charset;";

		/* ---------------- Misc ---------------- */
		$sql[] = "CREATE TABLE {$p}connect_orders (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			remote_id BIGINT UNSIGNED NOT NULL,
			number VARCHAR(60) NULL,
			status VARCHAR(40) NULL,
			total DECIMAL(15,2) NOT NULL DEFAULT 0,
			payment_method VARCHAR(100) NULL,
			is_cod TINYINT(1) NOT NULL DEFAULT 0,
			customer_name VARCHAR(191) NULL,
			customer_phone VARCHAR(60) NULL,
			customer_email VARCHAR(191) NULL,
			customer_address TEXT NULL,
			order_date DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY remote_id (remote_id),
			KEY is_cod (is_cod)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}connect_costs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			remote_product_id BIGINT UNSIGNED NOT NULL,
			sku VARCHAR(120) NULL,
			name VARCHAR(191) NULL,
			unit_cost DECIMAL(15,2) NOT NULL DEFAULT 0,
			source VARCHAR(20) NOT NULL DEFAULT 'manual',
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY remote_product_id (remote_product_id),
			KEY sku (sku)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}connect_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			remote_id BIGINT UNSIGNED NOT NULL,
			journal_id BIGINT UNSIGNED NULL,
			total DECIMAL(15,2) NOT NULL DEFAULT 0,
			order_date DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY remote_id (remote_id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}expense_categories (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(120) NOT NULL,
			account_code VARCHAR(20) NOT NULL DEFAULT '5200',
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}expenses (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			doc_no VARCHAR(40) NOT NULL,
			category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			amount DECIMAL(15,2) NOT NULL DEFAULT 0,
			paid_from VARCHAR(20) NOT NULL DEFAULT '1000',
			expense_date DATE NOT NULL,
			payee VARCHAR(191) NULL,
			memo VARCHAR(255) NULL,
			journal_id BIGINT UNSIGNED NULL,
			branch_id BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY cat (category_id),
			KEY edate (expense_date)
		) $charset;";

		/* Bulk messaging.
		 *
		 * A campaign is what you composed; the queue is one row per
		 * recipient. Kept apart because sending is asynchronous — a few
		 * thousand messages cannot go out inside one page request, and a
		 * failed send must be retryable without re-sending the rest. */
		$sql[] = "CREATE TABLE {$p}campaigns (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			channel VARCHAR(20) NOT NULL DEFAULT 'sms',
			body TEXT NULL,
			template_name VARCHAR(120) NULL,
			audience VARCHAR(40) NOT NULL DEFAULT 'all',
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			total INT UNSIGNED NOT NULL DEFAULT 0,
			sent INT UNSIGNED NOT NULL DEFAULT 0,
			failed INT UNSIGNED NOT NULL DEFAULT 0,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			finished_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY status (status)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}message_queue (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			campaign_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			channel VARCHAR(20) NOT NULL DEFAULT 'sms',
			recipient VARCHAR(30) NOT NULL,
			name VARCHAR(191) NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			body TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'queued',
			attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
			error VARCHAR(255) NULL,
			remote_id VARCHAR(100) NULL,
			created_at DATETIME NOT NULL,
			sent_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY campaign_status (campaign_id, status),
			KEY status (status),
			KEY recipient (recipient)
		) $charset;";

		/* Who has asked not to be messaged. Keyed by phone rather than user
		 * id, because most shops here have far more guest numbers than
		 * accounts, and an opt-out must survive the customer never having
		 * registered. */
		$sql[] = "CREATE TABLE {$p}message_optouts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			phone VARCHAR(30) NOT NULL,
			channel VARCHAR(20) NOT NULL DEFAULT 'all',
			reason VARCHAR(191) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY phone_channel (phone, channel)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}notifications (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			type VARCHAR(50) NOT NULL,
			title VARCHAR(191) NOT NULL,
			message TEXT NULL,
			link VARCHAR(255) NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			is_read TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY user_read (user_id, is_read)
		) $charset;";

		$sql[] = "CREATE TABLE {$p}audit_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			module VARCHAR(50) NOT NULL,
			action VARCHAR(50) NOT NULL,
			ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			note VARCHAR(255) NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY module (module)
		) $charset;";

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	/**
	 * Seed default warehouse and a Bangladesh-friendly chart of accounts.
	 */
	/**
	 * Accounts added in later versions — inserted only if missing, so
	 * upgrades are safe and existing charts are never disturbed.
	 */
	public static function seed_upgrade_accounts() {
		global $wpdb;
		$acc = wceerp_table( 'accounts' );

		$branches = wceerp_table( 'branches' );
		if ( ! $wpdb->get_var( "SELECT COUNT(*) FROM $branches" ) ) {
			$wpdb->insert( $branches, array(
				'code'       => 'HO',
				'name'       => __( 'Head Office', 'wc-enterprise-erp' ),
				'status'     => 'active',
				'created_at' => current_time( 'mysql' ),
			) );
		}

		$additions = self::default_accounts();

		foreach ( $additions as $row ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $acc WHERE code = %s", $row[0] ) );
			if ( $exists ) {
				continue;
			}
			$wpdb->insert( $acc, array(
				'code'      => $row[0],
				'name'      => $row[1],
				'type'      => $row[2],
				'subtype'   => $row[3],
				'is_system' => $row[4],
				'status'    => 'active',
			) );
		}

		// Seed default expense categories once (maps each to an account).
		$cats_table = wceerp_table( 'expense_categories' );
		if ( 0 === (int) $wpdb->get_var( "SELECT COUNT(*) FROM $cats_table" ) ) {
			$default_cats = array(
				array( 'Rent', '5200' ),
				array( 'Utilities (electricity, water, gas, internet)', '5300' ),
				array( 'Transport & Fuel', '5710' ),
				array( 'Marketing & Advertising', '5750' ),
				array( 'Office & Admin', '5800' ),
				array( 'Salaries & Wages', '5850' ),
				array( 'Miscellaneous', '5900' ),
			);
			foreach ( $default_cats as $c ) {
				$wpdb->insert( $cats_table, array(
					'name'         => $c[0],
					'account_code' => $c[1],
					'is_active'    => 1,
					'created_at'   => current_time( 'mysql' ),
				) );
			}
		}
	}

	public static function seed_defaults() {
		global $wpdb;

		$wh = wceerp_table( 'warehouses' );
		if ( ! $wpdb->get_var( "SELECT COUNT(*) FROM $wh" ) ) {
			$wpdb->insert( $wh, array(
				'name'       => __( 'Main Warehouse', 'wc-enterprise-erp' ),
				'code'       => 'MAIN',
				'is_default' => 1,
				'created_at' => current_time( 'mysql' ),
			) );
		}

		/* The chart of accounts is topped up rather than seeded.
		 *
		 * This used to return early whenever any account existed, with the
		 * default list sitting below that return — so accounts added in
		 * later versions never reached a site installed on an earlier one.
		 * Expense categories then pointed at codes the database had never
		 * received, and every expense failed with "Unknown account in
		 * journal line".
		 *
		 * Topping up by code keeps a customer's own edits and additions
		 * untouched while guaranteeing the accounts modules depend on are
		 * present.
		 */
		self::ensure_accounts();
		return;

		$defaults = self::default_accounts();

	}

	/**
	 * Add accounts introduced after a site was first installed.
	 *
	 * seed_accounts() deliberately does nothing once a chart of accounts
	 * exists, so that a customer's edits are never overwritten. New system
	 * accounts therefore have to be topped up individually, by code.
	 */
	/**
	 * The complete chart of accounts this plugin depends on.
	 *
	 * One list, used both to seed a new site and to top up an old one, so a
	 * code added here can never again be missing from an existing install.
	 *
	 * @return array Rows of [ code, name, type, subtype, is_system ].
	 */
	public static function default_accounts() {
		return array(
			// code, name, type, subtype, system
			array( '1000', 'Cash in Hand', 'asset', 'cash', 1 ),
			array( '1010', 'Bank Account', 'asset', 'bank', 1 ),
			array( '1020', 'bKash', 'asset', 'mobile_banking', 1 ),
			array( '1021', 'Nagad', 'asset', 'mobile_banking', 1 ),
			array( '1022', 'Rocket', 'asset', 'mobile_banking', 1 ),
			array( '1100', 'Accounts Receivable', 'asset', 'receivable', 1 ),
			array( '1200', 'Inventory', 'asset', 'inventory', 1 ),
			array( '1300', 'VAT Current Account (Input)', 'asset', 'tax', 1 ),
			array( '2000', 'Accounts Payable', 'liability', 'payable', 1 ),
			array( '2100', 'VAT Payable (Output)', 'liability', 'tax', 1 ),
			array( '2200', 'Commission Payable', 'liability', 'payable', 1 ),
			array( '3000', 'Owner Equity', 'equity', null, 1 ),
			array( '3100', 'Retained Earnings', 'equity', null, 1 ),
			array( '3200', 'Opening Balance Equity', 'equity', null, 1 ),
			array( '4000', 'Sales Revenue', 'income', 'sales', 1 ),
			array( '4100', 'Other Income', 'income', null, 0 ),
			array( '5000', 'Cost of Goods Sold', 'expense', 'cogs', 1 ),
			array( '5100', 'Salaries & Wages', 'expense', null, 0 ),
			array( '5200', 'Rent Expense', 'expense', null, 0 ),
			array( '5300', 'Utilities', 'expense', null, 0 ),
			array( '5400', 'Sales Commission Expense', 'expense', null, 1 ),
			array( '5500', 'Manufacturing Overhead', 'expense', null, 1 ),
			array( '5710', 'Transport & Fuel', 'expense', null, 0 ),
			array( '5750', 'Marketing & Advertising', 'expense', null, 0 ),
			array( '5800', 'Office & Admin', 'expense', null, 0 ),
			array( '5850', 'Salaries & Wages', 'expense', null, 0 ),
			array( '5900', 'Miscellaneous Expense', 'expense', null, 0 ),

			// Added in later versions; kept here so an existing install
			// receives them on upgrade rather than only a fresh one.
			array( '1110', 'Courier COD Receivable', 'asset', 'cod_receivable', 1 ),
			array( '1500', 'Fixed Assets (at cost)', 'asset', 'fixed_asset', 1 ),
			array( '1510', 'Accumulated Depreciation', 'asset', 'accum_depreciation', 1 ),
			array( '5600', 'Delivery & Courier Charges', 'expense', 'delivery', 1 ),
			/* Money given away at the door. Kept out of 4000 so the sales
			 * figure stays the price you actually asked, and the cost of
			 * discounting is visible on its own line rather than hidden
			 * inside lower revenue. */
			array( '4200', 'Discounts Given', 'expense', 'discount', 1 ),
			/* Charged by the courier on a parcel that came back. Separate
			 * from ordinary delivery charges because it is pure loss —
			 * nothing was sold, and knowing the size of it is the argument
			 * for reducing returns. */
			array( '5650', 'Return & Failed Delivery Charges', 'expense', 'return_charge', 1 ),
			/* The courier's fee for handling money, as opposed to for
			 * carrying goods. Separate because they behave differently: the
			 * delivery charge is roughly fixed per parcel, while this scales
			 * with what you sell — so a rising figure here means volume,
			 * not waste. */
			array( '5610', 'COD Collection Fees', 'expense', 'cod_fee', 1 ),
			/* Stock that has genuinely gone: broken, spoiled, stolen, or
			 * short on a count. A real cost of trading, and worth watching
			 * on its own line — in a dairy business spoilage is a number
			 * the owner should see monthly. */
			array( '5550', 'Stock Loss, Damage & Wastage', 'expense', 'stock_loss', 1 ),
			/* Goods sent back to a supplier. Not a loss: it reduces what you
			 * owe them, or becomes a credit against future purchases. */
			array( '2050', 'Supplier Credits Receivable', 'liability', 'supplier_credit', 1 ),
			/* Courier charges incurred but not yet deducted from a payout.
			 * Lets the cost sit in the month the parcel was delivered,
			 * rather than the month the remittance happened to arrive. */
			array( '2150', 'Courier Charges Payable', 'liability', 'courier_accrual', 1 ),
			array( '5700', 'Depreciation Expense', 'expense', 'depreciation', 1 ),
			array( '1120', 'Staff Salary Advances', 'asset', 'staff_advance', 1 ),
			array( '5110', 'Staff Bonus & Overtime', 'expense', 'payroll', 1 ),
		);
	}

	/**
	 * Insert any account that is missing, by code.
	 *
	 * Never updates or deletes: a customer may have renamed an account, and
	 * that is theirs to decide.
	 *
	 * @return int Number of accounts added.
	 */
	public static function ensure_accounts() {
		global $wpdb;
		$acc = wceerp_table( 'accounts' );

		$needed = apply_filters( 'wceerp_ensure_accounts', self::default_accounts() );
		$added  = 0;

		// One query rather than one per account: this runs on every upgrade.
		$have = (array) $wpdb->get_col( "SELECT code FROM {$acc}" );
		$have = array_flip( $have );

		foreach ( $needed as $row ) {
			if ( isset( $have[ $row[0] ] ) ) {
				continue;
			}
			$wpdb->insert( $acc, array(
				'code'      => $row[0],
				'name'      => $row[1],
				'type'      => $row[2],
				'subtype'   => $row[3],
				'is_system' => $row[4],
			) );
			$added++;
		}

		if ( $added && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'settings', 'accounts_added', 0, $added . ' missing account(s) restored' );
		}
		return $added;
	}
}
