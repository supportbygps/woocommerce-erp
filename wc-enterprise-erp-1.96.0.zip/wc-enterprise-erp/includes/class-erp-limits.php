<?php
/**
 * Package limits & per-tenant feature toggles (SaaS).
 *
 * Extends tier gating with two things operators actually sell on:
 *   1. Usage limits — caps on users, products and orders/month per
 *      package, enforced with friendly messages (never data loss).
 *   2. Feature overrides — turn individual modules on/off for a single
 *      tenant beyond what their tier implies (e.g. a Starter tenant who
 *      paid extra for POS).
 *
 * Everything reads from blog options set by the Tenant Manager, so it
 * only bites on Multisite SaaS installs; standalone sites are
 * unlimited.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Limits {

	/** Default caps per package. 0 / -1 means unlimited. */
	const PACKAGE_LIMITS = array(
		'starter'    => array( 'users' => 2,  'products' => 500,   'orders_month' => 500 ),
		'business'   => array( 'users' => 8,  'products' => 5000,  'orders_month' => 5000 ),
		'enterprise' => array( 'users' => 0,  'products' => 0,     'orders_month' => 0 ),
	);

	const LIMIT_LABELS = array(
		'users'        => 'Staff users',
		'products'     => 'Products',
		'orders_month' => 'Orders per month',
	);

	/** Active on SaaS tenants, or on any install that has entitlements. */
	public static function active() {
		if ( is_multisite() && get_option( 'wceerp_saas_tier', '' ) ) {
			return true;
		}
		// Key-based install with server-delivered limits/features.
		if ( get_option( 'wceerp_feature_overrides', '' ) !== '' ) {
			return true;
		}
		foreach ( array( 'users', 'products', 'orders_month' ) as $r ) {
			if ( '' !== get_option( 'wceerp_limit_' . $r, '' ) ) {
				return true;
			}
		}
		return false;
	}

	/** Resolved limit for a resource: per-tenant override → package default → 0 (unlimited). */
	public static function limit( $resource ) {
		if ( ! self::active() ) {
			return 0;
		}
		$override = get_option( 'wceerp_limit_' . $resource, '' );
		if ( '' !== $override ) {
			return (int) $override;
		}
		$tier = get_option( 'wceerp_saas_tier', '' );
		if ( ! $tier && class_exists( 'WCEERP_License' ) ) {
			$license = WCEERP_License::get();
			$tier    = $license['tier'] ?? 'starter';
		}
		if ( ! $tier ) {
			$tier = 'starter';
		}
		return (int) ( self::PACKAGE_LIMITS[ $tier ][ $resource ] ?? 0 );
	}

	/** Current usage count for a resource. */
	public static function usage( $resource ) {
		global $wpdb;
		switch ( $resource ) {
			case 'users':
				return (int) count_users()['total_users'];
			case 'products':
				return (int) wp_count_posts( 'product' )->publish;
			case 'orders_month':
				// HPOS-safe-ish: count orders created this month.
				$since = gmdate( 'Y-m-01 00:00:00' );
				$n = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ('shop_order','shop_order_placehold') AND post_date >= %s",
					$since
				) );
				if ( ! $n && function_exists( 'wc_get_orders' ) ) {
					$orders = wc_get_orders( array( 'limit' => -1, 'date_created' => '>=' . strtotime( $since ), 'return' => 'ids' ) );
					$n = count( $orders );
				}
				return $n;
			default:
				return 0;
		}
	}

	/**
	 * Is there room to add $add more of $resource?
	 * True when unlimited or under the cap.
	 */
	public static function can_add( $resource, $add = 1 ) {
		$limit = self::limit( $resource );
		if ( $limit <= 0 ) {
			return true;
		}
		return ( self::usage( $resource ) + $add ) <= $limit;
	}

	/** Human message when a limit is hit. */
	public static function limit_message( $resource ) {
		$label = self::LIMIT_LABELS[ $resource ] ?? $resource;
		return sprintf(
			/* translators: 1: resource label 2: limit */
			__( 'Your plan\'s %1$s limit (%2$d) has been reached. Contact your provider to upgrade — nothing is deleted.', 'wc-enterprise-erp' ),
			$label,
			self::limit( $resource )
		);
	}

	/**
	 * Per-tenant module override. Returns:
	 *   'on'  → force-enabled regardless of tier
	 *   'off' → force-disabled
	 *   ''    → no override (use tier default)
	 */
	public static function feature_override( $module_id ) {
		if ( ! self::active() ) {
			return '';
		}
		$map = (array) get_option( 'wceerp_feature_overrides', array() );
		return isset( $map[ $module_id ] ) ? $map[ $module_id ] : '';
	}
}
