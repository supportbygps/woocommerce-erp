<?php
/**
 * Public API authentication.
 *
 * WordPress Application Passwords authenticate a *user* and grant everything
 * that user can do, indefinitely, with no record of what was called. That is
 * fine for your own mobile app and wrong for a third party.
 *
 * This gives integrators a credential that is:
 *
 *   - narrow      — scoped per capability area (pos:write, orders:read …)
 *   - revocable   — one row, flipped to revoked, effective immediately
 *   - attributable— every call recorded against the key, not a shared login
 *   - throttled   — per-key request ceiling
 *   - expiring    — optional hard end date
 *
 * The credential is `key_id.secret`, sent as a bearer token. Only a SHA-256
 * digest of the secret is stored; the plaintext is shown once at creation and
 * cannot be recovered. SHA-256 without a slow KDF is appropriate here because
 * the secret is 48 random characters, not a human-chosen password.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_API_Auth {

	/** Scopes an integrator can be granted. */
	public static function scopes() {
		return apply_filters( 'wceerp_api_scopes', array(
			'pos:read'        => __( 'POS — read catalogue, shifts and sales', 'wc-enterprise-erp' ),
			'pos:write'       => __( 'POS — create sales and refunds', 'wc-enterprise-erp' ),
			'orders:read'     => __( 'Orders — read orders and payment status', 'wc-enterprise-erp' ),
			'orders:write'    => __( 'Orders — record payments', 'wc-enterprise-erp' ),
			'inventory:read'  => __( 'Inventory — read products and stock', 'wc-enterprise-erp' ),
			'inventory:write' => __( 'Inventory — adjust stock', 'wc-enterprise-erp' ),
			'courier:read'    => __( 'Courier — read consignments', 'wc-enterprise-erp' ),
			'courier:write'   => __( 'Courier — create and book consignments', 'wc-enterprise-erp' ),
			'accounting:read' => __( 'Accounting — read accounts and reports', 'wc-enterprise-erp' ),
		) );
	}

	/**
	 * Issue a new key.
	 *
	 * @return array{key_id:string,secret:string,token:string}|WP_Error
	 *         The plaintext token is returned once and never again.
	 */
	public static function create( $args ) {
		global $wpdb;

		$label = sanitize_text_field( $args['label'] ?? '' );
		if ( '' === $label ) {
			return new WP_Error( 'wceerp_api', __( 'Give the key a label so you know what it belongs to.', 'wc-enterprise-erp' ) );
		}

		$valid  = array_keys( self::scopes() );
		$scopes = array_values( array_intersect( (array) ( $args['scopes'] ?? array() ), $valid ) );
		if ( ! $scopes ) {
			return new WP_Error( 'wceerp_api', __( 'Select at least one scope. A key with no scopes can do nothing.', 'wc-enterprise-erp' ) );
		}

		$key_id = 'gps_' . wp_generate_password( 16, false, false );
		$secret = wp_generate_password( 48, false, false );

		$expires = (string) ( $args['expires_on'] ?? '' );
		$expires = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expires ) ? $expires : null;

		$wpdb->insert( wceerp_table( 'api_keys' ), array(
			'key_id'      => $key_id,
			'secret_hash' => hash( 'sha256', $secret ),
			'label'       => $label,
			'scopes'      => implode( ',', $scopes ),
			'status'      => 'active',
			'rate_limit'  => max( 10, min( 6000, (int) ( $args['rate_limit'] ?? 120 ) ) ),
			// Calls run as this user for capability-aware internals.
			'acts_as'     => (int) ( $args['acts_as'] ?? get_current_user_id() ),
			'expires_on'  => $expires,
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		) );

		wceerp_log( 'api', 'key_created', (int) $wpdb->insert_id, $label . ' [' . implode( ' ', $scopes ) . ']' );

		return array(
			'key_id' => $key_id,
			'secret' => $secret,
			'token'  => $key_id . '.' . $secret,
		);
	}

	public static function revoke( $id ) {
		global $wpdb;
		$wpdb->update( wceerp_table( 'api_keys' ), array( 'status' => 'revoked' ), array( 'id' => (int) $id ) );
		wceerp_log( 'api', 'key_revoked', (int) $id );
	}

	public static function all() {
		global $wpdb;
		return (array) $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'api_keys' ) . ' ORDER BY id DESC' );
	}

	/** Pull the bearer token out of the request. */
	protected static function bearer( WP_REST_Request $request ) {
		$header = (string) $request->get_header( 'authorization' );
		if ( ! $header ) {
			$header = (string) $request->get_header( 'x-wceerp-key' );
		}
		if ( ! $header ) {
			return '';
		}
		return trim( preg_replace( '/^Bearer\s+/i', '', $header ) );
	}

	/**
	 * Authenticate a request and return the key row.
	 *
	 * @return object|WP_Error
	 */
	public static function authenticate( WP_REST_Request $request ) {
		global $wpdb;

		$token = self::bearer( $request );
		if ( '' === $token || false === strpos( $token, '.' ) ) {
			return new WP_Error(
				'wceerp_api_unauthorized',
				__( 'Provide an API key as: Authorization: Bearer <key_id>.<secret>', 'wc-enterprise-erp' ),
				array( 'status' => 401 )
			);
		}

		list( $key_id, $secret ) = explode( '.', $token, 2 );

		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'api_keys' ) . ' WHERE key_id = %s',
			sanitize_text_field( $key_id )
		) );

		/* Same response whether the key is unknown or the secret is wrong,
		 * so the endpoint cannot be used to enumerate valid key ids. */
		$fail = new WP_Error( 'wceerp_api_unauthorized', __( 'Invalid API credentials.', 'wc-enterprise-erp' ), array( 'status' => 401 ) );

		if ( ! $row ) {
			return $fail;
		}
		if ( ! hash_equals( (string) $row->secret_hash, hash( 'sha256', $secret ) ) ) {
			wceerp_log( 'api', 'auth_failed', (int) $row->id, self::client_ip() );
			return $fail;
		}
		if ( 'active' !== $row->status ) {
			return new WP_Error( 'wceerp_api_revoked', __( 'This API key has been revoked.', 'wc-enterprise-erp' ), array( 'status' => 401 ) );
		}
		if ( $row->expires_on && $row->expires_on < current_time( 'Y-m-d' ) ) {
			return new WP_Error( 'wceerp_api_expired', __( 'This API key has expired.', 'wc-enterprise-erp' ), array( 'status' => 401 ) );
		}

		$limited = self::rate_limit( $row );
		if ( is_wp_error( $limited ) ) {
			return $limited;
		}

		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . wceerp_table( 'api_keys' ) . ' SET request_count = request_count + 1, last_used_at = %s, last_ip = %s WHERE id = %d',
			current_time( 'mysql' ),
			self::client_ip(),
			(int) $row->id
		) );

		return $row;
	}

	/** Fixed-window throttle, one counter per key per minute. */
	protected static function rate_limit( $row ) {
		$bucket = 'wceerp_rl_' . $row->key_id . '_' . gmdate( 'YmdHi' );
		$hits   = (int) get_transient( $bucket );
		$max    = max( 10, (int) $row->rate_limit );

		if ( $hits >= $max ) {
			return new WP_Error(
				'wceerp_api_rate_limited',
				sprintf(
					/* translators: %d: requests per minute. */
					__( 'Rate limit exceeded (%d requests per minute). Retry shortly.', 'wc-enterprise-erp' ),
					$max
				),
				array( 'status' => 429 )
			);
		}
		set_transient( $bucket, $hits + 1, MINUTE_IN_SECONDS * 2 );
		return true;
	}

	/**
	 * Permission callback factory for a required scope.
	 *
	 * @param string $scope e.g. 'pos:write'
	 * @return callable
	 */
	public static function require_scope( $scope ) {
		return function ( WP_REST_Request $request ) use ( $scope ) {
			$key = self::authenticate( $request );
			if ( is_wp_error( $key ) ) {
				return $key;
			}
			$granted = array_filter( array_map( 'trim', explode( ',', (string) $key->scopes ) ) );
			if ( ! in_array( $scope, $granted, true ) ) {
				return new WP_Error(
					'wceerp_api_forbidden',
					sprintf(
						/* translators: %s: scope name. */
						__( 'This key does not have the "%s" scope.', 'wc-enterprise-erp' ),
						$scope
					),
					array( 'status' => 403 )
				);
			}

			/* Run as the key's owner so capability-aware internals and audit
			 * attribution behave. Reset by REST teardown per request. */
			if ( $key->acts_as ) {
				wp_set_current_user( (int) $key->acts_as );
			}
			$request->set_param( '_wceerp_key_id', $key->key_id );
			return true;
		};
	}

	protected static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( $ip, 0, 45 );
	}

	/* ------------------------------------------------------------------
	 * Response envelope. Every public endpoint returns the same shape so
	 * integrators can write one error handler.
	 * ---------------------------------------------------------------- */

	public static function ok( $data, $meta = array() ) {
		return new WP_REST_Response( array_merge( array(
			'success' => true,
			'data'    => $data,
		), $meta ? array( 'meta' => $meta ) : array() ), 200 );
	}

	public static function fail( $code, $message, $status = 400 ) {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}
}
