<?php
/**
 * Global helpers: currency, Bangla numerals, fiscal year, formatting.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

function wceerp_get_option( $key, $default = null ) {
	$settings = get_option( 'wceerp_settings', array() );
	return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}

/**
 * Write several settings in one go.
 *
 * wceerp_update_option() does a full read-modify-write of the shared
 * settings option each time it is called. Saving a screen with twenty
 * fields therefore meant twenty of them, and any overlapping request --
 * an autosave, an AJAX call, a second admin -- could land between two and
 * silently drop everything written before it.
 *
 * @param array $pairs key => value
 * @return array Keys that did not read back, empty when all persisted.
 */
function wceerp_update_options( array $pairs ) {
	$settings = get_option( 'wceerp_settings', array() );
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}
	foreach ( $pairs as $key => $value ) {
		$settings[ $key ] = $value;
	}
	update_option( 'wceerp_settings', $settings );

	/* Read back and report anything that did not stick. A save that
	 * silently fails is worse than one that admits it. */
	$check  = get_option( 'wceerp_settings', array() );
	$failed = array();
	foreach ( $pairs as $key => $value ) {
		if ( ! isset( $check[ $key ] ) || $check[ $key ] !== $value ) {
			$failed[] = $key;
		}
	}
	return $failed;
}

function wceerp_update_option( $key, $value ) {
	$settings         = get_option( 'wceerp_settings', array() );
	$settings[ $key ] = $value;
	update_option( 'wceerp_settings', $settings );
}

/**
 * The date this ERP started keeping books ("go-live").
 *
 * Orders created before this date are deliberately invisible to the ERP:
 * they are not posted to the ledger and are excluded from ERP reports, so a
 * shop with years of WooCommerce history can start clean without its past
 * turnover appearing as if it happened under the ERP's watch.
 *
 * Defaults to the date the plugin was first activated. Empty string means
 * "no cutoff" (count everything), which is the legacy behaviour.
 *
 * @return string Y-m-d, or '' for no cutoff.
 */
function wceerp_start_date() {
	$mode = wceerp_get_option( 'history_mode', 'golive' );
	if ( 'all' === $mode ) {
		return '';
	}
	$date = (string) wceerp_get_option( 'start_date', '' );
	if ( ! $date ) {
		$date = (string) get_option( 'wceerp_installed_on', '' );
	}
	if ( ! $date ) {
		$date = current_time( 'Y-m-d' );
	}
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '';
}

/** True when an order predates the go-live date and must be ignored. */
function wceerp_is_pre_golive( $order ) {
	$start = wceerp_start_date();
	if ( ! $start ) {
		return false;
	}
	if ( is_numeric( $order ) ) {
		$order = wc_get_order( (int) $order );
	}
	if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
		return false;
	}
	$created = $order->get_date_created();
	if ( ! $created ) {
		return false;
	}
	return $created->date( 'Y-m-d' ) < $start;
}

/**
 * Format money. Supports BDT lakh/crore grouping (12,34,56,789.00)
 * and optional Bangla digits.
 */
function wceerp_money( $amount, $args = array() ) {
	$amount   = (float) $amount;
	$currency = isset( $args['currency'] ) ? $args['currency'] : get_woocommerce_currency();
	$symbol   = get_woocommerce_currency_symbol( $currency );
	$decimals = isset( $args['decimals'] ) ? (int) $args['decimals'] : 2;
	$style    = wceerp_get_option( 'number_grouping', 'BDT' === $currency ? 'lakh' : 'thousand' );

	$formatted = ( 'lakh' === $style )
		? wceerp_lakh_format( $amount, $decimals )
		: number_format( $amount, $decimals, '.', ',' );

	if ( 'yes' === wceerp_get_option( 'bangla_digits', 'no' ) ) {
		$formatted = wceerp_to_bangla_digits( $formatted );
	}

	return $symbol . $formatted;
}

/**
 * Indian/Bangladeshi lakh-crore number grouping.
 */
function wceerp_lakh_format( $number, $decimals = 2 ) {
	$negative = $number < 0;
	$number   = abs( (float) $number );
	$str      = number_format( $number, $decimals, '.', '' );
	$parts    = array_pad( explode( '.', $str ), 2, '' );
	$int      = $parts[0];
	$dec      = $parts[1];

	$last3 = strlen( $int ) > 3 ? substr( $int, -3 ) : $int;
	$rest  = strlen( $int ) > 3 ? substr( $int, 0, -3 ) : '';
	if ( '' !== $rest ) {
		$rest  = preg_replace( '/\B(?=(\d{2})+(?!\d))/', ',', $rest );
		$last3 = $rest . ',' . $last3;
	}
	$out = $last3 . ( $decimals > 0 ? '.' . $dec : '' );
	return ( $negative ? '-' : '' ) . $out;
}

/**
 * Convert Western digits to Bangla numerals.
 */
function wceerp_to_bangla_digits( $string ) {
	$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
	$bn = array( '০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯' );
	return str_replace( $en, $bn, (string) $string );
}

/**
 * Fiscal year boundaries. Bangladesh default: 1 July – 30 June.
 */
function wceerp_fiscal_year( $date = null ) {
	$start_month = (int) wceerp_get_option( 'fiscal_year_start_month', 7 );
	$ts          = $date ? strtotime( $date ) : current_time( 'timestamp' );
	$year        = (int) date( 'Y', $ts );
	$month       = (int) date( 'n', $ts );

	$fy_start_year = ( $month >= $start_month ) ? $year : $year - 1;
	$start         = sprintf( '%d-%02d-01', $fy_start_year, $start_month );
	$end           = date( 'Y-m-d', strtotime( $start . ' +1 year -1 day' ) );
	$label         = ( 1 === $start_month )
		? (string) $fy_start_year
		: $fy_start_year . '-' . substr( (string) ( $fy_start_year + 1 ), -2 );

	return array( 'start' => $start, 'end' => $end, 'label' => $label );
}

function wceerp_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'erp_' . $name;
}

function wceerp_user_can( $cap ) {
	return current_user_can( 'manage_woocommerce' ) || current_user_can( $cap );
}

/**
 * Sequential document numbers, e.g. PO-2526-000041, scoped per fiscal year.
 */
/**
 * Consignment numbers.
 *
 * Kept separate from wceerp_next_doc_number() because couriers and customers
 * read these aloud, so the format matters commercially. The sequence resets
 * with the period in the pattern, which is why the counter key embeds it.
 *
 * Patterns:
 *   ym  PDL-2026-7-0001    prefix, year, month, sequence (resets monthly)
 *   ymm PDL-2026-07-0001   same with a padded month
 *   y   PDL-2026-0001      prefix, year, sequence (resets yearly)
 *   fy  CN-2627-000001     legacy fiscal-year format
 *
 * @param bool $peek Preview the next number without consuming it.
 */
function wceerp_next_consignment_number( $peek = false ) {
	$prefix  = strtoupper( trim( (string) wceerp_get_option( 'cn_prefix', 'CN' ) ) );
	$prefix  = preg_replace( '/[^A-Z0-9]/', '', $prefix );
	$prefix  = $prefix ? $prefix : 'CN';
	$pattern = (string) wceerp_get_option( 'cn_pattern', 'ym' );
	$pad     = max( 1, min( 8, (int) wceerp_get_option( 'cn_pad', 4 ) ) );

	$year  = (int) current_time( 'Y' );
	$month = (int) current_time( 'n' );

	switch ( $pattern ) {
		case 'y':
			$period = (string) $year;
			$middle = (string) $year;
			break;
		case 'ymm':
			$period = $year . sprintf( '%02d', $month );
			$middle = $year . '-' . sprintf( '%02d', $month );
			break;
		case 'fy':
			$fy      = wceerp_fiscal_year();
			$period  = $fy['label'];
			$middle  = str_replace( '-', '', substr( $fy['label'], 2 ) );
			$pad     = 6;
			break;
		case 'ym':
		default:
			$period = $year . '-' . $month;
			$middle = $year . '-' . $month;
			break;
	}

	$key  = 'wceerp_seq_cn_' . $prefix . '_' . $period;
	$next = (int) get_option( $key, 0 ) + 1;
	if ( ! $peek ) {
		update_option( $key, $next, false );
	}

	return $prefix . '-' . $middle . '-' . str_pad( $next, $pad, '0', STR_PAD_LEFT );
}

/** True when a consignment number is already taken. */
function wceerp_consignment_number_exists( $doc_no ) {
	global $wpdb;
	return (bool) $wpdb->get_var( $wpdb->prepare(
		'SELECT id FROM ' . wceerp_table( 'consignments' ) . ' WHERE doc_no = %s LIMIT 1',
		$doc_no
	) );
}

function wceerp_next_doc_number( $type ) {
	$fy      = wceerp_fiscal_year();
	$key     = 'wceerp_seq_' . $type . '_' . $fy['label'];
	$next    = (int) get_option( $key, 0 ) + 1;
	update_option( $key, $next, false );
	$fy_code = str_replace( '-', '', substr( $fy['label'], 2 ) );
	return strtoupper( $type ) . '-' . $fy_code . '-' . str_pad( $next, 6, '0', STR_PAD_LEFT );
}

function wceerp_dec( $value ) {
	return round( (float) str_replace( ',', '', (string) $value ), 4 );
}

function wceerp_log( $module, $action, $ref_id = 0, $note = '' ) {
	global $wpdb;
	$wpdb->insert(
		wceerp_table( 'audit_log' ),
		array(
			'module'     => sanitize_key( $module ),
			'action'     => sanitize_key( $action ),
			'ref_id'     => (int) $ref_id,
			'note'       => sanitize_text_field( $note ),
			'user_id'    => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		)
	);
}

/**
 * Current page number for paginated lists.
 */
function wceerp_paged() {
	return isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
}

/**
 * SQL OFFSET for the current page.
 */
function wceerp_offset( $per_page ) {
	return ( wceerp_paged() - 1 ) * max( 1, (int) $per_page );
}

/**
 * Render pagination links under a list table, preserving current filters.
 */
function wceerp_pagination( $total, $per_page ) {
	$pages = (int) ceil( (int) $total / max( 1, (int) $per_page ) );
	if ( $pages < 2 ) {
		return;
	}
	$links = paginate_links( array(
		'base'      => add_query_arg( 'paged', '%#%' ),
		'format'    => '',
		'current'   => wceerp_paged(),
		'total'     => $pages,
		'type'      => 'plain',
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;',
	) );
	if ( $links ) {
		printf(
			'<div class="tablenav"><div class="tablenav-pages"><span class="displaying-num">%s</span> %s</div></div>',
			esc_html( sprintf( /* translators: %s: item count */ _n( '%s item', '%s items', $total, 'wc-enterprise-erp' ), number_format_i18n( $total ) ) ),
			wp_kses_post( $links )
		);
	}
}

/**
 * Render a WooCommerce AJAX product-search <select>.
 * Replaces raw product-ID inputs across the ERP screens.
 */
function wceerp_product_select( $name, $selected = 0, $args = array() ) {
	$defaults = array(
		'placeholder' => __( 'Search product by name or SKU…', 'wc-enterprise-erp' ),
		'required'    => false,
		'class'       => '',
		'id'          => '',
	);
	$args = wp_parse_args( $args, $defaults );

	printf(
		'<select class="wc-product-search wceerp-product-search %s" %s name="%s" data-placeholder="%s" data-action="woocommerce_json_search_products_and_variations" data-allow_clear="true" style="width:100%%;min-width:200px" %s>',
		esc_attr( $args['class'] ),
		$args['id'] ? 'id="' . esc_attr( $args['id'] ) . '"' : '',
		esc_attr( $name ),
		esc_attr( $args['placeholder'] ),
		$args['required'] ? 'required' : ''
	);
	$selected = (int) $selected;
	if ( $selected && function_exists( 'wc_get_product' ) ) {
		$product = wc_get_product( $selected );
		if ( $product ) {
			printf( '<option value="%d" selected>%s</option>', $selected, esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) );
		}
	}
	echo '</select>';
}


/**
 * A hex colour, validated.
 *
 * WordPress's own sanitize_hex_color() lives in the customiser and is not
 * loaded on every request — admin-post.php among them. Calling it there is
 * fatal, and a fatal inside a print handler shows as a blank page with
 * nothing to explain it, which is how the invoice and challan links came to
 * open onto nothing.
 *
 * @param string $colour e.g. #1a2b3c
 * @return string The colour, or '' if it is not one.
 */
function wceerp_hex_colour( $colour ) {
	if ( function_exists( 'sanitize_hex_color' ) ) {
		return (string) sanitize_hex_color( $colour );
	}
	$colour = trim( (string) $colour );
	return preg_match( '/^#([A-Fa-f0-9]{3}){1,2}$/', $colour ) ? $colour : '';
}
