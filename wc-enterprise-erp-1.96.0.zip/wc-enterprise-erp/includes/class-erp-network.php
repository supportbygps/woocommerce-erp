<?php
/**
 * Multi-Company — network layer.
 *
 * The multi-company model IS WordPress Multisite: one installation,
 * unlimited companies, and every company's accounting, inventory,
 * warehouses, users, tax and dashboards are isolated by construction
 * (each site owns its own wp_N_erp_* tables). This class adds the one
 * thing isolation can't give you: a group view. Network Admin →
 * Companies shows month revenue, profit, inventory value and COD
 * exposure per company, side by side.
 *
 * Honest scope note: cross-company consolidation journals (eliminating
 * inter-company sales for a statutory group balance sheet) are an
 * accountant-level feature and stay on the roadmap; this dashboard is a
 * management comparison, not a consolidated statement.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Network {

	public static function boot() {
		add_action( 'network_admin_menu', array( __CLASS__, 'menu' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'ERP Companies', 'wc-enterprise-erp' ),
			__( 'ERP Companies', 'wc-enterprise-erp' ),
			'manage_network',
			'wceerp-companies',
			array( __CLASS__, 'render' ),
			'dashicons-building',
			3
		);
		add_submenu_page(
			'wceerp-companies',
			__( 'ERP Tenants', 'wc-enterprise-erp' ),
			__( 'Tenants (SaaS)', 'wc-enterprise-erp' ),
			'manage_network',
			'wceerp-tenants',
			array( __CLASS__, 'render_tenants' )
		);
		add_submenu_page(
			'wceerp-companies',
			__( 'All Companies Overview', 'wc-enterprise-erp' ),
			__( 'Overview (all)', 'wc-enterprise-erp' ),
			'manage_network',
			'wceerp-overview',
			array( __CLASS__, 'render_overview' )
		);
	}

	/**
	 * Cross-tenant overview: one row per company with its headline numbers,
	 * so the operator can see the whole book of business at a glance.
	 *
	 * Each tenant's figures are read by switching into its site and asking
	 * the same accounting engine the tenant sees, so the numbers here and
	 * inside a tenant always agree.
	 */
	public static function render_overview() {
		if ( ! current_user_can( 'manage_network' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		$from = isset( $_GET['from'] ) ? sanitize_text_field( $_GET['from'] ) : gmdate( 'Y-m-01' );
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( $_GET['to'] ) : gmdate( 'Y-m-d' );

		$sites = get_sites( array( 'number' => 200, 'archived' => 0, 'deleted' => 0 ) );
		$rows  = array();
		$tot_income = 0.0;
		$tot_expense = 0.0;

		foreach ( $sites as $site ) {
			$blog_id = (int) $site->blog_id;
			switch_to_blog( $blog_id );

			$income  = 0.0;
			$expense = 0.0;
			$connected = '';
			if ( class_exists( 'WCEERP_Accounting' ) ) {
				// type_balances() returns arrays of account rows per type;
				// sum each type's 'amount' to get the headline figure.
				$balances = WCEERP_Accounting::type_balances( $from, $to );
				if ( ! empty( $balances['income'] ) ) {
					foreach ( $balances['income'] as $line ) {
						$income += (float) $line['amount'];
					}
				}
				if ( ! empty( $balances['expense'] ) ) {
					foreach ( $balances['expense'] as $line ) {
						$expense += (float) $line['amount'];
					}
				}
			}
			$health = array( 'state' => 'unconfigured', 'label' => '' );
			if ( class_exists( 'WCEERP_Module_Connect' ) ) {
				if ( WCEERP_Module_Connect::is_configured() ) {
					$connected = wceerp_get_option( 'connect_url', '' );
				}
				$health = WCEERP_Module_Connect::health();
			}

			$rows[] = array(
				'blog_id'   => $blog_id,
				'name'      => get_bloginfo( 'name' ),
				'url'       => get_home_url( $blog_id ),
				'tier'      => get_option( 'wceerp_saas_tier', '—' ),
				'expires'   => get_option( 'wceerp_saas_expires', '' ),
				'income'    => $income,
				'expense'   => $expense,
				'profit'    => $income - $expense,
				'connected' => $connected,
				'last_sync' => wceerp_get_option( 'connect_last_run', '' ),
				'sync_err'  => wceerp_get_option( 'connect_last_error', '' ),
				'health'    => $health,
			);
			$tot_income  += $income;
			$tot_expense += $expense;
			restore_current_blog();
		}

		usort( $rows, function ( $a, $b ) {
			return $b['profit'] <=> $a['profit'];
		} );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'All Companies — Overview', 'wc-enterprise-erp' ); ?></h1>
			<form method="get" style="margin:12px 0;display:flex;gap:8px;align-items:flex-end">
				<input type="hidden" name="page" value="wceerp-overview">
				<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
				<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
				<button class="button button-primary"><?php esc_html_e( 'Apply', 'wc-enterprise-erp' ); ?></button>
			</form>

			<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:16px">
				<div style="background:#fff;border:1px solid #dcdcd4;border-radius:10px;padding:14px 18px">
					<div style="color:#777;font-size:12px"><?php esc_html_e( 'Companies', 'wc-enterprise-erp' ); ?></div>
					<strong style="font-size:22px"><?php echo (int) count( $rows ); ?></strong>
				</div>
				<div style="background:#fff;border:1px solid #dcdcd4;border-radius:10px;padding:14px 18px">
					<div style="color:#777;font-size:12px"><?php esc_html_e( 'Combined income', 'wc-enterprise-erp' ); ?></div>
					<strong style="font-size:22px;color:#075742"><?php echo esc_html( number_format( $tot_income, 2 ) ); ?></strong>
				</div>
				<div style="background:#fff;border:1px solid #dcdcd4;border-radius:10px;padding:14px 18px">
					<div style="color:#777;font-size:12px"><?php esc_html_e( 'Combined expenses', 'wc-enterprise-erp' ); ?></div>
					<strong style="font-size:22px;color:#c8302e"><?php echo esc_html( number_format( $tot_expense, 2 ) ); ?></strong>
				</div>
				<div style="background:#fff;border:1px solid #dcdcd4;border-radius:10px;padding:14px 18px">
					<div style="color:#777;font-size:12px"><?php esc_html_e( 'Combined profit', 'wc-enterprise-erp' ); ?></div>
					<strong style="font-size:22px"><?php echo esc_html( number_format( $tot_income - $tot_expense, 2 ) ); ?></strong>
				</div>
			</div>

			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Company', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Package', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Connected store', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Income', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Expenses', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $r['name'] ); ?></strong><br><small><?php echo esc_html( $r['url'] ); ?></small></td>
						<td><?php echo esc_html( ucfirst( $r['tier'] ) ); ?><?php echo $r['expires'] ? '<br><small>' . esc_html( $r['expires'] ) . '</small>' : ''; ?></td>
						<td>
							<?php
							if ( $r['connected'] ) :
								$state  = $r['health']['state'];
								$colour = 'ok' === $state ? '#2f8a4c' : ( 'failing' === $state ? '#c8302e' : '#b98a2f' );
								?>
								<span style="color:<?php echo esc_attr( $colour ); ?>">●</span>
								<?php echo esc_html( wp_parse_url( $r['connected'], PHP_URL_HOST ) ); ?>
								<br><small style="color:<?php echo esc_attr( $colour ); ?>"><?php echo esc_html( $r['health']['label'] ); ?></small>
								<?php if ( ! empty( $r['health']['error'] ) ) : ?>
									<br><small style="color:#c8302e"><?php echo esc_html( wp_trim_words( $r['health']['error'], 12 ) ); ?></small>
								<?php endif; ?>
							<?php else : ?>
								<span style="color:#bbb">—</span>
							<?php endif; ?>
						</td>
						<td style="text-align:right"><?php echo esc_html( number_format( $r['income'], 2 ) ); ?></td>
						<td style="text-align:right"><?php echo esc_html( number_format( $r['expense'], 2 ) ); ?></td>
						<td style="text-align:right;font-weight:600;color:<?php echo $r['profit'] >= 0 ? '#2f8a4c' : '#c8302e'; ?>"><?php echo esc_html( number_format( $r['profit'], 2 ) ); ?></td>
						<td><a class="button button-small" href="<?php echo esc_url( get_admin_url( $r['blog_id'], 'admin.php?page=wceerp' ) ); ?>"><?php esc_html_e( 'Open ERP', 'wc-enterprise-erp' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Figures come from each company\'s own ledger for the selected date range.', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * SaaS Tenant Manager.
	 * Each tenant = a site. Package, expiry, custom domain and suspension
	 * are operator actions here; tenants never see license keys.
	 * ------------------------------------------------------------------- */

	protected static function handle_tenant_actions() {
		if ( empty( $_POST['wceerp_tenant_action'] ) || ! current_user_can( 'manage_network' ) ) {
			return '';
		}
		check_admin_referer( 'wceerp_tenants' );
		$action = sanitize_key( $_POST['wceerp_tenant_action'] );
		$tiers  = array( 'starter', 'business', 'enterprise' );

		if ( 'create' === $action ) {
			$slug  = sanitize_key( $_POST['slug'] ?? '' );
			$title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
			$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
			$tier  = in_array( $_POST['tier'] ?? '', $tiers, true ) ? $_POST['tier'] : 'starter';
			if ( ! $slug || ! $title || ! is_email( $email ) ) {
				return __( 'Slug, name and a valid email are required.', 'wc-enterprise-erp' );
			}
			$user = get_user_by( 'email', $email );
			if ( ! $user ) {
				$user_id = wp_create_user( sanitize_user( str_replace( '@', '_', $email ), true ), wp_generate_password( 16 ), $email );
				if ( is_wp_error( $user_id ) ) {
					return $user_id->get_error_message();
				}
				wp_new_user_notification( $user_id, null, 'user' ); // password set link.
			} else {
				$user_id = $user->ID;
			}
			$network = get_network();
			if ( is_subdomain_install() ) {
				$domain = $slug . '.' . preg_replace( '/^www\./', '', $network->domain );
				$path   = '/';
			} else {
				$domain = $network->domain;
				$path   = trailingslashit( $network->path . $slug );
			}
			$blog_id = wpmu_create_blog( $domain, $path, $title, $user_id, array( 'public' => 1 ), $network->id );
			if ( is_wp_error( $blog_id ) ) {
				return $blog_id->get_error_message();
			}
			update_blog_option( $blog_id, 'wceerp_saas_tier', $tier );
			update_blog_option( $blog_id, 'wceerp_company_name', $title );
			if ( ! empty( $_POST['expires'] ) ) {
				update_blog_option( $blog_id, 'wceerp_saas_expires', sanitize_text_field( $_POST['expires'] ) );
			}
			return sprintf( __( 'Tenant created (site #%d). The admin received a password-setup email.', 'wc-enterprise-erp' ), $blog_id );
		}

		$blog_id = (int) ( $_POST['blog_id'] ?? 0 );
		if ( ! $blog_id ) {
			return __( 'Missing site.', 'wc-enterprise-erp' );
		}

		if ( 'update' === $action ) {
			$tier = in_array( $_POST['tier'] ?? '', $tiers, true ) ? $_POST['tier'] : 'starter';
			update_blog_option( $blog_id, 'wceerp_saas_tier', $tier );
			update_blog_option( $blog_id, 'wceerp_saas_expires', sanitize_text_field( $_POST['expires'] ?? '' ) );

			// Per-tenant usage limits (blank = use package default).
			foreach ( array( 'users', 'products', 'orders_month' ) as $resource ) {
				$key = 'limit_' . $resource;
				if ( isset( $_POST[ $key ] ) ) {
					$raw = trim( (string) wp_unslash( $_POST[ $key ] ) );
					if ( '' === $raw ) {
						delete_blog_option( $blog_id, 'wceerp_limit_' . $resource );
					} else {
						update_blog_option( $blog_id, 'wceerp_limit_' . $resource, max( 0, (int) $raw ) );
					}
				}
			}

			// Per-tenant feature overrides (module_id => on|off|'').
			if ( isset( $_POST['feature'] ) && is_array( $_POST['feature'] ) ) {
				$overrides = array();
				foreach ( $_POST['feature'] as $mod => $state ) {
					$state = sanitize_key( $state );
					if ( in_array( $state, array( 'on', 'off' ), true ) ) {
						$overrides[ sanitize_key( $mod ) ] = $state;
					}
				}
				update_blog_option( $blog_id, 'wceerp_feature_overrides', $overrides );
			}

			$domain = strtolower( trim( (string) wp_unslash( $_POST['custom_domain'] ?? '' ) ) );
			$domain = preg_replace( '#^https?://#', '', rtrim( $domain, '/' ) );
			if ( $domain && ! is_main_site( $blog_id ) ) {
				if ( ! preg_match( '/^(?!-)[a-z0-9-]{1,63}(?<!-)(\.[a-z0-9-]{1,63})+$/', $domain ) ) {
					return __( 'That does not look like a valid domain.', 'wc-enterprise-erp' );
				}
				update_blog_details( $blog_id, array( 'domain' => $domain, 'path' => '/' ) );
				switch_to_blog( $blog_id );
				update_option( 'siteurl', 'https://' . $domain );
				update_option( 'home', 'https://' . $domain );
				restore_current_blog();
				return sprintf( __( 'Saved. %s is now the tenant address — make sure DNS points here and SSL is issued (see the help box).', 'wc-enterprise-erp' ), $domain );
			}
			return __( 'Tenant updated.', 'wc-enterprise-erp' );
		}

		if ( 'suspend' === $action || 'unsuspend' === $action ) {
			if ( is_main_site( $blog_id ) ) {
				return __( 'Refusing to suspend the main site.', 'wc-enterprise-erp' );
			}
			update_blog_status( $blog_id, 'archived', 'suspend' === $action ? 1 : 0 );
			return 'suspend' === $action
				? __( 'Tenant suspended — site archived, data intact.', 'wc-enterprise-erp' )
				: __( 'Tenant reactivated.', 'wc-enterprise-erp' );
		}
		return '';
	}

	public static function render_tenants() {
		$notice = self::handle_tenant_actions();
		$sites  = get_sites( array( 'number' => 200 ) );
		$tiers  = array( 'starter' => 'Starter', 'business' => 'Business', 'enterprise' => 'Enterprise' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ERP Tenants — SaaS control panel', 'wc-enterprise-erp' ); ?></h1>
			<?php if ( $notice ) : ?>
				<div class="notice notice-info is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>

			<div style="display:flex;gap:20px;flex-wrap:wrap;align-items:flex-start">
				<div style="flex:1;min-width:340px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px">
					<h2 style="margin-top:0"><?php esc_html_e( 'New tenant', 'wc-enterprise-erp' ); ?></h2>
					<form method="post">
						<?php wp_nonce_field( 'wceerp_tenants' ); ?>
						<input type="hidden" name="wceerp_tenant_action" value="create">
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Slug', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="slug" required placeholder="rahmantraders" pattern="[a-z0-9-]+">
								<p class="description"><?php esc_html_e( 'Provisioning address only — map their real domain after creation.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Business name', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="title" class="regular-text" required></td></tr>
							<tr><th><?php esc_html_e( 'Owner email', 'wc-enterprise-erp' ); ?></th>
								<td><input type="email" name="email" class="regular-text" required>
								<p class="description"><?php esc_html_e( 'They get a password-setup email automatically.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Package', 'wc-enterprise-erp' ); ?></th>
								<td><select name="tier">
									<?php foreach ( $tiers as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select></td></tr>
							<tr><th><?php esc_html_e( 'Paid until', 'wc-enterprise-erp' ); ?></th>
								<td><input type="date" name="expires">
								<p class="description"><?php esc_html_e( 'Past this date the tenant drops to Starter (data intact) until renewed.', 'wc-enterprise-erp' ); ?></p></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Create tenant', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div style="flex:1;min-width:340px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:8px;padding:16px">
					<h2 style="margin-top:0"><?php esc_html_e( 'Custom domain checklist', 'wc-enterprise-erp' ); ?></h2>
					<ol style="line-height:1.9;margin-left:18px">
						<li><?php esc_html_e( "Customer points an A record for their domain (and www) at this server's IP.", 'wc-enterprise-erp' ); ?></li>
						<li><?php esc_html_e( "Add the domain to the web server / hosting panel so it answers for it, and issue SSL (Let's Encrypt — panels like CloudPanel/RunCloud/cPanel or Caddy do this in one click; with plain nginx: certbot --nginx -d domain -d www.domain).", 'wc-enterprise-erp' ); ?></li>
						<li><?php esc_html_e( "Paste the domain into the tenant's row below and save — WordPress serves them on it immediately. No sunrise.php or mapping plugin needed.", 'wc-enterprise-erp' ); ?></li>
					</ol>
					<p class="description"><?php esc_html_e( "Tip: keep the provisioning subdomain alive in DNS as a fallback while the customer's DNS propagates.", 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>

			<h2 style="margin-top:26px"><?php esc_html_e( 'Tenants', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Tenant', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Package / paid until / custom domain', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $sites as $site ) :
					$blog_id = (int) $site->blog_id;
					if ( is_main_site( $blog_id ) ) {
						continue;
					}
					$tier     = get_blog_option( $blog_id, 'wceerp_saas_tier', 'starter' );
					$expires  = get_blog_option( $blog_id, 'wceerp_saas_expires', '' );
					$name     = get_blog_option( $blog_id, 'wceerp_company_name', '' ) ?: get_blog_option( $blog_id, 'blogname', '' );
					$archived = (bool) (int) $site->archived;
					$expired  = $expires && $expires < current_time( 'Y-m-d' );
					?>
					<tr>
						<td><strong><?php echo esc_html( $name ); ?></strong><br><small>#<?php echo (int) $blog_id; ?> · <a href="<?php echo esc_url( get_admin_url( $blog_id ) ); ?>"><?php esc_html_e( 'open admin', 'wc-enterprise-erp' ); ?></a></small></td>
						<td><a href="<?php echo esc_url( 'https://' . $site->domain . $site->path ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $site->domain . rtrim( $site->path, '/' ) ); ?></a></td>
						<td>
							<form method="post" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
								<?php wp_nonce_field( 'wceerp_tenants' ); ?>
								<input type="hidden" name="wceerp_tenant_action" value="update">
								<input type="hidden" name="blog_id" value="<?php echo (int) $blog_id; ?>">
								<select name="tier">
									<?php foreach ( $tiers as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $tier, $value ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
								<input type="date" name="expires" value="<?php echo esc_attr( $expires ); ?>">
								<input type="text" name="custom_domain" placeholder="<?php esc_attr_e( 'their-domain.com', 'wc-enterprise-erp' ); ?>" style="width:170px">
								<?php
								$lim_users    = get_blog_option( $blog_id, 'wceerp_limit_users', '' );
								$lim_products = get_blog_option( $blog_id, 'wceerp_limit_products', '' );
								$lim_orders   = get_blog_option( $blog_id, 'wceerp_limit_orders_month', '' );
								$overrides    = (array) get_blog_option( $blog_id, 'wceerp_feature_overrides', array() );
								$features     = array( 'pos' => 'POS', 'hr' => 'HR & Payroll', 'ai' => 'Assistant', 'crm' => 'CRM', 'service' => 'Service', 'api' => 'Mobile API', 'branches' => 'Multi-branch', 'analytics' => 'Analytics', 'banking' => 'Banking', 'procurement' => 'RFQ/Approvals', 'dealers' => 'Dealers', 'whitelabel' => 'White label' );
								?>
								<details style="width:100%">
									<summary style="cursor:pointer;color:#2271b1"><?php esc_html_e( 'Limits & features', 'wc-enterprise-erp' ); ?></summary>
									<div style="padding:8px 0;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
										<label><?php esc_html_e( 'Users', 'wc-enterprise-erp' ); ?><br><input type="number" min="0" name="limit_users" value="<?php echo esc_attr( $lim_users ); ?>" placeholder="<?php esc_attr_e( 'default', 'wc-enterprise-erp' ); ?>" style="width:80px"></label>
										<label><?php esc_html_e( 'Products', 'wc-enterprise-erp' ); ?><br><input type="number" min="0" name="limit_products" value="<?php echo esc_attr( $lim_products ); ?>" placeholder="<?php esc_attr_e( 'default', 'wc-enterprise-erp' ); ?>" style="width:90px"></label>
										<label><?php esc_html_e( 'Orders/mo', 'wc-enterprise-erp' ); ?><br><input type="number" min="0" name="limit_orders_month" value="<?php echo esc_attr( $lim_orders ); ?>" placeholder="<?php esc_attr_e( 'default', 'wc-enterprise-erp' ); ?>" style="width:90px"></label>
										<span style="color:#888;font-size:11px"><?php esc_html_e( '(blank = package default · 0 = unlimited)', 'wc-enterprise-erp' ); ?></span>
									</div>
									<div style="padding:4px 0 8px">
										<strong style="font-size:12px"><?php esc_html_e( 'Feature overrides (beyond tier):', 'wc-enterprise-erp' ); ?></strong>
										<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:4px;margin-top:5px">
											<?php foreach ( $features as $mod => $label ) :
												$cur = $overrides[ $mod ] ?? '';
												?>
												<span style="font-size:12px"><?php echo esc_html( $label ); ?>:
													<select name="feature[<?php echo esc_attr( $mod ); ?>]" style="font-size:11px">
														<option value="" <?php selected( $cur, '' ); ?>><?php esc_html_e( 'tier', 'wc-enterprise-erp' ); ?></option>
														<option value="on" <?php selected( $cur, 'on' ); ?>><?php esc_html_e( 'on', 'wc-enterprise-erp' ); ?></option>
														<option value="off" <?php selected( $cur, 'off' ); ?>><?php esc_html_e( 'off', 'wc-enterprise-erp' ); ?></option>
													</select>
												</span>
											<?php endforeach; ?>
										</div>
									</div>
								</details>
								<button class="button button-small"><?php esc_html_e( 'Save', 'wc-enterprise-erp' ); ?></button>
							</form>
							<?php if ( $expired ) : ?><small style="color:#b32d2e"><strong><?php esc_html_e( 'Expired → serving Starter', 'wc-enterprise-erp' ); ?></strong></small><?php endif; ?>
						</td>
						<td>
							<form method="post">
								<?php wp_nonce_field( 'wceerp_tenants' ); ?>
								<input type="hidden" name="wceerp_tenant_action" value="<?php echo $archived ? 'unsuspend' : 'suspend'; ?>">
								<input type="hidden" name="blog_id" value="<?php echo (int) $blog_id; ?>">
								<?php if ( $archived ) : ?>
									<span style="color:#b32d2e;font-weight:600"><?php esc_html_e( 'Suspended', 'wc-enterprise-erp' ); ?></span><br>
									<button class="button button-small"><?php esc_html_e( 'Reactivate', 'wc-enterprise-erp' ); ?></button>
								<?php else : ?>
									<span style="color:#00701f;font-weight:600"><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></span><br>
									<button class="button button-small" onclick="return confirm('<?php echo esc_js( __( 'Suspend this tenant? The site goes offline; all data stays intact.', 'wc-enterprise-erp' ) ); ?>')"><?php esc_html_e( 'Suspend', 'wc-enterprise-erp' ); ?></button>
								<?php endif; ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/** Month KPIs for the CURRENT blog — called inside switch_to_blog(). */
	protected static function site_kpis() {
		global $wpdb;
		$tables = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . 'erp_journals' ) );
		if ( ! $tables ) {
			return null; // ERP not installed on this site.
		}
		$month = gmdate( 'Y-m-01' );
		$jl    = $wpdb->prefix . 'erp_journal_lines';
		$j     = $wpdb->prefix . 'erp_journals';
		$acc   = $wpdb->prefix . 'erp_accounts';

		$pnl = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.type, SUM(l.debit) d, SUM(l.credit) c
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id=l.account_id
			 WHERE jr.journal_date >= %s AND a.type IN ('income','expense')
			 GROUP BY a.type", $month
		) );
		$income = $expense = 0.0;
		foreach ( (array) $pnl as $row ) {
			if ( 'income' === $row->type ) {
				$income = (float) $row->c - (float) $row->d;
			} else {
				$expense = (float) $row->d - (float) $row->c;
			}
		}
		$stock = (float) $wpdb->get_var( "SELECT COALESCE(SUM(qty*avg_cost),0) FROM {$wpdb->prefix}erp_stock" );
		$cod   = (float) $wpdb->get_var(
			"SELECT COALESCE(SUM(l.debit-l.credit),0)
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id=l.account_id AND a.code='1110'"
		);
		return array(
			'company' => get_option( 'wceerp_company_name', get_bloginfo( 'name' ) ) ?: get_bloginfo( 'name' ),
			'income'  => $income,
			'expense' => $expense,
			'profit'  => $income - $expense,
			'stock'   => $stock,
			'cod'     => $cod,
		);
	}

	public static function render() {
		$sites = get_sites( array( 'number' => 100 ) );
		$rows  = array();
		foreach ( $sites as $site ) {
			switch_to_blog( (int) $site->blog_id );
			$kpis = self::site_kpis();
			if ( $kpis ) {
				$kpis['blog_id']   = (int) $site->blog_id;
				$kpis['admin_url'] = get_admin_url( (int) $site->blog_id, 'admin.php?page=wceerp-dashboard' );
				$rows[]            = $kpis;
			}
			restore_current_blog();
		}
		usort( $rows, function ( $a, $b ) { return $b['income'] <=> $a['income']; } );
		$totals = array( 'income' => 0, 'expense' => 0, 'profit' => 0, 'stock' => 0, 'cod' => 0 );
		foreach ( $rows as $row ) {
			foreach ( $totals as $key => $value ) {
				$totals[ $key ] += $row[ $key ];
			}
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ERP Companies — this month, side by side', 'wc-enterprise-erp' ); ?></h1>
			<p class="description"><?php esc_html_e( 'Each company is a site with a fully isolated ERP (own accounts, stock, users, tax). Add a company: Network Admin → Sites → Add New — the ERP installs itself on creation.', 'wc-enterprise-erp' ); ?></p>
			<table class="widefat striped" style="max-width:1000px;margin-top:14px">
				<thead><tr>
					<th><?php esc_html_e( 'Company', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Revenue', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Expenses', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'Inventory', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php esc_html_e( 'COD held', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No sites with the ERP installed yet.', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( $row['admin_url'] ); ?>"><strong><?php echo esc_html( $row['company'] ); ?></strong></a> <small>#<?php echo (int) $row['blog_id']; ?></small></td>
						<td style="text-align:right"><?php echo wp_kses_post( wceerp_money( $row['income'] ) ); ?></td>
						<td style="text-align:right"><?php echo wp_kses_post( wceerp_money( $row['expense'] ) ); ?></td>
						<td style="text-align:right;color:<?php echo $row['profit'] >= 0 ? '#00701f' : '#b32d2e'; ?>"><strong><?php echo wp_kses_post( wceerp_money( $row['profit'] ) ); ?></strong></td>
						<td style="text-align:right"><?php echo wp_kses_post( wceerp_money( $row['stock'] ) ); ?></td>
						<td style="text-align:right"><?php echo wp_kses_post( wceerp_money( $row['cod'] ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr>
					<th><?php esc_html_e( 'Group total', 'wc-enterprise-erp' ); ?></th>
					<th style="text-align:right"><?php echo wp_kses_post( wceerp_money( $totals['income'] ) ); ?></th>
					<th style="text-align:right"><?php echo wp_kses_post( wceerp_money( $totals['expense'] ) ); ?></th>
					<th style="text-align:right"><?php echo wp_kses_post( wceerp_money( $totals['profit'] ) ); ?></th>
					<th style="text-align:right"><?php echo wp_kses_post( wceerp_money( $totals['stock'] ) ); ?></th>
					<th style="text-align:right"><?php echo wp_kses_post( wceerp_money( $totals['cod'] ) ); ?></th>
				</tr></tfoot>
			</table>
		</div>
		<?php
	}
}
