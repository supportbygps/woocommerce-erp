<?php
/**
 * WooCommerce bridge.
 *
 * Turns WooCommerce order events into ERP facts:
 *  - processing/completed  → sales journal (Revenue + VAT output), COGS,
 *    warehouse stock deduction, serial allocation, reseller commission.
 *  - unpaid orders post to Accounts Receivable per customer (Customer Due).
 *  - refunds reverse the sale.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_WC_Bridge {

	public static function init() {
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'post_sale' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'post_sale' ), 20 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'reverse_sale' ), 20 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'reverse_sale' ), 20 );
	}

	/** Default warehouse id. */
	public static function default_warehouse() {
		global $wpdb;
		$table = wceerp_table( 'warehouses' );
		$id    = (int) $wpdb->get_var( "SELECT id FROM $table WHERE is_default = 1 LIMIT 1" );
		return $id ? $id : (int) $wpdb->get_var( "SELECT id FROM $table ORDER BY id ASC LIMIT 1" );
	}

	/**
	 * Post the sales journal + stock movements once per order.
	 */
	/** Set while the courier module triggers a booking-time posting. */
	protected static $forced = false;

	/**
	 * When a sale should hit stock and the ledger.
	 *
	 * 'processing'     as soon as the order is paid/accepted (default,
	 *                  and how every earlier version behaved)
	 * 'completed'      only when the order is marked completed
	 * 'courier_booked' when the parcel is actually handed to a courier
	 *
	 * Stock and the ledger move together on purpose. Deducting stock at
	 * placement while recognising revenue and COGS later — or vice versa —
	 * would break the matching principle and leave the P&L wrong for the
	 * period, which is far worse than the timing being slightly early.
	 */
	public static function post_trigger() {
		$t = (string) wceerp_get_option( 'sale_post_trigger', 'processing' );
		return in_array( $t, array( 'processing', 'completed', 'courier_booked' ), true ) ? $t : 'processing';
	}

	/** Called by the courier module once a consignment is really booked. */
	public static function post_on_booking( $order_id ) {
		if ( 'courier_booked' !== self::post_trigger() ) {
			return;
		}
		self::$forced = true;
		self::post_sale( $order_id );
		self::$forced = false;
	}

	public static function post_sale( $order_id ) {
		if ( get_post_meta( $order_id, '_wceerp_posted', true ) ) {
			return;
		}

		/* Honour the configured trigger. POS sales are excluded: the goods
		 * have already left the counter, so deferring their stock movement
		 * would misreport what is on the shelf right now. */
		if ( ! self::$forced ) {
			$trigger = self::post_trigger();
			$action  = current_action();
			$is_pos  = ( 'wceerp_pos' === get_post_meta( $order_id, '_created_via', true ) );
			if ( ! $is_pos ) {
				$o = wc_get_order( $order_id );
				if ( $o && 'wceerp_pos' === $o->get_created_via() ) {
					$is_pos = true;
				}
			}

			if ( ! $is_pos ) {
				if ( 'completed' === $trigger && 'woocommerce_order_status_completed' !== $action ) {
					return;
				}
				if ( 'courier_booked' === $trigger && 'woocommerce_order_status_completed' !== $action ) {
					// Completion still posts, so an order that never ships
					// (collected in person, cancelled courier) is not lost.
					return;
				}
			}
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		/* Historic orders never enter the books. Without this guard, a shop
		 * that bulk-completes old orders after installing the ERP would post
		 * years of revenue dated today, and any late status change on a
		 * pre-go-live order would silently inflate the current period. */
		if ( wceerp_is_pre_golive( $order ) ) {
			update_post_meta( $order_id, '_wceerp_skipped_pre_golive', 1 );
			wceerp_log( 'accounting', 'skip_pre_golive', (int) $order_id, 'Order predates the ERP go-live date.' );
			return;
		}

		$warehouse = (int) apply_filters( 'wceerp_sale_warehouse', self::default_warehouse(), $order );
		$date      = current_time( 'Y-m-d' );
		$total     = wceerp_dec( $order->get_total() );
		$tax       = wceerp_dec( $order->get_total_tax() );
		$net       = $total - $tax;
		$paid      = $order->is_paid();

		/* ---- Stock out + COGS at moving average cost ---- */
		$cogs = 0;
		foreach ( $order->get_items() as $item ) {
			$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
			$qty        = (float) $item->get_quantity();
			if ( $product_id && $qty > 0 ) {
				$cost  = WCEERP_Module_Inventory::move_stock( $product_id, $warehouse, $qty, 'out', 'wc_order', $order_id );
				$cogs += $cost;

				/* Selling something with no cost basis posts zero COGS and
				 * silently overstates profit. Flag it on the order so it is
				 * visible at the time, not months later in the P&L. */
				if ( $cost <= 0 && $qty > 0 ) {
					$order->add_order_note( sprintf(
						/* translators: %s: product name. */
						__( 'ERP warning: "%s" has no purchase cost recorded, so this sale posted zero cost of goods sold. Enter its opening stock or a purchase to correct future margins.', 'wc-enterprise-erp' ),
						get_the_title( $product_id )
					) );
					wceerp_log( 'inventory', 'zero_cost_sale', (int) $product_id, 'order ' . $order_id );
				}
				if ( class_exists( 'WCEERP_Module_Barcode' ) ) {
					WCEERP_Module_Barcode::allocate_serials( $product_id, $warehouse, (int) $qty, $order_id );
				}
			}
		}

		/* ---- Sales journal ---- */
		$ar    = WCEERP_Accounting::account_by_subtype( 'receivable' );
		$sales = WCEERP_Accounting::account_by_subtype( 'sales' );
		$vat   = WCEERP_Accounting::account_by_subtype( 'tax' ); // 2100 output first? resolve by code below.
		$vat   = WCEERP_Accounting::resolve_account( '2100' );
		$inv   = WCEERP_Accounting::account_by_subtype( 'inventory' );
		$cogsa = WCEERP_Accounting::account_by_subtype( 'cogs' );
		$cash  = WCEERP_Accounting::account_by_subtype( 'cash' );

		$money_account = $paid ? self::map_gateway_account( $order->get_payment_method(), $cash ) : $ar->id;
		$customer_line = array( 'party_type' => 'customer', 'party_id' => (int) $order->get_customer_id() );

		/* Wholesale dealers carry their due under their own party ledger,
		 * so dealer statements and credit limits work off the books. */
		if ( class_exists( 'WCEERP_Module_Dealers' ) && $order->get_customer_id() ) {
			$dealer = WCEERP_Module_Dealers::by_user( (int) $order->get_customer_id() );
			if ( $dealer ) {
				$customer_line = array( 'party_type' => 'dealer', 'party_id' => (int) $dealer->id );
			}
		}

		/*
		 * Cash on Delivery: WooCommerce may mark the order "processing/paid",
		 * but the merchant has NOT received money — the courier is holding it.
		 * Book the debit to 1110 Courier COD Receivable; the Courier module's
		 * payout screen moves it to bank (net of charges) when the courier
		 * actually remits. This is what makes COD books truthful.
		 */
		$is_cod = ( false !== stripos( (string) $order->get_payment_method(), 'cod' ) );
		if ( $is_cod ) {
			$cod_account   = WCEERP_Accounting::resolve_account( '1110' );
			$money_account = $cod_account ? $cod_account : ( is_object( $cash ) ? $cash->id : $money_account );
			$paid          = true; // not customer AR — the courier owes us now.
		}

		$lines = array(
			array( 'account' => $sales->id, 'credit' => $net, 'memo' => 'Sales — order #' . $order_id ),
		);

		/*
		 * Split the debit side three ways:
		 *
		 *   advance -> already received (POS cash drawer, or an advance
		 *              recorded against the order before dispatch)
		 *   cod     -> what the courier will collect on delivery
		 *   due     -> whatever is still owed by the customer
		 *
		 * Pure COD and pure prepaid orders collapse back to exactly the
		 * single-debit behaviour this used to have, so nothing changes for
		 * shops that never take part payments.
		 */
		$pos_due = wceerp_dec( $order->get_meta( '_wceerp_pos_due' ) );
		$advance = 0.0;

		if ( class_exists( 'WCEERP_Order_Payments' ) ) {
			// Receipts logged against the order before it posted.
			$advance = WCEERP_Order_Payments::paid( $order_id );
		}
		// An explicit advance meta wins, for gateways that report one.
		$meta_advance = wceerp_dec( $order->get_meta( '_wceerp_advance_paid' ) );
		$meta_advance = (float) apply_filters( 'wceerp_order_advance_paid', $meta_advance, $order );
		if ( $meta_advance > $advance ) {
			$advance = $meta_advance;
		}
		$advance = min( $advance, $total );

		if ( ! $is_cod && $pos_due > 0.004 ) {
			// POS: received now, remainder a customer due.
			$received_portion = max( 0, round( $total - $pos_due, 2 ) );
			if ( $received_portion > 0.004 ) {
				$paid_account = self::map_gateway_account( $order->get_payment_method(), $cash );
				$lines[] = array( 'account' => $paid_account, 'debit' => $received_portion, 'memo' => 'Received — order #' . $order_id );
			}
			$lines[] = array_merge(
				array( 'account' => $ar->id, 'debit' => $pos_due, 'memo' => 'Balance due — order #' . $order_id ),
				$customer_line
			);
		} elseif ( $is_cod && $advance > 0.004 ) {
			/* COD with an advance: only the balance is collectible by the
			 * courier. Debiting 1110 for the full total here is what would
			 * leave the advance stranded in the courier control account. */
			$collectible = max( 0, round( $total - $advance, 2 ) );
			if ( $collectible > 0.004 ) {
				$lines[] = array( 'account' => $money_account, 'debit' => $collectible, 'memo' => 'COD to collect — order #' . $order_id );
			}
			/* The advance itself was (or will be) banked by its own receipt
			 * journal, which credits A/R. Debiting A/R here is the matching
			 * half, so the two net to zero. */
			$lines[] = array_merge(
				array( 'account' => $ar->id, 'debit' => $advance, 'memo' => 'Advance received — order #' . $order_id ),
				$customer_line
			);
			$order->update_meta_data( '_wceerp_cod_expected', $collectible );
			$order->save();
		} else {
			$lines[] = array_merge(
				array( 'account' => $money_account, 'debit' => $total, 'memo' => 'Order #' . $order_id ),
				$paid ? array() : $customer_line
			);
		}
		if ( $tax > 0 && $vat ) {
			$lines[] = array( 'account' => $vat, 'credit' => $tax, 'memo' => 'VAT output — order #' . $order_id );
		}
		if ( $cogs > 0 && $inv && $cogsa ) {
			$lines[] = array( 'account' => $cogsa->id, 'debit' => $cogs, 'memo' => 'COGS — order #' . $order_id );
			$lines[] = array( 'account' => $inv->id, 'credit' => $cogs, 'memo' => 'Inventory out — order #' . $order_id );
		}

		$branch_id = 1;
		if ( $warehouse ) {
			global $wpdb;
			$branch_id = max( 1, (int) $wpdb->get_var( $wpdb->prepare(
				'SELECT branch_id FROM ' . wceerp_table( 'warehouses' ) . ' WHERE id = %d', $warehouse
			) ) );
		}

		$journal = WCEERP_Accounting::post( array(
			'journal_date' => $date,
			'branch_id'    => $branch_id,
			'ref_type'     => 'wc_order',
			'ref_id'       => $order_id,
			'memo'         => sprintf( 'WooCommerce order #%d (%s)', $order_id, $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
		), $lines );

		if ( is_wp_error( $journal ) ) {
			wceerp_log( 'wc_bridge', 'post_failed', $order_id, $journal->get_error_message() );
			return;
		}

		update_post_meta( $order_id, '_wceerp_posted', $journal );
		$order->update_meta_data( '_wceerp_posted', $journal );
		$order->update_meta_data( '_wceerp_mushak_no', wceerp_get_option( 'mushak_prefix', 'MUS63' ) . '-' . $order->get_order_number() );
		$order->save();

		/* ---- Reseller commission ---- */
		if ( class_exists( 'WCEERP_Module_Resellers' ) ) {
			WCEERP_Module_Resellers::maybe_create_commission( $order );
		}

		do_action( 'wceerp_sale_posted', $order_id, $journal );
	}

	/**
	 * Reverse a posted sale: restock and void the journal.
	 */
	public static function reverse_sale( $order_id ) {
		// Nothing was ever posted for a pre-go-live order, so there is
		// nothing to reverse -- and reversing would create a one-sided entry.
		if ( wceerp_is_pre_golive( $order_id ) ) {
			return;
		}
		$journal = (int) get_post_meta( $order_id, '_wceerp_posted', true );
		if ( ! $journal ) {
			return;
		}
		$order     = wc_get_order( $order_id );
		$warehouse = self::default_warehouse();

		foreach ( $order->get_items() as $item ) {
			$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
			$qty        = (float) $item->get_quantity();
			if ( $product_id && $qty > 0 ) {
				WCEERP_Module_Inventory::move_stock( $product_id, $warehouse, $qty, 'in', 'wc_refund', $order_id );
			}
		}

		WCEERP_Accounting::void( $journal );
		delete_post_meta( $order_id, '_wceerp_posted' );
		wceerp_log( 'wc_bridge', 'sale_reversed', $order_id );
	}

	/**
	 * Map a WooCommerce payment gateway to a money account.
	 * bKash / Nagad / Rocket gateways route to their own accounts so the
	 * bank book and mobile-banking books reconcile per channel.
	 */
	public static function map_gateway_account( $gateway, $fallback ) {
		$map = apply_filters( 'wceerp_gateway_account_map', array(
			'cod'    => '1110', // Courier COD Receivable — settled via courier payouts.
			'bkash'  => '1020',
			'nagad'  => '1021',
			'rocket' => '1022',
			'bacs'   => '1010',
		) );

		foreach ( $map as $needle => $code ) {
			if ( false !== stripos( (string) $gateway, $needle ) ) {
				$id = WCEERP_Accounting::resolve_account( $code );
				if ( $id ) {
					return $id;
				}
			}
		}
		return is_object( $fallback ) ? $fallback->id : (int) $fallback;
	}
}
