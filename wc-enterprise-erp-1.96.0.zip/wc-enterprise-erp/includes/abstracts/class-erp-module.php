<?php
/**
 * Base class every ERP module extends. Modules are self-contained:
 * they declare an id, a title, required capability and license tier,
 * and register their own hooks and admin screens.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

abstract class WCEERP_Module {

	/** @var string Unique slug, e.g. 'inventory'. */
	protected $id = '';

	/** @var string Human title shown in the Modules screen and menu. */
	protected $title = '';

	/** @var string Capability required to view this module's screens. */
	protected $capability = 'wceerp_view_reports';

	/** @var string Minimum license tier: 'starter' | 'business' | 'enterprise'. */
	protected $tier = 'starter';

	/** @var int Menu order. */
	protected $order = 50;

	/** @var bool Whether module shows its own submenu page. */
	protected $has_menu = true;

	public function get_id() { return $this->id; }
	public function get_title() { return $this->title; }
	public function get_capability() { return $this->capability; }
	public function get_tier() { return $this->tier; }
	public function get_order() { return $this->order; }
	public function has_menu() { return $this->has_menu; }

	/**
	 * Whether the module is switched on in settings AND allowed by license.
	 */
	public function is_active() {
		$disabled = (array) get_option( 'wceerp_disabled_modules', array() );
		if ( in_array( $this->id, $disabled, true ) ) {
			return false;
		}

		// SaaS per-tenant override wins over tier: an operator can grant
		// or revoke a single module for one tenant regardless of package.
		if ( class_exists( 'WCEERP_Limits' ) ) {
			$override = WCEERP_Limits::feature_override( $this->id );
			if ( 'on' === $override ) {
				return true;
			}
			if ( 'off' === $override ) {
				return false;
			}
		}

		// Agency add-on modules need the add-on, whatever the tier.
		if ( WCEERP_License::is_agency_module( $this->id ) ) {
			return WCEERP_License::has_agency();
		}

		return WCEERP_License::tier_allows( $this->tier );
	}

	/**
	 * Register hooks. Called on plugins_loaded when active.
	 */
	abstract public function init();

	/**
	 * Render this module's main admin page.
	 */
	public function render_page() {
		echo '<div class="wrap wceerp-wrap"><h1>' . wp_kses_post( $this->heading() ) . '</h1></div>';
	}

	/**
	 * Register submenu under the ERP top-level menu.
	 */
	/**
	 * Dashicon per module.
	 *
	 * Held centrally rather than as a property on each of the thirty-seven
	 * module classes: one map is far easier to keep visually coherent, and
	 * a module added later still gets a sensible default instead of a gap
	 * in the menu.
	 */
	public static function icons() {
		return apply_filters( 'wceerp_module_icons', array(
			'dashboard'     => 'dashicons-chart-area',
			'pos'           => 'dashicons-store',
			'inventory'     => 'dashicons-archive',
			'warehouses'    => 'dashicons-building',
			'courier'       => 'dashicons-cart',
			'accounting'    => 'dashicons-book-alt',
			'reports'       => 'dashicons-analytics',
			'analytics'     => 'dashicons-chart-bar',
			'customers'     => 'dashicons-groups',
			'dues'          => 'dashicons-money-alt',
			'dealers'       => 'dashicons-networking',
			'suppliers'     => 'dashicons-admin-users',
			'purchases'     => 'dashicons-cart',
			'procurement'   => 'dashicons-clipboard',
			'expenses'      => 'dashicons-tickets-alt',
			'quotations'    => 'dashicons-media-document',
			'crm'           => 'dashicons-phone',
			'messaging'     => 'dashicons-email-alt',
			'notifications' => 'dashicons-bell',
			'hr'            => 'dashicons-id',
			'assets'        => 'dashicons-admin-multisite',
			'banking'       => 'dashicons-building',
			'tax'           => 'dashicons-portfolio',
			'manufacturing' => 'dashicons-hammer',
			'barcode'       => 'dashicons-tag',
			'branches'      => 'dashicons-admin-multisite',
			'service'       => 'dashicons-sos',
			'ai'            => 'dashicons-lightbulb',
			'import-export' => 'dashicons-download',
			'audit'         => 'dashicons-visibility',
			'connect'       => 'dashicons-admin-links',
			'roles'         => 'dashicons-lock',
			'api'           => 'dashicons-admin-generic',
			'whitelabel'    => 'dashicons-art',
			'resellers'     => 'dashicons-share',
			'staff'         => 'dashicons-businessman',
			'plan'          => 'dashicons-awards',
		) );
	}

	/** Page heading with the module's icon in front of it. */
	public function heading( $title = '' ) {
		return sprintf(
			'<span class="dashicons %s" aria-hidden="true"></span>%s',
			esc_attr( $this->get_icon() ),
			esc_html( $title ?: $this->title )
		);
	}

	public function get_icon() {
		$map = self::icons();
		return $map[ $this->id ] ?? 'dashicons-marker';
	}

	public function register_menu( $parent ) {
		if ( ! $this->has_menu ) {
			return;
		}

		/* The icon rides in the menu title. WordPress submenus have no icon
		 * argument, so this is the only way to get one without replacing
		 * the whole menu walker. */
		$label = sprintf(
			'<span class="wceerp-mi dashicons %s" aria-hidden="true"></span><span class="wceerp-ml">%s</span>',
			esc_attr( $this->get_icon() ),
			esc_html( $this->title )
		);

		add_submenu_page(
			$parent,
			$this->title,
			$label,
			current_user_can( 'manage_woocommerce' ) ? 'manage_woocommerce' : $this->capability,
			'wceerp-' . $this->id,
			array( $this, 'render_page' )
		);
	}

	/* ----- Small shared UI helpers ----- */

	protected function admin_url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'wceerp-' . $this->id ), $args ), admin_url( 'admin.php' ) );
	}

	protected function verify_nonce( $action ) {
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), $action ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		if ( ! wceerp_user_can( $this->capability ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}
	}

	protected function notice( $message, $type = 'success' ) {
		printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $message ) );
	}
}
