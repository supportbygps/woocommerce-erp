<?php
/**
 * Standalone ERP portal.
 *
 * A clean, app-like front door at /erp so staff can reach the ERP
 * without meeting the WordPress dashboard. They sign in with the shop's
 * 4-digit PIN.
 *
 * SECURITY NOTE — why this is more than a PIN box.
 *
 * A 4-digit PIN is 10,000 combinations. On a page that is the *only*
 * lock, that is trivially brute-forced. Inside wp-admin the PIN is a
 * second factor behind a WordPress login, which is what makes four
 * digits acceptable there. Here it is the front door, so this class
 * adds the controls that make it defensible:
 *
 *   - Attempt limiting per IP, with a widening lockout.
 *   - A global attempt ceiling, so a botnet spreading attempts across
 *     many IPs still trips the brake.
 *   - Signed, expiring device tokens, so a shop tablet authenticates
 *     once rather than re-entering the PIN all day (and a stolen cookie
 *     expires).
 *   - Constant-time PIN comparison via wp_check_password.
 *   - No user enumeration: a wrong PIN never reveals whether anything
 *     else about the request was valid.
 *
 * Even so, the portal is opt-in. An operator who does not want a
 * front-end door simply leaves it off.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Portal {

	const QUERY_VAR   = 'wceerp_portal';
	const COOKIE      = 'wceerp_portal_token';
	const MAX_TRIES   = 5;           // per IP before lockout
	const LOCK_TIME   = 900;         // 15 minutes
	const GLOBAL_CAP  = 40;          // attempts/hour across all IPs
	const TOKEN_LIFE  = 43200;       // 12 hours — a working day

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'add_route' ) );
		/* Send a portal request back to the portal. Runs late so it sees the
		 * final target, and only fires when the request carried the marker,
		 * so ordinary wp-admin use is untouched. */
		add_filter( 'wp_redirect', array( __CLASS__, 'keep_in_portal' ), 99 );
		add_filter( 'query_vars', array( __CLASS__, 'add_query_var' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ), 5 );
		add_action( 'admin_post_nopriv_wceerp_portal_login', array( __CLASS__, 'handle_login' ) );
		add_action( 'admin_post_wceerp_portal_login', array( __CLASS__, 'handle_login' ) );
		add_action( 'admin_post_nopriv_wceerp_portal_logout', array( __CLASS__, 'handle_logout' ) );
		add_action( 'admin_post_wceerp_portal_logout', array( __CLASS__, 'handle_logout' ) );
		add_action( 'admin_post_wceerp_portal_2fa', array( __CLASS__, 'handle_2fa' ) );
	}

	public static function is_enabled() {
		return 'yes' === wceerp_get_option( 'portal_enabled', 'no' );
	}

	public static function add_query_var( $vars ) {
		$vars[] = self::QUERY_VAR;
		$vars[] = 'wceerp_screen';
		return $vars;
	}

	public static function add_route() {
		$slug = self::slug();

		/* Module screens: /erp/inventory, /erp/courier …
		 *
		 * The pattern deliberately excludes anything containing a dot, so
		 * it cannot swallow /erp/manifest.json or /erp/sw.js. Those are
		 * registered by WCEERP_PWA at an earlier priority, but 'top'
		 * rules are evaluated in registration order and a greedy pattern
		 * here would still win — which is exactly why the install option
		 * never appeared. */
		add_rewrite_rule( '^' . $slug . '/([a-z0-9_\-]+)/?$', 'index.php?' . self::QUERY_VAR . '=app&wceerp_screen=$matches[1]', 'top' );
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?' . self::QUERY_VAR . '=app', 'top' );

		/* Self-heal. Keyed to the plugin version and the slug, so an
		 * upgrade or a slug change re-flushes automatically instead of
		 * leaving routes permanently broken behind a one-shot flag. */
		$stamp = WCEERP_VERSION . '|' . $slug;
		$rules = get_option( 'rewrite_rules' );
		$needed = array(
			'^' . $slug . '/?$',
			'^' . $slug . '/manifest\.json$',
			'^' . $slug . '/sw\.js$',
		);
		$missing = false;
		if ( ! is_array( $rules ) ) {
			$missing = true;
		} else {
			foreach ( $needed as $rule ) {
				if ( ! isset( $rules[ $rule ] ) ) {
					$missing = true;
					break;
				}
			}
		}
		if ( $missing || get_option( 'wceerp_portal_flushed' ) !== $stamp ) {
			flush_rewrite_rules( false );
			update_option( 'wceerp_portal_flushed', $stamp );
		}
	}

	public static function slug() {
		return sanitize_title( wceerp_get_option( 'portal_slug', 'erp' ) );
	}

	public static function url() {
		return home_url( '/' . self::slug() );
	}

	/* ---------------------------------------------------------------------
	 * Rate limiting.
	 * ------------------------------------------------------------------- */

	protected static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
		return substr( md5( $ip ), 0, 16 );
	}

	protected static function tries_key() {
		return 'wceerp_portal_try_' . self::ip();
	}

	public static function is_locked_out() {
		return (int) get_transient( 'wceerp_portal_lock_' . self::ip() ) > 0
			|| (int) get_transient( 'wceerp_portal_global' ) >= self::GLOBAL_CAP;
	}

	public static function lockout_remaining() {
		$until = (int) get_transient( 'wceerp_portal_lock_' . self::ip() );
		return $until ? max( 0, $until - time() ) : 0;
	}

	protected static function record_failure() {
		$key   = self::tries_key();
		$tries = (int) get_transient( $key ) + 1;
		set_transient( $key, $tries, HOUR_IN_SECONDS );

		// Global brake: catches attempts spread across many IPs.
		$g = (int) get_transient( 'wceerp_portal_global' ) + 1;
		set_transient( 'wceerp_portal_global', $g, HOUR_IN_SECONDS );

		if ( $tries >= self::MAX_TRIES ) {
			// Lockout widens with repeated offences.
			$multiplier = min( 8, (int) floor( $tries / self::MAX_TRIES ) );
			set_transient( 'wceerp_portal_lock_' . self::ip(), time() + ( self::LOCK_TIME * $multiplier ), self::LOCK_TIME * $multiplier );
		}
	}

	protected static function clear_failures() {
		delete_transient( self::tries_key() );
		delete_transient( 'wceerp_portal_lock_' . self::ip() );
	}

	/* ---------------------------------------------------------------------
	 * Device tokens.
	 * ------------------------------------------------------------------- */

	protected static function token_secret() {
		$secret = get_option( 'wceerp_portal_secret', '' );
		if ( ! $secret ) {
			$secret = wp_generate_password( 48, true, true );
			update_option( 'wceerp_portal_secret', $secret, false );
		}
		return $secret;
	}

	protected static function issue_token() {
		$expires = time() + self::TOKEN_LIFE;
		$sig     = hash_hmac( 'sha256', $expires . '|' . self::ip(), self::token_secret() );
		$token   = $expires . '.' . $sig;
		setcookie( self::COOKIE, $token, array(
			'expires'  => $expires,
			'path'     => '/',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		) );
		$_COOKIE[ self::COOKIE ] = $token;
	}

	public static function has_valid_token() {
		$token = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		if ( ! $token || false === strpos( $token, '.' ) ) {
			return false;
		}
		list( $expires, $sig ) = explode( '.', $token, 2 );
		if ( (int) $expires < time() ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', ( (int) $expires ) . '|' . self::ip(), self::token_secret() );
		return hash_equals( $expected, $sig );
	}

	protected static function clear_token() {
		setcookie( self::COOKIE, '', array( 'expires' => time() - 3600, 'path' => '/' ) );
		unset( $_COOKIE[ self::COOKIE ] );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public static function handle_login() {
		if ( ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ?? '' ), 'wceerp_portal_login' ) ) {
			wp_safe_redirect( add_query_arg( 'e', 'nonce', self::url() ) );
			exit;
		}
		if ( self::is_locked_out() ) {
			wp_safe_redirect( add_query_arg( 'e', 'locked', self::url() ) );
			exit;
		}

		$pin = preg_replace( '/\D/', '', (string) ( $_POST['pin'] ?? '' ) );
		if ( 4 === strlen( $pin ) && class_exists( 'WCEERP_Pin' ) && WCEERP_Pin::check_pin( $pin ) ) {
			self::clear_failures();
			self::issue_token();
			wp_safe_redirect( self::url() );
			exit;
		}

		self::record_failure();
		wp_safe_redirect( add_query_arg( 'e', 'bad', self::url() ) );
		exit;
	}

	public static function handle_logout() {
		if ( is_user_logged_in() ) {
			delete_transient( 'wceerp_2fa_ok_' . get_current_user_id() );
		}
		self::clear_token();
		wp_safe_redirect( self::url() );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Rendering.
	 * ------------------------------------------------------------------- */

	public static function maybe_render() {
		if ( 'app' !== get_query_var( self::QUERY_VAR ) ) {
			return;
		}
		if ( ! self::is_enabled() ) {
			wp_die( esc_html__( 'The ERP portal is not enabled on this site.', 'wc-enterprise-erp' ), '', array( 'response' => 404 ) );
		}
		if ( class_exists( 'WCEERP_License' ) && WCEERP_License::is_locked() ) {
			wp_die( esc_html( WCEERP_License::lock_reason() ), esc_html__( 'Licence required', 'wc-enterprise-erp' ), array( 'response' => 403 ) );
		}

		if ( ! self::has_valid_token() ) {
			self::render_login();
			exit;
		}

		/* A module screen needs a real WordPress identity: its forms post to
		 * admin-post.php and its queries respect capabilities. The PIN says
		 * "this device is authorised"; the login says "this is who you are".
		 * Both are required, and the portal says so plainly rather than
		 * rendering a screen that would fail on first click. */
		$screen = sanitize_key( get_query_var( 'wceerp_screen' ) );
		if ( $screen ) {
			if ( ! is_user_logged_in() ) {
				self::render_login_required( $screen );
				exit;
			}
			// Second factor, when this account uses one.
			if ( class_exists( 'WCEERP_TwoFactor' )
				&& WCEERP_TwoFactor::required_for( get_current_user_id() )
				&& ! self::has_2fa_session() ) {
				self::render_2fa( $screen );
				exit;
			}
			self::render_screen( $screen );
			exit;
		}

		self::render_hub();
		exit;
	}

	protected static function brand() {
		return apply_filters( 'wceerp_brand', 'WooCommerce ERP' );
	}

	/**
	 * The logo, or an empty string.
	 *
	 * Same precedence as the admin lock screen: a white-label logo wins,
	 * then the bundled mark. Callers fall back to initials only when both
	 * are absent, so the screen is never blank — but showing "Wo" when a
	 * perfectly good logo is sitting in assets/branding is just an omission.
	 */
	protected static function logo_url() {
		$logo = apply_filters( 'wceerp_pin_logo', '' );
		if ( $logo ) {
			return $logo;
		}
		$wl = function_exists( 'wceerp_get_option' ) ? wceerp_get_option( 'whitelabel_logo', '' ) : '';
		if ( $wl ) {
			return $wl;
		}
		if ( file_exists( WCEERP_PATH . 'assets/branding/logo.png' ) ) {
			return WCEERP_URL . 'assets/branding/logo.png';
		}
		return '';
	}

	protected static function head( $title ) {
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
			<meta name="robots" content="noindex,nofollow">
			<meta name="theme-color" content="#ffffff">
			<title><?php echo esc_html( $title . ' · ' . get_bloginfo( 'name' ) ); ?></title>
			<?php if ( class_exists( 'WCEERP_PWA' ) ) { WCEERP_PWA::head_tags(); } ?>
			<style>
				/* ---- Design tokens -------------------------------------- */
				:root{
					--g:#5b3df5; --g-dark:#3d24c9; --g-light:#7c4dff;
					--ink:#1a2230; --muted:#5f6b7a; --faint:#94a0ae;
					--line:#eaeef3; --bg:#f6f7fb; --card:#fff;
					--good:#16a34a; --warn:#d97706; --bad:#dc2626;
					--r:18px; --shadow:0 1px 3px rgba(16,24,40,.06),0 8px 24px rgba(16,24,40,.06);
				}
				*{box-sizing:border-box}
				html{-webkit-text-size-adjust:100%}
				body{margin:0;background:var(--bg);color:var(--ink);
					font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
					font-size:15px;line-height:1.55;-webkit-font-smoothing:antialiased}
				a{color:inherit;text-decoration:none}
				h1,h2,h3{margin:0;font-weight:650;letter-spacing:-.01em}

				/* ---- App bar --------------------------------------------- */
				.appbar{position:sticky;top:0;z-index:40;background:var(--card);color:var(--ink);
					padding:env(safe-area-inset-top) 0 0;border-bottom:1px solid var(--line)}
				.appbar .in{display:flex;align-items:center;gap:11px;max-width:1200px;margin:0 auto;padding:11px 16px}
				.appbar .logo.has-img{background:none;padding:0;width:auto;max-width:132px;height:36px}
				.appbar .logo.has-img img{height:36px;width:auto;max-width:132px;object-fit:contain;display:block}
				.brand-img{max-width:210px;width:100%;height:auto;margin:0 auto 16px;display:block}
				.appbar .logo{width:36px;height:36px;border-radius:12px;
					background:linear-gradient(135deg,var(--g),var(--g-light));color:#fff;
					display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;flex:0 0 auto;
					box-shadow:0 3px 9px rgba(91,61,245,.3)}
				.appbar h1{font-size:16.5px;font-weight:700;letter-spacing:-.01em;
					white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
				.appbar .spacer{margin-left:auto}
				.appbar .act{background:#f2f4f8;border-radius:11px;padding:8px 13px;
					font-size:12.5px;font-weight:650;white-space:nowrap;color:var(--muted);transition:background .15s}
				.appbar .act:hover{background:#e8ebf2}

				/* ---- Layout ---------------------------------------------- */
				.shell{max-width:1200px;margin:0 auto;padding:20px 18px 56px}
				.crumb{display:inline-flex;align-items:center;gap:6px;color:var(--g);font-weight:650;
					font-size:13.5px;font-weight:600;margin-bottom:14px}

				/* ---- Cards & tiles --------------------------------------- */
				.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:10px}
				.tile{background:var(--card);border:1px solid var(--line);border-radius:var(--r);
					padding:14px 8px;text-align:center;box-shadow:var(--shadow);
					transition:transform .16s ease,box-shadow .16s ease,border-color .16s ease;
					display:flex;flex-direction:column;align-items:center;justify-content:center;
					gap:7px;aspect-ratio:1/1;min-height:96px}
				.tile:hover{transform:translateY(-2px);border-color:var(--g);
					box-shadow:0 4px 8px rgba(16,24,20,.06),0 16px 34px rgba(16,24,20,.09)}
				.tile:active{transform:scale(.97)}
				.tile .ic{font-size:24px;line-height:1}
				/* Two lines maximum, then ellipsis — long module names were
				   pushing tiles to different heights and breaking the grid. */
				.tile .nm{font-weight:600;font-size:12px;color:var(--ink);line-height:1.25;
					display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
					overflow:hidden;word-break:break-word;hyphens:auto}

				/* ---- Summary strip --------------------------------------- */
				/* auto-fit with a single child left a dead grey panel beside it;
				   flex wraps cleanly whatever the count. */
				.strip{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:18px}
				.strip .cell{flex:1 1 150px;background:var(--card);border:1px solid var(--line);
					border-radius:var(--r);box-shadow:var(--shadow)}
				.strip .cell{background:var(--card);padding:15px 16px;min-height:82px;
					display:flex;flex-direction:column;justify-content:center}
				.strip .k{color:var(--faint);font-size:11px;letter-spacing:.05em;
					text-transform:uppercase;font-weight:650}
				.strip .v{font-size:20px;font-weight:700;margin-top:4px;font-variant-numeric:tabular-nums}
				.strip .s{color:var(--faint);font-size:11.5px;margin-top:1px}

				.section-title{font-size:12px;letter-spacing:.06em;text-transform:uppercase;
					color:var(--faint);font-weight:650;margin:24px 0 10px}

				/* ---- Auth screens ---------------------------------------- */
				/* ---- Auth: full-bleed, app-like ------------------------- */
				.auth-wrap{min-height:100vh;min-height:100dvh;display:flex;align-items:center;
					justify-content:center;padding:24px 20px calc(24px + env(safe-area-inset-bottom));
					background:var(--g-dark);position:relative;overflow:hidden}
				/* Soft depth without an image asset. */
				.auth-wrap::before{content:'';position:absolute;width:620px;height:620px;border-radius:50%;
					background:radial-gradient(circle,rgba(37,211,102,.16),transparent 68%);
					top:-230px;right:-190px;pointer-events:none}
				.auth-wrap::after{content:'';position:absolute;width:520px;height:520px;border-radius:50%;
					background:radial-gradient(circle,rgba(10,110,84,.5),transparent 66%);
					bottom:-220px;left:-160px;pointer-events:none}
				.auth{background:#fff;border-radius:26px;padding:36px 28px 30px;width:100%;max-width:370px;
					text-align:center;position:relative;z-index:1;
					box-shadow:0 26px 70px rgba(0,0,0,.34),0 2px 8px rgba(0,0,0,.12)}
				.auth .brand{width:60px;height:60px;border-radius:18px;
					background:linear-gradient(140deg,var(--g),var(--g-light));color:#fff;font-weight:800;
					font-size:21px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;
					box-shadow:0 8px 20px rgba(7,87,66,.3)}
				.auth h2{font-size:19px;margin-bottom:5px;letter-spacing:-.02em}
				.auth .sub{color:var(--faint);font-size:13.5px;margin-bottom:24px}
				.dots{display:flex;gap:13px;justify-content:center;margin-bottom:24px}
				.dot{width:13px;height:13px;border-radius:50%;background:#e2e8e5;
					transition:transform .18s cubic-bezier(.34,1.56,.64,1),background .18s}
				.dot.on{background:var(--g);transform:scale(1.25)}
				.pad{display:grid;grid-template-columns:repeat(3,1fr);gap:11px}
				.pad button{border:0;background:#f4f7f5;font-size:22px;border-radius:16px;
					cursor:pointer;font-weight:600;color:var(--ink);transition:transform .1s,background .12s;
					-webkit-tap-highlight-color:transparent;aspect-ratio:1/1;
					display:flex;align-items:center;justify-content:center;min-height:56px}
				.pad button:active{background:#e6ebe8;transform:scale(.94)}
				.pad .go{background:var(--g);color:#fff;font-size:24px}
				.pad .go:active{background:var(--g-light)}
				/* Shake on a wrong PIN — clearer than a line of red text. */
				@keyframes shake{10%,90%{transform:translateX(-2px)}30%,70%{transform:translateX(4px)}
					50%{transform:translateX(-4px)}}
				.auth.bad{animation:shake .4s}
				.code-in{width:100%;font-size:26px;letter-spacing:9px;text-align:center;padding:14px;
					border:2px solid #dfe4e1;border-radius:13px;font-weight:700;color:var(--g)}
				.code-in:focus{outline:0;border-color:var(--g)}
				.btn{display:block;width:100%;margin-top:14px;background:var(--g);color:#fff;border:0;
					border-radius:13px;padding:14px;font-size:15px;font-weight:650;cursor:pointer}
				.btn:hover{background:var(--g-light)}
				.err{color:var(--bad);font-size:13px;min-height:19px;margin-top:11px}
				.locked{background:#fdf3f2;border:1px solid #f2cbc9;color:#9d2b28;
					border-radius:12px;padding:14px;font-size:13.5px;text-align:left}
				.auth .foot{margin-top:18px;font-size:11.5px;color:#a9b2ae}

				/* ---- Module screens embed wp-admin markup ---------------- */
				.embed .wrap{margin:0;max-width:none;padding:0}
				.embed h1{font-size:21px;margin-bottom:14px}
				.embed .widefat{border-radius:10px;overflow:hidden;border-color:var(--line)}
				.embed table{max-width:100%}
				.embed .wceerp-card{box-shadow:var(--shadow)}

				/* ---- Responsive ------------------------------------------ */
				@media(max-width:860px){
					.shell{padding:14px 12px 44px}
					.tile .ic{font-size:22px}
					.appbar h1{font-size:15px}
				}
				@media(max-width:600px){
					.tiles{grid-template-columns:repeat(3,1fr);gap:9px}
					.tile{min-height:88px;padding:11px 6px;border-radius:12px}
					.tile .ic{font-size:21px}
					.tile .nm{font-size:11px}
					.strip .cell{flex:1 1 100%}
					.strip .v{font-size:19px}
					/* Long currency values were overflowing their cell. */
					.strip .v{word-break:break-all}
					/* Module tables scroll instead of breaking the page. */
					.embed table{display:block;overflow-x:auto;-webkit-overflow-scrolling:touch}
					.embed .form-table th{width:auto;display:block;padding-bottom:2px}
					.embed .form-table td{display:block;padding-top:0}
					.embed input[type=text],.embed input[type=number],.embed input[type=email],
					.embed input[type=url],.embed input[type=date],.embed select,.embed textarea{
						max-width:100%;width:100%}
				}
				@media(max-width:380px){
					.tiles{grid-template-columns:repeat(2,1fr)}
				}
				@media(prefers-color-scheme:dark){
					/* Kept light on purpose: module markup assumes a light
					   admin palette, and a half-dark screen reads as broken. */
				}
			</style>
		</head>
		<body>
		<?php
	}

	/**
	 * Render one ERP module inside the portal shell.
	 *
	 * Module classes already know how to draw themselves, so the portal
	 * reuses render_page() rather than duplicating 34 screens. WordPress
	 * admin styles are loaded because module markup is written against
	 * them; without those the tables and forms would be unreadable.
	 */
	protected static function render_screen( $screen ) {
		$modules = array();
		if ( function_exists( 'wceerp' ) && method_exists( wceerp(), 'modules' ) ) {
			$modules = (array) wceerp()->modules();
		}
		if ( ! isset( $modules[ $screen ] ) ) {
			// Say so rather than bouncing silently — a redirect here looked
			// exactly like "the portal dumped me back to wp-admin".
			self::head( __( 'Not found', 'wc-enterprise-erp' ) );
			self::topbar( __( 'Not found', 'wc-enterprise-erp' ) );
			echo '<div class="shell"><p style="color:#5f6b66">'
				. esc_html__( 'That screen is not available on this site.', 'wc-enterprise-erp' )
				. '</p><a class="crumb" href="' . esc_url( self::url() ) . '">← '
				. esc_html__( 'All features', 'wc-enterprise-erp' ) . '</a></div></body></html>';
			return;
		}
		$module = $modules[ $screen ];

		if ( ! $module->is_active() ) {
			wp_die( esc_html__( 'That feature is not part of your current plan.', 'wc-enterprise-erp' ), '', array( 'response' => 403 ) );
		}
		if ( ! wceerp_user_can( $module->get_capability() ) ) {
			wp_die( esc_html__( 'Your account does not have permission for this screen.', 'wc-enterprise-erp' ), '', array( 'response' => 403 ) );
		}

		self::head( $module->get_title() );
		self::topbar( $module->get_title() );
		?>
		<style>
			.portal-body{max-width:1180px;margin:0 auto;padding:20px 18px 50px}
			.portal-body .wrap{margin:0;max-width:none}
			.portal-body h1{font-size:22px;margin:0 0 14px}
			.portal-back{display:inline-block;margin-bottom:12px;color:#075742;font-size:13.5px;font-weight:600}

			/* Module screens are written for a desktop wp-admin column.
			 * Inside the app they are read on a phone, so the pieces that
			 * do not fit are made to behave rather than overflow. */

			/* Tabs become a single swipeable strip. Wrapping them produced
			 * the stack of full-width grey blocks that pushed the actual
			 * content off the first screen. */
			.portal-body .nav-tab-wrapper{
				display:flex;flex-wrap:nowrap;overflow-x:auto;-webkit-overflow-scrolling:touch;
				border-bottom:1px solid #E3E0E8;margin:0 0 16px;padding:0;gap:2px;
				scrollbar-width:none;
			}
			.portal-body .nav-tab-wrapper::-webkit-scrollbar{display:none}
			.portal-body .nav-tab{
				flex:0 0 auto;margin:0;border:0;background:none;white-space:nowrap;
				padding:10px 14px;font-size:14px;font-weight:600;color:#5B6675;
				border-bottom:2px solid transparent;border-radius:0;
			}
			.portal-body .nav-tab-active{color:#16202C;border-bottom-color:#8B5A9E;background:none}

			/* Wide tables scroll sideways instead of breaking the layout. */
			.portal-body .wceerp-table,
			.portal-body table.widefat{display:block;overflow-x:auto;white-space:nowrap;max-width:100%}
			.portal-body table.widefat thead th{position:sticky;top:0;z-index:1}

			/* Touch targets and inputs sized for a thumb. */
			.portal-body .button,
			.portal-body .button-primary{min-height:40px;padding:8px 16px;font-size:14px}
			.portal-body input[type=text],
			.portal-body input[type=number],
			.portal-body input[type=date],
			.portal-body input[type=search],
			.portal-body input[type=email],
			.portal-body select,
			.portal-body textarea{font-size:16px;min-height:40px;max-width:100%}

			@media (max-width:782px){
				.portal-body{padding:14px 12px 44px}
				.portal-body h1{font-size:19px}

				/* Label above field, rather than a 230px label column
				 * squeezing the input into nothing. */
				.portal-body .form-table,
				.portal-body .form-table tbody,
				.portal-body .form-table tr,
				.portal-body .form-table th,
				.portal-body .form-table td{display:block;width:auto}
				.portal-body .form-table th{padding:12px 0 4px;font-size:13.5px}
				.portal-body .form-table td{padding:0 0 12px}

				.portal-body .wceerp-kpis{grid-template-columns:1fr 1fr;gap:10px}
				.portal-body .wceerp-columns{grid-template-columns:1fr}
				.portal-body .wceerp-card{padding:14px;border-radius:10px}

				/* Filter bars stack instead of running off the edge. */
				.portal-body .wceerp-filter{flex-wrap:wrap;gap:8px}
				.portal-body .wceerp-filter select,
				.portal-body .wceerp-filter input{flex:1 1 auto;min-width:120px}
			}

			@media (max-width:420px){
				.portal-body .wceerp-kpis{grid-template-columns:1fr}
			}
		</style>
		<?php /* portal-body carries the embedded-module styling. It was
		         missing, so every rule written against it — including the
		         column width and heading size — has been inert. */ ?>
		<div class="shell embed portal-body">
			<a class="crumb" href="<?php echo esc_url( self::url() ); ?>">← <?php esc_html_e( 'All features', 'wc-enterprise-erp' ); ?></a>
			<?php
			// Module screens are written against wp-admin markup.
			wp_enqueue_style( 'common' );
			wp_enqueue_style( 'forms' );
			wp_enqueue_style( 'list-tables' );
			wp_enqueue_style( 'wceerp-admin', WCEERP_URL . 'assets/css/admin.css', array(), WCEERP_VERSION );
			/* The design system was missing here, which is why module tabs
			 * and tables appeared as raw WordPress defaults inside the app
			 * while looking correct in wp-admin. */
			wp_enqueue_style( 'wceerp-admin-ui', WCEERP_URL . 'assets/css/admin-ui.css', array( 'wceerp-admin' ), WCEERP_VERSION );
			wp_print_styles( array( 'common', 'forms', 'list-tables', 'wceerp-admin', 'wceerp-admin-ui' ) );

			/* Module markup links and posts to wp-admin. Buffer the output
			 * and rewrite in-ERP page links to portal routes, so tapping
			 * a tab inside a module keeps you in the app instead of
			 * throwing you into the WordPress dashboard. Form actions
			 * (admin-post.php) are deliberately left alone — they must
			 * still reach WordPress to be processed. */
			ob_start();
			$module->render_page();
			$html = ob_get_clean();
			/* Forms are the reason the app felt broken.
			 *
			 * Links were rewritten, but a form posts to admin-post.php and
			 * its handler ends with a redirect to admin.php — so any filter,
			 * save or booking threw the user into the WordPress dashboard on
			 * a phone, with no way back. The menus were fine; using them was
			 * not. This marks the request so the redirect can be caught. */
			$html = preg_replace(
				'#(<form\b[^>]*>)#i',
				'$1<input type="hidden" name="wceerp_from_portal" value="1">',
				$html
			);

			/* A GET form targets admin.php directly — module filter bars do
			 * this — and navigates out of the app on the first Filter press. */
			$html = str_replace(
				array(
					'action="' . admin_url( 'admin.php' ) . '"',
					"action='" . admin_url( 'admin.php' ) . "'",
				),
				'action="' . esc_url( self::url() . '/' . $screen ) . '"',
				$html
			);

			$html = preg_replace_callback(
				'#' . preg_quote( admin_url( 'admin.php' ), '#' ) . '\?page=wceerp-([a-z0-9_\-]+)([^"\']*)#i',
				function ( $m ) {
					$args = '';
					if ( ! empty( $m[2] ) ) {
						$args = str_replace( '&amp;', '&', $m[2] );
						$args = ltrim( $args, '&' );
						$args = $args ? '?' . $args : '';
					}
					return esc_url_raw( WCEERP_Portal::url() . '/' . $m[1] . $args );
				},
				$html
			);
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- module output, already escaped at source
			?>
		</div>
		</body></html>
		<?php
	}

	/** Shown when a device has the PIN but nobody is signed in. */
	protected static function render_login_required( $screen ) {
		$return = self::url() . '/' . sanitize_key( $screen );
		self::head( __( 'Sign in required', 'wc-enterprise-erp' ) );
		?>
		<style>
			body{display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f1f3f1}
			.card{background:#fff;border:1px solid #e6e3d8;border-radius:18px;padding:32px;max-width:420px;text-align:center}
			.card h2{margin:0 0 8px;font-size:19px}
			.card p{color:#6f7680;font-size:14px;line-height:1.6}
			.card a.btn{display:inline-block;margin-top:14px;background:#075742;color:#fff;padding:12px 22px;border-radius:10px;font-weight:600}
		</style>
		<div class="auth-wrap"><div class="auth">
			<h2><?php esc_html_e( 'One more step', 'wc-enterprise-erp' ); ?></h2>
			<p><?php esc_html_e( 'The PIN unlocked this device. Sign in with your account once and this device will stay signed in — after that the PIN is all you need each day.', 'wc-enterprise-erp' ); ?></p>
			<a class="btn" href="<?php echo esc_url( wp_login_url( $return ) ); ?>"><?php esc_html_e( 'Sign in', 'wc-enterprise-erp' ); ?></a>
			<p style="margin-top:16px"><a href="<?php echo esc_url( self::url() ); ?>" style="color:#8a8f98;font-size:13px"><?php esc_html_e( 'Back', 'wc-enterprise-erp' ); ?></a></p>
		</div></div>
		</body></html>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Two-factor session.
	 *
	 * Kept separate from the PIN token: the PIN says "this device is
	 * allowed", the 2FA session says "this person proved who they are".
	 * Shorter-lived than the device token, and tied to the user id.
	 * ------------------------------------------------------------------- */

	public static function has_2fa_session() {
		return (bool) get_transient( 'wceerp_2fa_ok_' . get_current_user_id() );
	}

	protected static function start_2fa_session() {
		set_transient( 'wceerp_2fa_ok_' . get_current_user_id(), 1, 8 * HOUR_IN_SECONDS );
	}

	public static function handle_2fa() {
		if ( ! is_user_logged_in() || ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ?? '' ), 'wceerp_portal_2fa' ) ) {
			wp_safe_redirect( self::url() );
			exit;
		}
		$screen = sanitize_key( $_POST['screen'] ?? '' );
		$code   = (string) ( $_POST['code'] ?? '' );

		// Reuse the portal's own attempt limiting — a 6-digit code is
		// still guessable if an attacker may try indefinitely.
		if ( self::is_locked_out() ) {
			wp_safe_redirect( add_query_arg( 'e', 'locked', self::url() ) );
			exit;
		}

		if ( class_exists( 'WCEERP_TwoFactor' ) && WCEERP_TwoFactor::verify( get_current_user_id(), $code ) ) {
			self::clear_failures();
			self::start_2fa_session();
			wp_safe_redirect( $screen ? self::url() . '/' . $screen : self::url() );
			exit;
		}
		self::record_failure();
		wp_safe_redirect( add_query_arg( array( 'e' => 'bad2fa', 's' => $screen ), self::url() . '/' . $screen ) );
		exit;
	}

	/** Six-digit code entry. */
	protected static function render_2fa( $screen ) {
		$bad = isset( $_GET['e'] ) && 'bad2fa' === $_GET['e'];
		self::head( __( 'Verification', 'wc-enterprise-erp' ) );
		?>
		<style>
			body{display:flex;align-items:center;justify-content:center;min-height:100vh;background:linear-gradient(150deg,#063f30,#0a6e54)}
			.card{background:#fff;border-radius:20px;padding:34px 30px;width:340px;text-align:center;box-shadow:0 24px 70px rgba(0,0,0,.28)}
			.card h2{margin:0 0 6px;font-size:18px}
			.card p{color:#8a8f98;font-size:13px;margin:0 0 20px}
			.card input{width:100%;font-size:26px;letter-spacing:9px;text-align:center;padding:13px;border:2px solid #dcdcd4;border-radius:12px;font-weight:700;color:#075742}
			.card input:focus{outline:0;border-color:#0a6e54}
			.card button{margin-top:14px;width:100%;background:#075742;color:#fff;border:0;border-radius:12px;padding:13px;font-size:15px;font-weight:600;cursor:pointer}
			.err{color:#c8302e;font-size:13px;margin-top:10px}
			.foot{margin-top:16px;font-size:12px;color:#a2a7ae}
		</style>
		<div class="auth-wrap"><div class="auth">
			<h2><?php esc_html_e( 'Verification code', 'wc-enterprise-erp' ); ?></h2>
			<p><?php esc_html_e( 'Open your authenticator app and enter the six-digit code.', 'wc-enterprise-erp' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_portal_2fa">
				<input type="hidden" name="screen" value="<?php echo esc_attr( $screen ); ?>">
				<?php wp_nonce_field( 'wceerp_portal_2fa' ); ?>
				<input type="text" name="code" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" autofocus autocomplete="one-time-code" placeholder="000000">
				<?php if ( $bad ) : ?><div class="err"><?php esc_html_e( 'That code was not accepted.', 'wc-enterprise-erp' ); ?></div><?php endif; ?>
				<button type="submit"><?php esc_html_e( 'Verify', 'wc-enterprise-erp' ); ?></button>
			</form>
			<div class="foot"><?php esc_html_e( 'A recovery code also works here.', 'wc-enterprise-erp' ); ?></div>
		</div></div>
		</body></html>
		<?php
	}

	/** Shared top bar. */
	protected static function topbar( $title = '' ) {
		?>
		<div class="appbar"><div class="in">
			<?php $bar_logo = self::logo_url(); ?>
			<a class="logo<?php echo $bar_logo ? ' has-img' : ''; ?>" href="<?php echo esc_url( self::url() ); ?>">
				<?php if ( $bar_logo ) : ?>
					<img src="<?php echo esc_url( $bar_logo ); ?>" alt="<?php echo esc_attr( self::brand() ); ?>">
				<?php else : ?>
					<?php echo esc_html( mb_substr( self::brand(), 0, 2 ) ); ?>
				<?php endif; ?>
			</a>
			<h1><?php echo esc_html( $title ?: get_bloginfo( 'name' ) ); ?></h1>
			<span class="spacer"></span>
			<a class="act" href="<?php echo esc_url( admin_url( 'admin-post.php?action=wceerp_portal_logout' ) ); ?>">🔒 <?php esc_html_e( 'Lock', 'wc-enterprise-erp' ); ?></a>
		</div></div>
		<?php
	}

	/** PIN entry screen. */
	protected static function render_login() {
		$err     = isset( $_GET['e'] ) ? sanitize_key( $_GET['e'] ) : '';
		$locked  = self::is_locked_out();
		$remain  = self::lockout_remaining();
		self::head( __( 'Sign in', 'wc-enterprise-erp' ) );
		?>
		<style>
			body{display:flex;align-items:center;justify-content:center;min-height:100vh;background:linear-gradient(150deg,#063f30,#0a6e54)}
			.card{background:#fff;border-radius:20px;padding:34px 30px;width:340px;box-shadow:0 24px 70px rgba(0,0,0,.28);text-align:center}
			.logo{width:56px;height:56px;border-radius:15px;background:linear-gradient(135deg,#075742,#0a6e54);color:#fff;font-weight:800;font-size:21px;display:flex;align-items:center;justify-content:center;margin:0 auto 15px}
			h2{margin:0 0 4px;font-size:18px}
			p.sub{color:#8a8f98;font-size:13px;margin:0 0 20px}
			.dots{display:flex;gap:11px;justify-content:center;margin-bottom:18px}
			.dot{width:15px;height:15px;border-radius:50%;border:2px solid #d6dbd8;transition:.15s}
			.dot.on{background:#075742;border-color:#075742;transform:scale(1.08)}
			.pad{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
			.pad button{border:0;background:#f2f4f2;font-size:21px;padding:17px 0;border-radius:13px;cursor:pointer;font-weight:600;color:#1f2430}
			.pad button:active{background:#e2e6e2;transform:scale(.97)}
			.pad .go{background:#075742;color:#fff}
			.err{color:#c8302e;font-size:13px;min-height:19px;margin:12px 0 0}
			.locked{background:#fdf3f2;border:1px solid #f3c9c7;color:#a12b28;border-radius:10px;padding:13px;font-size:13px}
			.foot{margin-top:18px;font-size:12px;color:#a2a7ae}
		</style>
		<div class="auth-wrap"><div class="auth<?php echo 'bad' === $err ? ' bad' : ''; ?>">
			<?php $auth_logo = self::logo_url(); ?>
			<?php if ( $auth_logo ) : ?>
				<img class="brand-img" src="<?php echo esc_url( $auth_logo ); ?>" alt="<?php echo esc_attr( self::brand() ); ?>">
			<?php else : ?>
				<div class="brand"><?php echo esc_html( mb_substr( self::brand(), 0, 2 ) ); ?></div>
			<?php endif; ?>
			<h2><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h2>
			<div class="sub"><?php esc_html_e( 'Enter your PIN to continue', 'wc-enterprise-erp' ); ?></div>

			<?php if ( $locked ) : ?>
				<div class="locked">
					<strong><?php esc_html_e( 'Too many attempts.', 'wc-enterprise-erp' ); ?></strong><br>
					<?php
					printf(
						esc_html__( 'Try again in about %d minutes.', 'wc-enterprise-erp' ),
						(int) max( 1, ceil( $remain / 60 ) )
					);
					?>
				</div>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="f">
					<input type="hidden" name="action" value="wceerp_portal_login">
					<?php wp_nonce_field( 'wceerp_portal_login' ); ?>
					<input type="hidden" name="pin" id="pin" value="">
					<div class="dots">
						<span class="dot" data-i="0"></span><span class="dot" data-i="1"></span>
						<span class="dot" data-i="2"></span><span class="dot" data-i="3"></span>
					</div>
					<div class="pad">
						<?php for ( $i = 1; $i <= 9; $i++ ) : ?>
							<button type="button" data-k="<?php echo (int) $i; ?>"><?php echo (int) $i; ?></button>
						<?php endfor; ?>
						<button type="button" data-clear="1">⌫</button>
						<button type="button" data-k="0">0</button>
						<button type="submit" class="go">→</button>
					</div>
					<div class="err"><?php echo 'bad' === $err ? esc_html__( 'Incorrect PIN', 'wc-enterprise-erp' ) : ''; ?></div>
				</form>
			<?php endif; ?>
			<div class="foot"><?php echo esc_html( self::brand() ); ?></div>
		</div></div>
		<script>
			var v='',pin=document.getElementById('pin');
			function paint(){document.querySelectorAll('.dot').forEach(function(d,i){d.classList.toggle('on',i<v.length);});pin.value=v;}
			document.querySelectorAll('.pad button[data-k]').forEach(function(b){
				b.addEventListener('click',function(){if(v.length<4){v+=b.dataset.k;paint();}if(v.length===4){setTimeout(function(){document.getElementById('f').submit();},120);}});
			});
			var c=document.querySelector('.pad button[data-clear]');
			if(c){c.addEventListener('click',function(){v='';paint();});}
			document.addEventListener('keydown',function(e){
				if(e.key>='0'&&e.key<='9'&&v.length<4){v+=e.key;paint();if(v.length===4){document.getElementById('f').submit();}}
				if(e.key==='Backspace'){v=v.slice(0,-1);paint();}
			});
		</script>
		</body></html>
		<?php
	}

	/**
	 * Headline figures for the staff hub.
	 *
	 * Read from the ledger rather than from WooCommerce, so the portal
	 * cannot disagree with the reports — a shop owner comparing the two and
	 * finding different numbers loses faith in both.
	 *
	 * Deltas compare against the equivalent earlier period, which is the
	 * only comparison that means anything on a partial month.
	 */
	protected static function overview() {
		$today = current_time( 'Y-m-d' );
		$start = gmdate( 'Y-m-01', strtotime( $today ) );

		// Same number of days, one month back.
		$days       = (int) gmdate( 'j', strtotime( $today ) );
		$prev_start = gmdate( 'Y-m-01', strtotime( $start . ' -1 month' ) );
		$prev_end   = gmdate( 'Y-m-d', strtotime( $prev_start . ' +' . ( $days - 1 ) . ' days' ) );

		$now  = self::period_figures( $start, $today );
		$prev = self::period_figures( $prev_start, $prev_end );

		$delta = function ( $a, $b ) {
			if ( $b <= 0.004 ) {
				return null; // no baseline; a percentage would be meaningless
			}
			return round( ( $a - $b ) / $b * 100, 1 );
		};

		return array(
			'sales'         => $now['sales'],
			'sales_delta'   => $delta( $now['sales'], $prev['sales'] ),
			'orders'        => $now['orders'],
			'orders_delta'  => $delta( $now['orders'], $prev['orders'] ),
			'customers'     => $now['customers'],
			'profit'        => $now['profit'],
			'profit_delta'  => $delta( $now['profit'], $prev['profit'] ),
		);
	}

	/** Sales, profit, order and customer counts for a date range. */
	protected static function period_figures( $from, $to ) {
		global $wpdb;

		$sales  = 0.0;
		$cogs   = 0.0;
		$expend = 0.0;

		if ( class_exists( 'WCEERP_Accounting' ) ) {
			foreach ( (array) WCEERP_Accounting::trial_balance( $from, $to ) as $row ) {
				$net = (float) $row->credit - (float) $row->debit;
				if ( 'income' === $row->type ) {
					$sales += $net;
				} elseif ( 'expense' === $row->type ) {
					// Expenses sit the other way round.
					$amount = (float) $row->debit - (float) $row->credit;
					if ( '5000' === $row->code ) {
						$cogs += $amount;
					} else {
						$expend += $amount;
					}
				}
			}
		}

		$orders    = 0;
		$customers = 0;
		if ( function_exists( 'wc_get_orders' ) ) {
			$found = wc_get_orders( array(
				'limit'        => -1,
				'status'       => array( 'processing', 'completed' ),
				'date_created' => $from . '...' . $to,
				'return'       => 'ids',
			) );
			$orders = count( (array) $found );

			/* Distinct buyers, counting guests by phone — most customers
			 * here never register an account. */
			$seen = array();
			foreach ( (array) $found as $oid ) {
				$o = wc_get_order( $oid );
				if ( ! $o ) {
					continue;
				}
				$key = $o->get_customer_id() ?: preg_replace( '/\D/', '', (string) $o->get_billing_phone() );
				if ( $key ) {
					$seen[ $key ] = 1;
				}
			}
			$customers = count( $seen );
		}

		return array(
			'sales'     => round( $sales, 2 ),
			'profit'    => round( $sales - $cogs - $expend, 2 ),
			'orders'    => $orders,
			'customers' => $customers,
		);
	}

	/** The last few orders, for the hub list. */
	protected static function recent_orders( $limit = 8 ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$out = array();
		foreach ( (array) wc_get_orders( array(
			'limit'   => (int) $limit,
			'orderby' => 'date',
			'order'   => 'DESC',
			'return'  => 'objects',
		) ) as $order ) {
			$name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
			$out[] = array(
				'number' => $order->get_order_number(),
				'name'   => $name ?: __( 'Guest', 'wc-enterprise-erp' ),
				'total'  => (float) $order->get_total(),
				'status' => $order->get_status(),
			);
		}
		return $out;
	}

	/** The hub shown once the PIN is accepted. */
	protected static function render_hub() {
		$tiles    = self::tiles();
		$can_see  = is_user_logged_in() && wceerp_user_can( 'wceerp_view_dashboard' );
		$data     = $can_see ? self::overview() : array();
		$orders   = $can_see ? self::recent_orders() : array();
		$license  = class_exists( 'WCEERP_License' ) ? WCEERP_License::get() : array( 'tier' => 'starter', 'status' => 'inactive', 'expires' => '' );
		$in_trial = class_exists( 'WCEERP_License' ) && WCEERP_License::in_trial();

		self::head( __( 'ERP', 'wc-enterprise-erp' ) );
		?>
		<style>
			.hub{padding-bottom:34px}

			/* ---- Plan banner ------------------------------------------- */
			.plan{background:linear-gradient(118deg,#5b3df5,#7c4dff 58%,#9163ff);
				border-radius:20px;padding:16px 18px;display:flex;align-items:center;gap:14px;
				color:#fff;margin-bottom:22px;box-shadow:0 10px 26px rgba(91,61,245,.28);position:relative;overflow:hidden}
			.plan::after{content:'';position:absolute;width:180px;height:180px;border-radius:50%;
				background:rgba(255,255,255,.09);top:-70px;right:-40px}
			.plan .crown{font-size:30px;line-height:1;flex:0 0 auto;position:relative}
			.plan .txt{flex:1;min-width:0;position:relative}
			.plan .txt b{display:block;font-size:16px;font-weight:700;letter-spacing:-.01em}
			.plan .txt span{font-size:12.5px;opacity:.88}
			.plan .cta{background:#ffc93c;color:#3a2a00;border-radius:24px;padding:10px 18px;
				font-weight:700;font-size:13px;white-space:nowrap;position:relative;
				box-shadow:0 4px 12px rgba(255,201,60,.4)}

			/* ---- Metric cards ------------------------------------------ */
			.sect{display:flex;align-items:center;justify-content:space-between;margin:0 0 12px}
			.sect h2{font-size:16px;font-weight:700;letter-spacing:-.01em}
			.sect a{font-size:13px;font-weight:650;color:#5b3df5}
			.metrics{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:24px}
			.mc{border-radius:18px;padding:15px 16px;position:relative;overflow:hidden;min-height:104px;
				display:flex;flex-direction:column;justify-content:center}
			.mc .lbl{font-size:12.5px;font-weight:600;opacity:.9;margin-bottom:5px}
			.mc .val{font-size:21px;font-weight:750;letter-spacing:-.02em;line-height:1.15;word-break:break-word}
			.mc .chg{font-size:12px;font-weight:650;margin-top:5px;opacity:.92}
			.mc .bgic{position:absolute;right:12px;top:12px;font-size:20px;opacity:.32}
			.mc.green{background:linear-gradient(135deg,#1eb85f,#14a052);color:#fff}
			.mc.blue{background:linear-gradient(135deg,#3a8dff,#2b6fd6);color:#fff}
			.mc.peach{background:#ffe9d6;color:#8a4b12}
			.mc.pink{background:#ffe1e8;color:#a8203c}

			/* ---- Feature tiles ----------------------------------------- */
			.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
			.tile{background:#fff;border-radius:16px;padding:13px 5px 11px;text-align:center;
				display:flex;flex-direction:column;align-items:center;gap:7px;
				box-shadow:0 1px 3px rgba(16,24,20,.06),0 6px 16px rgba(16,24,20,.05);
				transition:transform .14s ease,box-shadow .14s ease}
			.tile:active{transform:scale(.95)}
			.tile .ic{width:42px;height:42px;border-radius:13px;display:flex;align-items:center;
				justify-content:center;font-size:20px;flex:0 0 auto}
			.tile .nm{font-size:10.5px;font-weight:600;color:#2b3a34;line-height:1.2;
				display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
				padding:0 3px;word-break:break-word}

			/* Each module gets a stable colour so staff learn positions by hue. */
			.i1{background:#ede9ff;color:#5b3df5}   .i2{background:#e3f7ec;color:#16a34a}
			.i3{background:#fff2dd;color:#d97706}   .i4{background:#e4f0ff;color:#2b6fd6}
			.i5{background:#ffe4ec;color:#db2777}   .i6{background:#e6faf7;color:#0d9488}
			.i7{background:#fdeee2;color:#c2410c}   .i8{background:#eef2ff;color:#4f46e5}

			/* ---- Recent orders ----------------------------------------- */
			.feed{background:#fff;border-radius:18px;padding:6px 4px;
				box-shadow:0 1px 3px rgba(16,24,20,.06),0 6px 16px rgba(16,24,20,.05)}
			.row{display:flex;align-items:center;gap:12px;padding:13px 14px;border-bottom:1px solid #f2f5f3}
			.row:last-child{border-bottom:0}
			.row .av{width:38px;height:38px;border-radius:12px;background:#e3f7ec;color:#16a34a;
				display:flex;align-items:center;justify-content:center;font-size:17px;flex:0 0 auto}
			.row .mid{flex:1;min-width:0}
			.row .mid b{display:block;font-size:13.5px;font-weight:650}
			.row .mid span{font-size:12px;color:#8e9a95;display:block;white-space:nowrap;
				overflow:hidden;text-overflow:ellipsis}
			.row .end{text-align:right;flex:0 0 auto}
			.row .end b{display:block;font-size:13.5px;font-weight:700}
			.row .st{font-size:10.5px;font-weight:650;border-radius:20px;padding:2px 9px;display:inline-block;margin-top:3px}
			.st-processing{background:#fff2dd;color:#b45309}
			.st-completed{background:#e3f7ec;color:#15803d}
			.st-pending,.st-on-hold{background:#ffe9e9;color:#b91c1c}
			.st-cancelled,.st-refunded,.st-failed{background:#eef0ee;color:#6b7280}

			.empty{background:#fff;border-radius:18px;padding:26px 18px;text-align:center;color:#8e9a95;font-size:13.5px}
			.note{color:#9aa5a0;font-size:11.5px;text-align:center;margin-top:22px}

			@media(min-width:620px){
				.metrics{grid-template-columns:repeat(4,1fr)}
				.tiles{grid-template-columns:repeat(6,1fr)}
				.tile .nm{font-size:11.5px}
			}
			@media(min-width:900px){
				.tiles{grid-template-columns:repeat(8,1fr)}
			}
			@media(max-width:340px){
				.tiles{grid-template-columns:repeat(3,1fr)}
			}
		</style>
		<?php self::topbar(); ?>

		<div class="shell hub">

			<?php /* Plan banner. Shows what they have and the way to upgrade. */ ?>
			<a class="plan" href="<?php echo esc_url( self::url() . '/plan' ); ?>">
				<span class="crown">👑</span>
				<span class="txt">
					<b>
						<?php
						if ( $in_trial ) {
							$days = WCEERP_License::trial_days_left();
							/* translators: %d: days left */
							echo esc_html( sprintf( _n( 'Free trial — %d day left', 'Free trial — %d days left', $days, 'wc-enterprise-erp' ), $days ) );
						} else {
							echo esc_html( ucfirst( $license['tier'] ?: 'starter' ) . ' ' . __( 'Plan', 'wc-enterprise-erp' ) );
						}
						?>
					</b>
					<span>
						<?php
						if ( ! empty( $license['expires'] ) ) {
							/* translators: %s: date */
							echo esc_html( sprintf( __( 'Valid till %s', 'wc-enterprise-erp' ), mysql2date( 'j M Y', $license['expires'] ) ) );
						} elseif ( 'active' === $license['status'] ) {
							esc_html_e( 'Lifetime licence', 'wc-enterprise-erp' );
						} else {
							esc_html_e( 'Tap to see your plan', 'wc-enterprise-erp' );
						}
						?>
					</span>
				</span>
				<span class="cta"><?php echo 'active' === $license['status'] && ! $in_trial ? esc_html__( 'Manage', 'wc-enterprise-erp' ) : esc_html__( 'Upgrade', 'wc-enterprise-erp' ); ?></span>
			</a>

			<?php if ( $can_see ) : ?>
				<div class="sect"><h2><?php esc_html_e( 'Business Overview', 'wc-enterprise-erp' ); ?></h2>
					<a href="<?php echo esc_url( self::url() . '/reports' ); ?>"><?php esc_html_e( 'Reports', 'wc-enterprise-erp' ); ?></a>
				</div>
				<?php
				$cards = array(
					array( 'green', __( 'Total Sales', 'wc-enterprise-erp' ), wceerp_money( $data['sales'] ), $data['sales_delta'], '📈' ),
					array( 'blue', __( 'Total Orders', 'wc-enterprise-erp' ), number_format_i18n( $data['orders'] ), $data['orders_delta'], '🧾' ),
					array( 'peach', __( 'Customers', 'wc-enterprise-erp' ), number_format_i18n( $data['customers'] ), null, '👥' ),
					array( 'pink', __( 'Net Profit', 'wc-enterprise-erp' ), wceerp_money( $data['profit'] ), $data['profit_delta'], '💰' ),
				);
				?>
				<div class="metrics">
					<?php foreach ( $cards as $c ) : ?>
						<div class="mc <?php echo esc_attr( $c[0] ); ?>">
							<span class="bgic"><?php echo esc_html( $c[4] ); ?></span>
							<div class="lbl"><?php echo esc_html( $c[1] ); ?></div>
							<div class="val"><?php echo wp_kses_post( $c[2] ); ?></div>
							<?php if ( null !== $c[3] ) : ?>
								<div class="chg"><?php echo $c[3] >= 0 ? '▲' : '▼'; ?> <?php echo esc_html( abs( $c[3] ) ); ?>%</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="empty" style="margin-bottom:22px">
					<?php esc_html_e( 'Sign in to see your business figures.', 'wc-enterprise-erp' ); ?><br>
					<a href="<?php echo esc_url( wp_login_url( self::url() ) ); ?>" style="color:#5b3df5;font-weight:650"><?php esc_html_e( 'Sign in →', 'wc-enterprise-erp' ); ?></a>
				</div>
			<?php endif; ?>

			<div class="sect"><h2><?php esc_html_e( 'Feature Modules', 'wc-enterprise-erp' ); ?></h2></div>
			<div class="tiles">
				<?php foreach ( $tiles as $n => $t ) : ?>
					<a class="tile" href="<?php echo esc_url( $t['url'] ); ?>">
						<span class="ic i<?php echo (int) ( ( $n % 8 ) + 1 ); ?>"><?php echo esc_html( $t['icon'] ); ?></span>
						<span class="nm"><?php echo esc_html( $t['label'] ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>

			<?php if ( $can_see ) : ?>
				<div class="sect" style="margin-top:26px">
					<h2><?php esc_html_e( 'Recent Orders', 'wc-enterprise-erp' ); ?></h2>
					<a href="<?php echo esc_url( self::url() . '/courier' ); ?>"><?php esc_html_e( 'View all', 'wc-enterprise-erp' ); ?></a>
				</div>
				<?php if ( $orders ) : ?>
					<div class="feed">
						<?php foreach ( $orders as $o ) : ?>
							<div class="row">
								<span class="av">🧾</span>
								<span class="mid">
									<b>#<?php echo esc_html( $o['number'] ); ?></b>
									<span><?php echo esc_html( $o['name'] ); ?></span>
								</span>
								<span class="end">
									<b><?php echo wp_kses_post( wceerp_money( $o['total'] ) ); ?></b>
									<span class="st st-<?php echo esc_attr( $o['status'] ); ?>"><?php echo esc_html( ucfirst( str_replace( '-', ' ', $o['status'] ) ) ); ?></span>
								</span>
							</div>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<div class="empty"><?php esc_html_e( 'No orders yet.', 'wc-enterprise-erp' ); ?></div>
				<?php endif; ?>
			<?php endif; ?>

			<p class="note"><?php esc_html_e( 'Locked automatically after 12 hours.', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php if ( class_exists( 'WCEERP_PWA' ) ) { WCEERP_PWA::install_script(); } ?>
		</body></html>
		<?php
	}

	/** Today's takings, read from the ledger. */
	protected static function today_sales() {
		if ( ! class_exists( 'WCEERP_Accounting' ) ) {
			return '—';
		}
		$today = current_time( 'Y-m-d' );
		$rows  = WCEERP_Accounting::trial_balance( $today, $today );
		$total = 0.0;
		foreach ( (array) $rows as $r ) {
			if ( 'income' === $r->type ) {
				$total += (float) $r->credit - (float) $r->debit;
			}
		}
		return wceerp_money( $total );
	}

	/** Which shortcuts to show, respecting the current package. */
	/** Icons for the tiles; anything unlisted gets a neutral default. */
	protected static function icons() {
		return array(
			'pos' => '🧾', 'inventory' => '📦', 'courier' => '🚚', 'expenses' => '💸',
			'dues' => '💰', 'reports' => '📊', 'purchases' => '🛒', 'customers' => '👥',
			'suppliers' => '🏭', 'quotations' => '📄', 'warehouses' => '🏬', 'staff' => '👤',
			'accounting' => '📒', 'analytics' => '📈', 'crm' => '🤝', 'assets' => '🏗️',
			'hr' => '🧑‍💼', 'plan' => '⭐', 'dashboard' => '🏠', 'tax' => '🧮',
			'notifications' => '🔔', 'banking' => '🏦', 'connect' => '🔗',
		);
	}

	/**
	 * Every module the current plan includes and this user may see.
	 *
	 * Built from the live module registry rather than a fixed list, so a
	 * tier upgrade or a new module appears here without a code change.
	 */
	protected static function tiles() {
		$icons   = self::icons();
		$modules = array();
		if ( function_exists( 'wceerp' ) && method_exists( wceerp(), 'modules' ) ) {
			$modules = (array) wceerp()->modules();
		}
		$out     = array();

		// POS is a genuine front-end screen, so it links straight there.
		if ( isset( $modules['pos'] ) && $modules['pos']->is_active() ) {
			$out[] = array(
				'icon'  => '🧾',
				'label' => __( 'POS', 'wc-enterprise-erp' ),
				'desc'  => __( 'Sell at the counter', 'wc-enterprise-erp' ),
				'url'   => home_url( '/wceerp-pos' ),
			);
		}

		foreach ( $modules as $id => $module ) {
			if ( in_array( $id, array( 'pos' ), true ) || ! $module->is_active() ) {
				continue;
			}
			// Respect the signed-in user's permissions when we know them.
			if ( is_user_logged_in() && ! wceerp_user_can( $module->get_capability() ) ) {
				continue;
			}
			$out[] = array(
				'icon'  => $icons[ $id ] ?? '▫️',
				'label' => $module->get_title(),
				'desc'  => '',
				'url'   => self::url() . '/' . $id,
			);
		}
		return $out;
	}

	/**
	 * Rewrite an admin redirect back into the app.
	 *
	 * Handlers redirect to admin.php?page=wceerp-courier&tab=payouts. For a
	 * request that began in the app the equivalent is /erp/courier?tab=payouts,
	 * and anything else strands the user in wp-admin — which on a phone is
	 * where the app appeared to break.
	 */
	public static function keep_in_portal( $location ) {
		if ( empty( $_REQUEST['wceerp_from_portal'] ) ) {
			return $location;
		}

		$admin = admin_url( 'admin.php' );
		if ( 0 !== strpos( $location, $admin ) ) {
			return $location; // going somewhere else entirely; leave it alone
		}

		$query = wp_parse_url( $location, PHP_URL_QUERY );
		if ( ! $query ) {
			return $location;
		}
		parse_str( $query, $args );

		$page = isset( $args['page'] ) ? (string) $args['page'] : '';
		if ( 0 !== strpos( $page, 'wceerp-' ) ) {
			return $location;
		}

		$screen = sanitize_key( substr( $page, strlen( 'wceerp-' ) ) );
		unset( $args['page'] );

		$url = self::url() . '/' . $screen;
		return $args ? add_query_arg( $args, $url ) : $url;
	}

}
