<?php
/**
 * Import a courier's payout statement.
 *
 * A remittance covers a hundred or more parcels. Typing each collected
 * amount and each charge by hand is hours of work and a guaranteed source of
 * error, so the statement the courier already produces is read instead.
 *
 * Matching is by the courier's memo or reference column, which for Bahok
 * carries the ERP's own consignment number — the same doc_no printed on the
 * label. Where that is absent the courier's own parcel id is tried, then the
 * tracking code. Nothing is guessed: a row that matches nothing is reported
 * rather than quietly skipped, because a payout that silently drops parcels
 * leaves money stranded in the receivable for ever.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Payout_Import {

	/**
	 * Column aliases.
	 *
	 * Couriers all name these differently and change them without notice,
	 * so headers are matched loosely rather than by position.
	 */
	public static function aliases() {
		return array(
			'memo' => array( 'memo no', 'memo', 'invoice', 'invoice no', 'merchant order id', 'order id', 'reference', 'consignment', 'cn no', 'cn' ),
			'cid'  => array( 'bahok id', 'consignment id', 'parcel id', 'tracking', 'tracking code', 'tracking id', 'awb' ),
			'name' => array( 'customer info', 'customer', 'recipient', 'name' ),
			'coll' => array( 'collected', 'collected amount', 'cod collected', 'received', 'collected tk' ),
			'price'=> array( 'price', 'cod', 'cod amount', 'amount', 'invoice value' ),
			'stat' => array( 'status', 'parcel status', 'delivery status' ),
			'ch_service' => array( 'service charge', 'delivery charge', 'charge' ),
			'ch_weight'  => array( 'weight charge' ),
			'ch_cod'     => array( 'cod charge', 'cod fee' ),
			'ch_return'  => array( 'return charge' ),
			'ch_area'    => array( 'area charge' ),
			'final'      => array( 'final amount', 'net amount', 'payable', 'total' ),
		);
	}

	/* ------------------------------------------------------------------
	 * Reading files
	 * ---------------------------------------------------------------- */

	/**
	 * @return array|WP_Error Rows of cells.
	 */
	public static function read( $path, $name ) {
		$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

		if ( 'csv' === $ext || 'txt' === $ext ) {
			return self::read_csv( $path );
		}
		if ( 'xlsx' === $ext ) {
			return self::read_xlsx( $path );
		}
		return new WP_Error( 'wceerp_import', __( 'Upload the statement as .xlsx or .csv. If you have a PDF, use the Excel download instead — a PDF cannot be read reliably.', 'wc-enterprise-erp' ) );
	}

	protected static function read_csv( $path ) {
		$rows = array();
		$fh   = fopen( $path, 'r' );
		if ( ! $fh ) {
			return new WP_Error( 'wceerp_import', __( 'Could not open that file.', 'wc-enterprise-erp' ) );
		}
		while ( ( $line = fgetcsv( $fh, 0, ',' ) ) !== false ) {
			$rows[] = array_map( function ( $c ) {
				// Excel exports often carry a BOM on the first cell.
				return trim( str_replace( "\xEF\xBB\xBF", '', (string) $c ) );
			}, $line );
		}
		fclose( $fh );
		return $rows;
	}

	/**
	 * Minimal xlsx reader.
	 *
	 * An xlsx is a zip of XML. Only the first worksheet and the shared
	 * string table are needed, which avoids pulling in a spreadsheet
	 * library that many shared hosts cannot install.
	 */
	protected static function read_xlsx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'wceerp_import', __( 'This server cannot open .xlsx files. Open the file in Excel and save it as CSV, then upload that.', 'wc-enterprise-erp' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) {
			return new WP_Error( 'wceerp_import', __( 'That file is not a readable spreadsheet.', 'wc-enterprise-erp' ) );
		}

		// Shared strings: cells of type "s" hold an index into this table.
		$shared = array();
		$ss     = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( $ss ) {
			$xml = simplexml_load_string( $ss, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET );
			if ( $xml ) {
				foreach ( $xml->si as $si ) {
					// Runs of formatted text arrive split across <r><t> nodes.
					$text = '';
					if ( isset( $si->t ) ) {
						$text = (string) $si->t;
					} elseif ( isset( $si->r ) ) {
						foreach ( $si->r as $r ) {
							$text .= (string) $r->t;
						}
					}
					$shared[] = $text;
				}
			}
		}

		$sheet = $zip->getFromName( 'xl/worksheets/sheet1.xml' );
		$zip->close();
		if ( ! $sheet ) {
			return new WP_Error( 'wceerp_import', __( 'That spreadsheet has no readable first sheet.', 'wc-enterprise-erp' ) );
		}

		$xml = simplexml_load_string( $sheet, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET );
		if ( ! $xml ) {
			return new WP_Error( 'wceerp_import', __( 'That spreadsheet could not be parsed.', 'wc-enterprise-erp' ) );
		}

		$rows = array();
		foreach ( $xml->sheetData->row as $row ) {
			$cells = array();
			foreach ( $row->c as $c ) {
				$ref  = (string) $c['r'];                       // e.g. "C12"
				$col  = self::col_index( preg_replace( '/\d/', '', $ref ) );
				$type = (string) $c['t'];
				$val  = '';

				if ( 's' === $type ) {
					$idx = (int) $c->v;
					$val = $shared[ $idx ] ?? '';
				} elseif ( 'inlineStr' === $type ) {
					$val = (string) $c->is->t;
				} else {
					$val = (string) $c->v;
				}
				$cells[ $col ] = trim( $val );
			}
			if ( $cells ) {
				// Fill gaps so column positions stay aligned.
				$max  = max( array_keys( $cells ) );
				$flat = array();
				for ( $i = 0; $i <= $max; $i++ ) {
					$flat[] = $cells[ $i ] ?? '';
				}
				$rows[] = $flat;
			}
		}
		return $rows;
	}

	/** "AB" → 27 */
	protected static function col_index( $letters ) {
		$letters = strtoupper( $letters );
		$n       = 0;
		for ( $i = 0; $i < strlen( $letters ); $i++ ) {
			$n = $n * 26 + ( ord( $letters[ $i ] ) - 64 );
		}
		return max( 0, $n - 1 );
	}

	/* ------------------------------------------------------------------
	 * Understanding the sheet
	 * ---------------------------------------------------------------- */

	/**
	 * Find the header row and map its columns.
	 *
	 * The header is rarely the first row: these exports carry a title and
	 * a summary block above the table.
	 */
	/**
	 * The courier's own payment reference, e.g. "Payment ID: #BHKM-P-38540".
	 *
	 * It sits in a title row above the table rather than in a column, and
	 * it is the single most useful thing to keep: it is what you quote when
	 * querying a remittance, and what ties our payout to theirs.
	 */
	public static function payment_id( $rows ) {
		foreach ( array_slice( $rows, 0, 25 ) as $row ) {
			foreach ( (array) $row as $cell ) {
				// The id is often prefixed with a hash, e.g. "Payment ID: #BHKM-P-38540".
				if ( preg_match( '/payment\s*id\s*[:\s#]*([A-Za-z0-9][A-Za-z0-9\-]*)/i', (string) $cell, $m ) ) {
					return $m[1];
				}
			}
		}
		return '';
	}

	/**
	 * Fields a statement can supply, and what each one is for.
	 *
	 * Shown to the user when they map columns by hand, so the labels have
	 * to make sense to a shop owner rather than to a developer.
	 */
	public static function fields() {
		return array(
			'memo'       => array( __( 'Your consignment number', 'wc-enterprise-erp' ), true ),
			'cid'        => array( __( "The courier's own parcel id", 'wc-enterprise-erp' ), false ),
			'name'       => array( __( 'Customer name', 'wc-enterprise-erp' ), false ),
			'stat'       => array( __( 'Delivery status', 'wc-enterprise-erp' ), false ),
			'coll'       => array( __( 'Amount collected from the customer', 'wc-enterprise-erp' ), true ),
			'price'      => array( __( 'Order value', 'wc-enterprise-erp' ), false ),
			'ch_service' => array( __( 'Delivery charge', 'wc-enterprise-erp' ), false ),
			'ch_weight'  => array( __( 'Weight charge', 'wc-enterprise-erp' ), false ),
			'ch_cod'     => array( __( 'COD fee', 'wc-enterprise-erp' ), false ),
			'ch_return'  => array( __( 'Return charge', 'wc-enterprise-erp' ), false ),
			'ch_area'    => array( __( 'Area charge', 'wc-enterprise-erp' ), false ),
			'final'      => array( __( 'Net paid to you', 'wc-enterprise-erp' ), false ),
		);
	}

	/** A mapping the user saved for this courier, if any. */
	public static function saved_map( $courier ) {
		$all = (array) get_option( 'wceerp_payout_maps', array() );
		$m   = $all[ sanitize_key( $courier ) ] ?? null;
		return is_array( $m ) && $m ? $m : null;
	}

	/**
	 * Remember a mapping so the same courier never has to be mapped twice.
	 *
	 * Stored per courier rather than globally: Steadfast and Bahok lay their
	 * statements out completely differently, and a single mapping would be
	 * wrong for one of them by definition.
	 */
	public static function save_map( $courier, $header_row, $map ) {
		$all = (array) get_option( 'wceerp_payout_maps', array() );
		$all[ sanitize_key( $courier ) ] = array(
			'header' => (int) $header_row,
			'map'    => array_map( 'intval', (array) $map ),
			'saved'  => current_time( 'mysql' ),
		);
		update_option( 'wceerp_payout_maps', $all, false );
	}

	public static function forget_map( $courier ) {
		$all = (array) get_option( 'wceerp_payout_maps', array() );
		unset( $all[ sanitize_key( $courier ) ] );
		update_option( 'wceerp_payout_maps', $all, false );
	}

	/**
	 * Best guess at the header row, whether or not the columns are known.
	 *
	 * map() only succeeds when enough columns are recognised. This finds the
	 * row that looks most like a header regardless, so an unfamiliar
	 * statement can still be mapped by hand instead of simply refusing.
	 */
	public static function guess_header( $rows ) {
		$best  = null;
		$score = 0;

		foreach ( array_slice( $rows, 0, 40, true ) as $i => $row ) {
			$filled = 0;
			$texty  = 0;
			foreach ( (array) $row as $cell ) {
				$cell = trim( (string) $cell );
				if ( '' === $cell ) {
					continue;
				}
				$filled++;
				// A header is words, not figures.
				if ( ! is_numeric( str_replace( array( ',', '.' ), '', $cell ) ) ) {
					$texty++;
				}
			}
			/* Wants several columns, nearly all of them words. A summary
			 * block above the table has few columns; a data row has
			 * numbers. */
			if ( $filled >= 4 && $texty >= $filled - 1 && $filled > $score ) {
				$score = $filled;
				$best  = $i;
			}
		}
		return $best;
	}

	/** Column headings of a given row, for the mapping form. */
	public static function headings( $rows, $header ) {
		$out = array();
		foreach ( (array) ( $rows[ $header ] ?? array() ) as $pos => $cell ) {
			$label = trim( (string) $cell );
			$out[ $pos ] = ( '' === $label )
				? sprintf( __( 'Column %d', 'wc-enterprise-erp' ), $pos + 1 )
				: $label;
		}
		return $out;
	}

	public static function map( $rows ) {
		$aliases = self::aliases();

		foreach ( $rows as $i => $row ) {
			$map   = array();
			$score = 0;
			foreach ( $row as $pos => $cell ) {
				$key = strtolower( trim( preg_replace( '/\s+/', ' ', (string) $cell ) ) );
				if ( '' === $key ) {
					continue;
				}
				foreach ( $aliases as $field => $names ) {
					if ( isset( $map[ $field ] ) ) {
						continue;
					}
					if ( in_array( $key, $names, true ) ) {
						$map[ $field ] = $pos;
						$score++;
						break;
					}
				}
			}
			/* A real header carries an identifier and a money column. Two
			 * stray matches in a summary block must not win. */
			$has_id    = isset( $map['memo'] ) || isset( $map['cid'] );
			$has_money = isset( $map['coll'] ) || isset( $map['final'] ) || isset( $map['price'] );
			if ( $has_id && $has_money && $score >= 3 ) {
				return array( 'header' => $i, 'map' => $map );
			}
		}
		return null;
	}

	protected static function num( $v ) {
		$v = str_replace( array( ',', '৳', 'TK', 'tk', ' ' ), '', (string) $v );
		return is_numeric( $v ) ? (float) $v : 0.0;
	}

	/* ------------------------------------------------------------------
	 * Matching
	 * ---------------------------------------------------------------- */

	/**
	 * Turn sheet rows into something postable.
	 *
	 * @return array {matched, unmatched, totals}
	 */
	/**
	 * Compare a courier's payment file against the ERP, and change nothing.
	 *
	 * `prepare()` exists to settle parcels; this exists to explain a
	 * disagreement. The distinction matters, because the moment you are
	 * chasing a mismatch the last thing you want is the tool quietly
	 * altering the thing you are measuring.
	 *
	 * Five outcomes, each needing a different response:
	 *
	 *   agreed      the file and the ERP say the same thing
	 *   differs     both know the parcel, the amounts disagree
	 *   unbooked    the courier delivered and was paid for a parcel this
	 *               ERP has never heard of — booked in their portal, or
	 *               the consignment was deleted. The one that silently
	 *               loses money, because nothing here is waiting for it.
	 *   settled     already covered by an earlier payout
	 *   missing     the ERP is waiting for money this file does not mention
	 *
	 * @return array
	 */
	public static function analyse( $rows, $found, $courier = '' ) {
		global $wpdb;

		$map    = $found['map'];
		$start  = (int) $found['header'] + 1;
		$table  = wceerp_table( 'consignments' );

		$out = array(
			'agreed'   => array(),
			'differs'  => array(),
			'unbooked' => array(),
			'settled'  => array(),
			'missing'  => array(),
			'file_total' => 0.0,
			'erp_total'  => 0.0,
		);

		$seen_ids = array();

		foreach ( $rows as $i => $row ) {
			if ( $i < $start ) {
				continue;
			}

			$memo = isset( $map['memo'] ) ? trim( (string) ( $row[ $map['memo'] ] ?? '' ) ) : '';
			$cid  = isset( $map['cid'] ) ? trim( (string) ( $row[ $map['cid'] ] ?? '' ) ) : '';
			if ( '' === $memo && '' === $cid ) {
				continue; // blank or spacer row
			}

			$coll_raw = isset( $map['coll'] ) ? trim( (string) ( $row[ $map['coll'] ] ?? '' ) ) : '';
			$collected = ( '' !== $coll_raw ) ? self::num( $coll_raw ) : 0.0;

			$line = array(
				'memo'      => $memo,
				'cid'       => $cid,
				'name'      => isset( $map['name'] ) ? trim( (string) ( $row[ $map['name'] ] ?? '' ) ) : '',
				'collected' => $collected,
			);
			$out['file_total'] += $collected;

			$c = self::find_consignment( $memo, $cid );

			if ( ! $c ) {
				$out['unbooked'][] = $line;
				continue;
			}

			$seen_ids[ (int) $c->id ] = true;
			$line['doc_no'] = $c->doc_no;
			$line['due']    = (float) $c->cod_amount - (float) $c->collected_amount;

			if ( (int) $c->payout_id ) {
				$out['settled'][] = $line;
				continue;
			}

			if ( abs( $collected - $line['due'] ) > 0.5 ) {
				$line['gap']       = round( $collected - $line['due'], 2 );
				$out['differs'][]  = $line;
			} else {
				$out['agreed'][] = $line;
			}
		}

		/* What the ERP is still waiting for that this file never mentions.
		 * Restricted to the courier in question, or every other courier's
		 * parcels would appear as missing. */
		$where = "status = 'delivered' AND payout_id IS NULL AND cod_amount - collected_amount > 0.004";
		$args  = array();
		if ( $courier ) {
			$where .= ' AND courier = %s';
			$args[] = $courier;
		}
		$sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at ASC LIMIT 500";
		$open = $args
			? (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ) )
			: (array) $wpdb->get_results( $sql );

		foreach ( $open as $c ) {
			$out['erp_total'] += (float) $c->cod_amount - (float) $c->collected_amount;
			if ( isset( $seen_ids[ (int) $c->id ] ) ) {
				continue;
			}
			$out['missing'][] = array(
				'doc_no' => $c->doc_no,
				'name'   => $c->recipient_name,
				'due'    => (float) $c->cod_amount - (float) $c->collected_amount,
			);
		}

		return $out;
	}

	/** Match a file row to a consignment, by our reference then theirs. */
	protected static function find_consignment( $memo, $cid ) {
		global $wpdb;
		$table = wceerp_table( 'consignments' );

		if ( '' !== $memo ) {
			$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE doc_no = %s LIMIT 1", $memo ) );
			if ( $c ) {
				return $c;
			}
		}
		if ( '' !== $cid ) {
			$c = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$table} WHERE remote_id = %s OR tracking_code = %s LIMIT 1",
				$cid,
				$cid
			) );
			if ( $c ) {
				return $c;
			}
		}
		return null;
	}

	public static function prepare( $rows, $found ) {
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$map   = $found['map'];

		$matched = array();
		$seen    = array();

		/* Problems are grouped rather than lumped together, because they
		 * need different actions: an unmatched row might be a parcel booked
		 * outside the ERP, a duplicate is harmless, and a blank amount needs
		 * someone to look at the sheet. */
		$issues = array(
			'unmatched' => array(),
			'duplicate' => array(),
			'settled'   => array(),
			'no_amount' => array(),
			'over'      => array(),
		);

		$total_collected = 0.0;
		$total_charges   = 0.0;

		foreach ( array_slice( $rows, $found['header'] + 1 ) as $row ) {
			$memo = isset( $map['memo'] ) ? trim( (string) ( $row[ $map['memo'] ] ?? '' ) ) : '';
			$cid  = isset( $map['cid'] ) ? trim( (string) ( $row[ $map['cid'] ] ?? '' ) ) : '';
			if ( '' === $memo && '' === $cid ) {
				continue; // blank or summary line
			}

			$status = isset( $map['stat'] ) ? strtolower( trim( (string) ( $row[ $map['stat'] ] ?? '' ) ) ) : '';

			/* A blank cell is not zero.
			 *
			 * Treating it as zero made the row look like a return, and a
			 * return settles the parcel and reverses the sale — so one
			 * missing value in a spreadsheet could wipe out a real order.
			 * Blank means "this sheet does not say", which is a question,
			 * not an instruction. */
			$coll_raw  = isset( $map['coll'] ) ? trim( (string) ( $row[ $map['coll'] ] ?? '' ) ) : '';
			$has_coll  = ( '' !== $coll_raw );
			$collected = $has_coll ? self::num( $coll_raw ) : 0.0;
			$charge  = 0.0;
			$mapped  = 0;
			foreach ( array( 'ch_service', 'ch_weight', 'ch_cod', 'ch_return', 'ch_area' ) as $k ) {
				if ( isset( $map[ $k ] ) ) {
					$charge += self::num( $row[ $map[ $k ] ] ?? 0 );
					$mapped++;
				}
			}

			/* When the sheet gives a net figure, trust it over the parts.
			 *
			 * A statement can carry five charge columns and a mapping may
			 * only name one — Bahok's COD fee got mapped while delivery and
			 * weight did not, so a payout recorded 1,157.80 of charges when
			 * the real deduction was 8,631.45. The difference between what
			 * the customer paid and what the courier remits IS the charge,
			 * whatever it is made of, so where the net column exists it
			 * settles the question. */
			/* Keep the parts as well as the total.
			 *
			 * "Courier charge 135.50" answers less than "100 delivery + 30
			 * weight + 5.50 COD fee" when you are checking a statement line
			 * by line, so the components are stored where the sheet gives
			 * them. */
			$part_delivery = 0.0;
			foreach ( array( 'ch_service', 'ch_weight', 'ch_area', 'ch_return' ) as $k ) {
				if ( isset( $map[ $k ] ) ) {
					$part_delivery += self::num( $row[ $map[ $k ] ] ?? 0 );
				}
			}
			$part_cod = isset( $map['ch_cod'] ) ? self::num( $row[ $map['ch_cod'] ] ?? 0 ) : 0.0;

			if ( isset( $map['final'] ) ) {
				$net_raw = trim( (string) ( $row[ $map['final'] ] ?? '' ) );
				if ( '' !== $net_raw ) {
					$net_paid  = self::num( $net_raw );
					$from_net  = round( $collected - $net_paid, 2 );
					// Only when it looks like a fee rather than nonsense.
					if ( $from_net > 0.004 && $from_net <= $collected ) {
						$charge = $from_net;
					}
				}
			}

			/* Find the parcel. The memo column is the ERP's own consignment
			 * number, so it is tried first and is by far the most reliable. */
			$c = null;
			if ( '' !== $memo ) {
				$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE doc_no = %s", $memo ) );
			}
			if ( ! $c && '' !== $cid ) {
				$c = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM {$table} WHERE remote_id = %s OR tracking_code = %s LIMIT 1",
					$cid, $cid
				) );
			}

			$line = array(
				'memo'      => $memo,
				'cid'       => $cid,
				'name'      => isset( $map['name'] ) ? (string) ( $row[ $map['name'] ] ?? '' ) : '',
				'status'    => $status,
				'collected' => $collected,
				'charge'    => round( $charge, 2 ),
				'ch_deliv'  => round( $part_delivery, 2 ),
				'ch_cod'    => round( $part_cod, 2 ),
			);

			/* Every check below skips the row and carries on. A statement of
			 * two hundred parcels should never fail because three of them
			 * have a problem — the rest are still money that needs
			 * recording, and the problems are listed afterwards. */
			if ( ! $c ) {
				$issues['unmatched'][] = $line;
				continue;
			}
			if ( isset( $seen[ (int) $c->id ] ) ) {
				$line['doc_no']        = $c->doc_no;
				$issues['duplicate'][] = $line;
				continue;
			}
			if ( (int) $c->payout_id ) {
				$line['doc_no']      = $c->doc_no;
				$issues['settled'][] = $line;
				continue;
			}
			if ( ! $has_coll && $charge <= 0.004 ) {
				/* Nothing usable on the row at all. */
				$line['doc_no']        = $c->doc_no;
				$issues['no_amount'][] = $line;
				continue;
			}

			$seen[ (int) $c->id ] = 1;
			$line['id']      = (int) $c->id;
			$line['doc_no']  = $c->doc_no;
			$line['due']     = (float) $c->cod_amount - (float) $c->collected_amount;
			$line['recipient'] = $c->recipient_name;

			/* A returned parcel collects nothing but still costs a charge.
			 * It must not credit the receivable, or the books will show
			 * money arriving that never did. */
			/* Only an explicit zero means a return. A blank means the sheet
			 * is silent, and that must not reverse a sale. */
			$line['is_return'] = ( $has_coll && $collected <= 0.004 );

			/* More collected than was owed. Usually the sheet lists the
			 * order value rather than what was taken, or the parcel was
			 * part-settled before. Recorded and capped rather than trusted. */
			if ( $collected - $line['due'] > 0.004 ) {
				$line['reported']  = $collected;
				$collected         = $line['due'];
				$line['collected'] = $collected;
				$issues['over'][]  = $line;
			}

			$total_collected += $collected;
			$total_charges   += $line['charge'];
			$matched[]        = $line;
		}

		/* Kept as `unmatched` as well, so anything still reading the old
		 * shape keeps working. */
		$all_issues = array_merge(
			$issues['unmatched'],
			$issues['duplicate'],
			$issues['settled'],
			$issues['no_amount']
		);

		return array(
			'matched'   => $matched,
			'issues'    => $issues,
			'unmatched' => $all_issues,
			'totals'    => array(
				'collected' => round( $total_collected, 2 ),
				'charges'   => round( $total_charges, 2 ),
				'net'       => round( $total_collected - $total_charges, 2 ),
				'count'     => count( $matched ),
			),
		);
	}
}
