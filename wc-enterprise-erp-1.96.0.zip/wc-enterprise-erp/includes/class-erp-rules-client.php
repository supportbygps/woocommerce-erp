<?php
/**
 * Rules client (A2 thin-client, customer side).
 *
 * The customer's site owns its data and its screens. For the decisions
 * that carry the vendor's intellectual property — how a transaction
 * decomposes into journal lines, VAT treatment, COD maths, margin
 * shaping — it asks the vendor's Rules API and posts what comes back.
 *
 * Three rules this class refuses to break:
 *
 *   1. NEVER GUESS. If the API is unreachable the transaction is queued
 *      and retried; the client does not invent journal lines. Books that
 *      are late can be fixed. Books that are wrong are a liability.
 *
 *   2. NEVER POST UNBALANCED. Every response is re-checked locally
 *      before it touches the ledger, so a bad or tampered response can't
 *      corrupt the books.
 *
 *   3. IDEMPOTENT. Each queued job carries a reference; a job already
 *      posted is skipped, so retries can't double-count revenue.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Rules_Client {

	const QUEUE_OPTION = 'wceerp_rules_queue';
	const CRON         = 'wceerp_rules_retry';

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'process_queue' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedule' ) );
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 300, 'wceerp_five_minutes', self::CRON );
		}
		add_action( 'admin_notices', array( __CLASS__, 'queue_notice' ) );
	}

	public static function cron_schedule( $schedules ) {
		$schedules['wceerp_five_minutes'] = array(
			'interval' => 300,
			'display'  => __( 'Every five minutes', 'wc-enterprise-erp' ),
		);
		return $schedules;
	}

	protected static function endpoint() {
		$base = defined( 'WCEERP_RULES_ENDPOINT' )
			? WCEERP_RULES_ENDPOINT
			: wceerp_get_option( 'rules_endpoint', '' );
		return untrailingslashit( (string) $base );
	}

	protected static function license_key() {
		if ( class_exists( 'WCEERP_License' ) ) {
			$l = WCEERP_License::get();
			return (string) ( $l['key'] ?? '' );
		}
		return '';
	}

	public static function is_configured() {
		return self::endpoint() && self::license_key();
	}

	/* ---------------------------------------------------------------------
	 * The call.
	 * ------------------------------------------------------------------- */

	/**
	 * Ask the Rules API for a decision.
	 * Returns the decoded payload, or WP_Error — never a fabricated result.
	 */
	public static function ask( $route, $payload ) {
		if ( ! self::is_configured() ) {
			return new WP_Error( 'wceerp_rules_client', __( 'Rules service is not configured (endpoint or licence key missing).', 'wc-enterprise-erp' ) );
		}

		$key  = self::license_key();
		$body = wp_json_encode( $payload );
		$ts   = time();
		$sig  = hash_hmac( 'sha256', $ts . '.' . $body, $key );

		$response = wp_remote_post( self::endpoint() . '/' . ltrim( $route, '/' ), array(
			'timeout' => 20,
			'headers' => array(
				'Content-Type'        => 'application/json',
				'Accept'              => 'application/json',
				'x-wceerp-key'        => $key,
				'x-wceerp-timestamp'  => (string) $ts,
				'x-wceerp-signature'  => $sig,
			),
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 401 === $code || 403 === $code ) {
			$msg = is_array( $data ) && ! empty( $data['message'] ) ? $data['message'] : __( 'Rules service refused the licence.', 'wc-enterprise-erp' );
			return new WP_Error( 'wceerp_rules_client', $msg );
		}
		if ( $code < 200 || $code >= 300 || empty( $data['success'] ) ) {
			$msg = is_array( $data ) && ! empty( $data['message'] ) ? $data['message'] : sprintf( __( 'Rules service error (HTTP %d).', 'wc-enterprise-erp' ), $code );
			return new WP_Error( 'wceerp_rules_client', $msg );
		}
		return $data;
	}

	/**
	 * Ask for journal lines and post them locally.
	 *
	 * @param string $route   e.g. 'journal/sale'
	 * @param array  $payload facts about the transaction
	 * @param array  $meta    journal header (ref_type, ref_id, memo, date)
	 * @return int|WP_Error journal id, or error (already queued)
	 */
	public static function post_journal( $route, $payload, $meta ) {
		$ref_type = (string) ( $meta['ref_type'] ?? 'rules' );
		$ref_id   = (int) ( $meta['ref_id'] ?? 0 );

		// Idempotency: has this reference already been posted?
		if ( self::already_posted( $ref_type, $ref_id ) ) {
			return 0;
		}

		$result = self::ask( $route, $payload );
		if ( is_wp_error( $result ) ) {
			self::enqueue( $route, $payload, $meta );
			return $result;
		}

		$lines = isset( $result['lines'] ) && is_array( $result['lines'] ) ? $result['lines'] : array();
		if ( ! $lines ) {
			return new WP_Error( 'wceerp_rules_client', __( 'Rules service returned no journal lines.', 'wc-enterprise-erp' ) );
		}

		// Re-verify balance locally. Never trust a remote response with the
		// books, even one we asked for.
		$dr = 0.0;
		$cr = 0.0;
		foreach ( $lines as $l ) {
			$dr += (float) ( $l['debit'] ?? 0 );
			$cr += (float) ( $l['credit'] ?? 0 );
		}
		if ( abs( $dr - $cr ) > 0.005 ) {
			return new WP_Error( 'wceerp_rules_client', __( 'Rules service returned an unbalanced journal — refused.', 'wc-enterprise-erp' ) );
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $meta['journal_date'] ?? current_time( 'Y-m-d' ),
				'ref_type'     => $ref_type,
				'ref_id'       => $ref_id,
				'memo'         => (string) ( $meta['memo'] ?? '' ),
			),
			$lines
		);
		return $journal;
	}

	/** Has a journal already been posted for this reference? */
	protected static function already_posted( $ref_type, $ref_id ) {
		global $wpdb;
		if ( ! $ref_id ) {
			return false;
		}
		$table = wceerp_table( 'journals' );
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $table WHERE ref_type = %s AND ref_id = %d AND status = 'posted' LIMIT 1",
			$ref_type,
			$ref_id
		) );
	}

	/* ---------------------------------------------------------------------
	 * Queue — the answer to "what if the API is down".
	 * ------------------------------------------------------------------- */

	protected static function enqueue( $route, $payload, $meta ) {
		$queue = (array) get_option( self::QUEUE_OPTION, array() );
		$id    = ( $meta['ref_type'] ?? 'rules' ) . ':' . ( $meta['ref_id'] ?? 0 );
		$queue[ $id ] = array(
			'route'    => $route,
			'payload'  => $payload,
			'meta'     => $meta,
			'attempts' => (int) ( $queue[ $id ]['attempts'] ?? 0 ),
			'queued_at' => current_time( 'mysql' ),
		);
		update_option( self::QUEUE_OPTION, $queue, false );
	}

	/** Retry queued transactions. Runs every five minutes. */
	public static function process_queue() {
		$queue = (array) get_option( self::QUEUE_OPTION, array() );
		if ( ! $queue ) {
			return;
		}
		$done = array();
		foreach ( $queue as $id => $job ) {
			$result = self::post_journal( $job['route'], $job['payload'], $job['meta'] );
			if ( ! is_wp_error( $result ) ) {
				$done[] = $id;
				continue;
			}
			$queue[ $id ]['attempts'] = (int) $job['attempts'] + 1;
			$queue[ $id ]['last_error'] = $result->get_error_message();
		}
		foreach ( $done as $id ) {
			unset( $queue[ $id ] );
		}
		update_option( self::QUEUE_OPTION, $queue, false );
	}

	public static function queue_size() {
		return count( (array) get_option( self::QUEUE_OPTION, array() ) );
	}

	/**
	 * Tell the operator when transactions are waiting. Silence here would
	 * mean books quietly falling behind.
	 */
	public static function queue_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = self::queue_size();
		if ( ! $n ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
			esc_html__( 'ERP:', 'wc-enterprise-erp' ),
			esc_html( sprintf(
				/* translators: %d: number of queued transactions */
				_n(
					'%d transaction is waiting for the rules service and has not reached the ledger yet. It will post automatically when the connection returns.',
					'%d transactions are waiting for the rules service and have not reached the ledger yet. They will post automatically when the connection returns.',
					$n,
					'wc-enterprise-erp'
				),
				$n
			) )
		);
	}
}
