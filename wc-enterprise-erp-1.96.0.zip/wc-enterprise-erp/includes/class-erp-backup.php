<?php
/**
 * ERP backup and restore.
 *
 * Exports the plugin's own tables to a SQL file that can be downloaded and
 * restored later. Written in batches so a large shop does not exhaust memory.
 *
 * IMPORTANT SCOPE LIMIT — this is not a site backup.
 *
 * It covers ERP tables only. WooCommerce orders, customers, products and
 * WordPress itself are not included, because they are not ours to restore and
 * rolling them back would destroy trading records. The consequence is that
 * restoring an old ERP backup onto a site whose orders have moved on will
 * leave the two out of step: orders placed since the backup will exist in
 * WooCommerce with no ERP journal behind them.
 *
 * Treat this as a safety net for ERP experiments, not as a replacement for a
 * server-level database backup.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Backup {

	const DIR = 'wceerp-backups';

	/** Rows fetched per batch when exporting. */
	const BATCH = 500;

	/**
	 * Backup directory, created and protected on first use.
	 *
	 * @return string|WP_Error Absolute path with trailing slash.
	 */
	public static function dir() {
		$uploads = wp_upload_dir();
		if ( ! empty( $uploads['error'] ) ) {
			return new WP_Error( 'wceerp_backup', $uploads['error'] );
		}
		$dir = trailingslashit( $uploads['basedir'] ) . self::DIR . '/';

		if ( ! file_exists( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'wceerp_backup', __( 'Could not create the backup folder.', 'wc-enterprise-erp' ) );
		}

		/* Backups contain the whole business ledger, so they must never be
		 * fetchable over HTTP. .htaccess covers Apache; the index file and
		 * the unguessable filename cover the rest. Downloads always go
		 * through admin-post with a capability check. */
		if ( ! file_exists( $dir . '.htaccess' ) ) {
			file_put_contents( $dir . '.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		}
		if ( ! file_exists( $dir . 'index.php' ) ) {
			file_put_contents( $dir . 'index.php', "<?php // Silence is golden.\n" );
		}
		return $dir;
	}

	/** Every table this plugin owns, in dependency-safe order. */
	public static function tables() {
		global $wpdb;
		$prefix = $wpdb->prefix . 'wceerp_';
		$found  = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $prefix ) . '%' ) );
		sort( $found );
		return (array) $found;
	}

	/**
	 * Write a backup file.
	 *
	 * @return array|WP_Error { file, path, size, tables, rows }
	 */
	public static function create( $note = '' ) {
		global $wpdb;

		$dir = self::dir();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		$name = sprintf(
			'erp-%s-%s.sql',
			gmdate( 'Ymd-His' ),
			wp_generate_password( 8, false, false )
		);
		$path = $dir . $name;

		$fh = fopen( $path, 'w' );
		if ( ! $fh ) {
			return new WP_Error( 'wceerp_backup', __( 'Could not open the backup file for writing.', 'wc-enterprise-erp' ) );
		}

		$tables = self::tables();
		$rows   = 0;

		$manifest = array(
			'plugin_version' => WCEERP_VERSION,
			'db_prefix'      => $wpdb->prefix,
			'site_url'       => home_url(),
			'created_at'     => current_time( 'mysql' ),
			'created_by'     => wp_get_current_user()->user_login,
			'note'           => sanitize_text_field( $note ),
			'tables'         => array_values( $tables ),
		);

		fwrite( $fh, "-- WooCommerce ERP backup\n" );
		fwrite( $fh, '-- MANIFEST: ' . wp_json_encode( $manifest ) . "\n" );
		fwrite( $fh, "SET FOREIGN_KEY_CHECKS=0;\n\n" );

		foreach ( $tables as $table ) {
			fwrite( $fh, "\n-- TABLE {$table}\n" );
			fwrite( $fh, "TRUNCATE TABLE `{$table}`;\n" );

			$offset = 0;
			while ( true ) {
				$batch = $wpdb->get_results(
					$wpdb->prepare( "SELECT * FROM `{$table}` LIMIT %d OFFSET %d", self::BATCH, $offset ),
					ARRAY_A
				);
				if ( ! $batch ) {
					break;
				}
				foreach ( $batch as $row ) {
					$cols = array();
					$vals = array();
					foreach ( $row as $col => $val ) {
						$cols[] = '`' . str_replace( '`', '', $col ) . '`';
						$vals[] = ( null === $val ) ? 'NULL' : "'" . esc_sql( $val ) . "'";
					}
					fwrite( $fh, "INSERT INTO `{$table}` (" . implode( ',', $cols ) . ') VALUES (' . implode( ',', $vals ) . ");\n" );
					$rows++;
				}
				$offset += self::BATCH;
			}
		}

		fwrite( $fh, "\nSET FOREIGN_KEY_CHECKS=1;\n" );
		fclose( $fh );

		wceerp_log( 'settings', 'backup_created', 0, $name . ' — ' . $rows . ' rows' );

		return array(
			'file'   => $name,
			'path'   => $path,
			'size'   => filesize( $path ),
			'tables' => count( $tables ),
			'rows'   => $rows,
		);
	}

	/** Backups on disk, newest first. */
	public static function all() {
		$dir = self::dir();
		if ( is_wp_error( $dir ) ) {
			return array();
		}
		$out = array();
		foreach ( (array) glob( $dir . 'erp-*.sql' ) as $path ) {
			$out[] = array(
				'file'     => basename( $path ),
				'size'     => filesize( $path ),
				'modified' => filemtime( $path ),
				'manifest' => self::read_manifest( $path ),
			);
		}
		usort( $out, function ( $a, $b ) {
			return $b['modified'] <=> $a['modified'];
		} );
		return $out;
	}

	/** Read the manifest line without loading the whole file. */
	public static function read_manifest( $path ) {
		$fh = @fopen( $path, 'r' );
		if ( ! $fh ) {
			return array();
		}
		$manifest = array();
		for ( $i = 0; $i < 5; $i++ ) {
			$line = fgets( $fh );
			if ( false === $line ) {
				break;
			}
			if ( 0 === strpos( $line, '-- MANIFEST: ' ) ) {
				$manifest = json_decode( substr( $line, 13 ), true );
				break;
			}
		}
		fclose( $fh );
		return is_array( $manifest ) ? $manifest : array();
	}

	/** Resolve a user-supplied filename safely inside the backup folder. */
	public static function path_for( $file ) {
		$dir = self::dir();
		if ( is_wp_error( $dir ) ) {
			return $dir;
		}
		$file = basename( (string) $file );
		if ( ! preg_match( '/^erp-[0-9\-]+-[A-Za-z0-9]+\.sql$/', $file ) ) {
			return new WP_Error( 'wceerp_backup', __( 'That is not a valid backup file name.', 'wc-enterprise-erp' ) );
		}
		$path = $dir . $file;
		if ( ! file_exists( $path ) ) {
			return new WP_Error( 'wceerp_backup', __( 'Backup file not found.', 'wc-enterprise-erp' ) );
		}
		return $path;
	}

	public static function delete( $file ) {
		$path = self::path_for( $file );
		if ( is_wp_error( $path ) ) {
			return $path;
		}
		wp_delete_file( $path );
		wceerp_log( 'settings', 'backup_deleted', 0, basename( $file ) );
		return true;
	}

	/**
	 * Restore a backup, replacing the current ERP tables.
	 *
	 * A backup taken on a different plugin version may not match the current
	 * schema; unknown tables and columns are skipped rather than guessed at,
	 * and the caller is told what was ignored.
	 *
	 * @return array|WP_Error { statements, skipped, warnings }
	 */
	public static function restore( $file ) {
		global $wpdb;

		$path = self::path_for( $file );
		if ( is_wp_error( $path ) ) {
			return $path;
		}

		$manifest = self::read_manifest( $path );
		$warnings = array();

		if ( ! empty( $manifest['plugin_version'] ) && WCEERP_VERSION !== $manifest['plugin_version'] ) {
			$warnings[] = sprintf(
				/* translators: 1: backup version, 2: current version. */
				__( 'This backup was made on version %1$s but you are running %2$s. Anything the schema has changed since then was skipped.', 'wc-enterprise-erp' ),
				$manifest['plugin_version'],
				WCEERP_VERSION
			);
		}
		if ( ! empty( $manifest['db_prefix'] ) && $wpdb->prefix !== $manifest['db_prefix'] ) {
			return new WP_Error( 'wceerp_backup', sprintf(
				/* translators: 1: backup prefix, 2: this site's prefix. */
				__( 'This backup is from a database using the table prefix "%1$s"; this site uses "%2$s". Restoring it here would create the wrong tables.', 'wc-enterprise-erp' ),
				$manifest['db_prefix'],
				$wpdb->prefix
			) );
		}

		$existing = array_flip( self::tables() );

		$fh = fopen( $path, 'r' );
		if ( ! $fh ) {
			return new WP_Error( 'wceerp_backup', __( 'Could not read the backup file.', 'wc-enterprise-erp' ) );
		}

		$ran     = 0;
		$skipped = 0;

		$wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' );

		while ( false !== ( $line = fgets( $fh ) ) ) {
			$line = trim( $line );
			if ( '' === $line || 0 === strpos( $line, '--' ) || 0 === strpos( $line, 'SET ' ) ) {
				continue;
			}
			if ( ! preg_match( '/^(TRUNCATE TABLE|INSERT INTO) `([^`]+)`/', $line, $m ) ) {
				continue;
			}
			// Only ever touch tables that exist here and are ours.
			if ( ! isset( $existing[ $m[2] ] ) ) {
				$skipped++;
				continue;
			}
			$result = $wpdb->query( $line );
			if ( false === $result ) {
				$skipped++;
			} else {
				$ran++;
			}
		}

		fclose( $fh );
		$wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' );

		if ( $skipped ) {
			$warnings[] = sprintf(
				/* translators: %d: number of skipped statements. */
				__( '%d statements were skipped — usually rows for tables or columns that no longer exist.', 'wc-enterprise-erp' ),
				$skipped
			);
		}

		wceerp_log( 'settings', 'backup_restored', 0, basename( $file ) . " — {$ran} ok, {$skipped} skipped" );

		return array(
			'statements' => $ran,
			'skipped'    => $skipped,
			'warnings'   => $warnings,
		);
	}
}
