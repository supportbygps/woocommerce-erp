<?php
/**
 * Two-factor authentication for the ERP portal.
 *
 * The portal's PIN authorises a *device*. Two-factor authorises a
 * *person*: a six-digit code from an authenticator app (Google
 * Authenticator, Authy, Microsoft Authenticator) that changes every 30
 * seconds and cannot be reused.
 *
 * Why this matters here specifically: a 4-digit PIN has 10,000
 * combinations and is often shared across a shop floor. Adding TOTP means
 * that even a leaked PIN does not by itself open the books, because the
 * attacker also needs a device-bound secret they cannot guess.
 *
 * Implementation notes:
 *   - RFC 6238 TOTP, SHA-1, 6 digits, 30-second step — what every
 *     mainstream authenticator app expects.
 *   - A one-step window either side, so a slightly wrong device clock
 *     still works without meaningfully widening the attack surface.
 *   - Used codes are remembered for their lifetime, so an intercepted
 *     code cannot be replayed.
 *   - Recovery codes exist because people lose phones, and being locked
 *     out of your own accounting is its own kind of disaster.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_TwoFactor {

	const META_SECRET   = 'wceerp_2fa_secret';
	const META_ENABLED  = 'wceerp_2fa_enabled';
	const META_RECOVERY = 'wceerp_2fa_recovery';
	const DIGITS        = 6;
	const PERIOD        = 30;
	const WINDOW        = 1; // steps either side

	public static function boot() {
		add_action( 'admin_post_wceerp_2fa_setup', array( __CLASS__, 'handle_setup' ) );
		add_action( 'admin_post_wceerp_2fa_disable', array( __CLASS__, 'handle_disable' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'profile_section' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_section' ) );
	}

	/* ---------------------------------------------------------------------
	 * Base32 (RFC 4648) — authenticator apps expect secrets in this form.
	 * ------------------------------------------------------------------- */

	protected static function base32_alphabet() {
		return 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
	}

	public static function generate_secret( $length = 32 ) {
		$alphabet = self::base32_alphabet();
		$secret   = '';
		for ( $i = 0; $i < $length; $i++ ) {
			$secret .= $alphabet[ random_int( 0, 31 ) ];
		}
		return $secret;
	}

	protected static function base32_decode( $input ) {
		$alphabet = self::base32_alphabet();
		$input    = strtoupper( str_replace( '=', '', trim( $input ) ) );
		$buffer   = 0;
		$bits     = 0;
		$out      = '';
		for ( $i = 0, $len = strlen( $input ); $i < $len; $i++ ) {
			$pos = strpos( $alphabet, $input[ $i ] );
			if ( false === $pos ) {
				continue;
			}
			$buffer = ( $buffer << 5 ) | $pos;
			$bits  += 5;
			if ( $bits >= 8 ) {
				$bits -= 8;
				$out  .= chr( ( $buffer >> $bits ) & 0xFF );
			}
		}
		return $out;
	}

	/* ---------------------------------------------------------------------
	 * TOTP.
	 * ------------------------------------------------------------------- */

	/** The code for a given secret at a given time step. */
	public static function code_at( $secret, $step ) {
		$key    = self::base32_decode( $secret );
		$binary = pack( 'N*', 0 ) . pack( 'N*', $step ); // 64-bit big-endian counter
		$hash   = hash_hmac( 'sha1', $binary, $key, true );
		$offset = ord( substr( $hash, -1 ) ) & 0x0F;
		$part   = substr( $hash, $offset, 4 );
		$value  = unpack( 'N', $part )[1] & 0x7FFFFFFF;
		return str_pad( $value % ( 10 ** self::DIGITS ), self::DIGITS, '0', STR_PAD_LEFT );
	}

	/**
	 * Verify a submitted code.
	 * Accepts the current step plus one either side to tolerate clock drift.
	 */
	public static function verify( $user_id, $code ) {
		$code = preg_replace( '/\D/', '', (string) $code );
		if ( strlen( $code ) !== self::DIGITS ) {
			return false;
		}
		$secret = get_user_meta( $user_id, self::META_SECRET, true );
		if ( ! $secret ) {
			return false;
		}
		// Replay protection: a code is valid once only.
		$used_key = 'wceerp_2fa_used_' . $user_id . '_' . $code;
		if ( get_transient( $used_key ) ) {
			return false;
		}

		$now = (int) floor( time() / self::PERIOD );
		for ( $i = -self::WINDOW; $i <= self::WINDOW; $i++ ) {
			if ( hash_equals( self::code_at( $secret, $now + $i ), $code ) ) {
				set_transient( $used_key, 1, self::PERIOD * ( self::WINDOW * 2 + 1 ) );
				return true;
			}
		}
		return self::use_recovery_code( $user_id, $code );
	}

	/* ---------------------------------------------------------------------
	 * Recovery codes.
	 * ------------------------------------------------------------------- */

	public static function generate_recovery_codes( $user_id, $count = 8 ) {
		$codes  = array();
		$hashed = array();
		for ( $i = 0; $i < $count; $i++ ) {
			$code     = strtoupper( wp_generate_password( 10, false, false ) );
			$codes[]  = $code;
			$hashed[] = wp_hash_password( $code );
		}
		update_user_meta( $user_id, self::META_RECOVERY, $hashed );
		return $codes;
	}

	protected static function use_recovery_code( $user_id, $code ) {
		$hashed = (array) get_user_meta( $user_id, self::META_RECOVERY, true );
		foreach ( $hashed as $i => $hash ) {
			if ( wp_check_password( strtoupper( $code ), $hash ) ) {
				unset( $hashed[ $i ] ); // single use
				update_user_meta( $user_id, self::META_RECOVERY, array_values( $hashed ) );
				return true;
			}
		}
		return false;
	}

	public static function recovery_remaining( $user_id ) {
		return count( (array) get_user_meta( $user_id, self::META_RECOVERY, true ) );
	}

	/* ---------------------------------------------------------------------
	 * State.
	 * ------------------------------------------------------------------- */

	public static function is_enabled( $user_id ) {
		return (bool) get_user_meta( $user_id, self::META_ENABLED, true )
			&& get_user_meta( $user_id, self::META_SECRET, true );
	}

	/** Is 2FA required before this user may use the portal? */
	public static function required_for( $user_id ) {
		if ( 'yes' === wceerp_get_option( 'portal_2fa_required', 'no' ) ) {
			return true;
		}
		return self::is_enabled( $user_id );
	}

	/** otpauth:// URI — what the QR code encodes. */
	public static function provisioning_uri( $user_id, $secret ) {
		$user  = get_userdata( $user_id );
		$issuer = rawurlencode( apply_filters( 'wceerp_brand', 'WooCommerce ERP' ) );
		$label  = rawurlencode( ( $user ? $user->user_login : 'user' ) . '@' . wp_parse_url( home_url(), PHP_URL_HOST ) );
		return 'otpauth://totp/' . $label . '?secret=' . $secret . '&issuer=' . $issuer . '&digits=' . self::DIGITS . '&period=' . self::PERIOD;
	}

	/* ---------------------------------------------------------------------
	 * Setup UI (on the WordPress profile screen).
	 * ------------------------------------------------------------------- */

	public static function profile_section( $user ) {
		if ( get_current_user_id() !== $user->ID && ! current_user_can( 'edit_users' ) ) {
			return;
		}
		$enabled = self::is_enabled( $user->ID );
		$pending = get_user_meta( $user->ID, self::META_SECRET, true );
		if ( ! $pending ) {
			$pending = self::generate_secret();
			update_user_meta( $user->ID, self::META_SECRET, $pending );
		}
		$uri = self::provisioning_uri( $user->ID, $pending );
		?>
		<h2 id="wceerp-2fa"><?php esc_html_e( 'ERP two-factor authentication', 'wc-enterprise-erp' ); ?></h2>
		<table class="form-table"><tbody>
			<tr>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<td>
					<?php if ( $enabled ) : ?>
						<p style="color:#2f8a4c;font-weight:600">🔒 <?php esc_html_e( 'Two-factor is on for this account.', 'wc-enterprise-erp' ); ?></p>
						<p class="description">
							<?php
							printf(
								esc_html__( '%d recovery codes remaining.', 'wc-enterprise-erp' ),
								(int) self::recovery_remaining( $user->ID )
							);
							?>
						</p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
							onsubmit="return confirm('<?php echo esc_js( __( 'Turn off two-factor for this account?', 'wc-enterprise-erp' ) ); ?>');">
							<input type="hidden" name="action" value="wceerp_2fa_disable">
							<input type="hidden" name="user_id" value="<?php echo (int) $user->ID; ?>">
							<?php wp_nonce_field( 'wceerp_2fa_disable' ); ?>
							<?php submit_button( __( 'Turn off two-factor', 'wc-enterprise-erp' ), 'delete', 'submit', false ); ?>
						</form>
					<?php else : ?>
						<p class="description" style="max-width:640px">
							<?php esc_html_e( 'Scan this with Google Authenticator, Authy or a similar app, then enter the six-digit code it shows to switch two-factor on. The ERP portal will ask for a code after the PIN.', 'wc-enterprise-erp' ); ?>
						</p>
						<p>
							<img alt="<?php esc_attr_e( 'Authenticator QR code', 'wc-enterprise-erp' ); ?>" width="180" height="180"
								src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=<?php echo rawurlencode( $uri ); ?>">
						</p>
						<p class="description">
							<?php esc_html_e( 'Cannot scan? Enter this key manually:', 'wc-enterprise-erp' ); ?>
							<code style="font-size:14px;letter-spacing:1px"><?php echo esc_html( $pending ); ?></code>
						</p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="wceerp_2fa_setup">
							<input type="hidden" name="user_id" value="<?php echo (int) $user->ID; ?>">
							<?php wp_nonce_field( 'wceerp_2fa_setup' ); ?>
							<input type="text" name="code" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required
								placeholder="000000" style="width:120px;font-size:18px;letter-spacing:4px;text-align:center">
							<?php submit_button( __( 'Verify & enable', 'wc-enterprise-erp' ), 'primary', 'submit', false ); ?>
						</form>
					<?php endif; ?>
				</td>
			</tr>
		</tbody></table>
		<?php
	}

	public static function handle_setup() {
		if ( ! check_admin_referer( 'wceerp_2fa_setup' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		$user_id = (int) ( $_POST['user_id'] ?? 0 );
		if ( get_current_user_id() !== $user_id && ! current_user_can( 'edit_users' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		$code = preg_replace( '/\D/', '', (string) ( $_POST['code'] ?? '' ) );

		if ( self::verify( $user_id, $code ) ) {
			update_user_meta( $user_id, self::META_ENABLED, 1 );
			$codes = self::generate_recovery_codes( $user_id );
			set_transient( 'wceerp_2fa_codes_' . $user_id, $codes, 10 * MINUTE_IN_SECONDS );
			wp_safe_redirect( add_query_arg( 'wceerp_2fa', 'on', get_edit_user_link( $user_id ) ) );
			exit;
		}
		wp_safe_redirect( add_query_arg( 'wceerp_2fa', 'bad', get_edit_user_link( $user_id ) ) );
		exit;
	}

	public static function handle_disable() {
		if ( ! check_admin_referer( 'wceerp_2fa_disable' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		$user_id = (int) ( $_POST['user_id'] ?? 0 );
		if ( get_current_user_id() !== $user_id && ! current_user_can( 'edit_users' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		delete_user_meta( $user_id, self::META_ENABLED );
		delete_user_meta( $user_id, self::META_SECRET );
		delete_user_meta( $user_id, self::META_RECOVERY );
		wp_safe_redirect( add_query_arg( 'wceerp_2fa', 'off', get_edit_user_link( $user_id ) ) );
		exit;
	}
}
