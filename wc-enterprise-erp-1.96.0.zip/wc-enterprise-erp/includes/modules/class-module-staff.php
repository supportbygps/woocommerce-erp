<?php
/**
 * Module: Staff.
 *
 * Create and manage the people who use the ERP, without sending a shop
 * owner into WordPress's own Users screens — which expose roles and
 * options that mean nothing to them and can break the site.
 *
 * A staff member here is a WordPress user with an ERP role. The module
 * respects the package's user limit, so adding staff is the moment a
 * customer discovers they have outgrown their plan.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Staff extends WCEERP_Module {

	protected $id         = 'staff';
	protected $capability = 'wceerp_manage_settings';
	protected $tier       = 'starter';
	protected $order      = 90;

	public function __construct() {
		$this->title = __( 'Staff', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_staff_create', array( $this, 'handle_create' ) );
		add_action( 'admin_post_wceerp_staff_update', array( $this, 'handle_update' ) );
	}

	/**
	 * ERP-relevant roles, described in language a shop owner understands.
	 * Mapped to real WordPress roles so capabilities behave normally.
	 */
	public static function roles() {
		return apply_filters( 'wceerp_staff_roles', array(
			'administrator' => array(
				'label' => __( 'Owner / Administrator', 'wc-enterprise-erp' ),
				'desc'  => __( 'Full access, including settings, licence and all money screens.', 'wc-enterprise-erp' ),
			),
			'shop_manager'  => array(
				'label' => __( 'Manager', 'wc-enterprise-erp' ),
				'desc'  => __( 'Runs the business day to day: stock, purchases, orders, reports.', 'wc-enterprise-erp' ),
			),
			'wceerp_staff'  => array(
				'label' => __( 'Sales / POS staff', 'wc-enterprise-erp' ),
				'desc'  => __( 'Can sell at the POS and see stock. No accounting, profit or payroll.', 'wc-enterprise-erp' ),
			),
		) );
	}

	/** Create the limited staff role once, if it doesn't exist. */
	public static function ensure_staff_role() {
		if ( get_role( 'wceerp_staff' ) ) {
			return;
		}
		add_role( 'wceerp_staff', __( 'ERP Sales Staff', 'wc-enterprise-erp' ), array(
			'read'                    => true,
			'wceerp_view_dashboard'   => true,
			'wceerp_use_pos'          => true,
			'wceerp_manage_inventory' => false,
		) );
	}

	/** Users who hold an ERP role. */
	protected function staff_users() {
		return get_users( array(
			'role__in' => array_keys( self::roles() ),
			'orderby'  => 'display_name',
			'number'   => 200,
		) );
	}

	public function handle_create() {
		$this->verify_nonce( 'wceerp_staff_create' );

		// Package limit check happens before anything is created, so the
		// customer gets a clear upgrade message rather than a half-made user.
		if ( class_exists( 'WCEERP_Limits' ) && WCEERP_Limits::active() && ! WCEERP_Limits::can_add( 'users', 1 ) ) {
			$this->redirect( 'error', WCEERP_Limits::limit_message( 'users' ) );
		}

		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$name  = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$role  = sanitize_key( $_POST['role'] ?? 'wceerp_staff' );
		$pass  = (string) ( $_POST['password'] ?? '' );

		if ( ! is_email( $email ) ) {
			$this->redirect( 'error', __( 'Enter a valid email address.', 'wc-enterprise-erp' ) );
		}
		if ( email_exists( $email ) ) {
			$this->redirect( 'error', __( 'A user with that email already exists.', 'wc-enterprise-erp' ) );
		}
		if ( ! array_key_exists( $role, self::roles() ) ) {
			$role = 'wceerp_staff';
		}
		if ( strlen( $pass ) < 8 ) {
			$this->redirect( 'error', __( 'Password must be at least 8 characters.', 'wc-enterprise-erp' ) );
		}

		self::ensure_staff_role();

		$username = sanitize_user( current( explode( '@', $email ) ), true );
		$base     = $username;
		$i        = 1;
		while ( username_exists( $username ) ) {
			$username = $base . $i;
			$i++;
		}

		$user_id = wp_insert_user( array(
			'user_login'   => $username,
			'user_email'   => $email,
			'user_pass'    => $pass,
			'display_name' => $name ?: $username,
			'first_name'   => $name,
			'role'         => $role,
		) );

		if ( is_wp_error( $user_id ) ) {
			$this->redirect( 'error', $user_id->get_error_message() );
		}

		if ( ! empty( $_POST['notify'] ) ) {
			wp_new_user_notification( $user_id, null, 'user' );
		}

		wceerp_log( 'staff', 'create', $user_id, $role );
		$this->redirect( 'success', __( 'Staff member added.', 'wc-enterprise-erp' ) );
	}

	public function handle_update() {
		$this->verify_nonce( 'wceerp_staff_update' );
		$user_id = (int) ( $_POST['user_id'] ?? 0 );
		$action  = sanitize_key( $_POST['do'] ?? '' );
		$user    = $user_id ? get_userdata( $user_id ) : null;

		if ( ! $user ) {
			$this->redirect( 'error', __( 'User not found.', 'wc-enterprise-erp' ) );
		}
		// Never let someone remove their own access and lock the shop out.
		if ( get_current_user_id() === $user_id ) {
			$this->redirect( 'error', __( 'You cannot change your own access from here.', 'wc-enterprise-erp' ) );
		}

		if ( 'role' === $action ) {
			$role = sanitize_key( $_POST['role'] ?? '' );
			if ( array_key_exists( $role, self::roles() ) ) {
				$user->set_role( $role );
				wceerp_log( 'staff', 'role_change', $user_id, $role );
				$this->redirect( 'success', __( 'Role updated.', 'wc-enterprise-erp' ) );
			}
		}

		if ( 'revoke' === $action ) {
			// Remove ERP access without deleting the WordPress account —
			// deleting a user can orphan orders and ledger references.
			$user->set_role( 'subscriber' );
			wceerp_log( 'staff', 'revoke', $user_id );
			$this->redirect( 'success', __( 'ERP access removed. The account still exists but can no longer use the ERP.', 'wc-enterprise-erp' ) );
		}

		$this->redirect( 'error', __( 'Nothing to do.', 'wc-enterprise-erp' ) );
	}

	protected function redirect( $type, $msg ) {
		wp_safe_redirect( add_query_arg( array(
			'page'          => 'wceerp-staff',
			'wceerp_notice' => $type,
			'm'             => rawurlencode( $msg ),
		), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function render_page() {
		self::ensure_staff_role();
		$roles = self::roles();
		$users = $this->staff_users();

		$limit = 0;
		$used  = 0;
		if ( class_exists( 'WCEERP_Limits' ) && WCEERP_Limits::active() ) {
			$limit = WCEERP_Limits::limit( 'users' );
			$used  = WCEERP_Limits::usage( 'users' );
		}
		$at_limit = $limit > 0 && $used >= $limit;
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Staff', 'wc-enterprise-erp' ) ) ); ?></h1>

			<?php if ( isset( $_GET['wceerp_notice'], $_GET['m'] ) ) : ?>
				<div class="notice <?php echo 'error' === $_GET['wceerp_notice'] ? 'notice-error' : 'notice-success'; ?> is-dismissible">
					<p><?php echo esc_html( wp_unslash( $_GET['m'] ) ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $limit > 0 ) : ?>
				<p class="description">
					<?php
					printf(
						esc_html__( 'Your plan includes %1$d staff users. You are using %2$d.', 'wc-enterprise-erp' ),
						(int) $limit,
						(int) $used
					);
					?>
					<?php if ( $at_limit && class_exists( 'WCEERP_Module_Plan' ) ) : ?>
						<a href="<?php echo esc_url( WCEERP_Module_Plan::whatsapp_link( __( 'Hello, I need more staff users on my WordPress ERP plan', 'wc-enterprise-erp' ) ) ); ?>" target="_blank" rel="noopener">
							<?php esc_html_e( 'Upgrade on WhatsApp →', 'wc-enterprise-erp' ); ?>
						</a>
					<?php endif; ?>
				</p>
			<?php endif; ?>

			<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="max-width:420px">
					<h2><?php esc_html_e( 'Add a staff member', 'wc-enterprise-erp' ); ?></h2>
					<input type="hidden" name="action" value="wceerp_staff_create">
					<?php wp_nonce_field( 'wceerp_staff_create' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="name" class="regular-text" required <?php disabled( $at_limit ); ?>></td></tr>
						<tr><th><?php esc_html_e( 'Email', 'wc-enterprise-erp' ); ?></th>
							<td><input type="email" name="email" class="regular-text" required <?php disabled( $at_limit ); ?>>
								<p class="description"><?php esc_html_e( 'They sign in with this.', 'wc-enterprise-erp' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Password', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="password" class="regular-text" minlength="8" required <?php disabled( $at_limit ); ?>
									value="<?php echo esc_attr( wp_generate_password( 12, false ) ); ?>">
								<p class="description"><?php esc_html_e( 'Pre-filled with a strong password — copy it before saving.', 'wc-enterprise-erp' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Access level', 'wc-enterprise-erp' ); ?></th>
							<td>
								<?php foreach ( $roles as $key => $r ) : ?>
									<label style="display:block;margin-bottom:8px">
										<input type="radio" name="role" value="<?php echo esc_attr( $key ); ?>" <?php checked( 'wceerp_staff', $key ); ?> <?php disabled( $at_limit ); ?>>
										<strong><?php echo esc_html( $r['label'] ); ?></strong><br>
										<span class="description" style="margin-left:24px"><?php echo esc_html( $r['desc'] ); ?></span>
									</label>
								<?php endforeach; ?>
							</td></tr>
						<tr><th></th><td>
							<label><input type="checkbox" name="notify" value="1" <?php disabled( $at_limit ); ?>> <?php esc_html_e( 'Email them their login details', 'wc-enterprise-erp' ); ?></label>
						</td></tr>
					</tbody></table>
					<?php if ( $at_limit ) : ?>
						<p style="color:#c8302e"><strong><?php esc_html_e( 'You have reached your plan\'s staff limit.', 'wc-enterprise-erp' ); ?></strong></p>
					<?php else : ?>
						<?php submit_button( __( 'Add staff member', 'wc-enterprise-erp' ) ); ?>
					<?php endif; ?>
				</form>

				<div class="wceerp-card" style="flex:1;min-width:340px">
					<h2><?php esc_html_e( 'Current staff', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped">
						<thead><tr>
							<th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Access', 'wc-enterprise-erp' ); ?></th>
							<th></th>
						</tr></thead>
						<tbody>
						<?php if ( ! $users ) : ?>
							<tr><td colspan="3"><?php esc_html_e( 'No staff yet.', 'wc-enterprise-erp' ); ?></td></tr>
						<?php endif; ?>
						<?php foreach ( $users as $u ) :
							$current = '';
							foreach ( array_keys( $roles ) as $rk ) {
								if ( in_array( $rk, (array) $u->roles, true ) ) {
									$current = $rk;
									break;
								}
							}
							$is_me = get_current_user_id() === $u->ID;
							?>
							<tr>
								<td><strong><?php echo esc_html( $u->display_name ); ?></strong><br><small style="color:#888"><?php echo esc_html( $u->user_email ); ?></small></td>
								<td>
									<?php if ( $is_me ) : ?>
										<?php echo esc_html( $roles[ $current ]['label'] ?? $current ); ?>
										<br><small style="color:#888"><?php esc_html_e( '(you)', 'wc-enterprise-erp' ); ?></small>
									<?php else : ?>
										<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
											<input type="hidden" name="action" value="wceerp_staff_update">
											<input type="hidden" name="do" value="role">
											<input type="hidden" name="user_id" value="<?php echo (int) $u->ID; ?>">
											<?php wp_nonce_field( 'wceerp_staff_update' ); ?>
											<select name="role" onchange="this.form.submit()">
												<?php foreach ( $roles as $key => $r ) : ?>
													<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current, $key ); ?>><?php echo esc_html( $r['label'] ); ?></option>
												<?php endforeach; ?>
											</select>
										</form>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( ! $is_me ) : ?>
										<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
											onsubmit="return confirm('<?php echo esc_js( __( 'Remove ERP access for this person? Their account stays, but they can no longer use the ERP.', 'wc-enterprise-erp' ) ); ?>');">
											<input type="hidden" name="action" value="wceerp_staff_update">
											<input type="hidden" name="do" value="revoke">
											<input type="hidden" name="user_id" value="<?php echo (int) $u->ID; ?>">
											<?php wp_nonce_field( 'wceerp_staff_update' ); ?>
											<button class="button-link delete" style="color:#b32d2e"><?php esc_html_e( 'Remove access', 'wc-enterprise-erp' ); ?></button>
										</form>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p class="description"><?php esc_html_e( 'Removing access never deletes the account, so past orders and ledger entries keep their author.', 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}
}
