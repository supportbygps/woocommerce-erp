<?php
/**
 * Module: Multi-Branch.
 *
 * The branch dimension works through two anchors, both backward
 * compatible (everything existing lands on branch 1, "Head Office"):
 *
 *   warehouses.branch_id → stock, purchases and sales flow to a branch
 *                          through the warehouse they use
 *   journals.branch_id   → every posted journal carries its branch, so
 *                          revenue / expense / profit split cleanly
 *
 * Inter-branch transfer = the existing warehouse transfer between two
 * warehouses that belong to different branches; stock value moves with
 * it automatically at average cost.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Branches extends WCEERP_Module {

	protected $id         = 'branches';
	protected $title      = 'Branches';
	protected $capability = 'wceerp_manage_branches';
	protected $tier       = 'enterprise';
	protected $order      = 14;

	public function __construct() {
		$this->title = __( 'Branches', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_branch_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_branch_assign', array( $this, 'handle_assign' ) );
	}

	public static function all() {
		global $wpdb;
		return $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'branches' ) . " WHERE status='active' ORDER BY id" );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_save() {
		$this->verify_nonce( 'wceerp_branch_save' );
		global $wpdb;

		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$code = strtoupper( sanitize_key( $_POST['code'] ?? '' ) );
		if ( ! $name || ! $code ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => 'incomplete' ) ) );
			exit;
		}
		$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'branches' ) . ' WHERE code=%s', $code ) );
		if ( $exists ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => 'duplicate' ) ) );
			exit;
		}

		$wpdb->insert( wceerp_table( 'branches' ), array(
			'code'       => $code,
			'name'       => $name,
			'address'    => sanitize_textarea_field( wp_unslash( $_POST['address'] ?? '' ) ),
			'phone'      => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'status'     => 'active',
			'created_at' => current_time( 'mysql' ),
		) );
		wceerp_log( 'branches', 'create', (int) $wpdb->insert_id, $code );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/** Assign warehouses to branches — the mapping that drives everything. */
	public function handle_assign() {
		$this->verify_nonce( 'wceerp_branch_assign' );
		global $wpdb;
		$map = (array) ( $_POST['warehouse_branch'] ?? array() );
		foreach ( $map as $warehouse_id => $branch_id ) {
			$wpdb->update( wceerp_table( 'warehouses' ),
				array( 'branch_id' => max( 1, (int) $branch_id ) ),
				array( 'id' => (int) $warehouse_id )
			);
		}
		wceerp_log( 'branches', 'assign_warehouses', 0, count( $map ) . ' mapped' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		global $wpdb;
		$branches   = self::all();
		$warehouses = $wpdb->get_results( 'SELECT id, name, code, branch_id FROM ' . wceerp_table( 'warehouses' ) . ' ORDER BY name' );

		/* Per-branch numbers: fiscal-year-to-date P&L from journals,
		 * live stock value from warehouses. */
		$fy    = wceerp_fiscal_year();
		$jl    = wceerp_table( 'journal_lines' );
		$j     = wceerp_table( 'journals' );
		$acc   = wceerp_table( 'accounts' );
		$stats = array();

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT jr.branch_id, a.type, SUM(l.debit) AS d, SUM(l.credit) AS c
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id = l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id = l.account_id
			 WHERE jr.journal_date >= %s AND a.type IN ('income','expense')
			 GROUP BY jr.branch_id, a.type",
			$fy['start']
		) );
		foreach ( (array) $rows as $row ) {
			$b = (int) $row->branch_id;
			if ( ! isset( $stats[ $b ] ) ) {
				$stats[ $b ] = array( 'income' => 0.0, 'expense' => 0.0, 'stock' => 0.0 );
			}
			if ( 'income' === $row->type ) {
				$stats[ $b ]['income'] += (float) $row->c - (float) $row->d;
			} else {
				$stats[ $b ]['expense'] += (float) $row->d - (float) $row->c;
			}
		}
		$stock_rows = $wpdb->get_results(
			'SELECT w.branch_id, COALESCE(SUM(s.qty * s.avg_cost),0) AS value
			 FROM ' . wceerp_table( 'warehouses' ) . ' w
			 LEFT JOIN ' . wceerp_table( 'stock' ) . ' s ON s.warehouse_id = w.id
			 GROUP BY w.branch_id'
		);
		foreach ( (array) $stock_rows as $row ) {
			$b = (int) $row->branch_id;
			if ( ! isset( $stats[ $b ] ) ) {
				$stats[ $b ] = array( 'income' => 0.0, 'expense' => 0.0, 'stock' => 0.0 );
			}
			$stats[ $b ]['stock'] = (float) $row->value;
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Branches', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>
			<?php if ( ! empty( $_GET['error'] ) && 'duplicate' === $_GET['error'] ) { $this->notice( __( 'That branch code already exists.', 'wc-enterprise-erp' ), 'error' ); } ?>

			<div class="wceerp-card">
				<h2><?php printf( esc_html__( 'Branch comparison — fiscal year %s', 'wc-enterprise-erp' ), esc_html( $fy['label'] ) ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Branch', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Revenue', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Expenses', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Stock value (now)', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Warehouses', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $branches as $branch ) :
						$stat  = $stats[ (int) $branch->id ] ?? array( 'income' => 0, 'expense' => 0, 'stock' => 0 );
						$count = 0;
						foreach ( $warehouses as $warehouse ) {
							if ( (int) $warehouse->branch_id === (int) $branch->id ) {
								$count++;
							}
						}
						$profit = $stat['income'] - $stat['expense'];
						?>
						<tr>
							<td><strong><?php echo esc_html( $branch->name ); ?></strong> <code><?php echo esc_html( $branch->code ); ?></code></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $stat['income'] ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $stat['expense'] ) ); ?></td>
							<td class="num" style="color:<?php echo $profit >= 0 ? '#00701f' : '#b32d2e'; ?>"><strong><?php echo wp_kses_post( wceerp_money( $profit ) ); ?></strong></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $stat['stock'] ) ); ?></td>
							<td class="num"><?php echo (int) $count; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Sales and expenses land on a branch through the warehouse that served them; manual journal vouchers can pick a branch too. To move goods between branches, use a normal warehouse transfer — value follows automatically at average cost.', 'wc-enterprise-erp' ); ?></p>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Add a branch', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_branch_save">
						<?php wp_nonce_field( 'wceerp_branch_save' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="name" class="regular-text" required placeholder="<?php esc_attr_e( 'e.g. Chattogram Branch', 'wc-enterprise-erp' ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="code" required style="width:100px" placeholder="CTG"></td></tr>
							<tr><th><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="phone"></td></tr>
							<tr><th><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?></th>
								<td><textarea name="address" rows="2" class="large-text"></textarea></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Add branch', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Warehouse → branch mapping', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_branch_assign">
						<?php wp_nonce_field( 'wceerp_branch_assign' ); ?>
						<table class="widefat striped wceerp-table">
							<thead><tr><th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Belongs to branch', 'wc-enterprise-erp' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( $warehouses as $warehouse ) : ?>
								<tr>
									<td><?php echo esc_html( $warehouse->name ); ?> <code><?php echo esc_html( $warehouse->code ); ?></code></td>
									<td><select name="warehouse_branch[<?php echo (int) $warehouse->id; ?>]">
										<?php foreach ( $branches as $branch ) : ?>
											<option value="<?php echo (int) $branch->id; ?>" <?php selected( (int) $warehouse->branch_id, (int) $branch->id ); ?>><?php echo esc_html( $branch->name ); ?></option>
										<?php endforeach; ?>
									</select></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
						<?php submit_button( __( 'Save mapping', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>
			</div>
		</div>
		<?php
	}
}
