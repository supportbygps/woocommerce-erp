<?php
/**
 * Module: Business Analytics.
 *
 * Charts are server-rendered SVG — no JavaScript library, no CDN, they
 * load instantly, print perfectly and work on any device. Every number
 * comes from the double-entry ledger or stock tables, so this dashboard
 * always agrees with the accounting reports.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Analytics extends WCEERP_Module {

	protected $id         = 'analytics';
	protected $title      = 'Analytics';
	protected $capability = 'wceerp_view_analytics';
	protected $tier       = 'business';
	protected $order      = 12;

	public function __construct() {
		$this->title = __( 'Analytics', 'wc-enterprise-erp' );
	}

	public function init() {}

	/* ---------------------------------------------------------------------
	 * Data.
	 * ------------------------------------------------------------------- */

	/**
	 * Last-12-months series from the ledger:
	 * income (credit−debit on income accounts), expenses, profit, and net
	 * cash movement across cash/bank/mobile accounts.
	 */
	protected function monthly_series() {
		global $wpdb;
		$jl  = wceerp_table( 'journal_lines' );
		$j   = wceerp_table( 'journals' );
		$acc = wceerp_table( 'accounts' );

		$start = gmdate( 'Y-m-01', strtotime( '-11 months' ) );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT DATE_FORMAT(jr.journal_date, '%%Y-%%m') AS ym, a.type, a.subtype,
			        SUM(l.debit) AS d, SUM(l.credit) AS c
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id = l.journal_id AND jr.status = 'posted'
			 INNER JOIN $acc a ON a.id = l.account_id
			 WHERE jr.journal_date >= %s
			 GROUP BY ym, a.type, a.subtype",
			$start
		) );

		$months = array();
		for ( $i = 11; $i >= 0; $i-- ) {
			$months[ gmdate( 'Y-m', strtotime( "-$i months" ) ) ] = array( 'income' => 0.0, 'expense' => 0.0, 'cash' => 0.0 );
		}
		foreach ( (array) $rows as $row ) {
			if ( ! isset( $months[ $row->ym ] ) ) {
				continue;
			}
			if ( 'income' === $row->type ) {
				$months[ $row->ym ]['income'] += (float) $row->c - (float) $row->d;
			} elseif ( 'expense' === $row->type ) {
				$months[ $row->ym ]['expense'] += (float) $row->d - (float) $row->c;
			}
			if ( in_array( (string) $row->subtype, array( 'cash', 'bank', 'mobile_banking' ), true ) ) {
				$months[ $row->ym ]['cash'] += (float) $row->d - (float) $row->c;
			}
		}
		return $months;
	}

	protected function warehouse_values() {
		global $wpdb;
		return $wpdb->get_results(
			'SELECT w.name, COALESCE(SUM(s.qty * s.avg_cost),0) AS value
			 FROM ' . wceerp_table( 'warehouses' ) . ' w
			 LEFT JOIN ' . wceerp_table( 'stock' ) . ' s ON s.warehouse_id = w.id
			 GROUP BY w.id ORDER BY value DESC LIMIT 8'
		);
	}

	protected function top_products( $days = 90, $limit = 10 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT product_id, SUM(qty) AS sold
			 FROM " . wceerp_table( 'stock_moves' ) . "
			 WHERE direction = 'out' AND ref_type = 'wc_order' AND created_at >= %s
			 GROUP BY product_id ORDER BY sold DESC LIMIT %d",
			gmdate( 'Y-m-d', strtotime( "-$days days" ) ), $limit
		) );
	}

	/** Products holding stock with no sale in N days — dead money. */
	protected function slow_movers( $days = 60, $limit = 10 ) {
		global $wpdb;
		$stock = wceerp_table( 'stock' );
		$moves = wceerp_table( 'stock_moves' );
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT s.product_id, SUM(s.qty) AS qty, SUM(s.qty * s.avg_cost) AS value
			 FROM $stock s
			 WHERE s.qty > 0
			   AND s.product_id NOT IN (
			       SELECT DISTINCT product_id FROM $moves
			       WHERE direction = 'out' AND created_at >= %s
			   )
			 GROUP BY s.product_id ORDER BY value DESC LIMIT %d",
			gmdate( 'Y-m-d', strtotime( "-$days days" ) ), $limit
		) );
	}

	protected function supplier_spend( $limit = 8 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			'SELECT s.name, COALESCE(SUM(p.grand_total),0) AS spend
			 FROM ' . wceerp_table( 'suppliers' ) . ' s
			 INNER JOIN ' . wceerp_table( 'purchases' ) . " p ON p.supplier_id = s.id AND p.status <> 'cancelled'
			 GROUP BY s.id ORDER BY spend DESC LIMIT %d", $limit
		) );
	}

	protected function top_customers( $days = 180, $limit = 8 ) {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT jr.ref_id AS order_id, jr.memo, SUM(l.credit) AS revenue
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id = l.journal_id AND jr.status='posted' AND jr.ref_type='wc_order'
			 INNER JOIN " . wceerp_table( 'accounts' ) . " a ON a.id = l.account_id AND a.type='income'
			 WHERE jr.journal_date >= %s
			 GROUP BY jr.ref_id, jr.memo ORDER BY revenue DESC LIMIT %d",
			gmdate( 'Y-m-d', strtotime( "-$days days" ) ), $limit
		) );
	}

	/* ---------------------------------------------------------------------
	 * SVG chart helpers (dependency-free).
	 * ------------------------------------------------------------------- */

	/**
	 * Grouped bar + line combo for monthly series.
	 *
	 * @param array $labels  Month labels.
	 * @param array $series  name => [ 'values' => float[], 'color' => hex, 'type' => bar|line ].
	 */
	protected function chart( $labels, $series, $height = 240 ) {
		$width  = 760;
		$pad_l  = 56;
		$pad_b  = 26;
		$pad_t  = 14;
		$plot_w = $width - $pad_l - 12;
		$plot_h = $height - $pad_t - $pad_b;
		$n      = max( 1, count( $labels ) );

		$max = 1;
		$min = 0;
		foreach ( $series as $s ) {
			foreach ( $s['values'] as $value ) {
				$max = max( $max, $value );
				$min = min( $min, $value );
			}
		}
		$range = max( 1, $max - $min );
		$y     = function ( $value ) use ( $pad_t, $plot_h, $max, $range ) {
			return $pad_t + ( $max - $value ) / $range * $plot_h;
		};
		$slot  = $plot_w / $n;

		$svg  = '<svg viewBox="0 0 ' . $width . ' ' . $height . '" class="wceerp-chart" role="img" preserveAspectRatio="xMidYMid meet">';
		/* Gridlines + y labels. */
		for ( $g = 0; $g <= 4; $g++ ) {
			$value = $max - $range * $g / 4;
			$gy    = $y( $value );
			$svg  .= '<line x1="' . $pad_l . '" y1="' . $gy . '" x2="' . ( $width - 8 ) . '" y2="' . $gy . '" stroke="#e4e0d4" stroke-width="1"/>';
			$svg  .= '<text x="' . ( $pad_l - 6 ) . '" y="' . ( $gy + 4 ) . '" text-anchor="end" font-size="10" fill="#777">' . esc_html( wceerp_lakh_format( round( $value ) ) ) . '</text>';
		}
		/* Zero line emphasis when negatives exist. */
		if ( $min < 0 ) {
			$zy   = $y( 0 );
			$svg .= '<line x1="' . $pad_l . '" y1="' . $zy . '" x2="' . ( $width - 8 ) . '" y2="' . $zy . '" stroke="#999" stroke-width="1.4"/>';
		}

		/* Bars first, then lines on top. */
		$bar_series = array();
		foreach ( $series as $name => $s ) {
			if ( ( $s['type'] ?? 'bar' ) === 'bar' ) {
				$bar_series[ $name ] = $s;
			}
		}
		$bars   = max( 1, count( $bar_series ) );
		$bar_w  = min( 22, ( $slot * 0.66 ) / $bars );
		$b      = 0;
		foreach ( $bar_series as $s ) {
			foreach ( $s['values'] as $i => $value ) {
				$x  = $pad_l + $slot * $i + $slot / 2 - ( $bars * $bar_w ) / 2 + $b * $bar_w;
				$y0 = $y( max( 0, $value ) );
				$h  = abs( $y( $value ) - $y( 0 ) );
				$svg .= '<rect x="' . $x . '" y="' . $y0 . '" width="' . ( $bar_w - 2 ) . '" height="' . max( 0.5, $h ) . '" fill="' . esc_attr( $s['color'] ) . '" rx="2"><title>' . esc_html( wceerp_lakh_format( round( $value, 2 ) ) ) . '</title></rect>';
			}
			$b++;
		}
		foreach ( $series as $s ) {
			if ( ( $s['type'] ?? 'bar' ) !== 'line' ) {
				continue;
			}
			$points = array();
			foreach ( $s['values'] as $i => $value ) {
				$points[] = round( $pad_l + $slot * $i + $slot / 2, 1 ) . ',' . round( $y( $value ), 1 );
			}
			$svg .= '<polyline points="' . esc_attr( implode( ' ', $points ) ) . '" fill="none" stroke="' . esc_attr( $s['color'] ) . '" stroke-width="2.4" stroke-linejoin="round"/>';
			foreach ( $s['values'] as $i => $value ) {
				$svg .= '<circle cx="' . round( $pad_l + $slot * $i + $slot / 2, 1 ) . '" cy="' . round( $y( $value ), 1 ) . '" r="3" fill="' . esc_attr( $s['color'] ) . '"><title>' . esc_html( wceerp_lakh_format( round( $value, 2 ) ) ) . '</title></circle>';
			}
		}
		/* X labels. */
		foreach ( $labels as $i => $label ) {
			$svg .= '<text x="' . ( $pad_l + $slot * $i + $slot / 2 ) . '" y="' . ( $height - 8 ) . '" text-anchor="middle" font-size="10" fill="#555">' . esc_html( $label ) . '</text>';
		}
		return $svg . '</svg>';
	}

	/** Horizontal bar list — for rankings. */
	protected function hbar( $rows, $label_key, $value_key, $color = '#075742' ) {
		$max = 1;
		foreach ( $rows as $row ) {
			$max = max( $max, (float) $row->{$value_key} );
		}
		$html = '<div class="wceerp-hbars">';
		foreach ( $rows as $row ) {
			$pct   = 100 * (float) $row->{$value_key} / $max;
			$html .= '<div class="wceerp-hbar"><span class="lbl">' . esc_html( $row->{$label_key} ) . '</span>'
				. '<span class="bar"><i style="width:' . round( $pct, 1 ) . '%;background:' . esc_attr( $color ) . '"></i></span>'
				. '<span class="val">' . wp_kses_post( wceerp_money( $row->{$value_key} ) ) . '</span></div>';
		}
		return $html . '</div>';
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$months = $this->monthly_series();
		$labels = array();
		$income = $expense = $profit = $cash = array();
		foreach ( $months as $ym => $data ) {
			$labels[]  = gmdate( 'M', strtotime( $ym . '-01' ) );
			$income[]  = round( $data['income'], 2 );
			$expense[] = round( $data['expense'], 2 );
			$profit[]  = round( $data['income'] - $data['expense'], 2 );
			$cash[]    = round( $data['cash'], 2 );
		}
		$this_month   = end( $profit );
		$last_month   = count( $profit ) > 1 ? $profit[ count( $profit ) - 2 ] : 0;
		$profit_delta = $last_month ? round( 100 * ( $this_month - $last_month ) / abs( $last_month ) ) : null;

		$warehouses = $this->warehouse_values();
		$inv_value  = 0;
		foreach ( $warehouses as $warehouse ) {
			$inv_value += (float) $warehouse->value;
		}
		$slow       = $this->slow_movers();
		$dead_value = 0;
		foreach ( $slow as $row ) {
			$dead_value += (float) $row->value;
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Business Analytics', 'wc-enterprise-erp' ) ) ); ?></h1>

			<div class="wceerp-kpis">
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Revenue (this month)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( end( $income ) ) ); ?></strong></div>
				<div class="wceerp-kpi <?php echo $this_month >= 0 ? 'is-good' : 'is-bad'; ?>">
					<span><?php esc_html_e( 'Profit (this month)', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $this_month ) ); ?></strong>
					<?php if ( null !== $profit_delta ) : ?>
						<small><?php echo esc_html( ( $profit_delta >= 0 ? '▲ +' : '▼ ' ) . $profit_delta . '% ' ); ?><?php esc_html_e( 'vs last month', 'wc-enterprise-erp' ); ?></small>
					<?php endif; ?>
				</div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Net cash movement (this month)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( end( $cash ) ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Inventory value', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $inv_value ) ); ?></strong></div>
				<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Dead stock (60 days no sale)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $dead_value ) ); ?></strong></div>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Revenue, expenses & profit — last 12 months', 'wc-enterprise-erp' ); ?></h2>
				<?php
				echo $this->chart( $labels, array( // phpcs:ignore
					'income'  => array( 'values' => $income, 'color' => '#075742', 'type' => 'bar' ),
					'expense' => array( 'values' => $expense, 'color' => '#c8302e', 'type' => 'bar' ),
					'profit'  => array( 'values' => $profit, 'color' => '#b98a2f', 'type' => 'line' ),
				) );
				?>
				<p class="description"><span style="color:#075742">■</span> <?php esc_html_e( 'Income', 'wc-enterprise-erp' ); ?> &nbsp;
					<span style="color:#c8302e">■</span> <?php esc_html_e( 'Expenses (incl. COGS)', 'wc-enterprise-erp' ); ?> &nbsp;
					<span style="color:#b98a2f">●</span> <?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></p>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Cash flow — monthly net movement (cash + bank + mobile banking)', 'wc-enterprise-erp' ); ?></h2>
				<?php
				echo $this->chart( $labels, array( // phpcs:ignore
					'cash' => array( 'values' => $cash, 'color' => '#135e96', 'type' => 'bar' ),
				), 200 );
				?>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Inventory value by warehouse', 'wc-enterprise-erp' ); ?></h2>
					<?php echo $this->hbar( $warehouses, 'name', 'value' ); // phpcs:ignore ?>
				</div>
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Supplier spend (all time)', 'wc-enterprise-erp' ); ?></h2>
					<?php echo $this->hbar( $this->supplier_spend(), 'name', 'spend', '#b98a2f' ); // phpcs:ignore ?>
				</div>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Fast sellers — last 90 days', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped wceerp-table">
						<thead><tr><th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Units sold', 'wc-enterprise-erp' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $this->top_products() as $row ) :
							$product = function_exists( 'wc_get_product' ) ? wc_get_product( $row->product_id ) : null;
							?>
							<tr><td><?php echo esc_html( $product ? $product->get_name() : ( '#' . $row->product_id ) ); ?></td>
								<td class="num"><strong><?php echo esc_html( wceerp_dec( $row->sold ) ); ?></strong></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Slow movers — stock but no sale in 60 days', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped wceerp-table">
						<thead><tr><th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Qty held', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Money stuck', 'wc-enterprise-erp' ); ?></th></tr></thead>
						<tbody>
						<?php if ( ! $slow ) : ?>
							<tr><td colspan="3"><?php esc_html_e( 'Nothing is sitting idle — good rotation!', 'wc-enterprise-erp' ); ?></td></tr>
						<?php endif; ?>
						<?php foreach ( $slow as $row ) :
							$product = function_exists( 'wc_get_product' ) ? wc_get_product( $row->product_id ) : null;
							?>
							<tr><td><?php echo esc_html( $product ? $product->get_name() : ( '#' . $row->product_id ) ); ?></td>
								<td class="num"><?php echo esc_html( wceerp_dec( $row->qty ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $row->value ) ); ?></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Largest orders — last 180 days', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Revenue', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $this->top_customers() as $row ) : ?>
						<tr><td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->order_id . '&action=edit' ) ); ?>"><?php echo esc_html( $row->memo ?: ( 'Order #' . $row->order_id ) ); ?></a></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $row->revenue ) ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
}
