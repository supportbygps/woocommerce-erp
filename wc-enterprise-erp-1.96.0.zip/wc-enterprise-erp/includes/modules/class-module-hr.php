<?php
/**
 * Module: HR & Payroll.
 *
 * Payroll accounting (one balanced journal per monthly run):
 *   Dr 5100 Salaries & Wages      basic + allowances − absence deduction
 *   Dr 5110 Bonus & Overtime      overtime + bonus
 *   Cr 1120 Staff Salary Advances advance deductions (repayments)
 *   Cr 4100 Other Income          other deductions (fines etc.)
 *   Cr 1000/1010/1020/1021/1022   net pay, grouped by each employee's
 *                                 own channel — so a run really does
 *                                 "mobile banking salary": bKash people
 *                                 credit the bKash book, cash people the
 *                                 cash book, in one voucher.
 *
 * Advances: Dr 1120 / Cr money when given; repaid through payroll
 * deductions (oldest first) or on their own.
 *
 * A period can only be paid once (unique key on period): re-submitting
 * a month is rejected, never double-posted.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_HR extends WCEERP_Module {

	protected $id         = 'hr';
	protected $title      = 'HR & Payroll';
	protected $capability = 'wceerp_manage_hr';
	protected $tier       = 'enterprise';
	protected $order      = 50;

	const CHANNEL_ACCOUNTS = array(
		'cash'   => '1000',
		'bank'   => '1010',
		'bkash'  => '1020',
		'nagad'  => '1021',
		'rocket' => '1022',
	);

	public function __construct() {
		$this->title = __( 'HR & Payroll', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_employee_save', array( $this, 'handle_employee_save' ) );
		add_action( 'admin_post_wceerp_attendance_save', array( $this, 'handle_attendance_save' ) );
		add_action( 'admin_post_wceerp_leave_save', array( $this, 'handle_leave_save' ) );
		add_action( 'admin_post_wceerp_leave_act', array( $this, 'handle_leave_act' ) );
		add_action( 'admin_post_wceerp_advance_save', array( $this, 'handle_advance_save' ) );
		add_action( 'admin_post_wceerp_payroll_run', array( $this, 'handle_payroll_run' ) );
	}

	protected function employees( $only_active = true ) {
		global $wpdb;
		$where = $only_active ? "WHERE status='active'" : '';
		return $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'employees' ) . " $where ORDER BY name" );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_employee_save() {
		$this->verify_nonce( 'wceerp_employee_save' );
		global $wpdb;
		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		if ( ! $name ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'employees', 'error' => 1 ) ) );
			exit;
		}
		$channel = sanitize_key( $_POST['pay_channel'] ?? 'cash' );
		$wpdb->insert( wceerp_table( 'employees' ), array(
			'doc_no'       => wceerp_next_doc_number( 'emp' ),
			'name'         => $name,
			'phone'        => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'nid_no'       => sanitize_text_field( wp_unslash( $_POST['nid_no'] ?? '' ) ),
			'designation'  => sanitize_text_field( wp_unslash( $_POST['designation'] ?? '' ) ),
			'department'   => sanitize_text_field( wp_unslash( $_POST['department'] ?? '' ) ),
			'join_date'    => ! empty( $_POST['join_date'] ) ? sanitize_text_field( $_POST['join_date'] ) : null,
			'basic_salary' => wceerp_dec( $_POST['basic_salary'] ?? 0 ),
			'allowances'   => wceerp_dec( $_POST['allowances'] ?? 0 ),
			'pay_channel'  => array_key_exists( $channel, self::CHANNEL_ACCOUNTS ) ? $channel : 'cash',
			'pay_number'   => sanitize_text_field( wp_unslash( $_POST['pay_number'] ?? '' ) ),
			'status'       => 'active',
			'created_at'   => current_time( 'mysql' ),
		) );
		wceerp_log( 'hr', 'employee_create', (int) $wpdb->insert_id, $name );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'employees', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_attendance_save() {
		$this->verify_nonce( 'wceerp_attendance_save' );
		global $wpdb;
		$date  = sanitize_text_field( $_POST['att_date'] ?? current_time( 'Y-m-d' ) );
		$marks = (array) ( $_POST['mark'] ?? array() );
		$table = wceerp_table( 'attendance' );
		$valid = array( 'present', 'absent', 'leave', 'half_day', 'holiday' );
		$saved = 0;
		foreach ( $marks as $employee_id => $status ) {
			$status = sanitize_key( $status );
			if ( ! in_array( $status, $valid, true ) ) {
				continue;
			}
			$wpdb->query( $wpdb->prepare(
				"INSERT INTO $table (employee_id, att_date, status) VALUES (%d, %s, %s)
				 ON DUPLICATE KEY UPDATE status = VALUES(status)",
				(int) $employee_id, $date, $status
			) );
			$saved++;
		}
		wceerp_log( 'hr', 'attendance', 0, "$date: $saved marked" );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'attendance', 'date' => $date, 'updated' => 1 ) ) );
		exit;
	}

	public function handle_leave_save() {
		$this->verify_nonce( 'wceerp_leave_save' );
		global $wpdb;
		$from = sanitize_text_field( $_POST['from_date'] ?? '' );
		$to   = sanitize_text_field( $_POST['to_date'] ?? $from );
		$days = max( 0.5, ( strtotime( $to ) - strtotime( $from ) ) / DAY_IN_SECONDS + 1 );
		$wpdb->insert( wceerp_table( 'leaves' ), array(
			'employee_id' => (int) ( $_POST['employee_id'] ?? 0 ),
			'from_date'   => $from,
			'to_date'     => $to,
			'days'        => $days,
			'type'        => in_array( $_POST['type'] ?? '', array( 'casual', 'sick', 'annual', 'unpaid' ), true ) ? $_POST['type'] : 'casual',
			'status'      => 'pending',
			'note'        => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'  => current_time( 'mysql' ),
		) );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'leave', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_leave_act() {
		$this->verify_nonce( 'wceerp_leave_act' );
		global $wpdb;
		$id       = (int) ( $_POST['leave_id'] ?? 0 );
		$decision = 'approve' === ( $_POST['decision'] ?? '' ) ? 'approved' : 'rejected';
		$leave    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'leaves' ) . " WHERE id=%d AND status='pending'", $id ) );
		if ( $leave ) {
			$wpdb->update( wceerp_table( 'leaves' ), array( 'status' => $decision, 'acted_by' => get_current_user_id() ), array( 'id' => $id ) );
			/* Approved leave fills the attendance sheet automatically. */
			if ( 'approved' === $decision ) {
				$att = wceerp_table( 'attendance' );
				for ( $t = strtotime( $leave->from_date ); $t <= strtotime( $leave->to_date ); $t += DAY_IN_SECONDS ) {
					$wpdb->query( $wpdb->prepare(
						"INSERT INTO $att (employee_id, att_date, status) VALUES (%d, %s, 'leave')
						 ON DUPLICATE KEY UPDATE status='leave'",
						$leave->employee_id, gmdate( 'Y-m-d', $t )
					) );
				}
			}
			wceerp_log( 'hr', 'leave_' . $decision, $id );
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'leave', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_advance_save() {
		$this->verify_nonce( 'wceerp_advance_save' );
		global $wpdb;
		$employee_id = (int) ( $_POST['employee_id'] ?? 0 );
		$amount      = wceerp_dec( $_POST['amount'] ?? 0 );
		$account_id  = (int) ( $_POST['account_id'] ?? 0 );
		if ( ! $employee_id || $amount <= 0 || ! $account_id ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'advances', 'error' => 1 ) ) );
			exit;
		}
		$doc_no = wceerp_next_doc_number( 'adv' );
		$wpdb->insert( wceerp_table( 'salary_advances' ), array(
			'doc_no'       => $doc_no,
			'employee_id'  => $employee_id,
			'amount'       => $amount,
			'advance_date' => sanitize_text_field( $_POST['advance_date'] ?? current_time( 'Y-m-d' ) ),
			'account_id'   => $account_id,
			'status'       => 'open',
			'note'         => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'   => current_time( 'mysql' ),
		) );
		$advance_id = (int) $wpdb->insert_id;

		$journal = WCEERP_Accounting::post(
			array( 'ref_type' => 'salary_advance', 'ref_id' => $advance_id, 'memo' => 'Salary advance ' . $doc_no ),
			array(
				array( 'account' => '1120', 'debit' => $amount, 'party_type' => 'employee', 'party_id' => $employee_id, 'memo' => $doc_no ),
				array( 'account' => $account_id, 'credit' => $amount ),
			)
		);
		if ( ! is_wp_error( $journal ) ) {
			$wpdb->update( wceerp_table( 'salary_advances' ), array( 'journal_id' => (int) $journal ), array( 'id' => $advance_id ) );
		}
		wceerp_log( 'hr', 'advance', $advance_id, $doc_no );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'advances', 'updated' => 1 ) ) );
		exit;
	}

	/** Open advance total for one employee. */
	protected function open_advance( $employee_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(amount - repaid_amount),0) FROM ' . wceerp_table( 'salary_advances' ) . " WHERE employee_id=%d AND status='open'",
			$employee_id
		) );
	}

	/** Count absences (absent = 1, half day = 0.5) inside a Y-m period. */
	protected function absences( $employee_id, $period ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT SUM(status='absent') a, SUM(status='half_day') h FROM " . wceerp_table( 'attendance' ) . '
			 WHERE employee_id=%d AND att_date LIKE %s',
			$employee_id, $period . '-%'
		) );
		return (float) ( $row->a ?? 0 ) + 0.5 * (float) ( $row->h ?? 0 );
	}

	/**
	 * The payroll run: validates, posts ONE balanced journal, records the
	 * run + items, and knocks deductions off open advances (oldest first).
	 */
	public function handle_payroll_run() {
		$this->verify_nonce( 'wceerp_payroll_run' );
		global $wpdb;

		$period = sanitize_text_field( $_POST['period'] ?? '' );
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $period ) ) {
			wp_die( esc_html__( 'Invalid payroll period.', 'wc-enterprise-erp' ) );
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'payroll_runs' ) . ' WHERE period=%s', $period ) ) ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'payroll', 'error' => 'period' ) ) );
			exit;
		}

		$field = function ( $key, $employee_id ) {
			return wceerp_dec( $_POST[ $key ][ $employee_id ] ?? 0 ); // phpcs:ignore
		};
		$include = (array) ( $_POST['include'] ?? array() );

		$items          = array();
		$salary_expense = 0; // 5100.
		$extra_expense  = 0; // 5110.
		$advance_total  = 0;
		$other_total    = 0;
		$net_by_channel = array();
		$net_total      = 0;

		foreach ( $this->employees() as $employee ) {
			if ( empty( $include[ $employee->id ] ) ) {
				continue;
			}
			$basic  = $field( 'basic', $employee->id );
			$allow  = $field( 'allow', $employee->id );
			$ot     = $field( 'ot', $employee->id );
			$bonus  = $field( 'bonus', $employee->id );
			$absent = min( $basic + $allow, $field( 'absent', $employee->id ) );
			$adv    = min( $this->open_advance( $employee->id ), $field( 'adv', $employee->id ) );
			$other  = $field( 'other', $employee->id );

			$earn = $basic + $allow - $absent;
			$net  = $earn + $ot + $bonus - $adv - $other;
			if ( $net < -0.004 ) {
				wp_die( esc_html( sprintf( __( 'Deductions exceed pay for %s — fix the amounts.', 'wc-enterprise-erp' ), $employee->name ) ) );
			}
			if ( $earn + $ot + $bonus <= 0.004 ) {
				continue;
			}

			$salary_expense += $earn;
			$extra_expense  += $ot + $bonus;
			$advance_total  += $adv;
			$other_total    += $other;
			$net_total      += $net;
			$channel        = array_key_exists( $employee->pay_channel, self::CHANNEL_ACCOUNTS ) ? $employee->pay_channel : 'cash';
			$net_by_channel[ $channel ] = ( $net_by_channel[ $channel ] ?? 0 ) + $net;

			$items[] = array(
				'employee_id'       => (int) $employee->id,
				'basic'             => $basic,
				'allowances'        => $allow,
				'overtime'          => $ot,
				'bonus'             => $bonus,
				'absent_deduction'  => $absent,
				'advance_deduction' => $adv,
				'other_deduction'   => $other,
				'net'               => $net,
				'pay_channel'       => $channel,
			);
		}

		if ( ! $items ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'payroll', 'error' => 'empty' ) ) );
			exit;
		}

		/* One balanced voucher for the whole month. */
		$lines = array();
		if ( $salary_expense > 0.004 ) {
			$lines[] = array( 'account' => '5100', 'debit' => $salary_expense, 'memo' => 'Salaries ' . $period );
		}
		if ( $extra_expense > 0.004 ) {
			$lines[] = array( 'account' => '5110', 'debit' => $extra_expense, 'memo' => 'Bonus & overtime ' . $period );
		}
		if ( $advance_total > 0.004 ) {
			$lines[] = array( 'account' => '1120', 'credit' => $advance_total, 'memo' => 'Advance repayments ' . $period );
		}
		if ( $other_total > 0.004 ) {
			$lines[] = array( 'account' => '4100', 'credit' => $other_total, 'memo' => 'Payroll deductions ' . $period );
		}
		foreach ( $net_by_channel as $channel => $amount ) {
			if ( $amount > 0.004 ) {
				$lines[] = array( 'account' => self::CHANNEL_ACCOUNTS[ $channel ], 'credit' => $amount, 'memo' => 'Net pay via ' . $channel . ' — ' . $period );
			}
		}
		$doc_no  = wceerp_next_doc_number( 'pay' );
		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $period . '-' . min( 28, (int) gmdate( 'd' ) ),
				'ref_type'     => 'payroll',
				'memo'         => sprintf( 'Payroll %s (%s) — %d employees', $period, $doc_no, count( $items ) ),
			),
			$lines
		);
		if ( is_wp_error( $journal ) ) {
			wp_die( esc_html( $journal->get_error_message() ) );
		}

		$wpdb->insert( wceerp_table( 'payroll_runs' ), array(
			'doc_no'     => $doc_no,
			'period'     => $period,
			'gross'      => $salary_expense + $extra_expense,
			'deductions' => $advance_total + $other_total,
			'net'        => $net_total,
			'journal_id' => (int) $journal,
			'note'       => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_by' => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		) );
		$run_id = (int) $wpdb->insert_id;

		foreach ( $items as $item ) {
			$item['run_id'] = $run_id;
			$wpdb->insert( wceerp_table( 'payroll_items' ), $item );

			/* Repay open advances, oldest first. */
			$remaining = $item['advance_deduction'];
			if ( $remaining > 0.004 ) {
				$advances = $wpdb->get_results( $wpdb->prepare(
					'SELECT * FROM ' . wceerp_table( 'salary_advances' ) . " WHERE employee_id=%d AND status='open' ORDER BY id",
					$item['employee_id']
				) );
				foreach ( $advances as $advance ) {
					if ( $remaining <= 0.004 ) {
						break;
					}
					$open = (float) $advance->amount - (float) $advance->repaid_amount;
					$take = min( $open, $remaining );
					$wpdb->update( wceerp_table( 'salary_advances' ), array(
						'repaid_amount' => (float) $advance->repaid_amount + $take,
						'status'        => ( $open - $take <= 0.004 ) ? 'settled' : 'open',
					), array( 'id' => $advance->id ) );
					$remaining -= $take;
				}
			}
		}

		wceerp_log( 'hr', 'payroll', $run_id, $period . ' net ' . $net_total );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payroll', 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'employees' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'HR & Payroll', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'employees'  => __( 'Employees', 'wc-enterprise-erp' ),
					'attendance' => __( 'Attendance', 'wc-enterprise-erp' ),
					'leave'      => __( 'Leave', 'wc-enterprise-erp' ),
					'advances'   => __( 'Advances', 'wc-enterprise-erp' ),
					'payroll'    => __( 'Payroll', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), $tab === $slug ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php
			if ( ! empty( $_GET['updated'] ) ) {
				$this->notice( __( 'Saved.', 'wc-enterprise-erp' ) );
			}
			if ( ! empty( $_GET['error'] ) && 'period' === $_GET['error'] ) {
				$this->notice( __( 'That month is already paid — a period can only run once.', 'wc-enterprise-erp' ), 'error' );
			}
			call_user_func( array( $this, 'tab_' . ( method_exists( $this, 'tab_' . $tab ) ? $tab : 'employees' ) ) );
			?>
		</div>
		<?php
	}

	protected function tab_employees() {
		$employees = $this->employees( false );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Add employee', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_employee_save">
					<?php wp_nonce_field( 'wceerp_employee_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="name" class="regular-text" required></td></tr>
						<tr><th><?php esc_html_e( 'Phone / NID', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="phone" placeholder="<?php esc_attr_e( 'Phone', 'wc-enterprise-erp' ); ?>"> <input type="text" name="nid_no" placeholder="NID"></td></tr>
						<tr><th><?php esc_html_e( 'Designation / Dept.', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="designation"> <input type="text" name="department"></td></tr>
						<tr><th><?php esc_html_e( 'Joined', 'wc-enterprise-erp' ); ?></th><td><input type="date" name="join_date"></td></tr>
						<tr><th><?php esc_html_e( 'Basic salary', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0" name="basic_salary" required></td></tr>
						<tr><th><?php esc_html_e( 'Allowances (house+medical+conveyance)', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0" name="allowances" value="0"></td></tr>
						<tr><th><?php esc_html_e( 'Salary paid via', 'wc-enterprise-erp' ); ?></th>
							<td><select name="pay_channel">
								<?php foreach ( array_keys( self::CHANNEL_ACCOUNTS ) as $channel ) : ?>
									<option value="<?php echo esc_attr( $channel ); ?>"><?php echo esc_html( ucfirst( $channel ) ); ?></option>
								<?php endforeach; ?>
							</select>
							<input type="text" name="pay_number" placeholder="<?php esc_attr_e( 'bKash/Nagad/account no.', 'wc-enterprise-erp' ); ?>"></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Add employee', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Employees', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Role', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Basic + allow.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Paid via', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Open advance', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $employees as $employee ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $employee->name ); ?></strong> <code><?php echo esc_html( $employee->doc_no ); ?></code><br><small><?php echo esc_html( $employee->phone ); ?></small></td>
							<td><?php echo esc_html( trim( $employee->designation . ' · ' . $employee->department, ' ·' ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( (float) $employee->basic_salary + (float) $employee->allowances ) ); ?></td>
							<td><span class="wceerp-badge"><?php echo esc_html( $employee->pay_channel ); ?></span> <small><?php echo esc_html( $employee->pay_number ); ?></small></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $this->open_advance( (int) $employee->id ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_attendance() {
		global $wpdb;
		$date  = sanitize_text_field( $_GET['date'] ?? current_time( 'Y-m-d' ) );
		$marks = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT employee_id, status FROM ' . wceerp_table( 'attendance' ) . ' WHERE att_date=%s', $date ) ) as $row ) {
			$marks[ (int) $row->employee_id ] = $row->status;
		}
		?>
		<div class="wceerp-card" style="max-width:760px">
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-hr"><input type="hidden" name="tab" value="attendance">
				<input type="date" name="date" value="<?php echo esc_attr( $date ); ?>">
				<button class="button"><?php esc_html_e( 'Load day', 'wc-enterprise-erp' ); ?></button>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_attendance_save">
				<input type="hidden" name="att_date" value="<?php echo esc_attr( $date ); ?>">
				<?php wp_nonce_field( 'wceerp_attendance_save' ); ?>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $this->employees() as $employee ) : ?>
						<tr>
							<td><?php echo esc_html( $employee->name ); ?></td>
							<td><select name="mark[<?php echo (int) $employee->id; ?>]">
								<?php foreach ( array( 'present', 'absent', 'leave', 'half_day', 'holiday' ) as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $marks[ $employee->id ] ?? 'present', $status ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $status ) ) ); ?></option>
								<?php endforeach; ?>
							</select></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php submit_button( __( 'Save attendance', 'wc-enterprise-erp' ) ); ?>
			</form>
			<p class="description"><?php esc_html_e( 'Absences and half-days feed straight into the payroll screen as suggested deductions (basic ÷ 30 per day).', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php
	}

	protected function tab_leave() {
		global $wpdb;
		$rows = $wpdb->get_results(
			'SELECT l.*, e.name FROM ' . wceerp_table( 'leaves' ) . ' l INNER JOIN ' . wceerp_table( 'employees' ) . ' e ON e.id=l.employee_id ORDER BY l.id DESC LIMIT 50'
		);
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Request leave', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_leave_save">
					<?php wp_nonce_field( 'wceerp_leave_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th>
							<td><select name="employee_id" required>
								<?php foreach ( $this->employees() as $employee ) : ?>
									<option value="<?php echo (int) $employee->id; ?>"><?php echo esc_html( $employee->name ); ?></option>
								<?php endforeach; ?>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'From — To', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="from_date" required> <input type="date" name="to_date"></td></tr>
						<tr><th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th>
							<td><select name="type"><option value="casual">Casual</option><option value="sick">Sick</option><option value="annual">Annual</option><option value="unpaid">Unpaid</option></select></td></tr>
						<tr><th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="note" class="regular-text"></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Submit request', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Requests', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Dates', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( (array) $rows as $leave ) : ?>
						<tr>
							<td><?php echo esc_html( $leave->name ); ?></td>
							<td><?php echo esc_html( $leave->from_date . ' → ' . $leave->to_date . ' (' . $leave->days . 'd)' ); ?></td>
							<td><?php echo esc_html( $leave->type ); ?></td>
							<td>
							<?php if ( 'pending' === $leave->status ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px">
									<input type="hidden" name="action" value="wceerp_leave_act">
									<input type="hidden" name="leave_id" value="<?php echo (int) $leave->id; ?>">
									<?php wp_nonce_field( 'wceerp_leave_act' ); ?>
									<button class="button button-small button-primary" name="decision" value="approve"><?php esc_html_e( 'Approve', 'wc-enterprise-erp' ); ?></button>
									<button class="button button-small" name="decision" value="reject"><?php esc_html_e( 'Reject', 'wc-enterprise-erp' ); ?></button>
								</form>
							<?php else : ?>
								<span class="wceerp-badge is-<?php echo esc_attr( 'approved' === $leave->status ? 'completed' : 'rejected' ); ?>"><?php echo esc_html( $leave->status ); ?></span>
							<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_advances() {
		global $wpdb;
		$money = $wpdb->get_results( 'SELECT id, code, name FROM ' . wceerp_table( 'accounts' ) . " WHERE subtype IN ('cash','bank','mobile_banking') AND status='active' ORDER BY code" );
		$rows  = $wpdb->get_results( 'SELECT a.*, e.name FROM ' . wceerp_table( 'salary_advances' ) . ' a INNER JOIN ' . wceerp_table( 'employees' ) . ' e ON e.id=a.employee_id ORDER BY a.id DESC LIMIT 40' );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Give a salary advance', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Posts Dr Staff Advances / Cr money. Repayment happens through the payroll deduction column (oldest advance first).', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_advance_save">
					<?php wp_nonce_field( 'wceerp_advance_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th>
							<td><select name="employee_id" required>
								<?php foreach ( $this->employees() as $employee ) : ?>
									<option value="<?php echo (int) $employee->id; ?>"><?php echo esc_html( $employee->name ); ?></option>
								<?php endforeach; ?>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0.01" name="amount" required></td></tr>
						<tr><th><?php esc_html_e( 'Paid from', 'wc-enterprise-erp' ); ?></th>
							<td><select name="account_id" required>
								<?php foreach ( $money as $account ) : ?>
									<option value="<?php echo (int) $account->id; ?>"><?php echo esc_html( $account->code . ' — ' . $account->name ); ?></option>
								<?php endforeach; ?>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th><td><input type="date" name="advance_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Give advance & post', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Advances', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Doc', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Repaid', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( (array) $rows as $advance ) : ?>
						<tr>
							<td><code><?php echo esc_html( $advance->doc_no ); ?></code></td>
							<td><?php echo esc_html( $advance->name ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $advance->amount ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $advance->repaid_amount ) ); ?></td>
							<td><span class="wceerp-badge is-<?php echo esc_attr( 'settled' === $advance->status ? 'completed' : 'open' ); ?>"><?php echo esc_html( $advance->status ); ?></span></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_payroll() {
		global $wpdb;
		$period = sanitize_text_field( $_GET['period'] ?? gmdate( 'Y-m' ) );
		$runs   = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'payroll_runs' ) . ' ORDER BY period DESC LIMIT 12' );
		$paid   = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'payroll_runs' ) . ' WHERE period=%s', $period ) );
		?>
		<div class="wceerp-card">
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-hr"><input type="hidden" name="tab" value="payroll">
				<input type="month" name="period" value="<?php echo esc_attr( $period ); ?>">
				<button class="button"><?php esc_html_e( 'Prepare month', 'wc-enterprise-erp' ); ?></button>
			</form>

			<?php if ( $paid ) : ?>
				<p><strong><?php printf( esc_html__( '%s is already paid.', 'wc-enterprise-erp' ), esc_html( $period ) ); ?></strong></p>
			<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_payroll_run">
				<input type="hidden" name="period" value="<?php echo esc_attr( $period ); ?>">
				<?php wp_nonce_field( 'wceerp_payroll_run' ); ?>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Employee', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Basic', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Allow.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'OT', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Bonus', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Absent −', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Advance −', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Other −', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Via', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $this->employees() as $employee ) :
						$absent_days = $this->absences( (int) $employee->id, $period );
						$suggest     = round( $absent_days * (float) $employee->basic_salary / 30, 2 );
						$open_adv    = $this->open_advance( (int) $employee->id );
						$num         = 'type="number" step="0.01" min="0" style="width:86px"';
						?>
						<tr>
							<td><label><input type="checkbox" name="include[<?php echo (int) $employee->id; ?>]" value="1" checked>
								<strong><?php echo esc_html( $employee->name ); ?></strong></label>
								<?php if ( $absent_days ) : ?><br><small style="color:#b32d2e"><?php printf( esc_html__( '%s absent day(s)', 'wc-enterprise-erp' ), esc_html( $absent_days ) ); ?></small><?php endif; ?></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="basic[<?php echo (int) $employee->id; ?>]" value="<?php echo esc_attr( $employee->basic_salary ); ?>"></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="allow[<?php echo (int) $employee->id; ?>]" value="<?php echo esc_attr( $employee->allowances ); ?>"></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="ot[<?php echo (int) $employee->id; ?>]" value="0"></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="bonus[<?php echo (int) $employee->id; ?>]" value="0"></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="absent[<?php echo (int) $employee->id; ?>]" value="<?php echo esc_attr( $suggest ); ?>"></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="adv[<?php echo (int) $employee->id; ?>]" value="0" max="<?php echo esc_attr( $open_adv ); ?>">
								<?php if ( $open_adv > 0 ) : ?><br><small><?php printf( esc_html__( 'open: %s', 'wc-enterprise-erp' ), wp_kses_post( wceerp_money( $open_adv ) ) ); ?></small><?php endif; ?></td>
							<td><input <?php echo $num; // phpcs:ignore ?> name="other[<?php echo (int) $employee->id; ?>]" value="0"></td>
							<td><span class="wceerp-badge"><?php echo esc_html( $employee->pay_channel ); ?></span></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p><input type="text" name="note" class="regular-text" placeholder="<?php esc_attr_e( 'Run note (optional)', 'wc-enterprise-erp' ); ?>"></p>
				<?php submit_button( sprintf( __( 'Pay %s & post to books', 'wc-enterprise-erp' ), $period ) ); ?>
				<p class="description"><?php esc_html_e( 'One balanced voucher: salary and bonus expenses debited; advances and deductions credited; each person\'s net credited to their own channel — bKash salaries hit the bKash book, cash salaries the cash book.', 'wc-enterprise-erp' ); ?></p>
			</form>
			<?php endif; ?>
		</div>

		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Past runs', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped wceerp-table">
				<thead><tr><th><?php esc_html_e( 'Period', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Doc', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Gross', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Deductions', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Net paid', 'wc-enterprise-erp' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( (array) $runs as $run ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $run->period ); ?></strong></td>
						<td><code><?php echo esc_html( $run->doc_no ); ?></code></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $run->gross ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $run->deductions ) ); ?></td>
						<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $run->net ) ); ?></strong></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
