<?php
/**
 * Module: Audit Trail.
 *
 * Every module already writes to wp_erp_audit_log via wceerp_log().
 * This module adds authentication events (login / logout / failed login)
 * and a filterable viewer so an owner can answer "who did what, when".
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Audit extends WCEERP_Module {

	protected $id         = 'audit';
	protected $title      = 'Audit Trail';
	protected $capability = 'wceerp_view_audit';
	protected $tier       = 'business';
	protected $order      = 85;

	public function __construct() {
		$this->title = __( 'Audit Trail', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'wp_login', array( __CLASS__, 'log_login' ), 10, 2 );
		add_action( 'wp_logout', array( __CLASS__, 'log_logout' ) );
		add_action( 'wp_login_failed', array( __CLASS__, 'log_failed' ) );
	}

	/* ---------------------------------------------------------------------
	 * Authentication events.
	 * ------------------------------------------------------------------- */

	public static function log_login( $user_login, $user ) {
		global $wpdb;
		$wpdb->insert( wceerp_table( 'audit_log' ), array(
			'module'     => 'auth',
			'action'     => 'login',
			'ref_id'     => (int) $user->ID,
			'note'       => sanitize_text_field( $user_login . ' · ' . self::ip() ),
			'user_id'    => (int) $user->ID,
			'created_at' => current_time( 'mysql' ),
		) );
	}

	public static function log_logout( $user_id = 0 ) {
		global $wpdb;
		$wpdb->insert( wceerp_table( 'audit_log' ), array(
			'module'     => 'auth',
			'action'     => 'logout',
			'ref_id'     => (int) $user_id,
			'note'       => sanitize_text_field( self::ip() ),
			'user_id'    => (int) $user_id,
			'created_at' => current_time( 'mysql' ),
		) );
	}

	public static function log_failed( $username ) {
		global $wpdb;
		$wpdb->insert( wceerp_table( 'audit_log' ), array(
			'module'     => 'auth',
			'action'     => 'login_failed',
			'ref_id'     => 0,
			'note'       => sanitize_text_field( $username . ' · ' . self::ip() ),
			'user_id'    => 0,
			'created_at' => current_time( 'mysql' ),
		) );
	}

	protected static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/* ---------------------------------------------------------------------
	 * Viewer.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		global $wpdb;
		$table = wceerp_table( 'audit_log' );

		$module = sanitize_key( $_GET['module'] ?? '' );
		$user   = (int) ( $_GET['user'] ?? 0 );
		$from   = sanitize_text_field( $_GET['from'] ?? '' );
		$to     = sanitize_text_field( $_GET['to'] ?? '' );

		$where  = array( '1=1' );
		$params = array();
		if ( $module ) { $where[] = 'module = %s'; $params[] = $module; }
		if ( $user )   { $where[] = 'user_id = %d'; $params[] = $user; }
		if ( $from )   { $where[] = 'created_at >= %s'; $params[] = $from . ' 00:00:00'; }
		if ( $to )     { $where[] = 'created_at <= %s'; $params[] = $to . ' 23:59:59'; }
		$where_sql = implode( ' AND ', $where );

		$per_page = 40;
		$count_q  = "SELECT COUNT(*) FROM $table WHERE $where_sql";
		$total    = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_q, $params ) ) : $wpdb->get_var( $count_q ) );

		$list_q          = "SELECT * FROM $table WHERE $where_sql ORDER BY id DESC LIMIT %d OFFSET %d";
		$list_params     = $params;
		$list_params[]   = $per_page;
		$list_params[]   = wceerp_offset( $per_page );
		$rows            = $wpdb->get_results( $wpdb->prepare( $list_q, $list_params ) );

		$modules = $wpdb->get_col( "SELECT DISTINCT module FROM $table ORDER BY module" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Audit Trail', 'wc-enterprise-erp' ) ) ); ?></h1>
			<p class="description"><?php esc_html_e( 'Every ERP action — journals, receipts, payouts, settings, logins — with who and when. Records are append-only.', 'wc-enterprise-erp' ); ?></p>

			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-audit">
				<select name="module">
					<option value=""><?php esc_html_e( 'All modules', 'wc-enterprise-erp' ); ?></option>
					<?php foreach ( (array) $modules as $m ) : ?>
						<option value="<?php echo esc_attr( $m ); ?>" <?php selected( $module, $m ); ?>><?php echo esc_html( ucfirst( $m ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<label><?php esc_html_e( 'User ID', 'wc-enterprise-erp' ); ?> <input type="number" name="user" min="0" value="<?php echo $user ? (int) $user : ''; ?>" style="width:90px"></label>
				<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
				<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
				<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			</form>

			<div class="wceerp-card">
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'When', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'User', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Module', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Action', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Ref', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Detail', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'No activity matches this filter.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $row ) :
						$user_obj = $row->user_id ? get_userdata( $row->user_id ) : null;
						?>
						<tr>
							<td><span class="mono" style="font-family:monospace"><?php echo esc_html( $row->created_at ); ?></span></td>
							<td><?php echo $user_obj ? esc_html( $user_obj->user_login ) : ( $row->user_id ? '#' . (int) $row->user_id : '—' ); ?></td>
							<td><span class="wceerp-badge"><?php echo esc_html( $row->module ); ?></span></td>
							<td><code><?php echo esc_html( $row->action ); ?></code></td>
							<td><?php echo $row->ref_id ? '#' . (int) $row->ref_id : '—'; ?></td>
							<td><?php echo esc_html( $row->note ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php wceerp_pagination( $total, $per_page ); ?>
			</div>
		</div>
		<?php
	}
}
