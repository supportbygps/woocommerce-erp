<?php
/**
 * Module: Customers.
 *
 * Answers "who are my best customers, and who just crossed a milestone?"
 *
 * Counts come from WooCommerce orders, which covers both online orders
 * and POS sales (POS writes real WC orders), so a customer who buys
 * across both channels is counted once.
 *
 * Aggregation is done in SQL rather than by loading orders into PHP —
 * a shop with 50,000 orders would otherwise time out. The module detects
 * HPOS (the WooCommerce custom orders table) and falls back to the
 * classic posts/postmeta layout automatically.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Customers extends WCEERP_Module {

	protected $id         = 'customers';
	protected $capability = 'wceerp_view_reports';
	protected $tier       = 'starter';
	protected $order      = 46;

	/** Default milestones (order counts worth celebrating / flagging). */
	const DEFAULT_MILESTONES = '10,50,100,250,500,1000';

	public function __construct() {
		$this->title = __( 'Customers', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_customers_settings', array( $this, 'handle_settings' ) );
		// Check for a milestone crossing whenever an order is paid.
		add_action( 'woocommerce_order_status_processing', array( $this, 'maybe_flag_milestone' ), 40 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'maybe_flag_milestone' ), 40 );
	}

	/* ---------------------------------------------------------------------
	 * Storage layout detection.
	 * ------------------------------------------------------------------- */

	/** True when WooCommerce is using High-Performance Order Storage. */
	protected static function is_hpos() {
		return class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& method_exists( '\Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	}

	/** Order statuses that count as a real, revenue-bearing order. */
	protected static function counted_statuses() {
		$statuses = apply_filters( 'wceerp_customer_counted_statuses', array( 'wc-processing', 'wc-completed' ) );
		return array_map( 'sanitize_text_field', (array) $statuses );
	}

	/* ---------------------------------------------------------------------
	 * The aggregate query.
	 * ------------------------------------------------------------------- */

	/**
	 * Aggregated customer stats.
	 *
	 * Customers are keyed by WordPress user id when logged in, otherwise by
	 * billing email — so guest checkouts and POS walk-ins with an email
	 * still group correctly. Rows with neither are grouped as "Guest".
	 *
	 * @return array of objects: ident, name, email, orders, total, last_order
	 */
	public static function stats( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args( $args, array(
			'from'    => '',
			'to'      => '',
			'min'     => 0,
			'orderby' => 'orders',
			'limit'   => 100,
			'search'  => '',
		) );

		$statuses    = self::counted_statuses();
		$status_in   = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
		$order_by    = 'total' === $args['orderby'] ? 'total_spent' : ( 'recent' === $args['orderby'] ? 'last_order' : 'order_count' );

		if ( self::is_hpos() ) {
			$orders = $wpdb->prefix . 'wc_orders';
			$addr   = $wpdb->prefix . 'wc_order_addresses';

			$sql = "SELECT
					CASE
						WHEN o.customer_id > 0 THEN CONCAT('u:', o.customer_id)
						WHEN COALESCE(o.billing_email,'') <> '' THEN CONCAT('e:', o.billing_email)
						WHEN COALESCE(a.phone,'') <> '' THEN CONCAT('p:', a.phone)
						ELSE CONCAT('o:', o.id)
					END AS ident,
					MAX(o.customer_id) AS user_id,
					MAX(COALESCE(NULLIF(o.billing_email,''),'')) AS email,
					MAX(COALESCE(a.phone,'')) AS phone,
					MAX(CONCAT(COALESCE(a.first_name,''),' ',COALESCE(a.last_name,''))) AS name,
					COUNT(*) AS order_count,
					COALESCE(SUM(o.total_amount),0) AS total_spent,
					MAX(o.date_created_gmt) AS last_order
				FROM $orders o
				LEFT JOIN $addr a ON a.order_id = o.id AND a.address_type = 'billing'
				WHERE o.status IN ($status_in) AND o.type = 'shop_order'";

			$params = $statuses;
			$golive = wceerp_start_date();
			if ( $golive ) {
				$sql .= ' AND o.date_created_gmt >= %s';
				$params[] = $golive . ' 00:00:00';
			}
			if ( $args['from'] ) {
				$sql .= ' AND o.date_created_gmt >= %s';
				$params[] = $args['from'] . ' 00:00:00';
			}
			if ( $args['to'] ) {
				$sql .= ' AND o.date_created_gmt <= %s';
				$params[] = $args['to'] . ' 23:59:59';
			}
			$sql .= ' GROUP BY ident';
		} else {
			$posts    = $wpdb->posts;
			$meta     = $wpdb->postmeta;

			$sql = "SELECT
					CASE
						WHEN CAST(COALESCE(cid.meta_value,'0') AS UNSIGNED) > 0 THEN CONCAT('u:', cid.meta_value)
						WHEN COALESCE(em.meta_value,'') <> '' THEN CONCAT('e:', em.meta_value)
						WHEN COALESCE(ph.meta_value,'') <> '' THEN CONCAT('p:', ph.meta_value)
						ELSE CONCAT('o:', p.ID)
					END AS ident,
					MAX(CAST(COALESCE(cid.meta_value,'0') AS UNSIGNED)) AS user_id,
					MAX(COALESCE(em.meta_value,'')) AS email,
					MAX(COALESCE(ph.meta_value,'')) AS phone,
					MAX(CONCAT(COALESCE(fn.meta_value,''),' ',COALESCE(ln.meta_value,''))) AS name,
					COUNT(*) AS order_count,
					COALESCE(SUM(CAST(tot.meta_value AS DECIMAL(18,2))),0) AS total_spent,
					MAX(p.post_date_gmt) AS last_order
				FROM $posts p
				LEFT JOIN $meta cid ON cid.post_id = p.ID AND cid.meta_key = '_customer_user'
				LEFT JOIN $meta em  ON em.post_id  = p.ID AND em.meta_key  = '_billing_email'
				LEFT JOIN $meta ph  ON ph.post_id  = p.ID AND ph.meta_key  = '_billing_phone'
				LEFT JOIN $meta fn  ON fn.post_id  = p.ID AND fn.meta_key  = '_billing_first_name'
				LEFT JOIN $meta ln  ON ln.post_id  = p.ID AND ln.meta_key  = '_billing_last_name'
				LEFT JOIN $meta tot ON tot.post_id = p.ID AND tot.meta_key = '_order_total'
				WHERE p.post_type = 'shop_order' AND p.post_status IN ($status_in)";

			$params = $statuses;
			$golive = wceerp_start_date();
			if ( $golive ) {
				$sql .= ' AND p.post_date_gmt >= %s';
				$params[] = $golive . ' 00:00:00';
			}
			if ( $args['from'] ) {
				$sql .= ' AND p.post_date_gmt >= %s';
				$params[] = $args['from'] . ' 00:00:00';
			}
			if ( $args['to'] ) {
				$sql .= ' AND p.post_date_gmt <= %s';
				$params[] = $args['to'] . ' 23:59:59';
			}
			$sql .= ' GROUP BY ident';
		}

		if ( $args['min'] > 0 ) {
			$sql .= $wpdb->prepare( ' HAVING order_count >= %d', (int) $args['min'] );
		}
		$sql .= " ORDER BY $order_by DESC";
		$sql .= $wpdb->prepare( ' LIMIT %d', max( 1, min( 500, (int) $args['limit'] ) ) );

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql;
		$rows     = $wpdb->get_results( $prepared );

		// Optional in-PHP search (small result set by this point).
		if ( $args['search'] ) {
			$needle = strtolower( $args['search'] );
			$rows   = array_values( array_filter( (array) $rows, function ( $r ) use ( $needle ) {
				return false !== strpos( strtolower( $r->name . ' ' . $r->email . ' ' . ( $r->phone ?? '' ) ), $needle );
			} ) );
		}
		return (array) $rows;
	}

	/** Order count for a single customer (user id or billing email). */
	public static function order_count_for( $user_id, $email = '' ) {
		global $wpdb;
		$statuses  = self::counted_statuses();
		$status_in = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

		if ( self::is_hpos() ) {
			$orders = $wpdb->prefix . 'wc_orders';
			if ( $user_id > 0 ) {
				$sql = "SELECT COUNT(*) FROM $orders WHERE customer_id = %d AND type = 'shop_order' AND status IN ($status_in)";
				return (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( array( $user_id ), $statuses ) ) );
			}
			if ( $email ) {
				$sql = "SELECT COUNT(*) FROM $orders WHERE billing_email = %s AND type = 'shop_order' AND status IN ($status_in)";
				return (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( array( $email ), $statuses ) ) );
			}
			return 0;
		}

		$posts = $wpdb->posts;
		$meta  = $wpdb->postmeta;
		if ( $user_id > 0 ) {
			$sql = "SELECT COUNT(*) FROM $posts p
					INNER JOIN $meta m ON m.post_id = p.ID AND m.meta_key = '_customer_user'
					WHERE p.post_type='shop_order' AND p.post_status IN ($status_in) AND m.meta_value = %s";
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( $statuses, array( (string) $user_id ) ) ) );
		}
		if ( $email ) {
			$sql = "SELECT COUNT(*) FROM $posts p
					INNER JOIN $meta m ON m.post_id = p.ID AND m.meta_key = '_billing_email'
					WHERE p.post_type='shop_order' AND p.post_status IN ($status_in) AND m.meta_value = %s";
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, array_merge( $statuses, array( $email ) ) ) );
		}
		return 0;
	}

	/* ---------------------------------------------------------------------
	 * Milestones.
	 * ------------------------------------------------------------------- */

	public static function milestones() {
		$raw  = wceerp_get_option( 'customer_milestones', self::DEFAULT_MILESTONES );
		$list = array_filter( array_map( 'intval', array_map( 'trim', explode( ',', $raw ) ) ) );
		sort( $list );
		return $list;
	}

	/**
	 * When an order is paid, see whether this customer just crossed a
	 * milestone and, if so, raise a notification once.
	 *
	 * Idempotent: the highest milestone already announced is stored against
	 * the customer, so re-saving an order can't fire a duplicate alert.
	 */
	public function maybe_flag_milestone( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$user_id = (int) $order->get_customer_id();
		$email   = (string) $order->get_billing_email();
		if ( ! $user_id && ! $email ) {
			return;
		}

		$count = self::order_count_for( $user_id, $email );
		if ( $count < 1 ) {
			return;
		}

		$milestones = self::milestones();
		$reached    = 0;
		foreach ( $milestones as $m ) {
			if ( $count >= $m ) {
				$reached = $m;
			}
		}
		if ( ! $reached ) {
			return;
		}

		// Have we already announced this level for this customer?
		$key       = $user_id ? 'u:' . $user_id : 'e:' . strtolower( $email );
		$announced = (array) get_option( 'wceerp_customer_milestones_hit', array() );
		if ( isset( $announced[ $key ] ) && (int) $announced[ $key ] >= $reached ) {
			return;
		}
		$announced[ $key ] = $reached;
		update_option( 'wceerp_customer_milestones_hit', $announced, false );

		$name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$name = $name ?: ( $email ?: __( 'A customer', 'wc-enterprise-erp' ) );

		$message = sprintf(
			/* translators: 1: customer name 2: order count */
			__( '%1$s has now placed %2$d orders.', 'wc-enterprise-erp' ),
			$name,
			$count
		);

		// Raise an ERP notification if the table exists.
		global $wpdb;
		$table = wceerp_table( 'notifications' );
		if ( $table && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
			$wpdb->insert( $table, array(
				'type'       => 'customer_milestone',
				'title'      => sprintf( __( 'Customer milestone: %d orders', 'wc-enterprise-erp' ), $reached ),
				'message'    => $message,
				'link'       => admin_url( 'admin.php?page=wceerp-customers' ),
				'user_id'    => 0,
				'is_read'    => 0,
				'created_at' => current_time( 'mysql' ),
			) );
		}
		$order->add_order_note( $message );
		wceerp_log( 'customers', 'milestone', $order_id, $reached );
	}

	/* ---------------------------------------------------------------------
	 * Settings.
	 * ------------------------------------------------------------------- */

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_customers_settings' );
		wceerp_update_option( 'customer_milestones', sanitize_text_field( wp_unslash( $_POST['milestones'] ?? self::DEFAULT_MILESTONES ) ) );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'settings', 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	/**
	 * Outstanding receivable per customer and per dealer, keyed by WordPress
	 * user id.
	 *
	 * Read from the ledger rather than from orders, so it reflects what the
	 * books actually say a customer owes -- including balances from POS
	 * part-payments or manual journals, not just unpaid orders.
	 *
	 * Loaded once per request: querying per row would mean one ledger
	 * aggregate per customer on a list that can run to hundreds.
	 */
	public static function due_map() {
		static $map = null;
		if ( null !== $map ) {
			return $map;
		}
		$map = array();
		if ( ! class_exists( 'WCEERP_Accounting' ) ) {
			return $map;
		}

		foreach ( (array) WCEERP_Accounting::party_balances( 'customer', 'receivable' ) as $b ) {
			$due = (float) $b->balance;
			if ( $due > 0.005 ) {
				$map[ (int) $b->party_id ] = $due;
			}
		}

		/* Dealers sit on their own party ledger, so their WordPress user has
		 * to be resolved for them to appear on this list at all. */
		if ( class_exists( 'WCEERP_Module_Dealers' ) ) {
			global $wpdb;
			foreach ( (array) WCEERP_Accounting::party_balances( 'dealer', 'receivable' ) as $b ) {
				$due = (float) $b->balance;
				if ( $due <= 0.005 ) {
					continue;
				}
				$user_id = (int) $wpdb->get_var( $wpdb->prepare(
					'SELECT user_id FROM ' . wceerp_table( 'dealers' ) . ' WHERE id = %d',
					(int) $b->party_id
				) );
				if ( $user_id ) {
					$map[ $user_id ] = ( $map[ $user_id ] ?? 0 ) + $due;
				}
			}
		}
		return $map;
	}

	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'top';
		echo '<div class="wrap wceerp-wrap">';
		echo '<h1>' . esc_html__( 'Customers', 'wc-enterprise-erp' ) . '</h1>';
		$tabs = array(
			'top'      => __( 'Top customers', 'wc-enterprise-erp' ),
			'settings' => __( 'Milestones', 'wc-enterprise-erp' ),
		);
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $key => $label ) {
			printf(
				'<a href="%s" class="nav-tab %s">%s</a>',
				esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
				$tab === $key ? 'nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</h2>';
		if ( 'settings' === $tab ) {
			$this->render_settings();
		} else {
			$this->render_top();
		}
		echo '</div>';
	}

	protected function render_top() {
		$from    = sanitize_text_field( $_GET['from'] ?? '' );
		$to      = sanitize_text_field( $_GET['to'] ?? '' );
		$min     = (int) ( $_GET['min'] ?? 0 );
		$orderby = sanitize_key( $_GET['orderby'] ?? 'orders' );
		$search  = sanitize_text_field( $_GET['s'] ?? '' );

		$rows = self::stats( array(
			'from'    => $from,
			'to'      => $to,
			'min'     => $min,
			'orderby' => $orderby,
			'search'  => $search,
			'limit'   => 200,
		) );

		$milestones   = self::milestones();
		$total_orders = 0;
		$total_spent  = 0.0;
		foreach ( $rows as $r ) {
			$total_orders += (int) $r->order_count;
			$total_spent  += (float) $r->total_spent;
		}
		?>
		<form method="get" class="wceerp-card" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin:14px 0">
			<input type="hidden" name="page" value="wceerp-customers">
			<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
			<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
			<label><?php esc_html_e( 'Min orders', 'wc-enterprise-erp' ); ?><br><input type="number" name="min" min="0" value="<?php echo esc_attr( $min ); ?>" style="width:100px" placeholder="e.g. 500"></label>
			<label><?php esc_html_e( 'Sort by', 'wc-enterprise-erp' ); ?><br>
				<select name="orderby">
					<option value="orders" <?php selected( $orderby, 'orders' ); ?>><?php esc_html_e( 'Order count', 'wc-enterprise-erp' ); ?></option>
					<option value="total" <?php selected( $orderby, 'total' ); ?>><?php esc_html_e( 'Total spent', 'wc-enterprise-erp' ); ?></option>
					<option value="recent" <?php selected( $orderby, 'recent' ); ?>><?php esc_html_e( 'Most recent', 'wc-enterprise-erp' ); ?></option>
				</select></label>
			<label><?php esc_html_e( 'Search', 'wc-enterprise-erp' ); ?><br><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'name or email', 'wc-enterprise-erp' ); ?>"></label>
			<button class="button button-primary"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			<a class="button" href="<?php echo esc_url( $this->admin_url() ); ?>"><?php esc_html_e( 'Reset', 'wc-enterprise-erp' ); ?></a>
		</form>

		<div class="wceerp-kpis" style="margin-bottom:14px">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Customers listed', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) count( $rows ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Their orders', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $total_orders; ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Their spend', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $total_spent ) ); ?></strong></div>
		</div>

		<table class="widefat striped">
			<thead><tr>
					<th style="width:34px"><?php esc_html_e( '#', 'wc-enterprise-erp' ); ?></th>
				<th>#</th>
				<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Orders', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Total spent', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Avg order', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Last order', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Milestone', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="8"><?php esc_html_e( 'No customers match these filters.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php else : ?>
				<?php $due_map = self::due_map(); ?>
				<?php $i = 0; foreach ( $rows as $r ) :
					$i++;
					$count = (int) $r->order_count;
					$spent = (float) $r->total_spent;
					$aov   = $count > 0 ? $spent / $count : 0;
					$badge = 0;
					foreach ( $milestones as $m ) {
						if ( $count >= $m ) {
							$badge = $m;
						}
					}
					$name = trim( (string) $r->name ) ?: ( $r->email ?: __( 'Guest', 'wc-enterprise-erp' ) );
					?>
					<tr>
						<td><?php echo (int) $i; ?></td>
						<td>
							<strong><?php echo esc_html( $name ); ?></strong>
							<?php if ( $r->email ) : ?><br><small style="color:#888"><?php echo esc_html( $r->email ); ?></small><?php endif; ?>
						</td>
						<td class="num"><strong><?php echo (int) $count; ?></strong></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $spent ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $aov ) ); ?></td>
						<td class="num">
							<?php
							$due = ( $r->user_id && isset( $due_map[ (int) $r->user_id ] ) ) ? (float) $due_map[ (int) $r->user_id ] : 0;
							if ( $due > 0.005 ) {
								printf(
									'<a href="%s" style="color:#b32d2e;font-weight:600;text-decoration:none">%s</a>',
									esc_url( admin_url( 'admin.php?page=wceerp-dues' ) ),
									wp_kses_post( wceerp_money( $due ) )
								);
							} else {
								echo '<span style="color:#bbb">—</span>';
							}
							?>
						</td>
						<td><?php echo $r->last_order ? esc_html( mysql2date( 'j M Y', $r->last_order ) ) : '—'; ?></td>
						<td>
							<?php if ( $badge ) : ?>
								<span class="wceerp-badge" style="background:#e8f3ee;color:#075742"><?php echo esc_html( sprintf( __( '%d+ orders', 'wc-enterprise-erp' ), $badge ) ); ?></span>
							<?php else : ?>
								<span style="color:#bbb">—</span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
		<p class="description">
			<?php esc_html_e( 'Counts include online orders and POS sales (POS writes real WooCommerce orders). Only paid orders — processing and completed — are counted. Registered customers are grouped by account; guests are grouped by billing email, or by phone when no email was given. Orders with neither an email nor a phone cannot be identified and are listed individually rather than merged together.', 'wc-enterprise-erp' ); ?>
			<?php $gl = wceerp_start_date(); if ( $gl ) : ?>
				<br><?php printf( esc_html__( 'Only orders from %s onward are counted — the date your books start. Change it under ERP → Modules & Settings.', 'wc-enterprise-erp' ), esc_html( $gl ) ); ?>
			<?php endif; ?>
		</p>
		<?php
	}

	protected function render_settings() {
		?>
		<?php if ( isset( $_GET['updated'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Milestones saved.', 'wc-enterprise-erp' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="max-width:620px">
			<input type="hidden" name="action" value="wceerp_customers_settings">
			<?php wp_nonce_field( 'wceerp_customers_settings' ); ?>
			<h2><?php esc_html_e( 'Order-count milestones', 'wc-enterprise-erp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'When a customer crosses one of these order counts, a notification is raised and a note is added to the order. Comma separated.', 'wc-enterprise-erp' ); ?>
			</p>
			<table class="form-table"><tbody>
				<tr><th><?php esc_html_e( 'Milestones', 'wc-enterprise-erp' ); ?></th>
					<td><input type="text" name="milestones" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'customer_milestones', self::DEFAULT_MILESTONES ) ); ?>">
						<p class="description"><?php echo esc_html( sprintf( __( 'Default: %s', 'wc-enterprise-erp' ), self::DEFAULT_MILESTONES ) ); ?></p></td></tr>
			</tbody></table>
			<?php submit_button( __( 'Save milestones', 'wc-enterprise-erp' ) ); ?>
		</form>
		<?php
	}
}
