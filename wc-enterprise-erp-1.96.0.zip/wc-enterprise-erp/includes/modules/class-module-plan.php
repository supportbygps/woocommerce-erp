<?php
/**
 * Module: My Plan.
 *
 * The customer-facing view of what they have bought: current package,
 * trial countdown, what is included, usage against limits, and a direct
 * line to upgrade or renew.
 *
 * This is deliberately always available — even at Starter, even on the
 * free trial — because it is the screen a customer needs precisely when
 * their access is about to lapse.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Plan extends WCEERP_Module {

	protected $id         = 'plan';
	protected $capability = 'wceerp_view_dashboard';
	protected $tier       = 'starter';
	protected $order      = 2;

	/** Sales contact — used for the WhatsApp CTA. */
	const WHATSAPP = '8801729341345';

	public function __construct() {
		$this->title = __( 'My Plan', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_recheck_licence', array( $this, 'handle_recheck' ) );
		add_action( 'admin_notices', array( $this, 'trial_notice' ) );
		add_action( 'admin_post_wceerp_plan_contact', array( $this, 'handle_contact' ) );
	}

	/**
	 * Save the customer's WhatsApp number.
	 *
	 * Asked here rather than at activation: a number typed to dismiss an
	 * install prompt is worthless, whereas someone who fills it in on the
	 * plan screen is signalling genuine interest. It is sent with the
	 * trial heartbeat so the vendor can follow up.
	 */
	public function handle_contact() {
		$this->verify_nonce( 'wceerp_plan_contact' );
		$number = preg_replace( '/[^0-9+]/', '', (string) ( $_POST['whatsapp'] ?? '' ) );
		wceerp_update_option( 'contact_whatsapp', $number );
		if ( class_exists( 'WCEERP_License' ) ) {
			WCEERP_License::trial_ping(); // push it straight away
		}
		wp_safe_redirect( $this->admin_url( array( 'saved' => 1 ) ) );
		exit;
	}

	/** WhatsApp deep link with a pre-written message. */
	public static function whatsapp_link( $message = '' ) {
		$number = apply_filters( 'wceerp_support_whatsapp', self::WHATSAPP );
		$text   = $message ?: sprintf(
			/* translators: %s: site domain */
			__( 'Hello, I would like to upgrade my WordPress ERP licence for %s', 'wc-enterprise-erp' ),
			wp_parse_url( home_url(), PHP_URL_HOST )
		);
		return 'https://wa.me/' . rawurlencode( $number ) . '?text=' . rawurlencode( $text );
	}

	/**
	 * Countdown banner while the trial is running.
	 * Shown on ERP screens only, so it doesn't nag across all of wp-admin.
	 */
	public function trial_notice() {
		if ( ! class_exists( 'WCEERP_License' ) || ! WCEERP_License::in_trial() ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( 0 !== strpos( $page, 'wceerp' ) ) {
			return;
		}
		$days = WCEERP_License::trial_days_left();
		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong> %s <a href="%s" class="button button-primary" style="margin-left:8px">%s</a> <a href="%s" target="_blank" rel="noopener" style="margin-left:6px">%s</a></p></div>',
			esc_html__( 'Free trial:', 'wc-enterprise-erp' ),
			esc_html( sprintf(
				/* translators: %d: days remaining */
				_n( '%d day left. Activate a licence to keep access.', '%d days left. Activate a licence to keep access.', $days, 'wc-enterprise-erp' ),
				$days
			) ),
			esc_url( $this->admin_url() ),
			esc_html__( 'View plan', 'wc-enterprise-erp' ),
			esc_url( self::whatsapp_link() ),
			esc_html__( 'Chat on WhatsApp', 'wc-enterprise-erp' )
		);
	}

	public function render_page() {
		$license = WCEERP_License::get();
		$trial   = WCEERP_License::in_trial();
		$days    = WCEERP_License::trial_days_left();
		$active  = 'active' === $license['status'];
		$tier    = $trial ? 'starter' : ( $license['tier'] ?: 'starter' );
		$agency  = WCEERP_License::has_agency();

		$tier_labels = array(
			'starter'    => __( 'Starter', 'wc-enterprise-erp' ),
			'business'   => __( 'Business', 'wc-enterprise-erp' ),
			'enterprise' => __( 'Enterprise', 'wc-enterprise-erp' ),
		);
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'My Plan', 'wc-enterprise-erp' ) ) ); ?></h1>

			<div class="wceerp-plan-hero <?php echo $trial ? 'is-trial' : ( $active ? 'is-active' : 'is-lapsed' ); ?>">
				<div class="left">
					<div class="lbl"><?php esc_html_e( 'CURRENT PLAN', 'wc-enterprise-erp' ); ?></div>
					<div class="big">
						<?php echo esc_html( $tier_labels[ $tier ] ?? ucfirst( $tier ) ); ?>
						<?php if ( $agency ) : ?>
							<span class="addon"><?php esc_html_e( '+ Agency', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</div>
					<div class="sub">
						<?php if ( $trial ) : ?>
							<?php
							printf(
								esc_html( _n( 'Free trial — %d day remaining', 'Free trial — %d days remaining', $days, 'wc-enterprise-erp' ) ),
								(int) $days
							);
							?>
						<?php elseif ( $active ) : ?>
							<?php
							echo $license['expires']
								? esc_html( sprintf( __( 'Licensed until %s', 'wc-enterprise-erp' ), mysql2date( 'j M Y', $license['expires'] ) ) )
								: esc_html__( 'Lifetime licence', 'wc-enterprise-erp' );
							?>
						<?php else : ?>
							<?php esc_html_e( 'No active licence', 'wc-enterprise-erp' ); ?>
							<?php
							/* Say why, not just that. "Invalid" with no reason
							 * is the difference between a customer fixing it
							 * themselves and a support call. */
							$why = WCEERP_License::get();
							if ( ! empty( $why['message'] ) ) {
								echo '<span class="reason">' . esc_html( $why['message'] ) . '</span>';
							}
							?>
						<?php endif; ?>
					</div>
				</div>
				<div class="right">
					<a class="wa" href="<?php echo esc_url( self::whatsapp_link() ); ?>" target="_blank" rel="noopener">
						<span class="ic">💬</span>
						<span>
							<strong><?php echo $trial || ! $active ? esc_html__( 'Upgrade now', 'wc-enterprise-erp' ) : esc_html__( 'Need help?', 'wc-enterprise-erp' ); ?></strong>
							<small><?php esc_html_e( 'Chat on WhatsApp', 'wc-enterprise-erp' ); ?></small>
						</span>
					</a>

				</div>
			</div>

			<?php if ( class_exists( 'WCEERP_Limits' ) && WCEERP_Limits::active() ) : ?>
				<h2><?php esc_html_e( 'Usage', 'wc-enterprise-erp' ); ?></h2>
				<div class="wceerp-usage">
					<?php foreach ( array( 'users', 'products', 'orders_month' ) as $resource ) :
						$limit = WCEERP_Limits::limit( $resource );
						$used  = WCEERP_Limits::usage( $resource );
						$label = WCEERP_Limits::LIMIT_LABELS[ $resource ];
						$pct   = $limit > 0 ? min( 100, round( 100 * $used / $limit ) ) : 0;
						$near  = $limit > 0 && $pct >= 80;
						?>
						<div class="wceerp-usage-item">
							<span><?php echo esc_html( $label ); ?></span>
							<strong><?php echo (int) $used; ?><?php echo $limit > 0 ? ' / ' . (int) $limit : ' <small>· ' . esc_html__( 'unlimited', 'wc-enterprise-erp' ) . '</small>'; ?></strong>
							<?php if ( $limit > 0 ) : ?>
								<div class="bar"><div style="width:<?php echo (int) $pct; ?>%;background:<?php echo $near ? '#c8302e' : '#2f8a4c'; ?>"></div></div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php
			// Group modules by the package that unlocks them, so a customer
			// sees "what I have" and "what the next step buys" rather than a
			// flat list they must decode.
			$groups = array(
				'starter'    => array( 'label' => __( 'Starter', 'wc-enterprise-erp' ), 'blurb' => __( 'Everything to run the shop', 'wc-enterprise-erp' ), 'items' => array() ),
				'business'   => array( 'label' => __( 'Business', 'wc-enterprise-erp' ), 'blurb' => __( 'Control &amp; automation', 'wc-enterprise-erp' ), 'items' => array() ),
				'enterprise' => array( 'label' => __( 'Enterprise', 'wc-enterprise-erp' ), 'blurb' => __( 'Scale &amp; multi-branch', 'wc-enterprise-erp' ), 'items' => array() ),
				'agency'     => array( 'label' => __( 'Agency add-on', 'wc-enterprise-erp' ), 'blurb' => __( 'For reselling the ERP', 'wc-enterprise-erp' ), 'items' => array() ),
			);
			foreach ( wceerp()->modules() as $id => $module ) {
				if ( in_array( $id, array( 'plan' ), true ) ) {
					continue;
				}
				$key = WCEERP_License::is_agency_module( $id ) ? 'agency' : $module->get_tier();
				if ( ! isset( $groups[ $key ] ) ) {
					$key = 'starter';
				}
				$groups[ $key ]['items'][] = array(
					'title' => $module->get_title(),
					'on'    => $module->is_active(),
				);
			}
			?>
			<?php
		$lic = WCEERP_License::get();
		if ( 'active' !== $lic['status'] && $lic['key'] ) :
			$last = WCEERP_License::last_check();
			?>
			<div class="wceerp-card" style="border-left-color:#C0392B">
				<h2><span class="dashicons dashicons-warning"></span><?php esc_html_e( 'Why this licence is not active', 'wc-enterprise-erp' ); ?></h2>
				<?php if ( $last ) : ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Licence server', 'wc-enterprise-erp' ); ?></th>
							<td><code style="word-break:break-all"><?php echo esc_html( $last['url'] ?? '' ); ?></code></td></tr>
						<tr><th><?php esc_html_e( 'Last checked', 'wc-enterprise-erp' ); ?></th>
							<td><?php echo esc_html( $last['at'] ?? '—' ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Result', 'wc-enterprise-erp' ); ?></th>
							<td>
								<?php if ( 0 === (int) ( $last['code'] ?? 0 ) ) : ?>
									<span class="wceerp-badge wceerp-badge-danger"><?php esc_html_e( 'could not reach the server', 'wc-enterprise-erp' ); ?></span>
									<p class="description"><?php echo esc_html( $last['error'] ?? '' ); ?></p>
									<p class="description"><?php esc_html_e( 'Your host is probably blocking outbound connections. This is not a problem with your key.', 'wc-enterprise-erp' ); ?></p>
								<?php else : ?>
									<code>HTTP <?php echo (int) $last['code']; ?></code>
									<pre style="white-space:pre-wrap;font-size:11.5px;background:#F6F5F8;padding:10px;border-radius:6px;margin:8px 0 0"><?php
										echo esc_html( $last['body'] ?? '' );
									?></pre>
								<?php endif; ?>
							</td></tr>
					</tbody></table>
				<?php else : ?>
					<p class="description"><?php esc_html_e( 'This site has not managed to contact the licence server yet.', 'wc-enterprise-erp' ); ?></p>
				<?php endif; ?>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'wceerp_recheck_licence' ); ?>
					<input type="hidden" name="action" value="wceerp_recheck_licence">
					<button class="button button-primary"><?php esc_html_e( 'Check again now', 'wc-enterprise-erp' ); ?></button>
					<span class="description" style="margin-left:8px"><?php esc_html_e( 'Forces an immediate check rather than waiting for the next twelve-hourly one.', 'wc-enterprise-erp' ); ?></span>
				</form>
			</div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Your package', 'wc-enterprise-erp' ); ?></h2>
			<?php foreach ( $groups as $key => $g ) :
				if ( ! $g['items'] ) {
					continue;
				}
				$on_count = count( array_filter( wp_list_pluck( $g['items'], 'on' ) ) );
				$all_on   = $on_count === count( $g['items'] );
				?>
				<div class="wceerp-pkg <?php echo $all_on ? 'is-on' : ( $on_count ? 'is-part' : 'is-off' ); ?>">
					<div class="wceerp-pkg-head">
						<div>
							<strong><?php echo esc_html( $g['label'] ); ?></strong>
							<span class="blurb"><?php echo wp_kses_post( $g['blurb'] ); ?></span>
						</div>
						<div class="state">
							<?php if ( $all_on ) : ?>
								<span class="badge on"><?php esc_html_e( 'Included', 'wc-enterprise-erp' ); ?></span>
							<?php elseif ( $on_count ) : ?>
								<span class="badge part"><?php echo esc_html( sprintf( __( '%1$d of %2$d', 'wc-enterprise-erp' ), $on_count, count( $g['items'] ) ) ); ?></span>
							<?php else : ?>
								<a class="badge off" href="<?php echo esc_url( self::whatsapp_link( sprintf( __( 'Hello, I would like to add the %s package to my WordPress ERP', 'wc-enterprise-erp' ), $g['label'] ) ) ); ?>" target="_blank" rel="noopener">
									<?php esc_html_e( 'Unlock →', 'wc-enterprise-erp' ); ?>
								</a>
							<?php endif; ?>
						</div>
					</div>
					<div class="wceerp-pkg-items">
						<?php foreach ( $g['items'] as $item ) : ?>
							<span class="pill <?php echo $item['on'] ? 'yes' : 'no'; ?>">
								<?php echo $item['on'] ? '✓' : '·'; ?> <?php echo esc_html( $item['title'] ); ?>
							</span>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>

			<?php $wa_saved = wceerp_get_option( 'contact_whatsapp', '' ); ?>
			<div class="wceerp-card" style="max-width:520px;margin-top:18px">
				<h2 style="margin-top:0"><?php esc_html_e( 'Your WhatsApp number', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Optional. Add it so we can reach you about your licence, renewals and support.', 'wc-enterprise-erp' ); ?></p>
				<?php if ( isset( $_GET['saved'] ) ) : ?>
					<div class="notice notice-success inline"><p><?php esc_html_e( 'Saved.', 'wc-enterprise-erp' ); ?></p></div>
				<?php endif; ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_plan_contact">
					<?php wp_nonce_field( 'wceerp_plan_contact' ); ?>
					<input type="text" name="whatsapp" class="regular-text" value="<?php echo esc_attr( $wa_saved ); ?>" placeholder="8801XXXXXXXXX">
					<?php submit_button( __( 'Save number', 'wc-enterprise-erp' ), 'secondary', 'submit', false ); ?>
				</form>
			</div>

			<?php if ( ! $active ) : ?>
				<div class="wceerp-plan-cta">
					<h2><?php esc_html_e( 'Keep your ERP running', 'wc-enterprise-erp' ); ?></h2>
					<p>
						<?php esc_html_e( 'Message us on WhatsApp with your domain and we will set up your licence. Your data stays exactly where it is.', 'wc-enterprise-erp' ); ?>
					</p>
					<a class="button button-primary button-hero" href="<?php echo esc_url( self::whatsapp_link() ); ?>" target="_blank" rel="noopener">
						💬 <?php esc_html_e( 'Chat on WhatsApp to upgrade', 'wc-enterprise-erp' ); ?>
					</a>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/** Force an immediate licence re-check. */
	public function handle_recheck() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_recheck_licence' );

		if ( class_exists( 'WCEERP_License' ) ) {
			WCEERP_License::revalidate();
		}
		wp_safe_redirect( $this->admin_url( array( 'rechecked' => 1 ) ) );
		exit;
	}

}
