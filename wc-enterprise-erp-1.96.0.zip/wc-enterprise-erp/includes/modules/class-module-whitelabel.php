<?php
/**
 * Module: White Label — agency mode.
 *
 * Everything a reseller needs to put their own name on the ERP:
 * brand name (menu + screen headers), logo, primary color (live CSS
 * override), custom login-page logo, "powered by" removal, and a
 * client documentation URL.
 *
 * Agency lock: define WCEERP_AGENCY_LOCK as true in wp-config.php and
 * this settings screen disappears for everyone — clients see only the
 * brand, never the knobs. Because it's a PHP constant, no admin
 * account on the client site can switch it back off.
 *
 * Reseller licensing: keys are minted per client site on your license
 * server (see the wceerp-license-server package) — white label changes
 * the paint, not the license mechanics.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Whitelabel extends WCEERP_Module {

	protected $id         = 'whitelabel';
	protected $title      = 'White Label';
	protected $capability = 'wceerp_manage_settings';
	protected $tier       = 'enterprise';
	protected $order      = 95;

	public function __construct() {
		$this->title = __( 'White Label', 'wc-enterprise-erp' );
	}

	public static function locked() {
		return defined( 'WCEERP_AGENCY_LOCK' ) && WCEERP_AGENCY_LOCK;
	}

	/** Brand name used across ERP screens (filterable everywhere). */
	public static function brand() {
		return wceerp_get_option( 'wl_brand_name', '' ) ?: 'WC Enterprise ERP';
	}

	public function init() {
		add_action( 'admin_post_wceerp_wl_save', array( $this, 'handle_save' ) );

		/* Apply branding everywhere, cheaply. */
		add_filter( 'wceerp_brand', array( __CLASS__, 'brand' ) );
		add_action( 'admin_head', array( __CLASS__, 'admin_css' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'login_logo' ) );
		add_action( 'admin_menu', array( __CLASS__, 'rebrand_menu' ), 99 );
	}

	/** Rename the top-level ERP menu after it's registered. */
	public static function rebrand_menu() {
		global $menu;
		$label = wceerp_get_option( 'wl_menu_label', '' );
		if ( ! $label || ! is_array( $menu ) ) {
			return;
		}
		foreach ( $menu as $index => $item ) {
			if ( isset( $item[2] ) && 'wceerp-dashboard' === $item[2] ) {
				$menu[ $index ][0] = esc_html( $label ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
				break;
			}
		}
	}

	/** Primary color override via CSS variables + logo in ERP headers. */
	public static function admin_css() {
		$color = wceerp_hex_colour( wceerp_get_option( 'wl_primary_color', '' ) );
		$logo  = esc_url( wceerp_get_option( 'wl_logo_url', '' ) );
		if ( ! $color && ! $logo ) {
			return;
		}
		echo '<style id="wceerp-wl">';
		if ( $color ) {
			printf(
				'.wceerp-wrap .button-primary{background:%1$s;border-color:%1$s}
				 .wceerp-kpi strong, .wceerp-lead-card span{color:%1$s}
				 .wceerp-wrap .nav-tab-active{border-bottom-color:%1$s}',
				esc_html( $color )
			);
		}
		if ( $logo ) {
			printf(
				'.wceerp-wrap h1::before{content:"";display:inline-block;vertical-align:middle;margin-right:10px;width:28px;height:28px;background:url(%s) center/contain no-repeat}',
				esc_url( $logo )
			);
		}
		echo '</style>';
	}

	public static function login_logo() {
		$logo = esc_url( wceerp_get_option( 'wl_login_logo_url', '' ) );
		if ( ! $logo ) {
			return;
		}
		printf(
			'<style>#login h1 a{background-image:url(%s);background-size:contain;width:220px;height:70px}</style>',
			esc_url( $logo )
		);
	}

	/** Whether "powered by" style credits should render. */
	public static function show_credits() {
		return 'yes' !== wceerp_get_option( 'wl_hide_branding', 'no' );
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_wl_save' );
		if ( self::locked() ) {
			wp_die( esc_html__( 'White label settings are locked by the agency (WCEERP_AGENCY_LOCK).', 'wc-enterprise-erp' ) );
		}
		wceerp_update_option( 'wl_brand_name', sanitize_text_field( wp_unslash( $_POST['brand_name'] ?? '' ) ) );
		wceerp_update_option( 'wl_menu_label', sanitize_text_field( wp_unslash( $_POST['menu_label'] ?? '' ) ) );
		wceerp_update_option( 'wl_logo_url', esc_url_raw( wp_unslash( $_POST['logo_url'] ?? '' ) ) );
		wceerp_update_option( 'wl_login_logo_url', esc_url_raw( wp_unslash( $_POST['login_logo_url'] ?? '' ) ) );
		wceerp_update_option( 'wl_primary_color', wceerp_hex_colour( wp_unslash( $_POST['primary_color'] ?? '' ) ) ?: '' );
		wceerp_update_option( 'wl_docs_url', esc_url_raw( wp_unslash( $_POST['docs_url'] ?? '' ) ) );
		wceerp_update_option( 'wl_hide_branding', empty( $_POST['hide_branding'] ) ? 'no' : 'yes' );
		wceerp_log( 'whitelabel', 'save' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'White Label', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved — reload to see the new paint.', 'wc-enterprise-erp' ) ); } ?>

			<?php if ( self::locked() ) : ?>
				<div class="wceerp-card" style="max-width:640px">
					<p><strong><?php esc_html_e( 'Locked by the agency.', 'wc-enterprise-erp' ); ?></strong>
					<?php esc_html_e( 'Branding is fixed via the WCEERP_AGENCY_LOCK constant in wp-config.php and cannot be changed from the dashboard.', 'wc-enterprise-erp' ); ?></p>
				</div>
				<?php return; ?>
			<?php endif; ?>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Branding', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_wl_save">
						<?php wp_nonce_field( 'wceerp_wl_save' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Brand name', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="brand_name" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'wl_brand_name', '' ) ); ?>" placeholder="WC Enterprise ERP">
								<p class="description"><?php esc_html_e( 'Shown wherever the product refers to itself.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Admin menu label', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="menu_label" value="<?php echo esc_attr( wceerp_get_option( 'wl_menu_label', '' ) ); ?>" placeholder="ERP"></td></tr>
							<tr><th><?php esc_html_e( 'Logo URL (28px square works best)', 'wc-enterprise-erp' ); ?></th>
								<td><input type="url" name="logo_url" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'wl_logo_url', '' ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Login page logo URL', 'wc-enterprise-erp' ); ?></th>
								<td><input type="url" name="login_logo_url" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'wl_login_logo_url', '' ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Primary color', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="primary_color" value="<?php echo esc_attr( wceerp_get_option( 'wl_primary_color', '' ) ); ?>" placeholder="#075742" pattern="#?[0-9a-fA-F]{6}"></td></tr>
							<tr><th><?php esc_html_e( 'Client documentation URL', 'wc-enterprise-erp' ); ?></th>
								<td><input type="url" name="docs_url" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'wl_docs_url', '' ) ); ?>" placeholder="https://youragency.com/erp-docs"></td></tr>
							<tr><th><?php esc_html_e( 'Hide original branding', 'wc-enterprise-erp' ); ?></th>
								<td><label><input type="checkbox" name="hide_branding" value="1" <?php checked( wceerp_get_option( 'wl_hide_branding', 'no' ), 'yes' ); ?>> <?php esc_html_e( 'Remove "powered by" credits from ERP screens', 'wc-enterprise-erp' ); ?></label></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Save branding', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'For agencies', 'wc-enterprise-erp' ); ?></h2>
					<p><?php esc_html_e( 'Deploying for clients:', 'wc-enterprise-erp' ); ?></p>
					<ol style="line-height:1.9">
						<li><?php esc_html_e( 'Set the branding here, then add to the client\'s wp-config.php:', 'wc-enterprise-erp' ); ?>
							<br><code>define( 'WCEERP_AGENCY_LOCK', true );</code>
							<br><small><?php esc_html_e( 'This screen vanishes for everyone — the paint can\'t be peeled from the dashboard.', 'wc-enterprise-erp' ); ?></small></li>
						<li><?php esc_html_e( 'Issue the client a license key from your license server; the key is validated per site domain.', 'wc-enterprise-erp' ); ?></li>
						<li><?php esc_html_e( 'Point "Client documentation URL" at your own help pages so support requests come to you.', 'wc-enterprise-erp' ); ?></li>
					</ol>
					<p class="description"><?php esc_html_e( 'Scope, honestly: white label re-brands the product surface (name, logos, colors, menu, login, credits). It does not rename database tables, hooks or file paths — a developer viewing source will always be able to identify the underlying engine, as with every white-label WordPress product.', 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}
}
