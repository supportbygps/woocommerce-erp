<?php
/**
 * Bulk messaging screen.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Messaging extends WCEERP_Module {

	protected $id         = 'messaging';
	protected $title      = 'SMS & WhatsApp';
	protected $capability = 'wceerp_manage_crm';
	protected $tier       = 'business';

	public function __construct() {
		$this->title = __( 'SMS & WhatsApp', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_msg_send', array( $this, 'handle_send' ) );
		add_action( 'admin_post_wceerp_msg_settings', array( $this, 'handle_settings' ) );
		add_action( 'admin_post_wceerp_msg_auto', array( $this, 'handle_auto' ) );
		add_action( 'admin_post_wceerp_msg_optout', array( $this, 'handle_optout' ) );
		add_action( 'wp_ajax_wceerp_msg_count', array( $this, 'ajax_count' ) );
	}

	/* ------------------------------------------------------------------
	 * Handlers
	 * ---------------------------------------------------------------- */

	public function ajax_count() {
		if ( ! wceerp_user_can( $this->capability ) ) {
			wp_send_json_error( array(), 403 );
		}
		check_ajax_referer( 'wceerp_msg_count', 'nonce' );

		$audience = sanitize_key( $_GET['audience'] ?? 'recent' );
		$channel  = sanitize_key( $_GET['channel'] ?? 'sms' );
		$list     = WCEERP_Messaging::recipients( $audience, $channel );

		wp_send_json_success( array( 'count' => count( $list ) ) );
	}

	public function handle_send() {
		$this->verify_nonce( 'wceerp_msg_send' );

		$result = WCEERP_Messaging::create_campaign( array(
			'name'     => wp_unslash( $_POST['name'] ?? '' ),
			'channel'  => sanitize_key( $_POST['channel'] ?? 'sms' ),
			'body'     => wp_unslash( $_POST['body'] ?? '' ),
			'template' => wp_unslash( $_POST['template'] ?? '' ),
			'audience' => sanitize_key( $_POST['audience'] ?? 'recent' ),
		) );

		if ( is_wp_error( $result ) ) {
			set_transient( 'wceerp_msg_err_' . get_current_user_id(), $result->get_error_message(), 60 );
			wp_safe_redirect( $this->admin_url( array( 'failed' => 1 ) ) );
			exit;
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'history', 'queued' => 1 ) ) );
		exit;
	}

	public function handle_auto() {
		$this->verify_nonce( 'wceerp_msg_auto' );

		foreach ( array_keys( WCEERP_Messaging::events() ) as $event ) {
			wceerp_update_option( 'msg_evt_' . $event, empty( $_POST[ 'evt_' . $event ] ) ? '' : '1' );
			wceerp_update_option( 'msg_tpl_' . $event, sanitize_textarea_field( wp_unslash( $_POST[ 'tpl_' . $event ] ?? '' ) ) );
		}
		wceerp_log( 'messaging', 'auto_saved' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'auto', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_msg_settings' );

		$plain = array( 'sms_url', 'sms_sender', 'sms_method', 'sms_field_key', 'sms_field_to', 'sms_field_text', 'sms_field_sender', 'wa_phone_id', 'wa_version', 'wa_lang' );
		foreach ( $plain as $k ) {
			wceerp_update_option( 'msg_' . $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) ) );
		}
		// Secrets are stored verbatim; sanitize_text_field would corrupt any
		// token containing < > or %.
		foreach ( array( 'sms_api_key', 'wa_token' ) as $k ) {
			wceerp_update_option( 'msg_' . $k, trim( (string) wp_unslash( $_POST[ $k ] ?? '' ) ) );
		}
		wceerp_update_option( 'msg_sms_intl', empty( $_POST['sms_intl'] ) ? '' : '1' );

		wceerp_log( 'messaging', 'settings_saved' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'settings', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_optout() {
		$this->verify_nonce( 'wceerp_msg_optout' );
		$raw = wp_unslash( $_POST['numbers'] ?? '' );
		$n   = 0;
		foreach ( preg_split( '/[\s,;]+/', (string) $raw ) as $phone ) {
			if ( trim( $phone ) && WCEERP_Messaging::opt_out( $phone, 'all', 'Added by staff' ) ) {
				$n++;
			}
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'optout', 'added' => $n ) ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * Screen
	 * ---------------------------------------------------------------- */

	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'compose';
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'SMS & WhatsApp', 'wc-enterprise-erp' ) ) ); ?></h1>

			<?php if ( isset( $_GET['queued'] ) ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Campaign queued. Messages go out in the background — this page shows progress.', 'wc-enterprise-erp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['updated'] ) ) : ?>
				<div class="notice notice-success"><p><?php esc_html_e( 'Saved.', 'wc-enterprise-erp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['added'] ) ) : ?>
				<div class="notice notice-success"><p><?php printf( esc_html__( '%d number(s) added to the do-not-message list.', 'wc-enterprise-erp' ), (int) $_GET['added'] ); ?></p></div>
			<?php endif; ?>
			<?php
			if ( isset( $_GET['failed'] ) ) {
				$err = get_transient( 'wceerp_msg_err_' . get_current_user_id() );
				delete_transient( 'wceerp_msg_err_' . get_current_user_id() );
				printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( $err ? $err : __( 'Could not queue the campaign.', 'wc-enterprise-erp' ) ) );
			}
			?>

			<nav class="nav-tab-wrapper">
				<?php
				foreach ( array(
					'compose'  => __( 'Compose', 'wc-enterprise-erp' ),
					'history'  => __( 'Campaigns', 'wc-enterprise-erp' ),
					'auto'     => __( 'Automatic messages', 'wc-enterprise-erp' ),
					'optout'   => __( 'Do not message', 'wc-enterprise-erp' ),
					'settings' => __( 'Gateway settings', 'wc-enterprise-erp' ),
				) as $key => $label ) {
					printf(
						'<a class="nav-tab %s" href="%s">%s</a>',
						$tab === $key ? 'nav-tab-active' : '',
						esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php
			if ( 'auto' === $tab )          { $this->tab_auto(); }
			elseif ( 'history' === $tab )   { $this->tab_history(); }
			elseif ( 'optout' === $tab )    { $this->tab_optout(); }
			elseif ( 'settings' === $tab )  { $this->tab_settings(); }
			else                            { $this->tab_compose(); }
			?>
		</div>
		<?php
	}

	protected function tab_compose() {
		$sms_ok = WCEERP_Messaging::sms_ready();
		$wa_ok  = WCEERP_Messaging::wa_ready();
		?>
		<?php if ( ! $sms_ok && ! $wa_ok ) : ?>
			<div class="notice notice-warning"><p>
				<strong><?php esc_html_e( 'No gateway is set up yet.', 'wc-enterprise-erp' ); ?></strong>
				<?php esc_html_e( 'Add your SMS or WhatsApp details under Gateway settings before sending.', 'wc-enterprise-erp' ); ?>
			</p></div>
		<?php endif; ?>

		<?php
		$left  = WCEERP_Messaging::remaining();
		$quota = WCEERP_Messaging::monthly_quota();
		if ( $quota > 0 ) {
			$pct = $left / max( 1, $quota + WCEERP_Messaging::extra_balance() );
			printf(
				'<div class="notice notice-%s"><p>%s</p></div>',
				$pct < 0.15 ? 'error' : ( $pct < 0.4 ? 'warning' : 'info' ),
				esc_html( WCEERP_Messaging::allowance_text() )
			);
		}
		?>

		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'New message', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Messages are queued and sent in the background, so you can close this page.', 'wc-enterprise-erp' ); ?></p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wceerp-msg-form">
					<?php wp_nonce_field( 'wceerp_msg_send' ); ?>
					<input type="hidden" name="action" value="wceerp_msg_send">

					<table class="form-table"><tbody>
						<tr>
							<th><?php esc_html_e( 'Send by', 'wc-enterprise-erp' ); ?></th>
							<td>
								<div class="wceerp-choices">
									<label class="wceerp-choice is-on">
										<input type="radio" name="channel" value="sms" checked <?php disabled( ! $sms_ok ); ?>>
										<span><b><?php esc_html_e( 'SMS', 'wc-enterprise-erp' ); ?></b>
										<span class="wceerp-choice-desc"><?php echo $sms_ok ? esc_html__( 'Any message you like. Charged per segment.', 'wc-enterprise-erp' ) : esc_html__( 'Gateway not configured.', 'wc-enterprise-erp' ); ?></span></span>
									</label>
									<label class="wceerp-choice">
										<input type="radio" name="channel" value="whatsapp" <?php disabled( ! $wa_ok ); ?>>
										<span><b><?php esc_html_e( 'WhatsApp', 'wc-enterprise-erp' ); ?></b>
										<span class="wceerp-choice-desc"><?php echo $wa_ok ? esc_html__( 'Requires a template Meta has approved.', 'wc-enterprise-erp' ) : esc_html__( 'Cloud API not configured.', 'wc-enterprise-erp' ); ?></span></span>
									</label>
								</div>
							</td>
						</tr>

						<tr>
							<th><?php esc_html_e( 'Send to', 'wc-enterprise-erp' ); ?></th>
							<td>
								<select name="audience" id="wceerp-aud" style="max-width:320px">
									<?php foreach ( WCEERP_Messaging::audiences() as $k => $label ) : ?>
										<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description">
									<span id="wceerp-count"><?php esc_html_e( 'Counting recipients…', 'wc-enterprise-erp' ); ?></span>
									<br><?php esc_html_e( 'Duplicates and anyone on the do-not-message list are removed automatically.', 'wc-enterprise-erp' ); ?>
								</p>
							</td>
						</tr>

						<tr class="wceerp-sms-only">
							<th><?php esc_html_e( 'Message', 'wc-enterprise-erp' ); ?></th>
							<td>
								<textarea name="body" id="wceerp-body" rows="5" class="large-text" style="max-width:520px" placeholder="<?php esc_attr_e( 'Hello {first}, fresh ghee is back in stock at {shop}.', 'wc-enterprise-erp' ); ?>"></textarea>
								<p class="description">
									<?php esc_html_e( 'Merge fields:', 'wc-enterprise-erp' ); ?>
									<?php foreach ( WCEERP_Messaging::merge_fields() as $tag => $desc ) : ?>
										<code><?php echo esc_html( $tag ); ?></code>
									<?php endforeach; ?>
									<br><strong id="wceerp-seg"></strong>
								</p>
							</td>
						</tr>

						<tr class="wceerp-wa-only" style="display:none">
							<th><?php esc_html_e( 'Template name', 'wc-enterprise-erp' ); ?></th>
							<td>
								<input type="text" name="template" class="regular-text" placeholder="order_update_v1">
								<p class="description">
									<?php esc_html_e( 'The exact name of a template approved in your Meta Business account. WhatsApp does not allow free text for bulk sending — the customer\'s name is passed as the template\'s first variable.', 'wc-enterprise-erp' ); ?>
								</p>
							</td>
						</tr>

						<tr>
							<th><?php esc_html_e( 'Campaign name', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="name" class="regular-text" placeholder="<?php esc_attr_e( 'Eid offer — ghee', 'wc-enterprise-erp' ); ?>">
								<p class="description"><?php esc_html_e( 'For your own records only. Customers never see it.', 'wc-enterprise-erp' ); ?></p></td>
						</tr>
					</tbody></table>

					<p>
						<button class="button button-primary" onclick="return confirm('<?php echo esc_js( __( 'Queue this campaign? Messages start going out within a minute and cannot be recalled once sent.', 'wc-enterprise-erp' ) ); ?>');">
							<?php esc_html_e( 'Queue campaign', 'wc-enterprise-erp' ); ?>
						</button>
					</p>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Before you send', 'wc-enterprise-erp' ); ?></h2>
				<p class="description" style="margin-bottom:10px"><?php esc_html_e( 'Bulk messaging is easy to get wrong in ways that cost money or a phone number.', 'wc-enterprise-erp' ); ?></p>
				<ul style="margin:0 0 4px 18px;list-style:disc;font-size:12.5px;line-height:1.7;color:#5B6675">
					<li><strong><?php esc_html_e( 'Bengali text costs more.', 'wc-enterprise-erp' ); ?></strong> <?php esc_html_e( 'A Bengali SMS fits 70 characters per segment instead of 160, so the same message can cost several times as much. The count updates as you type.', 'wc-enterprise-erp' ); ?></li>
					<li><strong><?php esc_html_e( 'WhatsApp needs opt-in and approved templates.', 'wc-enterprise-erp' ); ?></strong> <?php esc_html_e( 'Sending marketing to people who did not agree gets the number blocked, and it is usually the shop\'s main number.', 'wc-enterprise-erp' ); ?></li>
					<li><strong><?php esc_html_e( 'Honour opt-outs.', 'wc-enterprise-erp' ); ?></strong> <?php esc_html_e( 'Add anyone who asks to stop under "Do not message". They are excluded from every future campaign automatically.', 'wc-enterprise-erp' ); ?></li>
					<li><strong><?php esc_html_e( 'Send at a sensible hour.', 'wc-enterprise-erp' ); ?></strong> <?php esc_html_e( 'A queued campaign starts immediately.', 'wc-enterprise-erp' ); ?></li>
				</ul>
			</div>
		</div>

		<script>
		(function () {
			var nonce = <?php echo wp_json_encode( wp_create_nonce( 'wceerp_msg_count' ) ); ?>;
			var ajax  = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			var body  = document.getElementById( 'wceerp-body' );
			var seg   = document.getElementById( 'wceerp-seg' );
			var aud   = document.getElementById( 'wceerp-aud' );
			var out   = document.getElementById( 'wceerp-count' );
			var recipients = 0;

			function channel() {
				var r = document.querySelector( 'input[name=channel]:checked' );
				return r ? r.value : 'sms';
			}

			/* Segment maths mirrors the server: Bengali forces UCS-2, which
			   cuts a segment from 160 characters to 70. */
			function segments( t ) {
				var len = t.length;
				if ( ! len ) { return 0; }
				var uni = /[^\u0000-\u007F]/.test( t );
				var one = uni ? 70 : 160, many = uni ? 67 : 153;
				return len <= one ? 1 : Math.ceil( len / many );
			}

			function updateSeg() {
				if ( ! body || ! seg ) { return; }
				var t = body.value, n = segments( t ), uni = /[^\u0000-\u007F]/.test( t );
				var total = n * recipients;
				seg.textContent = t.length + ' characters · ' + n + ' SMS part' + ( 1 === n ? '' : 's' ) +
					( uni ? ' (Bengali — 70 per part)' : '' ) +
					( recipients ? ' · about ' + total.toLocaleString() + ' messages in total' : '' );
			}

			function updateCount() {
				if ( ! out ) { return; }
				out.textContent = <?php echo wp_json_encode( __( 'Counting recipients…', 'wc-enterprise-erp' ) ); ?>;
				fetch( ajax + '?action=wceerp_msg_count&nonce=' + encodeURIComponent( nonce ) +
					'&audience=' + encodeURIComponent( aud.value ) + '&channel=' + encodeURIComponent( channel() ),
					{ credentials: 'same-origin' } )
					.then( function ( r ) { return r.json(); } )
					.then( function ( j ) {
						recipients = ( j && j.data && j.data.count ) || 0;
						out.innerHTML = '<strong>' + recipients.toLocaleString() + '</strong> ' +
							<?php echo wp_json_encode( __( 'people will receive this', 'wc-enterprise-erp' ) ); ?>;
						updateSeg();
					} )
					.catch( function () { out.textContent = <?php echo wp_json_encode( __( 'Could not count recipients.', 'wc-enterprise-erp' ) ); ?>; } );
			}

			document.querySelectorAll( 'input[name=channel]' ).forEach( function ( r ) {
				r.addEventListener( 'change', function () {
					var wa = 'whatsapp' === channel();
					document.querySelectorAll( '.wceerp-wa-only' ).forEach( function ( e ) { e.style.display = wa ? '' : 'none'; } );
					document.querySelectorAll( '.wceerp-sms-only' ).forEach( function ( e ) { e.style.display = wa ? 'none' : ''; } );
					document.querySelectorAll( '.wceerp-choice input[type=radio]' ).forEach( function ( o ) {
						o.closest( '.wceerp-choice' ).classList.toggle( 'is-on', o.checked );
					} );
					updateCount();
				} );
			} );
			if ( body ) { body.addEventListener( 'input', updateSeg ); }
			if ( aud ) { aud.addEventListener( 'change', updateCount ); }
			updateCount();
		})();
		</script>
		<?php
	}

	protected function tab_history() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'campaigns' ) . ' ORDER BY id DESC LIMIT 100' );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Campaign', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Channel', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Audience', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Recipients', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Sent', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Failed', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No campaigns yet.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php
			$auds = WCEERP_Messaging::audiences();
			foreach ( (array) $rows as $c ) :
				$pending = max( 0, (int) $c->total - (int) $c->sent - (int) $c->failed );
				?>
				<tr>
					<td><strong><?php echo esc_html( $c->name ); ?></strong>
						<span class="wceerp-sub"><?php echo esc_html( $c->created_at ); ?></span>
						<?php if ( $c->body ) : ?><span class="wceerp-sub"><?php echo esc_html( mb_substr( $c->body, 0, 70 ) ); ?></span><?php endif; ?>
					</td>
					<td><?php echo 'whatsapp' === $c->channel ? 'WhatsApp' : 'SMS'; ?></td>
					<td><small><?php echo esc_html( $auds[ $c->audience ] ?? $c->audience ); ?></small></td>
					<td class="num"><?php echo (int) $c->total; ?></td>
					<td class="num"><?php echo (int) $c->sent; ?></td>
					<td class="num"><?php echo (int) $c->failed ? '<span class="wceerp-due">' . (int) $c->failed . '</span>' : '<span class="wceerp-muted">0</span>'; ?></td>
					<td>
						<?php if ( 'done' === $c->status ) : ?>
							<span class="wceerp-badge wceerp-badge-ok"><?php esc_html_e( 'Finished', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-badge wceerp-badge-warn"><?php printf( esc_html__( 'Sending — %d left', 'wc-enterprise-erp' ), (int) $pending ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Queued messages are sent in small batches in the background. Leaving this page does not stop them.', 'wc-enterprise-erp' ); ?></p>
		<?php
	}

	protected function tab_auto() {
		$events = WCEERP_Messaging::events();
		$ready  = WCEERP_Messaging::sms_ready();
		?>
		<?php if ( ! $ready ) : ?>
			<div class="notice notice-warning"><p>
				<strong><?php esc_html_e( 'No SMS gateway configured.', 'wc-enterprise-erp' ); ?></strong>
				<?php esc_html_e( 'Automatic messages stay silent until one is set up under Gateway settings.', 'wc-enterprise-erp' ); ?>
			</p></div>
		<?php endif; ?>

		<div class="wceerp-card">
			<h2><span class="dashicons dashicons-megaphone"></span><?php esc_html_e( 'Automatic messages', 'wc-enterprise-erp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Sent to the customer by themselves when something happens to their parcel. Each one goes out once only — re-syncing a delivered parcel will not message anyone twice.', 'wc-enterprise-erp' ); ?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'wceerp_msg_auto' ); ?>
				<input type="hidden" name="action" value="wceerp_msg_auto">

				<?php foreach ( $events as $key => $event ) : ?>
					<?php $tpl = WCEERP_Messaging::event_template( $key ); ?>
					<div style="border:1px solid var(--wceerp-rule,#E3E0E8);border-radius:8px;padding:14px 16px;margin-bottom:14px">
						<label class="wceerp-switch" style="margin-bottom:10px">
							<input type="checkbox" name="evt_<?php echo esc_attr( $key ); ?>" value="1"
								<?php checked( WCEERP_Messaging::event_enabled( $key ) ); ?>>
							<span class="wceerp-track"></span>
							<span style="font-weight:600"><?php echo esc_html( $event['label'] ); ?></span>
						</label>
						<textarea name="tpl_<?php echo esc_attr( $key ); ?>" rows="3" class="large-text wceerp-tpl"
							data-for="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $tpl ); ?></textarea>
						<p class="description" id="seg-<?php echo esc_attr( $key ); ?>"></p>
					</div>
				<?php endforeach; ?>

				<p class="description" style="margin-bottom:14px">
					<strong><?php esc_html_e( 'Available fields:', 'wc-enterprise-erp' ); ?></strong>
					<code>{name}</code> <code>{first}</code> <code>{shop}</code>
					<code>{courier}</code> <code>{tracking}</code> <code>{cn}</code>
					<code>{order}</code> <code>{cod}</code>
				</p>

				<?php submit_button( __( 'Save automatic messages', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>

		<script>
		(function () {
			/* Same segment maths as the composer: Bengali forces UCS-2 and
			   cuts a part from 160 characters to 70, so a template that
			   looks short can cost three times what the shop expects. */
			function segs( t ) {
				var len = t.length;
				if ( ! len ) { return { n: 0, uni: false, len: 0 }; }
				var uni = /[^\u0000-\u007F]/.test( t );
				var one = uni ? 70 : 160, many = uni ? 67 : 153;
				return { n: len <= one ? 1 : Math.ceil( len / many ), uni: uni, len: len };
			}
			function update( ta ) {
				var out = document.getElementById( 'seg-' + ta.dataset.for );
				if ( ! out ) { return; }
				/* Merge fields expand, so estimate with realistic values
				   rather than counting the placeholders. */
				var sample = ta.value
					.replace( /\{name\}|\{first\}/g, 'Md. Abul Hossain' )
					.replace( /\{shop\}/g, 'Pabna Dairy Limited' )
					.replace( /\{courier\}/g, 'Steadfast' )
					.replace( /\{tracking\}|\{cn\}/g, 'PDL-2026-7-0001' )
					.replace( /\{order\}/g, '#23823' )
					.replace( /\{cod\}/g, 'BDT 1,500.00' );
				var s = segs( sample );
				out.textContent = s.len + ' characters when filled in · ' + s.n + ' SMS part' +
					( 1 === s.n ? '' : 's' ) + ( s.uni ? ' (Bengali — 70 per part)' : '' );
			}
			document.querySelectorAll( '.wceerp-tpl' ).forEach( function ( ta ) {
				ta.addEventListener( 'input', function () { update( ta ); } );
				update( ta );
			} );
		})();
		</script>
		<?php
	}

	protected function tab_optout() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'message_optouts' ) . ' ORDER BY id DESC LIMIT 200' );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Do not message', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Numbers here are excluded from every campaign automatically. Add anyone who asks you to stop.', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'wceerp_msg_optout' ); ?>
					<input type="hidden" name="action" value="wceerp_msg_optout">
					<textarea name="numbers" rows="4" class="large-text" placeholder="01711120544, 01812345678"></textarea>
					<p class="description"><?php esc_html_e( 'One per line, or separated by commas.', 'wc-enterprise-erp' ); ?></p>
					<?php submit_button( __( 'Add to list', 'wc-enterprise-erp' ), 'secondary' ); ?>
				</form>
			</div>
			<div class="wceerp-card">
				<h2><?php printf( esc_html__( '%d number(s) on the list', 'wc-enterprise-erp' ), count( (array) $rows ) ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Number', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Added', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="2"><?php esc_html_e( 'Nobody has opted out.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $r ) : ?>
						<tr><td><code><?php echo esc_html( $r->phone ); ?></code></td>
							<td><small><?php echo esc_html( $r->created_at ); ?><?php echo $r->reason ? ' · ' . esc_html( $r->reason ) : ''; ?></small></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_settings() {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'wceerp_msg_settings' ); ?>
			<input type="hidden" name="action" value="wceerp_msg_settings">

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'SMS gateway', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Works with any provider that accepts a plain HTTP request — BulkSMSBD, Elitbuzz, MIM, Reve, SSL Wireless and most others. Copy the field names from your provider\'s API page.', 'wc-enterprise-erp' ); ?></p>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'API URL', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="sms_url" class="regular-text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_url' ) ); ?>" placeholder="http://bulksmsbd.net/api/smsapi"></td></tr>
					<tr><th><?php esc_html_e( 'API key', 'wc-enterprise-erp' ); ?></th>
						<td><input type="password" name="sms_api_key" class="regular-text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_api_key' ) ); ?>" autocomplete="new-password"></td></tr>
					<tr><th><?php esc_html_e( 'Sender ID', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="sms_sender" class="regular-text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_sender' ) ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Request method', 'wc-enterprise-erp' ); ?></th>
						<td><select name="sms_method">
							<?php foreach ( array( 'GET', 'POST' ) as $m ) : ?>
								<option value="<?php echo esc_attr( $m ); ?>" <?php selected( WCEERP_Messaging::setting( 'sms_method', 'GET' ), $m ); ?>><?php echo esc_html( $m ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Field names', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label style="display:inline-block;margin:0 12px 6px 0"><?php esc_html_e( 'API key', 'wc-enterprise-erp' ); ?><br>
								<input type="text" name="sms_field_key" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_field_key', 'api_key' ) ); ?>" style="width:130px"></label>
							<label style="display:inline-block;margin:0 12px 6px 0"><?php esc_html_e( 'Number', 'wc-enterprise-erp' ); ?><br>
								<input type="text" name="sms_field_to" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_field_to', 'msisdn' ) ); ?>" style="width:130px"></label>
							<label style="display:inline-block;margin:0 12px 6px 0"><?php esc_html_e( 'Message', 'wc-enterprise-erp' ); ?><br>
								<input type="text" name="sms_field_text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_field_text', 'sms' ) ); ?>" style="width:130px"></label>
							<label style="display:inline-block;margin:0 12px 6px 0"><?php esc_html_e( 'Sender', 'wc-enterprise-erp' ); ?><br>
								<input type="text" name="sms_field_sender" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'sms_field_sender', 'senderid' ) ); ?>" style="width:130px"></label>
							<p class="description"><?php esc_html_e( 'These are the parameter names your gateway expects, not the values.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Number format', 'wc-enterprise-erp' ); ?></th>
						<td><label class="wceerp-switch">
							<input type="checkbox" name="sms_intl" value="1" <?php checked( WCEERP_Messaging::setting( 'sms_intl' ), '1' ); ?>>
							<span class="wceerp-track"></span>
							<span><?php esc_html_e( 'Send as 8801XXXXXXXXX instead of 01XXXXXXXXX', 'wc-enterprise-erp' ); ?></span>
						</label></td></tr>
				</tbody></table>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'WhatsApp Cloud API', 'wc-enterprise-erp' ); ?></h2>
				<div class="notice notice-warning inline" style="margin:0 0 14px">
					<p><strong><?php esc_html_e( 'WhatsApp only permits bulk sending through Meta\'s official API.', 'wc-enterprise-erp' ); ?></strong>
					<?php esc_html_e( 'Messages must use a template Meta approved in advance, and go only to people who agreed to be contacted. Tools that automate a normal WhatsApp account breach Meta\'s terms and get the number banned permanently.', 'wc-enterprise-erp' ); ?></p>
				</div>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Phone number ID', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="wa_phone_id" class="regular-text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'wa_phone_id' ) ); ?>">
						<p class="description"><?php esc_html_e( 'From Meta Business → WhatsApp → API setup.', 'wc-enterprise-erp' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'Access token', 'wc-enterprise-erp' ); ?></th>
						<td><input type="password" name="wa_token" class="regular-text" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'wa_token' ) ); ?>" autocomplete="new-password">
						<p class="description"><?php esc_html_e( 'Use a permanent system-user token. A temporary one stops working after 24 hours.', 'wc-enterprise-erp' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'Template language', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="wa_lang" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'wa_lang', 'en' ) ); ?>" style="width:100px" placeholder="en">
						<p class="description"><?php esc_html_e( 'Must match the language of the approved template, e.g. en or bn.', 'wc-enterprise-erp' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'API version', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="wa_version" value="<?php echo esc_attr( WCEERP_Messaging::setting( 'wa_version', 'v21.0' ) ); ?>" style="width:100px"></td></tr>
				</tbody></table>
			</div>

			<?php submit_button( __( 'Save gateway settings', 'wc-enterprise-erp' ) ); ?>
		</form>
		<?php
	}
}
