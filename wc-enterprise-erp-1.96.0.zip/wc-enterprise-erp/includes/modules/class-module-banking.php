<?php
/**
 * Module: Bank Reconciliation.
 *
 * Import a bank/bKash statement (CSV), then match each statement line to
 * a posted journal line on the same ledger account. Auto-match pairs
 * identical amounts within a 7-day window; anything else is matched by
 * hand. The report shows book balance vs statement and what's outstanding
 * on each side.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Banking extends WCEERP_Module {

	protected $id         = 'banking';
	protected $title      = 'Bank Reconciliation';
	protected $capability = 'wceerp_manage_accounting';
	protected $tier       = 'business';
	protected $order      = 37;

	public function __construct() {
		$this->title = __( 'Bank Reconciliation', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_bank_import', array( $this, 'handle_import' ) );
		add_action( 'admin_post_wceerp_bank_automatch', array( $this, 'handle_automatch' ) );
		add_action( 'admin_post_wceerp_bank_match', array( $this, 'handle_match' ) );
	}

	protected function bank_accounts() {
		global $wpdb;
		return $wpdb->get_results(
			'SELECT id, code, name FROM ' . wceerp_table( 'accounts' ) . " WHERE subtype IN ('bank','mobile_banking','cash') AND status='active' ORDER BY code"
		);
	}

	/* ---------------------------------------------------------------------
	 * Import.
	 * ------------------------------------------------------------------- */

	public function handle_import() {
		$this->verify_nonce( 'wceerp_bank_import' );
		global $wpdb;

		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		if ( ! $account_id || empty( $_FILES['csv']['tmp_name'] ) ) {
			wp_die( esc_html__( 'Choose an account and a CSV file.', 'wc-enterprise-erp' ) );
		}

		$handle = fopen( $_FILES['csv']['tmp_name'], 'r' ); // phpcs:ignore
		if ( ! $handle ) {
			wp_die( esc_html__( 'Could not read the uploaded file.', 'wc-enterprise-erp' ) );
		}

		$header = fgetcsv( $handle );
		if ( $header && isset( $header[0] ) ) {
			$header[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $header[0] );
		}
		$header = array_map( function ( $h ) {
			return sanitize_key( str_replace( array( ' ', '.' ), '_', strtolower( trim( (string) $h ) ) ) );
		}, (array) $header );

		/* Flexible column detection across common bank exports. */
		$find = function ( $candidates ) use ( $header ) {
			foreach ( $candidates as $name ) {
				$idx = array_search( $name, $header, true );
				if ( false !== $idx ) {
					return $idx;
				}
			}
			return -1;
		};
		$col_date   = $find( array( 'date', 'txn_date', 'transaction_date', 'value_date', 'tran_date' ) );
		$col_desc   = $find( array( 'description', 'particulars', 'narration', 'details', 'remarks' ) );
		$col_ref    = $find( array( 'ref', 'ref_no', 'reference', 'cheque_no', 'trx_id', 'transaction_id' ) );
		$col_debit  = $find( array( 'debit', 'withdrawal', 'withdraw', 'dr', 'out' ) );
		$col_credit = $find( array( 'credit', 'deposit', 'cr', 'in' ) );
		$col_amount = $find( array( 'amount', 'txn_amount' ) );

		if ( $col_date < 0 || ( $col_debit < 0 && $col_credit < 0 && $col_amount < 0 ) ) {
			fclose( $handle ); // phpcs:ignore
			wp_die( esc_html__( 'Could not find the date and amount columns. Expected headers like: Date, Description, Ref, Debit, Credit (or Amount with +/−).', 'wc-enterprise-erp' ) );
		}

		$batch    = 'B' . gmdate( 'ymdHis' );
		$imported = 0;

		while ( ( $data = fgetcsv( $handle ) ) !== false ) {
			$date = strtotime( trim( (string) ( $data[ $col_date ] ?? '' ) ) );
			if ( ! $date ) {
				continue;
			}
			$debit  = $col_debit >= 0 ? wceerp_dec( $data[ $col_debit ] ?? 0 ) : 0;
			$credit = $col_credit >= 0 ? wceerp_dec( $data[ $col_credit ] ?? 0 ) : 0;
			if ( $col_amount >= 0 && ! $debit && ! $credit ) {
				$amount = wceerp_dec( $data[ $col_amount ] ?? 0 );
				if ( $amount >= 0 ) {
					$credit = $amount;
				} else {
					$debit = -$amount;
				}
			}
			if ( $debit <= 0 && $credit <= 0 ) {
				continue;
			}

			$wpdb->insert( wceerp_table( 'bank_statement_lines' ), array(
				'account_id'  => $account_id,
				'txn_date'    => gmdate( 'Y-m-d', $date ),
				'description' => $col_desc >= 0 ? sanitize_text_field( (string) $data[ $col_desc ] ) : '',
				'ref_no'      => $col_ref >= 0 ? sanitize_text_field( (string) $data[ $col_ref ] ) : '',
				'debit'       => $debit,
				'credit'      => $credit,
				'status'      => 'unmatched',
				'batch'       => $batch,
				'created_at'  => current_time( 'mysql' ),
			) );
			$imported++;
		}
		fclose( $handle ); // phpcs:ignore

		wceerp_log( 'banking', 'import', $account_id, "$batch: $imported lines" );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'reconcile', 'account' => $account_id, 'imported' => $imported ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Matching.
	 * ------------------------------------------------------------------- */

	/**
	 * A statement CREDIT (money into the bank) corresponds to a journal
	 * DEBIT on the bank account, and vice versa.
	 */
	public function handle_automatch() {
		$this->verify_nonce( 'wceerp_bank_automatch' );
		global $wpdb;

		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		$stmt       = wceerp_table( 'bank_statement_lines' );
		$jl         = wceerp_table( 'journal_lines' );
		$j          = wceerp_table( 'journals' );

		$lines   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $stmt WHERE account_id=%d AND status='unmatched' ORDER BY txn_date", $account_id ) );
		$matched = 0;

		foreach ( (array) $lines as $line ) {
			$book_side = (float) $line->credit > 0 ? 'debit' : 'credit';
			$amount    = (float) $line->credit > 0 ? (float) $line->credit : (float) $line->debit;

			$candidate = $wpdb->get_var( $wpdb->prepare(
				"SELECT l.id FROM $jl l
				 INNER JOIN $j jr ON jr.id = l.journal_id AND jr.status='posted'
				 WHERE l.account_id = %d
				   AND ABS(l.$book_side - %f) < 0.005
				   AND jr.journal_date BETWEEN DATE_SUB(%s, INTERVAL 7 DAY) AND DATE_ADD(%s, INTERVAL 7 DAY)
				   AND l.id NOT IN ( SELECT matched_line_id FROM $stmt WHERE matched_line_id IS NOT NULL )
				 ORDER BY ABS(DATEDIFF(jr.journal_date, %s)) ASC LIMIT 1",
				$account_id, $amount, $line->txn_date, $line->txn_date, $line->txn_date
			) );

			if ( $candidate ) {
				$wpdb->update( $stmt, array( 'matched_line_id' => (int) $candidate, 'status' => 'matched' ), array( 'id' => $line->id ) );
				$matched++;
			}
		}

		wceerp_log( 'banking', 'automatch', $account_id, "$matched matched" );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'reconcile', 'account' => $account_id, 'matched' => $matched ) ) );
		exit;
	}

	public function handle_match() {
		$this->verify_nonce( 'wceerp_bank_match' );
		global $wpdb;
		$stmt = wceerp_table( 'bank_statement_lines' );

		$line_id = (int) ( $_POST['statement_line_id'] ?? 0 );
		$do      = sanitize_key( $_POST['do'] ?? 'match' );

		if ( 'unmatch' === $do ) {
			$wpdb->update( $stmt, array( 'matched_line_id' => null, 'status' => 'unmatched' ), array( 'id' => $line_id ) );
		} else {
			$journal_line_id = (int) ( $_POST['journal_line_id'] ?? 0 );
			if ( $line_id && $journal_line_id ) {
				$wpdb->update( $stmt, array( 'matched_line_id' => $journal_line_id, 'status' => 'matched' ), array( 'id' => $line_id ) );
			}
		}
		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'reconcile', 'account' => $account_id, 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'import' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Bank Reconciliation', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'import'    => __( 'Import statement', 'wc-enterprise-erp' ),
					'reconcile' => __( 'Reconcile', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), $tab === $slug ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php
			if ( isset( $_GET['imported'] ) ) {
				$this->notice( sprintf( __( '%d statement lines imported.', 'wc-enterprise-erp' ), (int) $_GET['imported'] ) );
			}
			if ( isset( $_GET['matched'] ) ) {
				$this->notice( sprintf( __( 'Auto-match linked %d lines.', 'wc-enterprise-erp' ), (int) $_GET['matched'] ) );
			}
			'reconcile' === $tab ? $this->render_reconcile() : $this->render_import();
			?>
		</div>
		<?php
	}

	protected function render_import() {
		?>
		<div class="wceerp-card" style="max-width:680px">
			<h2><?php esc_html_e( 'Import a bank / bKash statement', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php esc_html_e( 'CSV with headers. Recognised columns: Date, Description/Particulars, Ref/TrxID, Debit & Credit (or a single signed Amount). Most bank and bKash merchant exports work as-is.', 'wc-enterprise-erp' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="wceerp_bank_import">
				<?php wp_nonce_field( 'wceerp_bank_import' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Ledger account', 'wc-enterprise-erp' ); ?></th>
						<td><select name="account_id" required>
							<?php foreach ( $this->bank_accounts() as $a ) : ?>
								<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Statement CSV', 'wc-enterprise-erp' ); ?></th>
						<td><input type="file" name="csv" accept=".csv" required></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Import statement', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_reconcile() {
		global $wpdb;
		$stmt = wceerp_table( 'bank_statement_lines' );
		$jl   = wceerp_table( 'journal_lines' );
		$j    = wceerp_table( 'journals' );

		$accounts   = $this->bank_accounts();
		$account_id = (int) ( $_GET['account'] ?? ( $accounts ? $accounts[0]->id : 0 ) );
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-banking">
			<input type="hidden" name="tab" value="reconcile">
			<select name="account">
				<?php foreach ( $accounts as $a ) : ?>
					<option value="<?php echo (int) $a->id; ?>" <?php selected( $account_id, $a->id ); ?>><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="button"><?php esc_html_e( 'Open account', 'wc-enterprise-erp' ); ?></button>
		</form>
		<?php
		if ( ! $account_id ) {
			return;
		}

		/* Summary numbers. */
		$book = $wpdb->get_row( $wpdb->prepare(
			"SELECT COALESCE(SUM(l.debit),0) AS d, COALESCE(SUM(l.credit),0) AS c
			 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 WHERE l.account_id=%d", $account_id
		) );
		$statement = $wpdb->get_row( $wpdb->prepare(
			"SELECT COALESCE(SUM(credit),0) AS c, COALESCE(SUM(debit),0) AS d,
			        SUM(status='unmatched') AS open_lines
			 FROM $stmt WHERE account_id=%d", $account_id
		) );
		$book_balance = (float) $book->d - (float) $book->c;
		$stmt_balance = (float) $statement->c - (float) $statement->d;
		?>
		<div class="wceerp-kpis">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Balance per books', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $book_balance ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Balance per statement (imported)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $stmt_balance ) ); ?></strong></div>
			<div class="wceerp-kpi <?php echo abs( $book_balance - $stmt_balance ) < 0.01 ? 'is-good' : 'is-bad'; ?>"><span><?php esc_html_e( 'Difference', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $book_balance - $stmt_balance ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Unmatched statement lines', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $statement->open_lines; ?></strong></div>
		</div>

		<div class="wceerp-card">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:14px">
				<input type="hidden" name="action" value="wceerp_bank_automatch">
				<input type="hidden" name="account_id" value="<?php echo (int) $account_id; ?>">
				<?php wp_nonce_field( 'wceerp_bank_automatch' ); ?>
				<button class="button button-primary"><?php esc_html_e( 'Auto-match (same amount, ±7 days)', 'wc-enterprise-erp' ); ?></button>
			</form>

			<?php
			$per_page = 30;
			$total    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $stmt WHERE account_id=%d", $account_id ) );
			$lines    = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM $stmt WHERE account_id=%d ORDER BY status='matched', txn_date DESC, id DESC LIMIT %d OFFSET %d",
				$account_id, $per_page, wceerp_offset( $per_page )
			) );
			?>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Description', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Ref', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Out (Dr)', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'In (Cr)', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Match', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $lines ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No statement lines for this account yet — import a CSV first.', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $lines as $line ) : ?>
					<tr>
						<td><?php echo esc_html( $line->txn_date ); ?></td>
						<td><?php echo esc_html( wp_trim_words( (string) $line->description, 8, '…' ) ); ?></td>
						<td><code><?php echo esc_html( $line->ref_no ); ?></code></td>
						<td class="num"><?php echo (float) $line->debit ? wp_kses_post( wceerp_money( $line->debit ) ) : '—'; ?></td>
						<td class="num"><?php echo (float) $line->credit ? wp_kses_post( wceerp_money( $line->credit ) ) : '—'; ?></td>
						<td>
						<?php if ( 'matched' === $line->status ) : ?>
							<span class="wceerp-badge is-completed"><?php esc_html_e( 'Matched', 'wc-enterprise-erp' ); ?></span>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
								<input type="hidden" name="action" value="wceerp_bank_match">
								<input type="hidden" name="do" value="unmatch">
								<input type="hidden" name="statement_line_id" value="<?php echo (int) $line->id; ?>">
								<input type="hidden" name="account_id" value="<?php echo (int) $account_id; ?>">
								<?php wp_nonce_field( 'wceerp_bank_match' ); ?>
								<button class="button-link wceerp-danger"><?php esc_html_e( 'undo', 'wc-enterprise-erp' ); ?></button>
							</form>
						<?php else :
							$book_side  = (float) $line->credit > 0 ? 'debit' : 'credit';
							$amount     = (float) $line->credit > 0 ? (float) $line->credit : (float) $line->debit;
							$candidates = $wpdb->get_results( $wpdb->prepare(
								"SELECT l.id, jr.doc_no, jr.journal_date, l.$book_side AS amount, jr.memo
								 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
								 WHERE l.account_id=%d AND l.$book_side > 0
								   AND ABS(l.$book_side - %f) < %f
								   AND l.id NOT IN ( SELECT matched_line_id FROM $stmt WHERE matched_line_id IS NOT NULL )
								 ORDER BY ABS(DATEDIFF(jr.journal_date, %s)) ASC LIMIT 8",
								$account_id, $amount, max( 1, $amount * 0.02 ), $line->txn_date
							) );
							?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;align-items:center">
								<input type="hidden" name="action" value="wceerp_bank_match">
								<input type="hidden" name="statement_line_id" value="<?php echo (int) $line->id; ?>">
								<input type="hidden" name="account_id" value="<?php echo (int) $account_id; ?>">
								<?php wp_nonce_field( 'wceerp_bank_match' ); ?>
								<select name="journal_line_id" style="max-width:260px">
									<option value=""><?php echo $candidates ? esc_html__( '— choose book entry —', 'wc-enterprise-erp' ) : esc_html__( 'no close book entry', 'wc-enterprise-erp' ); ?></option>
									<?php foreach ( (array) $candidates as $cand ) : ?>
										<option value="<?php echo (int) $cand->id; ?>">
											<?php echo esc_html( $cand->journal_date . ' · ' . $cand->doc_no . ' · ' . wp_strip_all_tags( wceerp_money( $cand->amount ) ) ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<button class="button button-small"><?php esc_html_e( 'Match', 'wc-enterprise-erp' ); ?></button>
							</form>
						<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php wceerp_pagination( $total, $per_page ); ?>
			<p class="description"><?php esc_html_e( 'Statement lines with no book entry usually mean bank charges or interest — post them as a journal voucher, then match. Book entries with no statement line are cheques or transfers still clearing.', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php
	}
}
