<?php
/**
 * Module: Tax — VAT/GST configuration and the NBR VAT summary.
 *
 * Output VAT collects in account 2100 (from sales), input VAT in 1300
 * (from purchases). Net payable = output − input, which mirrors the
 * figure a Bangladeshi business reports on Mushak-9.1.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Tax extends WCEERP_Module {

	protected $id         = 'tax';
	protected $title      = 'VAT / GST';
	protected $capability = 'wceerp_manage_accounting';
	protected $tier       = 'starter';
	protected $order      = 55;

	public function __construct() {
		$this->title = __( 'VAT / GST', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_tax_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_mushak_pdf', array( $this, 'handle_mushak_pdf' ) );
		add_filter( 'woocommerce_admin_order_actions', array( $this, 'order_action_button' ), 20, 2 );
	}

	/**
	 * "Mushak-6.3" button on the WooCommerce orders list.
	 */
	public function order_action_button( $actions, $order ) {
		if ( wceerp_user_can( $this->capability ) || current_user_can( 'manage_woocommerce' ) ) {
			$actions['wceerp_mushak'] = array(
				'url'    => wp_nonce_url(
					admin_url( 'admin-post.php?action=wceerp_mushak_pdf&order_id=' . $order->get_id() ),
					'wceerp_mushak_pdf'
				),
				'name'   => __( 'Mushak-6.3 PDF', 'wc-enterprise-erp' ),
				'action' => 'wceerp_mushak',
			);
		}
		return $actions;
	}

	/**
	 * Stream a Mushak-6.3 tax invoice PDF for a WooCommerce order.
	 */
	public function handle_mushak_pdf() {
		if ( ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ?? '' ), 'wceerp_mushak_pdf' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		if ( ! wceerp_user_can( $this->capability ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}

		$order = wc_get_order( (int) ( $_GET['order_id'] ?? 0 ) );
		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'wc-enterprise-erp' ) );
		}

		$mushak_no = $order->get_meta( '_wceerp_mushak_no' );
		if ( ! $mushak_no ) {
			$mushak_no = wceerp_get_option( 'mushak_prefix', 'MUS63' ) . '-' . $order->get_order_number();
			$order->update_meta_data( '_wceerp_mushak_no', $mushak_no );
			$order->save();
		}

		$pdf = new WCEERP_PDF();
		$pdf->add_page();

		$company = wceerp_get_option( 'company_name', get_bloginfo( 'name' ) );
		$bin     = wceerp_get_option( 'company_bin', '' );
		$address = wceerp_get_option( 'company_address', '' );
		$left    = 40;
		$right   = 555;
		$y       = 50;

		/* Header. */
		$pdf->set_font( 9 )->text( $left, $y, __( 'Government of the People\'s Republic of Bangladesh', 'wc-enterprise-erp' ) );
		$pdf->text_right( $right, $y, __( 'Mushak-6.3', 'wc-enterprise-erp' ) );
		$y += 14;
		$pdf->text( $left, $y, __( 'National Board of Revenue', 'wc-enterprise-erp' ) );
		$pdf->set_font( 9, true )->text_right( $right, $y, __( 'TAX INVOICE', 'wc-enterprise-erp' ) );
		$y += 10;
		$pdf->line( $left, $y, $right, $y, 1.2 );
		$y += 22;

		$pdf->set_font( 15, true )->text( $left, $y, $company );
		$y += 16;
		$pdf->set_font( 9 );
		if ( $bin ) {
			$pdf->text( $left, $y, sprintf( __( 'BIN: %s', 'wc-enterprise-erp' ), $bin ) );
			$y += 12;
		}
		if ( $address ) {
			$pdf->text( $left, $y, $address );
			$y += 12;
		}

		$pdf->text_right( $right, $y - 24, sprintf( __( 'Invoice no: %s', 'wc-enterprise-erp' ), $mushak_no ) );
		$pdf->text_right( $right, $y - 12, sprintf( __( 'Order: #%s', 'wc-enterprise-erp' ), $order->get_order_number() ) );
		$pdf->text_right( $right, $y, sprintf( __( 'Date: %s', 'wc-enterprise-erp' ), $order->get_date_created() ? $order->get_date_created()->date_i18n( 'j M Y' ) : '' ) );
		$y += 16;

		/* Buyer. */
		$pdf->set_font( 10, true )->text( $left, $y, __( 'Buyer', 'wc-enterprise-erp' ) );
		$y += 13;
		$pdf->set_font( 9 )->text( $left, $y, $order->get_formatted_billing_full_name() );
		$y += 12;
		$one_line_address = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( str_replace( '<br/>', ', ', $order->get_formatted_billing_address() ) ) ) );
		if ( $one_line_address ) {
			$pdf->text( $left, $y, $one_line_address );
			$y += 12;
		}
		if ( $order->get_billing_phone() ) {
			$pdf->text( $left, $y, sprintf( __( 'Phone: %s', 'wc-enterprise-erp' ), $order->get_billing_phone() ) );
			$y += 12;
		}
		$y += 8;

		/* Item table: SL | Description | Qty | Unit price | Value | VAT. */
		$cols = array( 'sl' => 40, 'desc' => 70, 'qty' => 330, 'unit' => 400, 'value' => 475, 'vat' => 555 );
		$pdf->set_font( 9, true );
		$pdf->text( $cols['sl'], $y, __( 'SL', 'wc-enterprise-erp' ) );
		$pdf->text( $cols['desc'], $y, __( 'Description of goods', 'wc-enterprise-erp' ) );
		$pdf->text_right( $cols['qty'] + 40, $y, __( 'Qty', 'wc-enterprise-erp' ) );
		$pdf->text_right( $cols['unit'] + 55, $y, __( 'Unit price', 'wc-enterprise-erp' ) );
		$pdf->text_right( $cols['value'] + 55, $y, __( 'Value', 'wc-enterprise-erp' ) );
		$pdf->text_right( $cols['vat'], $y, __( 'VAT', 'wc-enterprise-erp' ) );
		$y += 5;
		$pdf->line( $left, $y, $right, $y );
		$y += 13;
		$pdf->set_font( 9 );

		$sl = 0;
		foreach ( $order->get_items() as $item ) {
			$sl++;
			$qty   = (float) $item->get_quantity();
			$net   = (float) $item->get_total();
			$vat   = (float) $item->get_total_tax();
			$unit  = $qty > 0 ? $net / $qty : 0;

			$pdf->text( $cols['sl'], $y, (string) $sl );
			$pdf->text( $cols['desc'], $y, mb_substr( $item->get_name(), 0, 45 ) );
			$pdf->text_right( $cols['qty'] + 40, $y, rtrim( rtrim( number_format( $qty, 2, '.', ',' ), '0' ), '.' ) );
			$pdf->text_right( $cols['unit'] + 55, $y, number_format( $unit, 2, '.', ',' ) );
			$pdf->text_right( $cols['value'] + 55, $y, number_format( $net, 2, '.', ',' ) );
			$pdf->text_right( $cols['vat'], $y, number_format( $vat, 2, '.', ',' ) );
			$y += 13;

			if ( $y > 700 ) {
				$pdf->add_page();
				$y = 50;
			}
		}

		$y += 3;
		$pdf->line( $left, $y, $right, $y );
		$y += 15;

		/* Totals. */
		$rows = array(
			__( 'Total value (ex VAT)', 'wc-enterprise-erp' ) => (float) $order->get_total() - (float) $order->get_total_tax(),
			__( 'VAT', 'wc-enterprise-erp' )                  => (float) $order->get_total_tax(),
			__( 'Grand total', 'wc-enterprise-erp' )          => (float) $order->get_total(),
		);
		$i = 0;
		foreach ( $rows as $label => $amount ) {
			$i++;
			$pdf->set_font( 9, 3 === $i );
			$pdf->text_right( $cols['value'] + 55, $y, $label );
			$pdf->text_right( $cols['vat'], $y, 'Tk ' . number_format( $amount, 2, '.', ',' ) );
			$y += 13;
		}

		/* Footer. */
		$y = max( $y + 60, 740 );
		$pdf->set_font( 9 );
		$pdf->line( $left, $y, $left + 150, $y );
		$pdf->text( $left, $y + 12, __( 'Prepared by', 'wc-enterprise-erp' ) );
		$pdf->line( $right - 150, $y, $right, $y );
		$pdf->text_right( $right, $y + 12, __( 'Authorised signature', 'wc-enterprise-erp' ) );
		$pdf->set_font( 7 )->text_center( ( $left + $right ) / 2, 810, __( 'This is a computer-generated Mushak-6.3 tax invoice.', 'wc-enterprise-erp' ) );

		wceerp_log( 'tax', 'mushak_pdf', $order->get_id(), $mushak_no );
		$pdf->stream( $mushak_no . '.pdf' );
	}

	/**
	 * Standard NBR (Bangladesh) VAT rate presets.
	 */
	public static function bd_rates() {
		return apply_filters( 'wceerp_bd_vat_rates', array(
			'15'  => __( '15% — standard rate', 'wc-enterprise-erp' ),
			'10'  => __( '10% — reduced rate', 'wc-enterprise-erp' ),
			'7.5' => __( '7.5% — reduced rate', 'wc-enterprise-erp' ),
			'5'   => __( '5% — reduced rate', 'wc-enterprise-erp' ),
			'0'   => __( '0% — exempt / zero-rated', 'wc-enterprise-erp' ),
		) );
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_tax_save' );

		wceerp_update_option( 'default_vat_rate', wceerp_dec( $_POST['default_vat_rate'] ?? 15 ) );
		wceerp_update_option( 'mushak_prefix', sanitize_text_field( wp_unslash( $_POST['mushak_prefix'] ?? 'MUS63' ) ) );
		wceerp_update_option( 'company_bin', sanitize_text_field( wp_unslash( $_POST['company_bin'] ?? '' ) ) );
		wceerp_update_option( 'vat_inclusive_prices', ! empty( $_POST['vat_inclusive_prices'] ) ? 1 : 0 );

		wceerp_log( 'tax', 'settings_save' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'summary' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'VAT / GST', 'wc-enterprise-erp' ) ) ); ?></h1>

			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'summary'  => __( 'VAT summary', 'wc-enterprise-erp' ),
					'settings' => __( 'Settings', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf(
						'<a href="%s" class="nav-tab %s">%s</a>',
						esc_url( $this->admin_url( array( 'tab' => $slug ) ) ),
						$tab === $slug ? 'nav-tab-active' : '',
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Tax settings saved.', 'wc-enterprise-erp' ) ); } ?>

			<?php 'settings' === $tab ? $this->render_settings() : $this->render_summary(); ?>
		</div>
		<?php
	}

	protected function render_summary() {
		global $wpdb;

		$fy   = wceerp_fiscal_year();
		$from = sanitize_text_field( $_GET['from'] ?? $fy['start'] );
		$to   = sanitize_text_field( $_GET['to'] ?? $fy['end'] );

		$jl  = wceerp_table( 'journal_lines' );
		$j   = wceerp_table( 'journals' );
		$acc = wceerp_table( 'accounts' );

		$vat = function ( $code, $credit_normal ) use ( $wpdb, $jl, $j, $acc, $from, $to ) {
			$net = (float) $wpdb->get_var( $wpdb->prepare(
				"SELECT COALESCE(SUM(l.debit - l.credit),0)
				 FROM $jl l
				 INNER JOIN $j j ON j.id = l.journal_id AND j.status='posted'
				 INNER JOIN $acc a ON a.id = l.account_id
				 WHERE a.code = %s AND j.journal_date BETWEEN %s AND %s",
				$code, $from, $to
			) );
			return $credit_normal ? -$net : $net;
		};

		$output  = $vat( '2100', true );  // VAT collected on sales.
		$input   = $vat( '1300', false ); // VAT paid on purchases.
		$payable = $output - $input;
		?>
		<div class="wceerp-card">
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-tax">
				<input type="hidden" name="tab" value="summary">
				<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
				<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
				<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			</form>

			<div class="wceerp-kpis">
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Output VAT (on sales — a/c 2100)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $output ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Input VAT (on purchases — a/c 1300)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $input ) ); ?></strong></div>
				<div class="wceerp-kpi <?php echo $payable >= 0 ? 'is-bad' : 'is-good'; ?>"><span><?php echo $payable >= 0 ? esc_html__( 'Net VAT payable to NBR', 'wc-enterprise-erp' ) : esc_html__( 'Net VAT rebate carried', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( abs( $payable ) ) ); ?></strong></div>
			</div>

			<p class="description">
				<?php esc_html_e( 'Net payable = output VAT minus input VAT for the period — the same figure carried onto the monthly Mushak-9.1 return. Sales invoices carry a sequential Mushak-6.3 number stored on each WooCommerce order.', 'wc-enterprise-erp' ); ?>
			</p>
		</div>
		<?php
	}

	protected function render_settings() {
		$rate      = wceerp_get_option( 'default_vat_rate', 15 );
		$prefix    = wceerp_get_option( 'mushak_prefix', 'MUS63' );
		$bin       = wceerp_get_option( 'company_bin', '' );
		$inclusive = (int) wceerp_get_option( 'vat_inclusive_prices', 0 );
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'VAT settings (Bangladesh / NBR)', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_tax_save">
				<?php wp_nonce_field( 'wceerp_tax_save' ); ?>
				<table class="form-table"><tbody>
					<tr>
						<th><label><?php esc_html_e( 'Default VAT rate', 'wc-enterprise-erp' ); ?></label></th>
						<td><select name="default_vat_rate">
							<?php foreach ( self::bd_rates() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $rate, (string) $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Used as the default VAT % on purchase order lines. WooCommerce sales use your WooCommerce tax settings.', 'wc-enterprise-erp' ); ?></p></td>
					</tr>
					<tr>
						<th><label><?php esc_html_e( 'Company BIN', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" name="company_bin" value="<?php echo esc_attr( $bin ); ?>" class="regular-text" placeholder="000123456-0101">
						<p class="description"><?php esc_html_e( 'Business Identification Number printed on tax invoices.', 'wc-enterprise-erp' ); ?></p></td>
					</tr>
					<tr>
						<th><label><?php esc_html_e( 'Mushak-6.3 prefix', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" name="mushak_prefix" value="<?php echo esc_attr( $prefix ); ?>">
						<p class="description"><?php esc_html_e( 'Each completed order gets a sequential tax-invoice number with this prefix (stored as order meta _wceerp_mushak_no).', 'wc-enterprise-erp' ); ?></p></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Price entry', 'wc-enterprise-erp' ); ?></th>
						<td><label><input type="checkbox" name="vat_inclusive_prices" value="1" <?php checked( $inclusive, 1 ); ?>> <?php esc_html_e( 'Product prices are entered VAT-inclusive', 'wc-enterprise-erp' ); ?></label></td>
					</tr>
				</tbody></table>
				<p><button class="button button-primary"><?php esc_html_e( 'Save tax settings', 'wc-enterprise-erp' ); ?></button></p>
			</form>
		</div>
		<?php
	}
}
