<?php
/**
 * Module: Reports — trial balance, profit & loss, balance sheet,
 * stock valuation. Every figure derives from posted journal lines,
 * so the three statements always reconcile.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Reports extends WCEERP_Module {

	protected $id         = 'reports';
	protected $title      = 'Reports';
	protected $capability = 'wceerp_view_reports';
	protected $tier       = 'starter';
	protected $order      = 60;

	public function __construct() {
		$this->title = __( 'Reports', 'wc-enterprise-erp' );
	}

	public function init() {}

	protected function range() {
		$fy = wceerp_fiscal_year();
		return array(
			sanitize_text_field( $_GET['from'] ?? $fy['start'] ),
			sanitize_text_field( $_GET['to'] ?? $fy['end'] ),
		);
	}

	protected function filter_form( $tab, $from, $to ) {
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-reports">
			<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>">
			<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
			<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
			<button class="button"><?php esc_html_e( 'Run report', 'wc-enterprise-erp' ); ?></button>
			<button type="button" class="button" onclick="window.print()"><?php esc_html_e( 'Print', 'wc-enterprise-erp' ); ?></button>
		</form>
		<?php
	}

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'pl' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Reports', 'wc-enterprise-erp' ) ) ); ?></h1>

			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'pl'       => __( 'Profit & loss', 'wc-enterprise-erp' ),
					'orders'   => __( 'Order profit', 'wc-enterprise-erp' ),
					'analysis' => __( 'Profit analysis', 'wc-enterprise-erp' ),
					'bs'       => __( 'Balance sheet', 'wc-enterprise-erp' ),
					'tb'       => __( 'Trial balance', 'wc-enterprise-erp' ),
					'stock'    => __( 'Stock valuation', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf(
						'<a href="%s" class="nav-tab %s">%s</a>',
						esc_url( $this->admin_url( array( 'tab' => $slug ) ) ),
						$tab === $slug ? 'nav-tab-active' : '',
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php
			if ( 'bs' === $tab ) {
				$this->render_balance_sheet();
			} elseif ( 'orders' === $tab ) {
				$this->render_order_profit();
			} elseif ( 'analysis' === $tab ) {
				$this->render_profit_analysis();
			} elseif ( 'tb' === $tab ) {
				$this->render_trial_balance();
			} elseif ( 'stock' === $tab ) {
				$this->render_stock_valuation();
			} else {
				$this->render_profit_loss();
			}
			?>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */

	protected function render_profit_loss() {
		list( $from, $to ) = $this->range();
		$types = WCEERP_Accounting::type_balances( $from, $to );

		$section = function ( $rows, $label ) {
			$total = 0;
			echo '<tr class="wceerp-section"><th colspan="2">' . esc_html( $label ) . '</th></tr>';
			foreach ( (array) $rows as $row ) {
				$total += $row['amount'];
				/* Every figure links to the entries behind it. A number in
				 * an account like Miscellaneous is otherwise impossible to
				 * explain, and "where did this come from" is the first
				 * question anyone asks of a profit and loss. */
				$link = add_query_arg(
					array(
						'page' => 'wceerp-accounting',
						'tab'  => 'ledger',
						'account' => (int) $row['id'],
						'from' => $from,
						'to'   => $to,
					),
					admin_url( 'admin.php' )
				);
				printf(
					'<tr><td><a href="%s" title="%s">%s %s</a></td><td class="num">%s</td></tr>',
					esc_url( $link ),
					esc_attr__( 'Show every entry in this account', 'wc-enterprise-erp' ),
					esc_html( $row['code'] ), esc_html( $row['name'] ),
					wp_kses_post( wceerp_money( $row['amount'] ) )
				);
			}
			printf( '<tr class="wceerp-total"><th>%s</th><th class="num">%s</th></tr>', esc_html__( 'Total', 'wc-enterprise-erp' ), wp_kses_post( wceerp_money( $total ) ) );
			return $total;
		};
		?>
		<div class="wceerp-card wceerp-report">
			<?php $this->filter_form( 'pl', $from, $to ); ?>
			<h2><?php echo esc_html( wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ) ); ?> — <?php esc_html_e( 'Profit & Loss Statement', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php echo esc_html( $from . ' → ' . $to ); ?></p>
			<table class="widefat wceerp-table">
				<tbody>
				<?php
				$income  = $section( $types['income'] ?? array(), __( 'Income', 'wc-enterprise-erp' ) );
				$expense = $section( $types['expense'] ?? array(), __( 'Expenses (incl. COGS)', 'wc-enterprise-erp' ) );
				$net     = $income - $expense;
				?>
				<tr class="wceerp-grand <?php echo $net >= 0 ? 'is-good' : 'is-bad'; ?>">
					<th><?php echo $net >= 0 ? esc_html__( 'Net profit', 'wc-enterprise-erp' ) : esc_html__( 'Net loss', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php echo wp_kses_post( wceerp_money( abs( $net ) ) ); ?></th>
				</tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Profit analysis: selling price vs a broken-out cost stack
	 * (product purchase cost / COGS + courier charges + other expenses),
	 * with the profit margin shown as a percentage in brackets.
	 */
	/**
	 * Profit per order, and per line within it.
	 *
	 * Cost comes from the stock movement written when the sale was posted,
	 * not from the product's cost today. A product repriced last week must
	 * not silently rewrite the profit on a sale made last month — the whole
	 * point of holding unit_cost on the movement is that history stays put.
	 */
	protected function render_order_profit() {
		global $wpdb;
		list( $from, $to ) = $this->range();
		$this->filter_form( 'orders', $from, $to );

		if ( ! function_exists( 'wc_get_orders' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'WooCommerce is not active.', 'wc-enterprise-erp' ) . '</p></div>';
			return;
		}

		$per_page = 50;
		$paged    = max( 1, (int) ( $_GET['paged'] ?? 1 ) );

		$args = array(
			'limit'        => $per_page,
			'paged'        => $paged,
			'status'       => array( 'processing', 'completed' ),
			'date_created' => $from . '...' . $to,
			'orderby'      => 'date',
			'order'        => 'DESC',
			'return'       => 'objects',
			'paginate'     => true,
		);
		$result = wc_get_orders( $args );
		$orders = $result->orders ?? array();
		$found  = (int) ( $result->total ?? count( $orders ) );

		/* Costs for every order on this page in one query, rather than one
		 * lookup per line. */
		/* Courier charges per order. A COD sale's real margin is the sale
		 * less the goods AND less what the courier takes — leaving it out
		 * flatters every delivered order. */
		$courier_cost = array();
		if ( $orders ) {
			$oid_list = array();
			foreach ( $orders as $o ) {
				$oid_list[] = (int) $o->get_id();
			}
			$oin = implode( ',', array_map( 'absint', $oid_list ) );
			$crs = $wpdb->get_results(
				"SELECT order_id, courier, cod_amount, collected_amount, delivery_charge, remote_charge, weight
				 FROM " . wceerp_table( 'consignments' ) . "
				 WHERE order_id IN ({$oin})"
			);
			foreach ( (array) $crs as $cr ) {
				$charge = (float) $cr->delivery_charge;
				if ( $charge <= 0.004 ) {
					$charge = (float) $cr->remote_charge;
				}
				if ( $charge <= 0.004 && class_exists( 'WCEERP_Module_Courier' ) ) {
					$basis = (float) $cr->collected_amount > 0.004 ? (float) $cr->collected_amount : (float) $cr->cod_amount;
					$est   = WCEERP_Module_Courier::estimate_charge( $cr->courier, $basis, $cr );
					$charge = ( null !== $est ) ? (float) $est : 0;
				}
				$courier_cost[ (int) $cr->order_id ] = ( $courier_cost[ (int) $cr->order_id ] ?? 0 ) + $charge;
			}
		}

		$costs = array();
		if ( $orders ) {
			$ids = array();
			foreach ( $orders as $o ) {
				$ids[] = (int) $o->get_id();
			}
			$in   = implode( ',', array_map( 'absint', $ids ) );
			$rows = $wpdb->get_results(
				"SELECT ref_id, product_id,
				        SUM(qty) AS qty,
				        SUM(qty * unit_cost) AS cost
				 FROM " . wceerp_table( 'stock_moves' ) . "
				 WHERE direction = 'out'
				   AND ref_type IN ('wc_order','pos')
				   AND ref_id IN ({$in})
				 GROUP BY ref_id, product_id"
			);
			foreach ( (array) $rows as $r ) {
				$costs[ (int) $r->ref_id ][ (int) $r->product_id ] = array(
					'qty'  => (float) $r->qty,
					'cost' => (float) $r->cost,
				);
			}
		}

		$t_sales         = 0;
		$t_cost          = 0;
		$t_courier       = 0;
		$t_unknown       = 0;
		$t_unknown_count = 0;
		$missing = 0;
		?>

		<div class="wceerp-kpis">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Orders', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $found; ?></strong></div>
			<div class="wceerp-kpi" id="kpi-sales"><span><?php esc_html_e( 'Sales (this page)', 'wc-enterprise-erp' ); ?></span><strong>—</strong></div>
			<div class="wceerp-kpi" id="kpi-cost"><span><?php esc_html_e( 'Cost of goods', 'wc-enterprise-erp' ); ?></span><strong>—</strong></div>
			<div class="wceerp-kpi is-good" id="kpi-profit"><span><?php esc_html_e( 'Gross profit', 'wc-enterprise-erp' ); ?></span><strong>—</strong></div>
		</div>

		<table class="widefat striped wceerp-table">
			<thead>
				<tr>
					<th style="width:26px"></th>
					<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Selling', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Cost', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Margin', 'wc-enterprise-erp' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( ! $orders ) : ?>
				<tr><td colspan="9"><?php esc_html_e( 'No orders in this period.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>

			<?php foreach ( $orders as $order ) : ?>
				<?php
				$oid       = (int) $order->get_id();
				$order_map = $costs[ $oid ] ?? array();

				/* Sales excludes tax and shipping: profit here is what the
				 * goods earned. Delivery is a separate cost line and mixing
				 * the two hides which products actually make money. */
				$o_sales = 0;
				$o_cost  = 0;
				$lines   = array();
				$no_cost = false;

				foreach ( $order->get_items() as $item ) {
					$pid   = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
					$qty   = (float) $item->get_quantity();
					$sale  = (float) $item->get_total();          // after line discount, before tax
					$known = $order_map[ $pid ] ?? null;

					/* The movement holds the cost for the whole order line;
					 * scale it when only part of that quantity is on this
					 * line (the same product added twice). */
					$cost = 0;
					if ( $known && $known['qty'] > 0 ) {
						$cost = $known['cost'] * ( min( $qty, $known['qty'] ) / $known['qty'] );
					}
					if ( $cost <= 0 && $qty > 0 ) {
						$no_cost = true;
					}

					$o_sales += $sale;
					$o_cost  += $cost;

					$lines[] = array(
						'name'  => $item->get_name(),
						'qty'   => $qty,
						'sale'  => $sale,
						'cost'  => $cost,
						'unit_sale' => $qty > 0 ? $sale / $qty : 0,
						'unit_cost' => $qty > 0 ? $cost / $qty : 0,
					);
				}

				$o_courier = (float) ( $courier_cost[ $oid ] ?? 0 );
				$profit    = $o_sales - $o_cost - $o_courier;
				$margin    = $o_sales > 0 ? ( $profit / $o_sales * 100 ) : 0;

				/* An order with no cost against it is not 100% profit — it
				 * is an order whose cost is unknown, usually because the
				 * stock movement has not happened yet or the product was
				 * never given a purchase cost. Showing 100% invites someone
				 * to believe it, and the page total inherits the fiction.
				 *
				 * These are counted separately and left out of the totals,
				 * so the figure at the bottom is one you could defend. */
				$costless = ( $o_cost <= 0.004 && $o_sales > 0.004 );

				$t_sales   += $costless ? 0 : $o_sales;
				$t_cost    += $costless ? 0 : $o_cost;
				$t_courier += $costless ? 0 : $o_courier;
				if ( $costless ) {
					$t_unknown       += $o_sales;
					$t_unknown_count++;
				}
				if ( $no_cost ) {
					$missing++;
				}
				?>
				<tr class="<?php echo $no_cost ? 'wceerp-row-warn' : ''; ?>">
					<td>
						<button type="button" class="button-link wceerp-exp" data-order="<?php echo (int) $oid; ?>"
							aria-label="<?php esc_attr_e( 'Show items', 'wc-enterprise-erp' ); ?>">+</button>
					</td>
					<td>
						<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"><strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong></a>
						<?php if ( $no_cost ) : ?>
							<span class="wceerp-sub" style="color:#B7791F"><?php esc_html_e( 'no cost recorded', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $order->get_date_created() ? $order->get_date_created()->date( 'j M Y' ) : '—' ); ?></td>
					<td><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ?: '—' ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $o_sales ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $o_cost ) ); ?></td>
					<td class="num"><?php echo $o_courier > 0.004 ? wp_kses_post( wceerp_money( $o_courier ) ) : '<span class="wceerp-muted">—</span>'; ?></td>
					<td class="num" style="color:<?php echo $costless ? '#8B94A1' : ( $profit >= 0 ? '#0F7B5A' : '#C0392B' ); ?>;font-weight:650">
						<?php echo $costless ? '<span class="wceerp-muted">—</span>' : wp_kses_post( wceerp_money( $profit ) ); ?>
					</td>
					<td class="num">
						<?php echo $costless ? '<span class="wceerp-muted">—</span>' : esc_html( number_format( $margin, 1 ) ) . '%'; ?>
					</td>
				</tr>

				<tr class="wceerp-items" id="items-<?php echo (int) $oid; ?>" style="display:none">
					<td></td>
					<td colspan="7" style="padding:0 12px 12px">
						<table class="widefat" style="margin:0">
							<thead><tr>
								<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Selling price', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Cost price', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Line total', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Line cost', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Profit', 'wc-enterprise-erp' ); ?></th>
							</tr></thead>
							<tbody>
							<?php foreach ( $lines as $l ) : ?>
								<?php $lp = $l['sale'] - $l['cost']; ?>
								<tr>
									<td><?php echo esc_html( $l['name'] ); ?></td>
									<td class="num"><?php echo esc_html( rtrim( rtrim( number_format( $l['qty'], 2 ), '0' ), '.' ) ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $l['unit_sale'] ) ); ?></td>
									<td class="num">
										<?php if ( $l['unit_cost'] > 0 ) : ?>
											<?php echo wp_kses_post( wceerp_money( $l['unit_cost'] ) ); ?>
										<?php else : ?>
											<span style="color:#B7791F"><?php esc_html_e( 'not recorded', 'wc-enterprise-erp' ); ?></span>
										<?php endif; ?>
									</td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $l['sale'] ) ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $l['cost'] ) ); ?></td>
									<td class="num" style="color:<?php echo $lp >= 0 ? '#0F7B5A' : '#C0392B'; ?>">
										<?php echo wp_kses_post( wceerp_money( $lp ) ); ?>
									</td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<?php if ( $orders ) : ?>
			<tfoot>
				<tr class="wceerp-grand">
					<td colspan="5"><?php esc_html_e( 'Total for this page', 'wc-enterprise-erp' ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $t_sales ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $t_cost ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $t_courier ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $t_sales - $t_cost - $t_courier ) ); ?></td>
					<td class="num"><?php echo esc_html( $t_sales > 0 ? number_format( ( $t_sales - $t_cost - $t_courier ) / $t_sales * 100, 1 ) : '0.0' ); ?>%</td>
				</tr>
			</tfoot>
			<?php endif; ?>
		</table>

		<?php if ( $t_unknown_count ) : ?>
			<div class="notice notice-info" style="margin-top:14px"><p>
				<?php
				printf(
					/* translators: 1: orders, 2: their sales value. */
					esc_html__( '%1$d order(s) worth %2$s are left out of the totals above because no cost is recorded against them. They are not 100%% profit — their cost is simply unknown, so including them would overstate what you earned.', 'wc-enterprise-erp' ),
					(int) $t_unknown_count,
					wp_kses_post( wceerp_money( $t_unknown ) )
				);
				?>
			</p></div>
		<?php endif; ?>

		<?php if ( $missing ) : ?>
			<div class="notice notice-warning" style="margin-top:14px"><p>
				<strong><?php
					printf(
						/* translators: %d: number of orders. */
						esc_html__( '%d order(s) on this page contain a product with no cost recorded.', 'wc-enterprise-erp' ),
						(int) $missing
					);
				?></strong>
				<?php esc_html_e( 'Their profit is overstated, because the goods are being treated as free. Enter opening stock with real purchase costs, or record a purchase, and future sales will cost correctly. Past sales keep the cost they were posted with.', 'wc-enterprise-erp' ); ?>
			</p></div>
		<?php endif; ?>

		<?php
		// Pagination.
		$pages = (int) ceil( $found / $per_page );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post( paginate_links( array(
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'current'   => $paged,
				'total'     => $pages,
				'prev_text' => '&laquo;',
				'next_text' => '&raquo;',
			) ) );
			echo '</div></div>';
		}
		?>

		<p class="description">
			<?php esc_html_e( 'Selling excludes tax and delivery, so this is what the goods themselves earned. Cost is the stock cost recorded when each sale was posted, not the product\'s cost today — repricing a product never rewrites the profit on a sale already made.', 'wc-enterprise-erp' ); ?>
		</p>

		<script>
		(function () {
			document.querySelectorAll( '.wceerp-exp' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var row = document.getElementById( 'items-' + b.dataset.order );
					if ( ! row ) { return; }
					var open = row.style.display !== 'none';
					row.style.display = open ? 'none' : '';
					b.textContent = open ? '+' : '−';
				} );
			} );

			/* The KPI strip is filled from the footer so the two can never
			   disagree about the same page of orders. */
			var foot = document.querySelector( '.wceerp-grand' );
			if ( foot ) {
				var cells = foot.querySelectorAll( '.num' );
				var set = function ( id, node ) {
					var el = document.querySelector( '#' + id + ' strong' );
					if ( el && node ) { el.innerHTML = node.innerHTML; }
				};
				set( 'kpi-sales', cells[0] );
				set( 'kpi-cost', cells[1] );
				set( 'kpi-profit', cells[2] );
			}
		})();
		</script>
		<?php
	}

	protected function render_profit_analysis() {
		list( $from, $to ) = $this->range();
		$rows = WCEERP_Accounting::trial_balance( $from, $to );

		$sales   = 0.0;
		$cogs    = 0.0;
		$courier = 0.0;
		$other   = 0.0;

		foreach ( $rows as $r ) {
			$net_dr = (float) $r->debit - (float) $r->credit;
			if ( 'income' === $r->type ) {
				$sales += -$net_dr;
			} elseif ( 'expense' === $r->type ) {
				if ( '5000' === $r->code ) {
					$cogs += $net_dr;
				} elseif ( '5600' === $r->code ) {
					$courier += $net_dr;
				} else {
					$other += $net_dr;
				}
			}
		}

		$total_cost = $cogs + $courier + $other;
		$profit     = $sales - $total_cost;
		$margin     = $sales > 0 ? ( $profit / $sales ) * 100 : 0;

		$pct = function ( $amount ) use ( $sales ) {
			if ( $sales <= 0 ) {
				return '';
			}
			return ' <span class="wceerp-pct">(' . number_format( ( $amount / $sales ) * 100, 1 ) . '%)</span>';
		};
		?>
		<div class="wceerp-card wceerp-report">
			<?php $this->filter_form( 'analysis', $from, $to ); ?>
			<h2><?php echo esc_html( wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ) ); ?> — <?php esc_html_e( 'Profit Analysis', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php echo esc_html( $from . ' → ' . $to ); ?></p>

			<table class="widefat wceerp-table">
				<tbody>
					<tr class="wceerp-section"><th colspan="2"><?php esc_html_e( 'Revenue', 'wc-enterprise-erp' ); ?></th></tr>
					<tr>
						<td><?php esc_html_e( 'Total product selling price', 'wc-enterprise-erp' ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $sales ) ); ?></td>
					</tr>

					<tr class="wceerp-section"><th colspan="2"><?php esc_html_e( 'Cost breakdown', 'wc-enterprise-erp' ); ?></th></tr>
					<tr>
						<td><?php esc_html_e( 'Product purchase price (COGS)', 'wc-enterprise-erp' ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $cogs ) . $pct( $cogs ) ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Courier / delivery charges', 'wc-enterprise-erp' ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $courier ) . $pct( $courier ) ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Other expenses (rent, utilities, marketing…)', 'wc-enterprise-erp' ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $other ) . $pct( $other ) ); ?></td>
					</tr>
					<tr class="wceerp-total">
						<th><?php esc_html_e( 'Total cost', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php echo wp_kses_post( wceerp_money( $total_cost ) . $pct( $total_cost ) ); ?></th>
					</tr>

					<tr class="wceerp-grand <?php echo $profit >= 0 ? 'is-good' : 'is-bad'; ?>">
						<th>
							<?php echo $profit >= 0 ? esc_html__( 'Net profit', 'wc-enterprise-erp' ) : esc_html__( 'Net loss', 'wc-enterprise-erp' ); ?>
							<span class="wceerp-margin">(<?php echo esc_html( number_format( $margin, 1 ) ); ?>%)</span>
						</th>
						<th class="num"><?php echo wp_kses_post( wceerp_money( abs( $profit ) ) ); ?></th>
					</tr>
				</tbody>
			</table>

			<p class="description">
				<?php esc_html_e( 'Percentages in brackets are each line as a share of total selling price. The margin beside net profit is profit ÷ selling price.', 'wc-enterprise-erp' ); ?>
			</p>
		</div>
		<?php
	}

	protected function render_balance_sheet() {
		list( $from, $to ) = $this->range();

		// Balance sheet is cumulative from the beginning of time to the "as at" date.
		$types = WCEERP_Accounting::type_balances( '1970-01-01', $to );

		$total_of = function ( $rows ) {
			$total = 0;
			foreach ( (array) $rows as $row ) {
				$total += $row['amount'];
			}
			return $total;
		};

		$net_profit = $total_of( $types['income'] ?? array() ) - $total_of( $types['expense'] ?? array() );

		$section = function ( $rows, $label, $extra = array() ) {
			$total = 0;
			echo '<tr class="wceerp-section"><th colspan="2">' . esc_html( $label ) . '</th></tr>';
			foreach ( (array) $rows as $row ) {
				if ( abs( $row['amount'] ) < 0.005 ) {
					continue;
				}
				$total += $row['amount'];
				printf(
					'<tr><td>%s %s</td><td class="num">%s</td></tr>',
					esc_html( $row['code'] ), esc_html( $row['name'] ),
					wp_kses_post( wceerp_money( $row['amount'] ) )
				);
			}
			foreach ( $extra as $name => $amount ) {
				$total += $amount;
				printf( '<tr><td>%s</td><td class="num">%s</td></tr>', esc_html( $name ), wp_kses_post( wceerp_money( $amount ) ) );
			}
			printf( '<tr class="wceerp-total"><th>%s</th><th class="num">%s</th></tr>', esc_html__( 'Total', 'wc-enterprise-erp' ), wp_kses_post( wceerp_money( $total ) ) );
			return $total;
		};
		?>
		<div class="wceerp-card wceerp-report">
			<?php $this->filter_form( 'bs', $from, $to ); ?>
			<h2><?php echo esc_html( wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ) ); ?> — <?php esc_html_e( 'Balance Sheet', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php printf( esc_html__( 'As at %s', 'wc-enterprise-erp' ), esc_html( $to ) ); ?></p>
			<table class="widefat wceerp-table">
				<tbody>
				<?php
				$assets = $section( $types['asset'] ?? array(), __( 'Assets', 'wc-enterprise-erp' ) );
				$liab   = $section( $types['liability'] ?? array(), __( 'Liabilities', 'wc-enterprise-erp' ) );
				$equity = $section(
					$types['equity'] ?? array(),
					__( 'Equity', 'wc-enterprise-erp' ),
					array( __( 'Retained earnings (current)', 'wc-enterprise-erp' ) => $net_profit )
				);
				$check  = $assets - ( $liab + $equity );
				?>
				<tr class="wceerp-grand <?php echo abs( $check ) < 0.01 ? 'is-good' : 'is-bad'; ?>">
					<th><?php esc_html_e( 'Assets − (Liabilities + Equity)', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php echo wp_kses_post( wceerp_money( $check ) ); ?></th>
				</tr>
				</tbody>
			</table>
			<?php if ( abs( $check ) >= 0.01 ) : ?>
				<p class="description"><?php esc_html_e( 'The sheet is out of balance — usually a manually posted journal touching only one side. Check the journal list.', 'wc-enterprise-erp' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function render_trial_balance() {
		list( $from, $to ) = $this->range();
		$rows = WCEERP_Accounting::trial_balance( $from, $to );

		$dr = 0;
		$cr = 0;
		?>
		<div class="wceerp-card wceerp-report">
			<?php $this->filter_form( 'tb', $from, $to ); ?>
			<h2><?php esc_html_e( 'Trial Balance', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php echo esc_html( $from . ' → ' . $to ); ?></p>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Debit', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Credit', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( (array) $rows as $row ) :
					$net = (float) $row->debit - (float) $row->credit;
					if ( abs( $net ) < 0.005 ) {
						continue;
					}
					$d = $net > 0 ? $net : 0;
					$c = $net < 0 ? -$net : 0;
					$dr += $d;
					$cr += $c;
					?>
					<tr>
						<td><code><?php echo esc_html( $row->code ); ?></code></td>
						<td><?php echo esc_html( $row->name ); ?></td>
						<td><span class="wceerp-badge is-<?php echo esc_attr( $row->type ); ?>"><?php echo esc_html( $row->type ); ?></span></td>
						<td class="num"><?php echo $d ? wp_kses_post( wceerp_money( $d ) ) : '—'; ?></td>
						<td class="num"><?php echo $c ? wp_kses_post( wceerp_money( $c ) ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr class="wceerp-grand <?php echo abs( $dr - $cr ) < 0.01 ? 'is-good' : 'is-bad'; ?>">
					<th colspan="3"><?php esc_html_e( 'Totals', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php echo wp_kses_post( wceerp_money( $dr ) ); ?></th>
					<th class="num"><?php echo wp_kses_post( wceerp_money( $cr ) ); ?></th>
				</tr></tfoot>
			</table>
		</div>
		<?php
	}

	protected function render_stock_valuation() {
		global $wpdb;
		$stock = wceerp_table( 'stock' );
		$w     = wceerp_table( 'warehouses' );
		$rows  = $wpdb->get_results(
			"SELECT s.product_id, s.qty, s.avg_cost, s.qty * s.avg_cost AS value, w.name AS warehouse
			 FROM $stock s LEFT JOIN $w w ON w.id = s.warehouse_id
			 WHERE s.qty <> 0 ORDER BY value DESC LIMIT 500"
		);
		$total = 0;
		?>
		<div class="wceerp-card wceerp-report">
			<h2><?php esc_html_e( 'Stock Valuation (moving average)', 'wc-enterprise-erp' ); ?></h2>
			<p><button type="button" class="button" onclick="window.print()"><?php esc_html_e( 'Print', 'wc-enterprise-erp' ); ?></button></p>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Avg cost', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Value', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( (array) $rows as $row ) :
					$total += (float) $row->value;
					?>
					<tr>
						<td><?php echo esc_html( get_the_title( $row->product_id ) ?: '#' . $row->product_id ); ?></td>
						<td><?php echo esc_html( $row->warehouse ); ?></td>
						<td class="num"><?php echo esc_html( wceerp_lakh_format( $row->qty, 0 ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $row->avg_cost ) ); ?></td>
						<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $row->value ) ); ?></strong></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr class="wceerp-grand">
					<th colspan="4"><?php esc_html_e( 'Total stock value', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php echo wp_kses_post( wceerp_money( $total ) ); ?></th>
				</tr></tfoot>
			</table>
		</div>
		<?php
	}
}
