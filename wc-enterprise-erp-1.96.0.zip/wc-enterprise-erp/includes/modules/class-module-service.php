<?php
/**
 * Module: Service Management — projects, AMC contracts, tickets.
 *
 * Recurring invoicing (AMC / monthly contracts): a daily cron finds
 * active contracts whose next_invoice_date has arrived and creates a
 * REAL pending WooCommerce order with a fee line for the contract
 * amount. When that order is paid/processed, the normal ERP bridge
 * posts revenue, VAT and dues — service income lives in the same ledger
 * as product sales, never a side spreadsheet.
 *
 * Tickets: subject/detail, priority, employee assignment, minute-level
 * time logging, open → in progress → resolved → closed.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Service extends WCEERP_Module {

	protected $id         = 'service';
	protected $title      = 'Service & Tickets';
	protected $capability = 'wceerp_manage_service';
	protected $tier       = 'business';
	protected $order      = 36;

	public function __construct() {
		$this->title = __( 'Service & Tickets', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_project_save', array( $this, 'handle_project_save' ) );
		add_action( 'admin_post_wceerp_project_status', array( $this, 'handle_project_status' ) );
		add_action( 'admin_post_wceerp_ticket_save', array( $this, 'handle_ticket_save' ) );
		add_action( 'admin_post_wceerp_ticket_update', array( $this, 'handle_ticket_update' ) );

		add_action( 'wceerp_service_invoices', array( __CLASS__, 'cron_recurring_invoices' ) );
		if ( ! wp_next_scheduled( 'wceerp_service_invoices' ) ) {
			wp_schedule_event( strtotime( 'tomorrow 03:00' ), 'daily', 'wceerp_service_invoices' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Recurring invoices.
	 * ------------------------------------------------------------------- */

	public static function cron_recurring_invoices() {
		global $wpdb;
		$table = wceerp_table( 'service_projects' );
		$due   = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table
			 WHERE status='active' AND billing IN ('monthly','yearly')
			   AND next_invoice_date IS NOT NULL AND next_invoice_date <= %s
			 LIMIT 25",
			current_time( 'Y-m-d' )
		) );
		foreach ( (array) $due as $project ) {
			$order = wc_create_order( array( 'created_via' => 'wceerp_service' ) );
			if ( is_wp_error( $order ) ) {
				continue;
			}
			$period = 'monthly' === $project->billing ? gmdate( 'F Y', strtotime( $project->next_invoice_date ) ) : gmdate( 'Y', strtotime( $project->next_invoice_date ) );
			$fee    = new WC_Order_Item_Fee();
			$fee->set_name( sprintf( '%s — %s (%s)', strtoupper( $project->kind ), $project->name, $period ) );
			$fee->set_total( (float) $project->amount );
			$order->add_item( $fee );
			$order->set_billing_first_name( $project->customer_name );
			$order->set_billing_phone( (string) $project->customer_phone );
			$order->update_meta_data( '_wceerp_service_project', (int) $project->id );
			$order->set_total( (float) $project->amount );
			$order->update_status( 'pending', __( 'Recurring service invoice', 'wc-enterprise-erp' ) );
			$order->save();

			$next = 'monthly' === $project->billing
				? gmdate( 'Y-m-d', strtotime( $project->next_invoice_date . ' +1 month' ) )
				: gmdate( 'Y-m-d', strtotime( $project->next_invoice_date . ' +1 year' ) );
			$wpdb->update( $table, array( 'next_invoice_date' => $next ), array( 'id' => $project->id ) );

			if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
				WCEERP_Module_Notifications::add(
					'service',
					sprintf( __( 'Invoice raised — %s', 'wc-enterprise-erp' ), $project->name ),
					sprintf( __( 'Order #%1$d for %2$s (%3$s). Collect and mark paid; the books follow automatically.', 'wc-enterprise-erp' ), $order->get_id(), wp_strip_all_tags( wceerp_money( $project->amount ) ), $period ),
					admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' )
				);
			}
			wceerp_log( 'service', 'invoice', (int) $project->id, 'order ' . $order->get_id() );
		}
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_project_save() {
		$this->verify_nonce( 'wceerp_project_save' );
		global $wpdb;
		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$customer = sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) );
		if ( ! $name || ! $customer ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'projects', 'error' => 1 ) ) );
			exit;
		}
		$billing = in_array( $_POST['billing'] ?? '', array( 'one_time', 'monthly', 'yearly' ), true ) ? $_POST['billing'] : 'one_time';
		$wpdb->insert( wceerp_table( 'service_projects' ), array(
			'doc_no'               => wceerp_next_doc_number( 'srv' ),
			'name'                 => $name,
			'kind'                 => in_array( $_POST['kind'] ?? '', array( 'project', 'contract', 'amc' ), true ) ? $_POST['kind'] : 'project',
			'customer_name'        => $customer,
			'customer_phone'       => sanitize_text_field( wp_unslash( $_POST['customer_phone'] ?? '' ) ),
			'amount'               => wceerp_dec( $_POST['amount'] ?? 0 ),
			'billing'              => $billing,
			'start_date'           => ! empty( $_POST['start_date'] ) ? sanitize_text_field( $_POST['start_date'] ) : null,
			'end_date'             => ! empty( $_POST['end_date'] ) ? sanitize_text_field( $_POST['end_date'] ) : null,
			'next_invoice_date'    => ( 'one_time' !== $billing && ! empty( $_POST['next_invoice_date'] ) ) ? sanitize_text_field( $_POST['next_invoice_date'] ) : null,
			'assigned_employee_id' => (int) ( $_POST['assigned_employee_id'] ?? 0 ) ?: null,
			'status'               => 'active',
			'note'                 => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'           => current_time( 'mysql' ),
		) );
		wceerp_log( 'service', 'project_create', (int) $wpdb->insert_id, $name );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'projects', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_project_status() {
		$this->verify_nonce( 'wceerp_project_status' );
		global $wpdb;
		$id = (int) ( $_POST['project_id'] ?? 0 );
		$to = in_array( $_POST['to'] ?? '', array( 'active', 'completed', 'cancelled' ), true ) ? $_POST['to'] : 'active';
		if ( $id ) {
			$wpdb->update( wceerp_table( 'service_projects' ), array( 'status' => $to ), array( 'id' => $id ) );
			wceerp_log( 'service', 'project_status', $id, $to );
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'projects', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_ticket_save() {
		$this->verify_nonce( 'wceerp_ticket_save' );
		global $wpdb;
		$subject  = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
		$customer = sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) );
		if ( ! $subject || ! $customer ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => 1 ) ) );
			exit;
		}
		$wpdb->insert( wceerp_table( 'service_tickets' ), array(
			'doc_no'               => wceerp_next_doc_number( 'tkt' ),
			'project_id'           => (int) ( $_POST['project_id'] ?? 0 ) ?: null,
			'customer_name'        => $customer,
			'phone'                => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'subject'              => $subject,
			'detail'               => sanitize_textarea_field( wp_unslash( $_POST['detail'] ?? '' ) ),
			'priority'             => in_array( $_POST['priority'] ?? '', array( 'low', 'normal', 'high' ), true ) ? $_POST['priority'] : 'normal',
			'status'               => 'open',
			'assigned_employee_id' => (int) ( $_POST['assigned_employee_id'] ?? 0 ) ?: null,
			'created_at'           => current_time( 'mysql' ),
		) );
		wceerp_log( 'service', 'ticket_create', (int) $wpdb->insert_id, $subject );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function handle_ticket_update() {
		$this->verify_nonce( 'wceerp_ticket_update' );
		global $wpdb;
		$id     = (int) ( $_POST['ticket_id'] ?? 0 );
		$ticket = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'service_tickets' ) . ' WHERE id=%d', $id ) );
		if ( $ticket ) {
			$update  = array();
			$status  = sanitize_key( $_POST['status'] ?? '' );
			if ( in_array( $status, array( 'open', 'in_progress', 'resolved', 'closed' ), true ) && $status !== $ticket->status ) {
				$update['status'] = $status;
				if ( in_array( $status, array( 'resolved', 'closed' ), true ) && ! $ticket->resolved_at ) {
					$update['resolved_at'] = current_time( 'mysql' );
				}
			}
			$minutes = (int) ( $_POST['add_minutes'] ?? 0 );
			if ( $minutes > 0 ) {
				$update['minutes_logged'] = (int) $ticket->minutes_logged + $minutes;
			}
			if ( isset( $_POST['assigned_employee_id'] ) ) {
				$update['assigned_employee_id'] = (int) $_POST['assigned_employee_id'] ?: null;
			}
			if ( $update ) {
				$wpdb->update( wceerp_table( 'service_tickets' ), $update, array( 'id' => $id ) );
				wceerp_log( 'service', 'ticket_update', $id, $status ?: ( '+' . $minutes . 'm' ) );
			}
		}
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	protected function employees_options( $selected = 0 ) {
		global $wpdb;
		$rows = class_exists( 'WCEERP_Module_HR' )
			? $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'employees' ) . " WHERE status='active' ORDER BY name" )
			: array();
		echo '<option value="0">' . esc_html__( '— unassigned —', 'wc-enterprise-erp' ) . '</option>';
		foreach ( (array) $rows as $employee ) {
			printf( '<option value="%d" %s>%s</option>', (int) $employee->id, selected( $selected, $employee->id, false ), esc_html( $employee->name ) );
		}
	}

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'tickets' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Service & Tickets', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'tickets'  => __( 'Tickets', 'wc-enterprise-erp' ),
					'projects' => __( 'Projects & AMC', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), $tab === $slug ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>
			<?php 'projects' === $tab ? $this->tab_projects() : $this->tab_tickets(); ?>
		</div>
		<?php
	}

	protected function tab_projects() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'service_projects' ) . " ORDER BY status='cancelled', status='completed', id DESC LIMIT 60" );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'New project / contract / AMC', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_project_save">
					<?php wp_nonce_field( 'wceerp_project_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="name" class="regular-text" required placeholder="<?php esc_attr_e( 'e.g. Website AMC — Rahman Traders', 'wc-enterprise-erp' ); ?>"></td></tr>
						<tr><th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th>
							<td><select name="kind"><option value="project"><?php esc_html_e( 'Project', 'wc-enterprise-erp' ); ?></option><option value="contract"><?php esc_html_e( 'Contract', 'wc-enterprise-erp' ); ?></option><option value="amc">AMC</option></select></td></tr>
						<tr><th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="customer_name" required placeholder="<?php esc_attr_e( 'Name', 'wc-enterprise-erp' ); ?>"> <input type="text" name="customer_phone" placeholder="01…"></td></tr>
						<tr><th><?php esc_html_e( 'Amount & billing', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" step="0.01" min="0" name="amount" required>
								<select name="billing"><option value="one_time"><?php esc_html_e( 'One time', 'wc-enterprise-erp' ); ?></option><option value="monthly"><?php esc_html_e( 'Monthly', 'wc-enterprise-erp' ); ?></option><option value="yearly"><?php esc_html_e( 'Yearly', 'wc-enterprise-erp' ); ?></option></select></td></tr>
						<tr><th><?php esc_html_e( 'First invoice date (recurring)', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="next_invoice_date">
							<p class="description"><?php esc_html_e( 'From this date, a pending WooCommerce order is raised automatically each month/year — revenue posts to the books when it\'s marked paid.', 'wc-enterprise-erp' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Start — End', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="start_date"> <input type="date" name="end_date"></td></tr>
						<tr><th><?php esc_html_e( 'Assigned to', 'wc-enterprise-erp' ); ?></th>
							<td><select name="assigned_employee_id"><?php $this->employees_options(); ?></select></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Create', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Projects & contracts', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Next invoice', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'Nothing yet.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $project ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $project->name ); ?></strong> <span class="wceerp-badge"><?php echo esc_html( $project->kind ); ?></span><br><code><?php echo esc_html( $project->doc_no ); ?></code></td>
							<td><?php echo esc_html( $project->customer_name ); ?><br><small><?php echo esc_html( $project->customer_phone ); ?></small></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $project->amount ) ); ?><br><small><?php echo esc_html( str_replace( '_', ' ', $project->billing ) ); ?></small></td>
							<td><?php echo esc_html( $project->next_invoice_date ?: '—' ); ?></td>
							<td>
								<span class="wceerp-badge is-<?php echo esc_attr( 'active' === $project->status ? 'active' : ( 'completed' === $project->status ? 'completed' : 'rejected' ) ); ?>"><?php echo esc_html( $project->status ); ?></span>
								<?php if ( 'active' === $project->status ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
									<input type="hidden" name="action" value="wceerp_project_status">
									<input type="hidden" name="project_id" value="<?php echo (int) $project->id; ?>">
									<?php wp_nonce_field( 'wceerp_project_status' ); ?>
									<button class="button-link" name="to" value="completed"><?php esc_html_e( 'complete', 'wc-enterprise-erp' ); ?></button>
									<button class="button-link wceerp-danger" name="to" value="cancelled"><?php esc_html_e( 'cancel', 'wc-enterprise-erp' ); ?></button>
								</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_tickets() {
		global $wpdb;
		$status   = sanitize_key( $_GET['status'] ?? '' );
		$where    = $status ? $wpdb->prepare( 'WHERE t.status=%s', $status ) : "WHERE t.status <> 'closed'";
		$rows     = $wpdb->get_results(
			'SELECT t.*, p.name AS project_name, e.name AS employee_name
			 FROM ' . wceerp_table( 'service_tickets' ) . ' t
			 LEFT JOIN ' . wceerp_table( 'service_projects' ) . ' p ON p.id = t.project_id
			 LEFT JOIN ' . wceerp_table( 'employees' ) . " e ON e.id = t.assigned_employee_id
			 $where ORDER BY FIELD(t.priority,'high','normal','low'), t.id DESC LIMIT 80"
		);
		$projects = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'service_projects' ) . " WHERE status='active' ORDER BY name" );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'New ticket', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_ticket_save">
					<?php wp_nonce_field( 'wceerp_ticket_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="customer_name" required> <input type="text" name="phone" placeholder="01…"></td></tr>
						<tr><th><?php esc_html_e( 'Subject', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="subject" class="regular-text" required></td></tr>
						<tr><th><?php esc_html_e( 'Detail', 'wc-enterprise-erp' ); ?></th><td><textarea name="detail" rows="3" class="large-text"></textarea></td></tr>
						<tr><th><?php esc_html_e( 'Project / AMC', 'wc-enterprise-erp' ); ?></th>
							<td><select name="project_id"><option value="0">—</option>
								<?php foreach ( (array) $projects as $project ) : ?>
									<option value="<?php echo (int) $project->id; ?>"><?php echo esc_html( $project->name ); ?></option>
								<?php endforeach; ?>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'Priority', 'wc-enterprise-erp' ); ?></th>
							<td><select name="priority"><option value="low">Low</option><option value="normal" selected>Normal</option><option value="high">High</option></select></td></tr>
						<tr><th><?php esc_html_e( 'Assign to', 'wc-enterprise-erp' ); ?></th>
							<td><select name="assigned_employee_id"><?php $this->employees_options(); ?></select></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Open ticket', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Tickets', 'wc-enterprise-erp' ); ?></h2>
				<form method="get" class="wceerp-filter">
					<input type="hidden" name="page" value="wceerp-service">
					<select name="status">
						<option value=""><?php esc_html_e( 'Open + in progress + resolved', 'wc-enterprise-erp' ); ?></option>
						<?php foreach ( array( 'open', 'in_progress', 'resolved', 'closed' ) as $option ) : ?>
							<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $status, $option ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $option ) ) ); ?></option>
						<?php endforeach; ?>
					</select>
					<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
				</form>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Ticket', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Assigned', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Time', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Update', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No tickets here.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $ticket ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $ticket->subject ); ?></strong>
								<span class="wceerp-badge is-<?php echo esc_attr( 'high' === $ticket->priority ? 'rejected' : ( 'low' === $ticket->priority ? 'closed' : 'open' ) ); ?>"><?php echo esc_html( $ticket->priority ); ?></span><br>
								<small><code><?php echo esc_html( $ticket->doc_no ); ?></code> · <?php echo esc_html( $ticket->customer_name ); ?><?php echo $ticket->project_name ? ' · ' . esc_html( $ticket->project_name ) : ''; ?></small>
							</td>
							<td><?php echo esc_html( $ticket->employee_name ?: '—' ); ?></td>
							<td><?php echo esc_html( floor( $ticket->minutes_logged / 60 ) . 'h ' . ( $ticket->minutes_logged % 60 ) . 'm' ); ?></td>
							<td>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;flex-wrap:wrap;align-items:center">
									<input type="hidden" name="action" value="wceerp_ticket_update">
									<input type="hidden" name="ticket_id" value="<?php echo (int) $ticket->id; ?>">
									<?php wp_nonce_field( 'wceerp_ticket_update' ); ?>
									<select name="status">
										<?php foreach ( array( 'open', 'in_progress', 'resolved', 'closed' ) as $option ) : ?>
											<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $ticket->status, $option ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $option ) ) ); ?></option>
										<?php endforeach; ?>
									</select>
									<input type="number" name="add_minutes" min="0" placeholder="+min" style="width:66px">
									<button class="button button-small"><?php esc_html_e( 'Save', 'wc-enterprise-erp' ); ?></button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
}
