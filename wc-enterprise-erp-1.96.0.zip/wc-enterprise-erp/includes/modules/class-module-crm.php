<?php
/**
 * Module: CRM — leads, pipeline, follow-ups.
 *
 * Pipeline stages: new → contacted → qualified → proposal → won / lost.
 * Every touch (call, meeting, WhatsApp, email, note) is logged against
 * the lead. Follow-ups due today raise an ERP notification each morning.
 *
 * WhatsApp, honestly: one-click wa.me chat links per lead (works with
 * any WhatsApp/WhatsApp Business phone). The official Business API needs
 * a Meta BSP account and belongs in a dedicated integration — roadmap,
 * not pretense.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_CRM extends WCEERP_Module {

	protected $id         = 'crm';
	protected $title      = 'CRM';
	protected $capability = 'wceerp_manage_crm';
	protected $tier       = 'business';
	protected $order      = 34;

	const STAGES = array( 'new', 'contacted', 'qualified', 'proposal', 'won', 'lost' );

	public function __construct() {
		$this->title = __( 'CRM', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_lead_save', array( $this, 'handle_lead_save' ) );
		add_action( 'admin_post_wceerp_lead_update', array( $this, 'handle_lead_update' ) );
		add_action( 'admin_post_wceerp_lead_activity', array( $this, 'handle_activity' ) );

		add_action( 'wceerp_crm_followups', array( __CLASS__, 'cron_followups' ) );
		if ( ! wp_next_scheduled( 'wceerp_crm_followups' ) ) {
			wp_schedule_event( strtotime( 'tomorrow 08:00' ), 'daily', 'wceerp_crm_followups' );
		}
	}

	public static function cron_followups() {
		global $wpdb;
		$due = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'leads' ) . " WHERE next_follow_up <= %s AND stage NOT IN ('won','lost') LIMIT 30",
			current_time( 'Y-m-d' )
		) );
		if ( $due && class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'crm',
				sprintf( _n( '%d lead needs a follow-up today', '%d leads need a follow-up today', count( $due ), 'wc-enterprise-erp' ), count( $due ) ),
				implode( ', ', array_map( function ( $lead ) { return $lead->name; }, array_slice( $due, 0, 5 ) ) ),
				admin_url( 'admin.php?page=wceerp-crm&tab=followups' )
			);
		}
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_lead_save() {
		$this->verify_nonce( 'wceerp_lead_save' );
		global $wpdb;
		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		if ( ! $name ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'new', 'error' => 1 ) ) );
			exit;
		}
		$wpdb->insert( wceerp_table( 'leads' ), array(
			'doc_no'         => wceerp_next_doc_number( 'lead' ),
			'name'           => $name,
			'company'        => sanitize_text_field( wp_unslash( $_POST['company'] ?? '' ) ),
			'phone'          => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'email'          => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
			'source'         => sanitize_text_field( wp_unslash( $_POST['source'] ?? '' ) ),
			'value_estimate' => wceerp_dec( $_POST['value_estimate'] ?? 0 ),
			'stage'          => 'new',
			'assigned_to'    => get_current_user_id(),
			'next_follow_up' => ! empty( $_POST['next_follow_up'] ) ? sanitize_text_field( $_POST['next_follow_up'] ) : null,
			'note'           => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'     => current_time( 'mysql' ),
		) );
		wceerp_log( 'crm', 'lead_create', (int) $wpdb->insert_id, $name );
		wp_safe_redirect( $this->admin_url( array( 'view' => (int) $wpdb->insert_id, 'updated' => 1 ) ) );
		exit;
	}

	public function handle_lead_update() {
		$this->verify_nonce( 'wceerp_lead_update' );
		global $wpdb;
		$id    = (int) ( $_POST['lead_id'] ?? 0 );
		$stage = sanitize_key( $_POST['stage'] ?? '' );
		if ( $id && in_array( $stage, self::STAGES, true ) ) {
			$update = array( 'stage' => $stage, 'updated_at' => current_time( 'mysql' ) );
			if ( isset( $_POST['next_follow_up'] ) ) {
				$update['next_follow_up'] = ! empty( $_POST['next_follow_up'] ) ? sanitize_text_field( $_POST['next_follow_up'] ) : null;
			}
			if ( 'won' === $stage && ! empty( $_POST['won_order_id'] ) ) {
				$update['won_order_id'] = (int) $_POST['won_order_id'];
			}
			$wpdb->update( wceerp_table( 'leads' ), $update, array( 'id' => $id ) );
			wceerp_log( 'crm', 'lead_stage', $id, $stage );
		}
		wp_safe_redirect( $this->admin_url( array( 'view' => $id, 'updated' => 1 ) ) );
		exit;
	}

	public function handle_activity() {
		$this->verify_nonce( 'wceerp_lead_activity' );
		global $wpdb;
		$lead_id = (int) ( $_POST['lead_id'] ?? 0 );
		$summary = sanitize_text_field( wp_unslash( $_POST['summary'] ?? '' ) );
		$kind    = sanitize_key( $_POST['kind'] ?? 'note' );
		if ( $lead_id && $summary ) {
			$wpdb->insert( wceerp_table( 'crm_activities' ), array(
				'lead_id'    => $lead_id,
				'kind'       => in_array( $kind, array( 'call', 'meeting', 'whatsapp', 'email', 'note' ), true ) ? $kind : 'note',
				'summary'    => $summary,
				'user_id'    => get_current_user_id(),
				'created_at' => current_time( 'mysql' ),
			) );
		}
		wp_safe_redirect( $this->admin_url( array( 'view' => $lead_id, 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab  = sanitize_key( $_GET['tab'] ?? 'pipeline' );
		$view = (int) ( $_GET['view'] ?? 0 );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'CRM', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'pipeline'  => __( 'Pipeline', 'wc-enterprise-erp' ),
					'new'       => __( 'New lead', 'wc-enterprise-erp' ),
					'followups' => __( 'Follow-ups due', 'wc-enterprise-erp' ),
					'report'    => __( 'Conversion report', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), ( $tab === $slug && ! $view ) ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>
			<?php
			if ( $view ) {
				$this->render_lead( $view );
			} elseif ( 'new' === $tab ) {
				$this->render_new();
			} elseif ( 'followups' === $tab ) {
				$this->render_followups();
			} elseif ( 'report' === $tab ) {
				$this->render_report();
			} else {
				$this->render_pipeline();
			}
			?>
		</div>
		<?php
	}

	protected function render_pipeline() {
		global $wpdb;
		$leads = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'leads' ) . ' ORDER BY updated_at DESC, id DESC LIMIT 300' );
		$cols  = array_fill_keys( self::STAGES, array() );
		foreach ( (array) $leads as $lead ) {
			$cols[ $lead->stage ][] = $lead;
		}
		?>
		<div class="wceerp-pipeline">
			<?php foreach ( self::STAGES as $stage ) :
				$value = 0;
				foreach ( $cols[ $stage ] as $lead ) {
					$value += (float) $lead->value_estimate;
				}
				?>
				<div class="wceerp-stage <?php echo esc_attr( 'is-' . $stage ); ?>">
					<h3><?php echo esc_html( ucfirst( $stage ) ); ?> <span><?php echo count( $cols[ $stage ] ); ?> · <?php echo wp_kses_post( wceerp_money( $value ) ); ?></span></h3>
					<?php foreach ( array_slice( $cols[ $stage ], 0, 15 ) as $lead ) : ?>
						<a class="wceerp-lead-card" href="<?php echo esc_url( $this->admin_url( array( 'view' => $lead->id ) ) ); ?>">
							<b><?php echo esc_html( $lead->name ); ?></b>
							<?php if ( $lead->company ) : ?><small><?php echo esc_html( $lead->company ); ?></small><?php endif; ?>
							<span><?php echo wp_kses_post( wceerp_money( $lead->value_estimate ) ); ?></span>
							<?php if ( $lead->next_follow_up && $lead->next_follow_up <= current_time( 'Y-m-d' ) && ! in_array( $lead->stage, array( 'won', 'lost' ), true ) ) : ?>
								<em>⏰ <?php echo esc_html( $lead->next_follow_up ); ?></em>
							<?php endif; ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	protected function render_new() {
		?>
		<div class="wceerp-card" style="max-width:640px">
			<h2><?php esc_html_e( 'New lead', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_lead_save">
				<?php wp_nonce_field( 'wceerp_lead_save' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="name" class="regular-text" required></td></tr>
					<tr><th><?php esc_html_e( 'Company', 'wc-enterprise-erp' ); ?></th><td><input type="text" name="company" class="regular-text"></td></tr>
					<tr><th><?php esc_html_e( 'Phone / Email', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="phone" placeholder="01…"> <input type="email" name="email" placeholder="email"></td></tr>
					<tr><th><?php esc_html_e( 'Source', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="source" placeholder="<?php esc_attr_e( 'Facebook / referral / walk-in…', 'wc-enterprise-erp' ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Deal value estimate', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0" name="value_estimate" value="0"></td></tr>
					<tr><th><?php esc_html_e( 'Next follow-up', 'wc-enterprise-erp' ); ?></th><td><input type="date" name="next_follow_up"></td></tr>
					<tr><th><?php esc_html_e( 'Notes', 'wc-enterprise-erp' ); ?></th><td><textarea name="note" rows="3" class="large-text"></textarea></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Create lead', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_lead( $lead_id ) {
		global $wpdb;
		$lead = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'leads' ) . ' WHERE id=%d', $lead_id ) );
		if ( ! $lead ) {
			echo '<p>' . esc_html__( 'Lead not found.', 'wc-enterprise-erp' ) . '</p>';
			return;
		}
		$activities = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'crm_activities' ) . ' WHERE lead_id=%d ORDER BY id DESC LIMIT 50', $lead_id ) );
		$wa         = $lead->phone ? 'https://wa.me/' . preg_replace( '/^0/', '880', preg_replace( '/\D/', '', $lead->phone ) ) : '';
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php echo esc_html( $lead->name ); ?> <span class="wceerp-badge is-<?php echo esc_attr( $lead->stage ); ?>"><?php echo esc_html( $lead->stage ); ?></span></h2>
				<p>
					<?php if ( $lead->company ) : ?><strong><?php echo esc_html( $lead->company ); ?></strong><br><?php endif; ?>
					<?php echo esc_html( $lead->phone ); ?>
					<?php if ( $wa ) : ?> · <a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener">💬 <?php esc_html_e( 'WhatsApp', 'wc-enterprise-erp' ); ?></a><?php endif; ?>
					<?php if ( $lead->email ) : ?> · <a href="mailto:<?php echo esc_attr( $lead->email ); ?>"><?php echo esc_html( $lead->email ); ?></a><?php endif; ?>
					<br><small><?php printf( esc_html__( 'Source: %1$s · Estimated value: %2$s', 'wc-enterprise-erp' ), esc_html( $lead->source ?: '—' ), wp_kses_post( wceerp_money( $lead->value_estimate ) ) ); ?></small>
				</p>
				<?php if ( $lead->note ) : ?><p style="background:#fbf8ee;padding:10px;border-radius:6px"><?php echo esc_html( $lead->note ); ?></p><?php endif; ?>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_lead_update">
					<input type="hidden" name="lead_id" value="<?php echo (int) $lead_id; ?>">
					<?php wp_nonce_field( 'wceerp_lead_update' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Stage', 'wc-enterprise-erp' ); ?></th>
							<td><select name="stage">
								<?php foreach ( self::STAGES as $stage ) : ?>
									<option value="<?php echo esc_attr( $stage ); ?>" <?php selected( $lead->stage, $stage ); ?>><?php echo esc_html( ucfirst( $stage ) ); ?></option>
								<?php endforeach; ?>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'Next follow-up', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="next_follow_up" value="<?php echo esc_attr( $lead->next_follow_up ); ?>"></td></tr>
						<tr><th><?php esc_html_e( 'Won — order # (optional)', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" name="won_order_id" min="1" value="<?php echo $lead->won_order_id ? (int) $lead->won_order_id : ''; ?>"></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Update lead', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

			<div class="wceerp-card">
				<h3><?php esc_html_e( 'Log an activity', 'wc-enterprise-erp' ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:6px;flex-wrap:wrap">
					<input type="hidden" name="action" value="wceerp_lead_activity">
					<input type="hidden" name="lead_id" value="<?php echo (int) $lead_id; ?>">
					<?php wp_nonce_field( 'wceerp_lead_activity' ); ?>
					<select name="kind">
						<option value="call"><?php esc_html_e( 'Call', 'wc-enterprise-erp' ); ?></option>
						<option value="meeting"><?php esc_html_e( 'Meeting', 'wc-enterprise-erp' ); ?></option>
						<option value="whatsapp">WhatsApp</option>
						<option value="email">Email</option>
						<option value="note"><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></option>
					</select>
					<input type="text" name="summary" style="flex:1;min-width:200px" placeholder="<?php esc_attr_e( 'What happened?', 'wc-enterprise-erp' ); ?>" required>
					<button class="button button-primary"><?php esc_html_e( 'Log', 'wc-enterprise-erp' ); ?></button>
				</form>

				<h3 style="margin-top:16px"><?php esc_html_e( 'History', 'wc-enterprise-erp' ); ?></h3>
				<?php if ( ! $activities ) : ?><p class="description"><?php esc_html_e( 'No activity yet.', 'wc-enterprise-erp' ); ?></p><?php endif; ?>
				<?php foreach ( (array) $activities as $activity ) :
					$who = get_userdata( $activity->user_id );
					?>
					<div style="padding:8px 0;border-bottom:1px dashed #ece7d8">
						<span class="wceerp-badge"><?php echo esc_html( $activity->kind ); ?></span>
						<?php echo esc_html( $activity->summary ); ?><br>
						<small style="color:#888"><?php echo esc_html( $activity->created_at . ' · ' . ( $who ? $who->display_name : '' ) ); ?></small>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	protected function render_followups() {
		global $wpdb;
		$due = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'leads' ) . " WHERE next_follow_up <= %s AND stage NOT IN ('won','lost') ORDER BY next_follow_up LIMIT 100",
			current_time( 'Y-m-d' )
		) );
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Follow-ups due', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped wceerp-table">
				<thead><tr><th><?php esc_html_e( 'Due', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Lead', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Stage', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Value', 'wc-enterprise-erp' ); ?></th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $due ) : ?>
					<tr><td colspan="5"><?php esc_html_e( 'Nothing overdue — inbox zero!', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $due as $lead ) : ?>
					<tr>
						<td><strong style="color:#b32d2e"><?php echo esc_html( $lead->next_follow_up ); ?></strong></td>
						<td><?php echo esc_html( $lead->name . ( $lead->company ? ' — ' . $lead->company : '' ) ); ?><br><small><?php echo esc_html( $lead->phone ); ?></small></td>
						<td><span class="wceerp-badge is-<?php echo esc_attr( $lead->stage ); ?>"><?php echo esc_html( $lead->stage ); ?></span></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $lead->value_estimate ) ); ?></td>
						<td><a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'view' => $lead->id ) ) ); ?>"><?php esc_html_e( 'Open', 'wc-enterprise-erp' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	protected function render_report() {
		global $wpdb;
		$table = wceerp_table( 'leads' );
		$funnel = $wpdb->get_results( "SELECT stage, COUNT(*) n, COALESCE(SUM(value_estimate),0) v FROM $table GROUP BY stage" );
		$by_source = $wpdb->get_results( "SELECT COALESCE(NULLIF(source,''),'(unknown)') source, COUNT(*) n, SUM(stage='won') won FROM $table GROUP BY source ORDER BY n DESC LIMIT 12" );
		$won = $lost = $won_value = 0;
		$counts = array();
		foreach ( (array) $funnel as $row ) {
			$counts[ $row->stage ] = $row;
			if ( 'won' === $row->stage ) { $won = (int) $row->n; $won_value = (float) $row->v; }
			if ( 'lost' === $row->stage ) { $lost = (int) $row->n; }
		}
		$closed = $won + $lost;
		?>
		<div class="wceerp-kpis">
			<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Won', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $won; ?></strong></div>
			<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Lost', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $lost; ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Win rate (closed)', 'wc-enterprise-erp' ); ?></span><strong><?php echo $closed ? round( 100 * $won / $closed ) : 0; ?>%</strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Won value', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $won_value ) ); ?></strong></div>
		</div>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Funnel', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Stage', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Leads', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Pipeline value', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( self::STAGES as $stage ) :
						$row = $counts[ $stage ] ?? null;
						?>
						<tr>
							<td><span class="wceerp-badge is-<?php echo esc_attr( $stage ); ?>"><?php echo esc_html( $stage ); ?></span></td>
							<td class="num"><?php echo $row ? (int) $row->n : 0; ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $row ? $row->v : 0 ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Sources', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Source', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Leads', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Won', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( (array) $by_source as $row ) : ?>
						<tr><td><?php echo esc_html( $row->source ); ?></td><td class="num"><?php echo (int) $row->n; ?></td><td class="num"><?php echo (int) $row->won; ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
}
