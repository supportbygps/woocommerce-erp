<?php
/**
 * Module: Expenses.
 *
 * Records day-to-day business expenses by category (rent, utilities,
 * transport, marketing, salaries …). Every expense posts a balanced
 * double-entry journal — debit the category's expense account, credit
 * the money account it was paid from — so expenses flow straight into
 * the Profit & Loss and Trial Balance. No more ৳0 expense column.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Expenses extends WCEERP_Module {

	protected $id         = 'expenses';
	protected $title      = 'Expenses';
	protected $capability = 'wceerp_manage_expenses';
	protected $tier       = 'starter';
	protected $order      = 45;

	public function __construct() {
		$this->title = __( 'Expenses', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_expense_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_expense_delete', array( $this, 'handle_delete' ) );
		add_action( 'admin_post_wceerp_expense_category_save', array( $this, 'handle_category_save' ) );
	}

	/* ---------------------------------------------------------------------
	 * Money accounts available to pay an expense from.
	 * ------------------------------------------------------------------- */
	protected function money_accounts() {
		global $wpdb;
		$acc  = wceerp_table( 'accounts' );
		$rows = $wpdb->get_results( "SELECT code, name FROM $acc WHERE type = 'asset' AND subtype IN ('cash','bank','mobile_banking') AND status = 'active' ORDER BY code" );
		if ( ! $rows ) {
			// Fallback to the core money codes if subtypes aren't set.
			$rows = $wpdb->get_results( "SELECT code, name FROM $acc WHERE code IN ('1000','1010','1020','1021','1022') ORDER BY code" );
		}
		return $rows;
	}

	protected function categories( $only_active = true ) {
		global $wpdb;
		$t     = wceerp_table( 'expense_categories' );
		$where = $only_active ? 'WHERE is_active = 1' : '';
		return $wpdb->get_results( "SELECT * FROM $t $where ORDER BY name" );
	}

	/* ---------------------------------------------------------------------
	 * Save an expense + post its journal.
	 * ------------------------------------------------------------------- */
	public function handle_save() {
		$this->verify_nonce( 'wceerp_expense_save' );
		global $wpdb;

		$amount = wceerp_dec( $_POST['amount'] ?? 0 );
		$cat_id = (int) ( $_POST['category_id'] ?? 0 );
		$paid   = sanitize_text_field( wp_unslash( $_POST['paid_from'] ?? '1000' ) );
		$date   = sanitize_text_field( wp_unslash( $_POST['expense_date'] ?? current_time( 'Y-m-d' ) ) );
		$payee  = sanitize_text_field( wp_unslash( $_POST['payee'] ?? '' ) );
		$memo   = sanitize_text_field( wp_unslash( $_POST['memo'] ?? '' ) );

		$category = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . wceerp_table( 'expense_categories' ) . " WHERE id = %d", $cat_id ) );
		if ( ! $category || $amount <= 0 ) {
			$this->notice_redirect( 'error', __( 'Pick a category and enter an amount greater than zero.', 'wc-enterprise-erp' ) );
		}

		// Post the journal: Dr expense account, Cr money account.
		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $date,
				'ref_type'     => 'expense',
				'ref_id'       => 0,
				'memo'         => $category->name . ( $payee ? ' — ' . $payee : '' ) . ( $memo ? ' (' . $memo . ')' : '' ),
			),
			array(
				array( 'account' => $category->account_code, 'debit' => $amount, 'memo' => $memo ?: $category->name ),
				array( 'account' => $paid, 'credit' => $amount, 'memo' => __( 'Expense payment', 'wc-enterprise-erp' ) ),
			)
		);

		if ( is_wp_error( $journal ) ) {
			$this->notice_redirect( 'error', $journal->get_error_message() );
		}

		$inserted = $wpdb->insert( wceerp_table( 'expenses' ), array(
			'doc_no'       => wceerp_next_doc_number( 'expense' ),
			'category_id'  => $cat_id,
			'amount'       => $amount,
			'paid_from'    => $paid,
			'expense_date' => $date,
			'payee'        => $payee,
			'memo'         => $memo,
			'journal_id'   => (int) $journal,
			'created_by'   => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
		) );

		/* Reporting success on a failed insert is how an expense can post to
		 * the ledger and then not appear in the list -- the books move and
		 * the record does not. Surface the database's own message, and undo
		 * the journal so the two never disagree. */
		if ( false === $inserted ) {
			$db_error = $wpdb->last_error;
			WCEERP_Accounting::void( (int) $journal, __( 'Expense edited', 'wc-enterprise-erp' ) );
			wceerp_log( 'expenses', 'save_failed', 0, $db_error );
			$this->notice_redirect(
				'error',
				sprintf(
					/* translators: %s: database error. */
					__( 'The expense could not be saved and its journal has been voided. Database said: %s', 'wc-enterprise-erp' ),
					$db_error ? $db_error : __( 'no message returned — run ERP → Modules & Settings → System health.', 'wc-enterprise-erp' )
				)
			);
		}

		wceerp_log( 'expenses', 'saved', (int) $wpdb->insert_id, (string) $amount );
		$this->notice_redirect( 'success', __( 'Expense recorded and posted to the ledger.', 'wc-enterprise-erp' ) );
	}

	public function handle_delete() {
		$this->verify_nonce( 'wceerp_expense_delete' );
		global $wpdb;
		$id  = (int) ( $_POST['id'] ?? 0 );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . wceerp_table( 'expenses' ) . " WHERE id = %d", $id ) );
		if ( $row ) {
			// Void the journal so it drops out of the P&L / trial balance
			// while staying in the audit trail.
			if ( $row->journal_id ) {
				WCEERP_Accounting::void( (int) $row->journal_id, __( 'Expense deleted', 'wc-enterprise-erp' ) );
			}
			$wpdb->delete( wceerp_table( 'expenses' ), array( 'id' => $id ) );
			$this->notice_redirect( 'success', __( 'Expense deleted and its journal voided.', 'wc-enterprise-erp' ) );
		}
		$this->notice_redirect( 'error', __( 'Expense not found.', 'wc-enterprise-erp' ) );
	}

	public function handle_category_save() {
		$this->verify_nonce( 'wceerp_expense_category_save' );
		global $wpdb;
		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$code = sanitize_text_field( wp_unslash( $_POST['account_code'] ?? '5900' ) );
		if ( '' === $name ) {
			$this->notice_redirect( 'error', __( 'Category name is required.', 'wc-enterprise-erp' ), 'categories' );
		}
		$id = (int) ( $_POST['id'] ?? 0 );
		if ( $id ) {
			$wpdb->update( wceerp_table( 'expense_categories' ), array(
				'name'         => $name,
				'account_code' => $code,
				'is_active'    => empty( $_POST['is_active'] ) ? 0 : 1,
			), array( 'id' => $id ) );
		} else {
			$wpdb->insert( wceerp_table( 'expense_categories' ), array(
				'name'         => $name,
				'account_code' => $code,
				'is_active'    => 1,
				'created_at'   => current_time( 'mysql' ),
			) );
		}
		$this->notice_redirect( 'success', __( 'Category saved.', 'wc-enterprise-erp' ), 'categories' );
	}

	protected function notice_redirect( $type, $msg, $tab = '' ) {
		$args = array( 'page' => 'wceerp-expenses', 'wceerp_notice' => $type, 'm' => rawurlencode( $msg ) );
		if ( $tab ) {
			$args['tab'] = $tab;
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */
	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'list';
		if ( isset( $_GET['wceerp_notice'], $_GET['m'] ) ) {
			$cls = 'error' === $_GET['wceerp_notice'] ? 'notice-error' : 'notice-success';
			printf( '<div class="notice %s is-dismissible"><p>%s</p></div>', esc_attr( $cls ), esc_html( wp_unslash( $_GET['m'] ) ) );
		}
		echo '<div class="wrap wceerp-wrap">';
		echo '<h1>' . esc_html__( 'Expenses', 'wc-enterprise-erp' ) . '</h1>';

		$tabs = array(
			'list'       => __( 'Expenses', 'wc-enterprise-erp' ),
			'add'        => __( 'Add expense', 'wc-enterprise-erp' ),
			'categories' => __( 'Categories', 'wc-enterprise-erp' ),
		);
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $key => $label ) {
			printf(
				'<a href="%s" class="nav-tab %s">%s</a>',
				esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
				$tab === $key ? 'nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</h2>';

		if ( 'add' === $tab ) {
			$this->render_add();
		} elseif ( 'categories' === $tab ) {
			$this->render_categories();
		} else {
			$this->render_list();
		}
		echo '</div>';
	}

	protected function render_add() {
		$cats = $this->categories();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="max-width:640px">
			<input type="hidden" name="action" value="wceerp_expense_save">
			<?php wp_nonce_field( 'wceerp_expense_save' ); ?>
			<table class="form-table"><tbody>
				<tr><th><?php esc_html_e( 'Category', 'wc-enterprise-erp' ); ?></th>
					<td><select name="category_id" required>
						<option value=""><?php esc_html_e( '— select —', 'wc-enterprise-erp' ); ?></option>
						<?php foreach ( $cats as $c ) : ?>
							<option value="<?php echo (int) $c->id; ?>"><?php echo esc_html( $c->name ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php if ( ! $cats ) : ?><p class="description"><?php esc_html_e( 'No categories yet — add one under the Categories tab.', 'wc-enterprise-erp' ); ?></p><?php endif; ?></td></tr>
				<tr><th><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
					<td><input type="number" name="amount" step="0.01" min="0" required class="regular-text"></td></tr>
				<tr><th><?php esc_html_e( 'Paid from', 'wc-enterprise-erp' ); ?></th>
					<td><select name="paid_from">
						<?php foreach ( $this->money_accounts() as $m ) : ?>
							<option value="<?php echo esc_attr( $m->code ); ?>"><?php echo esc_html( $m->code . ' — ' . $m->name ); ?></option>
						<?php endforeach; ?>
					</select></td></tr>
				<tr><th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
					<td><input type="date" name="expense_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Payee (optional)', 'wc-enterprise-erp' ); ?></th>
					<td><input type="text" name="payee" class="regular-text" placeholder="<?php esc_attr_e( 'Who was paid', 'wc-enterprise-erp' ); ?>"></td></tr>
				<tr><th><?php esc_html_e( 'Note (optional)', 'wc-enterprise-erp' ); ?></th>
					<td><input type="text" name="memo" class="regular-text"></td></tr>
			</tbody></table>
			<?php submit_button( __( 'Record expense', 'wc-enterprise-erp' ) ); ?>
		</form>
		<?php
	}

	protected function render_list() {
		global $wpdb;
		$exp  = wceerp_table( 'expenses' );
		$cats = wceerp_table( 'expense_categories' );

		$f_cat  = (int) ( $_GET['category'] ?? 0 );
		$f_from = sanitize_text_field( $_GET['from'] ?? gmdate( 'Y-m-01' ) );
		$f_to   = sanitize_text_field( $_GET['to'] ?? gmdate( 'Y-m-d' ) );

		$where  = $wpdb->prepare( 'WHERE e.expense_date BETWEEN %s AND %s', $f_from, $f_to );
		if ( $f_cat ) {
			$where .= $wpdb->prepare( ' AND e.category_id = %d', $f_cat );
		}

		$rows  = $wpdb->get_results( "SELECT e.*, c.name AS category FROM $exp e LEFT JOIN $cats c ON c.id = e.category_id $where ORDER BY e.expense_date DESC, e.id DESC LIMIT 500" );
		$total = 0;
		foreach ( $rows as $r ) {
			$total += (float) $r->amount;
		}
		?>
		<form method="get" class="wceerp-card" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:14px">
			<input type="hidden" name="page" value="wceerp-expenses">
			<label><?php esc_html_e( 'Category', 'wc-enterprise-erp' ); ?><br>
				<select name="category">
					<option value="0"><?php esc_html_e( 'All', 'wc-enterprise-erp' ); ?></option>
					<?php foreach ( $this->categories( false ) as $c ) : ?>
						<option value="<?php echo (int) $c->id; ?>" <?php selected( $f_cat, $c->id ); ?>><?php echo esc_html( $c->name ); ?></option>
					<?php endforeach; ?>
				</select></label>
			<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $f_from ); ?>"></label>
			<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $f_to ); ?>"></label>
			<button class="button button-primary"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
		</form>

		<?php
		/* Courier charges are real expenses, but they are never typed in
		 * here — they arrive with a payout and post straight to the ledger.
		 * That left this screen showing a total far below what the business
		 * actually spent, and someone reasonably concluding the charges were
		 * not being counted at all. They were; they were just invisible in
		 * the one place people look for expenses.
		 *
		 * Read from the ledger for the same period, so the figures agree
		 * with the profit and loss rather than being counted a second way. */
		$courier_spend = array();
		if ( class_exists( 'WCEERP_Accounting' ) ) {
			foreach ( array( '5600', '5610', '5650' ) as $code ) {
				$acc = WCEERP_Accounting::resolve_account( $code );
				if ( ! $acc ) {
					continue;
				}
				$amount = 0;
				foreach ( (array) WCEERP_Accounting::ledger( $acc, $f_from, $f_to ) as $l ) {
					$amount += (float) $l->debit - (float) $l->credit;
				}
				if ( abs( $amount ) > 0.004 ) {
					$courier_spend[ $code ] = array( 'amount' => $amount, 'id' => $acc );
				}
			}
		}
		$courier_total = 0;
		foreach ( $courier_spend as $cs ) {
			$courier_total += $cs['amount'];
		}
		$labels = array(
			'5600' => __( 'Delivery charges', 'wc-enterprise-erp' ),
			'5610' => __( 'COD collection fees', 'wc-enterprise-erp' ),
			'5650' => __( 'Return charges', 'wc-enterprise-erp' ),
		);
		?>

		<div class="wceerp-kpis" style="margin-bottom:14px">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Recorded here', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $total ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Entries', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) count( $rows ); ?></strong></div>
			<?php if ( $courier_total > 0.004 ) : ?>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Courier charges', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $courier_total ) ); ?></strong>
					<em><?php esc_html_e( 'posted with payouts', 'wc-enterprise-erp' ); ?></em></div>
				<div class="wceerp-kpi is-warn"><span><?php esc_html_e( 'Spent in total', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $total + $courier_total ) ); ?></strong></div>
			<?php endif; ?>
		</div>

		<?php if ( $courier_spend ) : ?>
			<div class="wceerp-card" style="margin-bottom:14px">
				<h3 style="margin:0 0 4px"><?php esc_html_e( 'What couriers cost you', 'wc-enterprise-erp' ); ?></h3>
				<p class="description" style="margin-top:0">
					<?php esc_html_e( 'These are not entered by hand — they post automatically when you record a courier payment, so they never appear in the list below. They are in your profit and loss all the same.', 'wc-enterprise-erp' ); ?>
				</p>
				<table class="widefat striped" style="max-width:560px">
					<tbody>
					<?php foreach ( $courier_spend as $code => $cs ) : ?>
						<tr>
							<td>
								<a href="<?php echo esc_url( add_query_arg(
									array( 'page' => 'wceerp-accounting', 'tab' => 'ledger', 'account' => $cs['id'], 'from' => $f_from, 'to' => $f_to ),
									admin_url( 'admin.php' )
								) ); ?>"><?php echo esc_html( $labels[ $code ] ?? $code ); ?></a>
								<span class="wceerp-sub"><code><?php echo esc_html( $code ); ?></code></span>
							</td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $cs['amount'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Doc', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Category', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Payee', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
				<th></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No expenses in this range.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<td><code><?php echo esc_html( $r->doc_no ); ?></code></td>
						<td><?php echo esc_html( mysql2date( 'j M Y', $r->expense_date ) ); ?></td>
						<td><?php echo esc_html( $r->category ); ?></td>
						<td><?php echo esc_html( $r->payee ); ?></td>
						<td><?php echo esc_html( $r->memo ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $r->amount ) ); ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Delete and reverse this expense?', 'wc-enterprise-erp' ) ); ?>');" style="display:inline">
								<input type="hidden" name="action" value="wceerp_expense_delete">
								<input type="hidden" name="id" value="<?php echo (int) $r->id; ?>">
								<?php wp_nonce_field( 'wceerp_expense_delete' ); ?>
								<button class="button-link delete" style="color:#b32d2e"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>
		<?php
	}

	protected function render_categories() {
		global $wpdb;
		$acc  = wceerp_table( 'accounts' );
		$expense_accounts = $wpdb->get_results( "SELECT code, name FROM $acc WHERE type = 'expense' AND status = 'active' ORDER BY code" );
		?>
		<div style="display:flex;gap:24px;flex-wrap:wrap">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="max-width:420px">
				<h2><?php esc_html_e( 'Add / edit category', 'wc-enterprise-erp' ); ?></h2>
				<input type="hidden" name="action" value="wceerp_expense_category_save">
				<input type="hidden" name="id" value="0">
				<?php wp_nonce_field( 'wceerp_expense_category_save' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="name" class="regular-text" required></td></tr>
					<tr><th><?php esc_html_e( 'Posts to account', 'wc-enterprise-erp' ); ?></th>
						<td><select name="account_code">
							<?php foreach ( $expense_accounts as $a ) : ?>
								<option value="<?php echo esc_attr( $a->code ); ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Save category', 'wc-enterprise-erp' ) ); ?>
			</form>

			<div class="wceerp-card" style="flex:1;min-width:320px">
				<h2><?php esc_html_e( 'Categories', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $this->categories( false ) as $c ) : ?>
						<tr>
							<td><?php echo esc_html( $c->name ); ?></td>
							<td><code><?php echo esc_html( $c->account_code ); ?></code></td>
							<td><?php echo $c->is_active ? '✓' : '—'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
}
