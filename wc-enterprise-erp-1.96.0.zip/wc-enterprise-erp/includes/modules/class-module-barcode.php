<?php
/**
 * Module: Barcode, batch tracking and serial numbers.
 *
 * Barcode rendering uses Code 39 drawn as inline SVG — no external
 * libraries or image extensions required, prints crisply at any size.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Barcode extends WCEERP_Module {

	protected $id         = 'barcode';
	protected $title      = 'Barcode & Serials';
	protected $capability = 'wceerp_manage_inventory';
	protected $tier       = 'business';
	protected $order      = 45;

	public function __construct() {
		$this->title = __( 'Barcode & Serials', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_serials_add', array( $this, 'handle_serials_add' ) );
	}

	/* ---------------------------------------------------------------------
	 * Static API used by the WooCommerce bridge on sale posting.
	 * ------------------------------------------------------------------- */

	/**
	 * Mark up to $qty in-stock serials of a product as sold against an order.
	 * FIFO by id. Silently allocates fewer if not enough serials are tracked
	 * (not every product is serialised).
	 */
	public static function allocate_serials( $product_id, $warehouse_id, $qty, $order_id ) {
		global $wpdb;
		$table = wceerp_table( 'serials' );

		$ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT id FROM $table
			 WHERE product_id = %d AND warehouse_id = %d AND status = 'in_stock'
			 ORDER BY id ASC LIMIT %d",
			$product_id, $warehouse_id, max( 0, (int) $qty )
		) );

		foreach ( $ids as $id ) {
			$wpdb->update( $table, array( 'status' => 'sold', 'order_id' => (int) $order_id ), array( 'id' => (int) $id ) );
		}

		return count( $ids );
	}

	/* ---------------------------------------------------------------------
	 * Code 39 SVG generator.
	 * ------------------------------------------------------------------- */

	/**
	 * Encoding table: 9 elements per character, 1 = wide, 0 = narrow,
	 * alternating bar/space starting with a bar.
	 */
	protected static function code39_map() {
		return array(
			'0' => '000110100', '1' => '100100001', '2' => '001100001', '3' => '101100000',
			'4' => '000110001', '5' => '100110000', '6' => '001110000', '7' => '000100101',
			'8' => '100100100', '9' => '001100100', 'A' => '100001001', 'B' => '001001001',
			'C' => '101001000', 'D' => '000011001', 'E' => '100011000', 'F' => '001011000',
			'G' => '000001101', 'H' => '100001100', 'I' => '001001100', 'J' => '000011100',
			'K' => '100000011', 'L' => '001000011', 'M' => '101000010', 'N' => '000010011',
			'O' => '100010010', 'P' => '001010010', 'Q' => '000000111', 'R' => '100000110',
			'S' => '001000110', 'T' => '000010110', 'U' => '110000001', 'V' => '011000001',
			'W' => '111000000', 'X' => '010010001', 'Y' => '110010000', 'Z' => '011010000',
			'-' => '010000101', '.' => '110000100', ' ' => '011000100', '$' => '010101000',
			'/' => '010100010', '+' => '010001010', '%' => '000101010', '*' => '010010100',
		);
	}

	/**
	 * Render a Code 39 barcode as an SVG string.
	 */
	public static function barcode_svg( $text, $height = 50, $narrow = 2 ) {
		$map  = self::code39_map();
		$text = strtoupper( preg_replace( '/[^0-9A-Z\-\. \$\/\+%]/', '-', (string) $text ) );
		$code = '*' . $text . '*';
		$wide = $narrow * 3;

		// Compute total width first.
		$width = 0;
		foreach ( str_split( $code ) as $ch ) {
			foreach ( str_split( $map[ $ch ] ) as $el ) {
				$width += ( '1' === $el ) ? $wide : $narrow;
			}
			$width += $narrow; // inter-character gap.
		}

		$x    = 0;
		$bars = '';
		foreach ( str_split( $code ) as $ch ) {
			$is_bar = true;
			foreach ( str_split( $map[ $ch ] ) as $el ) {
				$w = ( '1' === $el ) ? $wide : $narrow;
				if ( $is_bar ) {
					$bars .= sprintf( '<rect x="%d" y="0" width="%d" height="%d" fill="#000"/>', $x, $w, $height );
				}
				$x     += $w;
				$is_bar = ! $is_bar;
			}
			$x += $narrow;
		}

		return sprintf(
			'<svg class="wceerp-barcode" xmlns="http://www.w3.org/2000/svg" width="%1$d" height="%2$d" viewBox="0 0 %1$d %2$d" shape-rendering="crispEdges">%3$s</svg>',
			$width, $height + 16, $bars
		) ;
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_serials_add() {
		$this->verify_nonce( 'wceerp_serials_add' );
		global $wpdb;
		$table = wceerp_table( 'serials' );

		$product_id   = (int) ( $_POST['product_id'] ?? 0 );
		$warehouse_id = (int) ( $_POST['warehouse_id'] ?? 0 );
		$batch_id     = (int) ( $_POST['batch_id'] ?? 0 );
		$raw          = sanitize_textarea_field( wp_unslash( $_POST['serials'] ?? '' ) );
		$serials      = array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $raw ) ) );

		$added = 0;
		foreach ( $serials as $serial ) {
			$exists = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM $table WHERE serial_no = %s AND product_id = %d", $serial, $product_id
			) );
			if ( $exists ) {
				continue;
			}
			$wpdb->insert( $table, array(
				'product_id'   => $product_id,
				'warehouse_id' => $warehouse_id,
				'batch_id'     => $batch_id ? $batch_id : null,
				'serial_no'    => $serial,
				'status'       => 'in_stock',
				'created_at'   => current_time( 'mysql' ),
			) );
			$added++;
		}

		wceerp_log( 'barcode', 'serials_add', $product_id, $added . ' serials' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'serials', 'updated' => $added ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'labels' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Barcode, Batches & Serial Numbers', 'wc-enterprise-erp' ) ) ); ?></h1>

			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'labels'  => __( 'Barcode labels', 'wc-enterprise-erp' ),
					'batches' => __( 'Batches', 'wc-enterprise-erp' ),
					'serials' => __( 'Serial numbers', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf(
						'<a href="%s" class="nav-tab %s">%s</a>',
						esc_url( $this->admin_url( array( 'tab' => $slug ) ) ),
						$tab === $slug ? 'nav-tab-active' : '',
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php
			if ( 'batches' === $tab ) {
				$this->render_batches();
			} elseif ( 'serials' === $tab ) {
				$this->render_serials();
			} else {
				$this->render_labels();
			}
			?>
		</div>
		<?php
	}

	protected function render_labels() {
		$product_id = (int) ( $_GET['product_id'] ?? 0 );
		$copies     = min( 100, max( 1, (int) ( $_GET['copies'] ?? 12 ) ) );
		$product    = $product_id ? wc_get_product( $product_id ) : null;
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Print product barcode labels', 'wc-enterprise-erp' ); ?></h2>
			<form method="get">
				<input type="hidden" name="page" value="wceerp-barcode">
				<input type="hidden" name="tab" value="labels">
				<table class="form-table"><tbody>
					<tr>
						<th><label for="wceerp-bc-product"><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></label></th>
						<td><?php wceerp_product_select( 'product_id', $product_id, array( 'required' => true, 'id' => 'wceerp-bc-product' ) ); ?>
						<p class="description"><?php esc_html_e( 'The label encodes the SKU when set, otherwise the product ID.', 'wc-enterprise-erp' ); ?></p></td>
					</tr>
					<tr>
						<th><label for="wceerp-bc-copies"><?php esc_html_e( 'Copies', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="number" id="wceerp-bc-copies" name="copies" value="<?php echo esc_attr( $copies ); ?>" min="1" max="100"></td>
					</tr>
				</tbody></table>
				<p><button class="button button-primary"><?php esc_html_e( 'Generate labels', 'wc-enterprise-erp' ); ?></button>
				<?php if ( $product ) : ?>
					<button type="button" class="button" onclick="window.print()"><?php esc_html_e( 'Print', 'wc-enterprise-erp' ); ?></button>
				<?php endif; ?></p>
			</form>
		</div>

		<?php if ( $product_id && ! $product ) : ?>
			<?php $this->notice( __( 'No product found with that ID.', 'wc-enterprise-erp' ), 'error' ); ?>
		<?php elseif ( $product ) :
			$code  = $product->get_sku() ? $product->get_sku() : (string) $product_id;
			$price = wceerp_money( (float) $product->get_price() );
			$svg   = self::barcode_svg( $code );
			?>
			<div class="wceerp-card wceerp-label-sheet">
				<?php for ( $i = 0; $i < $copies; $i++ ) : ?>
					<div class="wceerp-label">
						<div class="wceerp-label-name"><?php echo esc_html( wp_trim_words( $product->get_name(), 6, '…' ) ); ?></div>
						<?php echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG built from integers. ?>
						<div class="wceerp-label-code"><?php echo esc_html( $code ); ?> · <?php echo wp_kses_post( $price ); ?></div>
					</div>
				<?php endfor; ?>
			</div>
		<?php endif;
	}

	protected function render_batches() {
		global $wpdb;
		$table = wceerp_table( 'batches' );
		$w     = wceerp_table( 'warehouses' );
		$per_page = 50;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT b.*, w.name AS warehouse FROM $table b LEFT JOIN $w w ON w.id = b.warehouse_id ORDER BY b.exp_date IS NULL, b.exp_date ASC LIMIT %d OFFSET %d",
			$per_page, wceerp_offset( $per_page )
		) );
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Batches', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Batches are created automatically when you receive a purchase with a batch number. Rows are ordered by nearest expiry.', 'wc-enterprise-erp' ); ?></p>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Batch no.', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Unit cost', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Expiry', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No batches yet.', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $rows as $b ) :
					$expiring = $b->exp_date && strtotime( $b->exp_date ) < strtotime( '+30 days' );
					?>
					<tr>
						<td><strong><?php echo esc_html( $b->batch_no ); ?></strong></td>
						<td><?php echo esc_html( get_the_title( $b->product_id ) ?: '#' . $b->product_id ); ?></td>
						<td><?php echo esc_html( $b->warehouse ); ?></td>
						<td class="num"><?php echo esc_html( wceerp_lakh_format( $b->qty, 0 ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $b->unit_cost ) ); ?></td>
						<td><?php
							if ( $b->exp_date ) {
								printf( '<span class="wceerp-badge %s">%s</span>', $expiring ? 'is-out' : 'is-in', esc_html( $b->exp_date ) );
							} else {
								echo '—';
							}
						?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php wceerp_pagination( $total, $per_page ); ?>
		</div>
		<?php
	}

	protected function render_serials() {
		global $wpdb;
		$table  = wceerp_table( 'serials' );
		$w      = wceerp_table( 'warehouses' );
		$search = sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) );
		$where  = $search ? $wpdb->prepare( 'WHERE s.serial_no LIKE %s', '%' . $wpdb->esc_like( $search ) . '%' ) : '';
		$per_page = 50;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table s $where" );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.*, w.name AS warehouse FROM $table s LEFT JOIN $w w ON w.id = s.warehouse_id $where ORDER BY s.id DESC LIMIT %d OFFSET %d",
			$per_page, wceerp_offset( $per_page )
		) );
		$warehouses = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'warehouses' ) . " WHERE status='active' ORDER BY name" );

		if ( isset( $_GET['updated'] ) ) {
			/* translators: %d: number of serials added */
			$this->notice( sprintf( __( '%d serial numbers added.', 'wc-enterprise-erp' ), (int) $_GET['updated'] ) );
		}
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Add serial numbers', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_serials_add">
					<?php wp_nonce_field( 'wceerp_serials_add' ); ?>
					<table class="form-table"><tbody>
						<tr>
							<th><label><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></label></th>
							<td><?php wceerp_product_select( 'product_id', 0, array( 'required' => true ) ); ?></td>
						</tr>
						<tr>
							<th><label><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></label></th>
							<td><select name="warehouse_id" required>
								<?php foreach ( (array) $warehouses as $wh ) : ?>
									<option value="<?php echo (int) $wh->id; ?>"><?php echo esc_html( $wh->name ); ?></option>
								<?php endforeach; ?>
							</select></td>
						</tr>
						<tr>
							<th><label><?php esc_html_e( 'Serial numbers', 'wc-enterprise-erp' ); ?></label></th>
							<td><textarea name="serials" rows="6" class="large-text" placeholder="<?php esc_attr_e( 'One per line (or comma separated)', 'wc-enterprise-erp' ); ?>" required></textarea></td>
						</tr>
					</tbody></table>
					<p><button class="button button-primary"><?php esc_html_e( 'Add serials', 'wc-enterprise-erp' ); ?></button></p>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Serial lookup', 'wc-enterprise-erp' ); ?></h2>
				<form method="get" class="wceerp-filter">
					<input type="hidden" name="page" value="wceerp-barcode">
					<input type="hidden" name="tab" value="serials">
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search serial…', 'wc-enterprise-erp' ); ?>">
					<button class="button"><?php esc_html_e( 'Search', 'wc-enterprise-erp' ); ?></button>
				</form>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Serial', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No serials found.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $s ) : ?>
						<tr>
							<td><code><?php echo esc_html( $s->serial_no ); ?></code></td>
							<td><?php echo esc_html( get_the_title( $s->product_id ) ?: '#' . $s->product_id ); ?></td>
							<td><?php echo esc_html( $s->warehouse ); ?></td>
							<td><span class="wceerp-badge is-<?php echo esc_attr( 'in_stock' === $s->status ? 'in' : 'out' ); ?>"><?php echo esc_html( str_replace( '_', ' ', $s->status ) ); ?></span></td>
							<td><?php echo $s->order_id ? '<a href="' . esc_url( admin_url( 'post.php?post=' . (int) $s->order_id . '&action=edit' ) ) . '">#' . (int) $s->order_id . '</a>' : '—'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php wceerp_pagination( $total, $per_page ); ?>
			</div>
		</div>
		<?php
	}
}
