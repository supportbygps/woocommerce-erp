<?php
/**
 * Module: Manufacturing — bills of material and production orders.
 *
 * A completed production consumes component stock (at moving-average
 * cost), adds finished goods at the rolled-up unit cost, and posts an
 * overhead journal so factory cost lands in the books.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Manufacturing extends WCEERP_Module {

	protected $id         = 'manufacturing';
	protected $title      = 'Manufacturing';
	protected $capability = 'wceerp_manage_manufacturing';
	protected $tier       = 'enterprise';
	protected $order      = 40;

	public function __construct() {
		$this->title = __( 'Manufacturing', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_bom_save', array( $this, 'handle_bom_save' ) );
		add_action( 'admin_post_wceerp_production_run', array( $this, 'handle_production_run' ) );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_bom_save() {
		$this->verify_nonce( 'wceerp_bom_save' );
		global $wpdb;

		$bom = array(
			'product_id'    => (int) ( $_POST['product_id'] ?? 0 ),
			'name'          => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
			'output_qty'    => max( 0.0001, wceerp_dec( $_POST['output_qty'] ?? 1 ) ),
			'overhead_cost' => wceerp_dec( $_POST['overhead_cost'] ?? 0 ),
			'labour_cost'   => wceerp_dec( $_POST['labour_cost'] ?? 0 ),
			'status'        => 'active',
		);

		if ( ! $bom['product_id'] || ! $bom['name'] ) {
			wp_die( esc_html__( 'A BOM needs a finished product ID and a name.', 'wc-enterprise-erp' ) );
		}

		$bom['created_at'] = current_time( 'mysql' );
		$wpdb->insert( wceerp_table( 'boms' ), $bom );
		$bom_id = (int) $wpdb->insert_id;

		$components = isset( $_POST['component_id'] ) ? (array) $_POST['component_id'] : array();
		$qtys       = isset( $_POST['component_qty'] ) ? (array) $_POST['component_qty'] : array();
		$wastes     = isset( $_POST['component_wastage'] ) ? (array) $_POST['component_wastage'] : array();

		foreach ( $components as $i => $component_id ) {
			$component_id = (int) $component_id;
			$qty          = wceerp_dec( $qtys[ $i ] ?? 0 );
			if ( ! $component_id || $qty <= 0 ) {
				continue;
			}
			$wpdb->insert( wceerp_table( 'bom_items' ), array(
				'bom_id'       => $bom_id,
				'component_id' => $component_id,
				'qty'          => $qty,
				'wastage_pct'  => min( 99, max( 0, wceerp_dec( $wastes[ $i ] ?? 0 ) ) ),
			) );
		}

		wceerp_log( 'manufacturing', 'bom_save', $bom_id );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function handle_production_run() {
		$this->verify_nonce( 'wceerp_production_run' );
		global $wpdb;

		$bom_id       = (int) ( $_POST['bom_id'] ?? 0 );
		$warehouse_id = (int) ( $_POST['warehouse_id'] ?? 0 );
		$runs         = max( 0.0001, wceerp_dec( $_POST['qty'] ?? 1 ) ); // number of BOM output batches.
		$date         = sanitize_text_field( $_POST['production_date'] ?? current_time( 'Y-m-d' ) );
		$note         = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) );

		$bom = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'boms' ) . ' WHERE id = %d', $bom_id ) );
		if ( ! $bom ) {
			wp_die( esc_html__( 'BOM not found.', 'wc-enterprise-erp' ) );
		}
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'bom_items' ) . ' WHERE bom_id = %d', $bom_id ) );
		if ( ! $items ) {
			wp_die( esc_html__( 'This BOM has no components.', 'wc-enterprise-erp' ) );
		}

		// 1) Check component availability first (with wastage).
		$needed = array();
		foreach ( $items as $item ) {
			$qty = (float) $item->qty * $runs * ( 1 + (float) $item->wastage_pct / 100 );
			$needed[ (int) $item->component_id ] = ( $needed[ (int) $item->component_id ] ?? 0 ) + $qty;
		}
		foreach ( $needed as $component_id => $qty ) {
			$have = WCEERP_Module_Inventory::stock_of( $component_id, $warehouse_id );
			if ( $have + 0.0001 < $qty ) {
				wp_die( sprintf(
					/* translators: 1: product 2: needed 3: available */
					esc_html__( 'Not enough stock of %1$s — need %2$s, have %3$s in this warehouse.', 'wc-enterprise-erp' ),
					esc_html( get_the_title( $component_id ) ?: '#' . $component_id ),
					esc_html( wceerp_lakh_format( $qty ) ),
					esc_html( wceerp_lakh_format( $have ) )
				) );
			}
		}

		// 2) Create the production order.
		$doc_no = wceerp_next_doc_number( 'prod' );
		$wpdb->insert( wceerp_table( 'productions' ), array(
			'doc_no'          => $doc_no,
			'bom_id'          => $bom_id,
			'warehouse_id'    => $warehouse_id,
			'qty'             => $runs * (float) $bom->output_qty,
			'total_cost'      => 0,
			'status'          => 'in_progress',
			'production_date' => $date,
			'note'            => $note,
			'created_at'      => current_time( 'mysql' ),
		) );
		$production_id = (int) $wpdb->insert_id;

		// 3) Consume components at moving-average cost.
		$material_cost = 0;
		foreach ( $needed as $component_id => $qty ) {
			$material_cost += (float) WCEERP_Module_Inventory::move_stock(
				$component_id, $warehouse_id, $qty, 'out', 'production', $production_id, null, null,
				sprintf( 'Consumed for %s', $doc_no )
			);
		}

		$overhead   = ( (float) $bom->overhead_cost + (float) $bom->labour_cost ) * $runs;
		$total_cost = $material_cost + $overhead;
		$out_qty    = $runs * (float) $bom->output_qty;
		$unit_cost  = $out_qty > 0 ? $total_cost / $out_qty : 0;

		// 4) Receive finished goods at rolled-up unit cost.
		WCEERP_Module_Inventory::move_stock(
			(int) $bom->product_id, $warehouse_id, $out_qty, 'in', 'production', $production_id, $unit_cost, null,
			sprintf( 'Produced via %s', $doc_no )
		);

		// 5) Post overhead journal: Dr Inventory / Cr Manufacturing overhead (5500).
		//    Material cost already moved inside Inventory via the stock moves,
		//    so only the added overhead needs a journal to keep books balanced.
		if ( $overhead > 0.004 ) {
			WCEERP_Accounting::post(
				array(
					'journal_date' => $date,
					'ref_type'     => 'production',
					'ref_id'       => $production_id,
					'memo'         => sprintf( 'Overhead & labour absorbed — %s', $doc_no ),
				),
				array(
					array( 'account' => '1200', 'debit'  => $overhead ),
					array( 'account' => '5500', 'credit' => $overhead ),
				)
			);
		}

		$wpdb->update( wceerp_table( 'productions' ), array(
			'status'     => 'completed',
			'total_cost' => $total_cost,
		), array( 'id' => $production_id ) );

		if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'production',
				__( 'Production completed', 'wc-enterprise-erp' ),
				sprintf(
					/* translators: 1: doc no 2: qty 3: product */
					__( '%1$s finished — %2$s × %3$s added to stock.', 'wc-enterprise-erp' ),
					$doc_no,
					wceerp_lakh_format( $out_qty, 0 ),
					get_the_title( $bom->product_id ) ?: '#' . $bom->product_id
				),
				$this->admin_url( array( 'tab' => 'productions' ) )
			);
		}

		wceerp_log( 'manufacturing', 'production', $production_id, $doc_no );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'productions', 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'boms' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Manufacturing', 'wc-enterprise-erp' ) ) ); ?></h1>

			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'boms'        => __( 'Bills of material', 'wc-enterprise-erp' ),
					'produce'     => __( 'Run production', 'wc-enterprise-erp' ),
					'productions' => __( 'Production history', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf(
						'<a href="%s" class="nav-tab %s">%s</a>',
						esc_url( $this->admin_url( array( 'tab' => $slug ) ) ),
						$tab === $slug ? 'nav-tab-active' : '',
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>

			<?php
			if ( 'produce' === $tab ) {
				$this->render_produce();
			} elseif ( 'productions' === $tab ) {
				$this->render_productions();
			} else {
				$this->render_boms();
			}
			?>
		</div>
		<?php
	}

	protected function render_boms() {
		global $wpdb;
		$boms = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'boms' ) . ' ORDER BY id DESC LIMIT 100' );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'New bill of material', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_bom_save">
					<?php wp_nonce_field( 'wceerp_bom_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><label><?php esc_html_e( 'BOM name', 'wc-enterprise-erp' ); ?></label></th>
							<td><input type="text" name="name" class="regular-text" required></td></tr>
						<tr><th><label><?php esc_html_e( 'Finished product', 'wc-enterprise-erp' ); ?></label></th>
							<td><?php wceerp_product_select( 'product_id', 0, array( 'required' => true ) ); ?></td></tr>
						<tr><th><label><?php esc_html_e( 'Output qty per run', 'wc-enterprise-erp' ); ?></label></th>
							<td><input type="number" name="output_qty" step="0.0001" min="0.0001" value="1"></td></tr>
						<tr><th><label><?php esc_html_e( 'Overhead cost per run', 'wc-enterprise-erp' ); ?></label></th>
							<td><input type="number" name="overhead_cost" step="0.01" min="0" value="0"></td></tr>
						<tr><th><label><?php esc_html_e( 'Labour cost per run', 'wc-enterprise-erp' ); ?></label></th>
							<td><input type="number" name="labour_cost" step="0.01" min="0" value="0"></td></tr>
					</tbody></table>

					<h3><?php esc_html_e( 'Components', 'wc-enterprise-erp' ); ?></h3>
					<table class="widefat wceerp-table wceerp-items">
						<thead><tr>
							<th style="width:45%"><?php esc_html_e( 'Component product', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Qty per run', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Wastage %', 'wc-enterprise-erp' ); ?></th>
						</tr></thead>
						<tbody>
							<tr>
								<td><?php wceerp_product_select( 'component_id[]' ); ?></td>
								<td><input type="number" name="component_qty[]" step="0.0001" min="0"></td>
								<td><input type="number" name="component_wastage[]" step="0.01" min="0" max="99" value="0"></td>
							</tr>
						</tbody>
					</table>
					<p><button type="button" class="button" id="wceerp-add-row"><?php esc_html_e( '+ Add component', 'wc-enterprise-erp' ); ?></button></p>

					<p><button class="button button-primary"><?php esc_html_e( 'Save BOM', 'wc-enterprise-erp' ); ?></button></p>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Existing BOMs', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Finished product', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Output qty', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Overhead + labour', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $boms ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No BOMs yet.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $boms as $bom ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $bom->name ); ?></strong></td>
							<td><?php echo esc_html( get_the_title( $bom->product_id ) ?: '#' . $bom->product_id ); ?></td>
							<td class="num"><?php echo esc_html( wceerp_lakh_format( $bom->output_qty, 0 ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( (float) $bom->overhead_cost + (float) $bom->labour_cost ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function render_produce() {
		global $wpdb;
		$boms       = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'boms' ) . " WHERE status='active' ORDER BY name" );
		$warehouses = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'warehouses' ) . " WHERE status='active' ORDER BY name" );
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Run a production order', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Components are consumed at moving-average cost (plus wastage), finished goods are received at the rolled-up unit cost, and overhead is absorbed into inventory via account 5500.', 'wc-enterprise-erp' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_production_run">
				<?php wp_nonce_field( 'wceerp_production_run' ); ?>
				<table class="form-table"><tbody>
					<tr><th><label><?php esc_html_e( 'BOM', 'wc-enterprise-erp' ); ?></label></th>
						<td><select name="bom_id" required>
							<?php foreach ( (array) $boms as $bom ) : ?>
								<option value="<?php echo (int) $bom->id; ?>"><?php echo esc_html( $bom->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><label><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></label></th>
						<td><select name="warehouse_id" required>
							<?php foreach ( (array) $warehouses as $wh ) : ?>
								<option value="<?php echo (int) $wh->id; ?>"><?php echo esc_html( $wh->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><label><?php esc_html_e( 'Number of runs', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="number" name="qty" step="0.0001" min="0.0001" value="1"></td></tr>
					<tr><th><label><?php esc_html_e( 'Production date', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="date" name="production_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
					<tr><th><label><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" name="note" class="regular-text"></td></tr>
				</tbody></table>
				<p><button class="button button-primary"><?php esc_html_e( 'Run production', 'wc-enterprise-erp' ); ?></button></p>
			</form>
		</div>
		<?php
	}

	protected function render_productions() {
		global $wpdb;
		$p    = wceerp_table( 'productions' );
		$b    = wceerp_table( 'boms' );
		$per_page = 25;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $p" );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.*, b.name AS bom_name, b.product_id FROM $p p LEFT JOIN $b b ON b.id = p.bom_id ORDER BY p.id DESC LIMIT %d OFFSET %d",
			$per_page, wceerp_offset( $per_page )
		) );
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Production history', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Doc no.', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'BOM', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Finished product', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Total cost', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'No productions yet.', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $rows as $row ) : ?>
					<tr>
						<td><code><?php echo esc_html( $row->doc_no ); ?></code></td>
						<td><?php echo esc_html( $row->production_date ); ?></td>
						<td><?php echo esc_html( $row->bom_name ); ?></td>
						<td><?php echo esc_html( get_the_title( $row->product_id ) ?: '#' . $row->product_id ); ?></td>
						<td class="num"><?php echo esc_html( wceerp_lakh_format( $row->qty, 0 ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $row->total_cost ) ); ?></td>
						<td><span class="wceerp-badge is-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( str_replace( '_', ' ', $row->status ) ); ?></span></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php wceerp_pagination( $total, $per_page ); ?>
		</div>
		<?php
	}
}
