<?php
/**
 * Module: AI Business Assistant.
 *
 * Two honest layers:
 *
 *  1. INSIGHT ENGINE (always on, no external service): deterministic
 *     analytics computed from your own ledger and stock tables —
 *     stock-out forecasts, supplier price gaps, profit swings, cash
 *     runway, COD aging, expense spikes. Every number is auditable;
 *     nothing is "AI guessing". A daily digest pushes the important
 *     ones to the notification center.
 *
 *  2. ASK YOUR BOOKS (optional): connect your own LLM API key
 *     (Anthropic Claude or any OpenAI-compatible endpoint). Questions
 *     are answered against a compact, server-built summary of your
 *     KPIs and insights — the model sees aggregates, not your raw
 *     customer table. No key, no calls: the module says so plainly
 *     instead of pretending.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_AI extends WCEERP_Module {

	protected $id         = 'ai';
	protected $title      = 'Assistant';
	protected $capability = 'wceerp_view_reports';
	protected $tier       = 'enterprise';
	protected $order      = 10;

	public function __construct() {
		$this->title = __( 'Assistant', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_ai_settings', array( $this, 'handle_settings' ) );
		add_action( 'admin_post_wceerp_ai_ask', array( $this, 'handle_ask' ) );

		add_action( 'wceerp_ai_digest', array( __CLASS__, 'cron_digest' ) );
		if ( ! wp_next_scheduled( 'wceerp_ai_digest' ) ) {
			wp_schedule_event( strtotime( 'tomorrow 07:30' ), 'daily', 'wceerp_ai_digest' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Insight engine — every rule returns
	 * { severity: good|info|warn, title, detail, link }.
	 * ------------------------------------------------------------------- */

	public static function insights() {
		$insights = array_merge(
			self::insight_stockouts(),
			self::insight_profit_swing(),
			self::insight_cash_runway(),
			self::insight_supplier_prices(),
			self::insight_cod_aging(),
			self::insight_expense_spikes()
		);
		/* warn first, then info, then good news. */
		$rank = array( 'warn' => 0, 'info' => 1, 'good' => 2 );
		usort( $insights, function ( $a, $b ) use ( $rank ) {
			return $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ];
		} );
		return apply_filters( 'wceerp_ai_insights', $insights );
	}

	/** Products that will run out soon at the current 30-day sales rate. */
	protected static function insight_stockouts() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT m.product_id, SUM(m.qty) sold30,
			        (SELECT COALESCE(SUM(s.qty),0) FROM " . wceerp_table( 'stock' ) . " s WHERE s.product_id = m.product_id) stock
			 FROM " . wceerp_table( 'stock_moves' ) . " m
			 WHERE m.direction='out' AND m.ref_type='wc_order' AND m.created_at >= %s
			 GROUP BY m.product_id HAVING sold30 > 0
			 ORDER BY sold30 DESC LIMIT 30",
			gmdate( 'Y-m-d', strtotime( '-30 days' ) )
		) );
		$out = array();
		foreach ( (array) $rows as $row ) {
			$rate = (float) $row->sold30 / 30;
			$days = $rate > 0 ? (int) floor( (float) $row->stock / $rate ) : 999;
			if ( $days > 14 ) {
				continue;
			}
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $row->product_id ) : null;
			$name    = $product ? $product->get_name() : ( 'Product #' . $row->product_id );
			$out[]   = array(
				'severity' => $days <= 5 ? 'warn' : 'info',
				'title'    => $days <= 0
					? sprintf( __( '%s is out of stock and still selling', 'wc-enterprise-erp' ), $name )
					: sprintf( __( '%1$s will run out in about %2$d days', 'wc-enterprise-erp' ), $name, $days ),
				'detail'   => sprintf( __( 'Selling %1$s/day over 30 days; %2$s left. Raise a purchase order now to avoid lost sales.', 'wc-enterprise-erp' ), number_format( $rate, 1 ), number_format( (float) $row->stock, 0 ) ),
				'link'     => admin_url( 'admin.php?page=wceerp-purchases&tab=new' ),
			);
			if ( count( $out ) >= 5 ) {
				break;
			}
		}
		return $out;
	}

	protected static function insight_profit_swing() {
		global $wpdb;
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );
		$acc = wceerp_table( 'accounts' );
		$profit_of = function ( $from, $to ) use ( $wpdb, $jl, $j, $acc ) {
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT a.type, SUM(l.debit) d, SUM(l.credit) c
				 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
				 INNER JOIN $acc a ON a.id=l.account_id
				 WHERE jr.journal_date BETWEEN %s AND %s AND a.type IN ('income','expense')
				 GROUP BY a.type", $from, $to
			) );
			$profit = 0.0;
			foreach ( (array) $rows as $row ) {
				$profit += 'income' === $row->type ? (float) $row->c - (float) $row->d : -( (float) $row->d - (float) $row->c );
			}
			return $profit;
		};
		$this_month = $profit_of( gmdate( 'Y-m-01' ), current_time( 'Y-m-d' ) );
		$prev       = $profit_of( gmdate( 'Y-m-01', strtotime( 'first day of last month' ) ), gmdate( 'Y-m-t', strtotime( 'first day of last month' ) ) );
		if ( abs( $prev ) < 1 ) {
			return array();
		}
		$pct = round( 100 * ( $this_month - $prev ) / abs( $prev ) );
		if ( abs( $pct ) < 15 ) {
			return array();
		}
		return array( array(
			'severity' => $pct < 0 ? 'warn' : 'good',
			'title'    => $pct < 0
				? sprintf( __( 'Profit is down %d%% vs last month', 'wc-enterprise-erp' ), abs( $pct ) )
				: sprintf( __( 'Profit is up %d%% vs last month', 'wc-enterprise-erp' ), $pct ),
			'detail'   => sprintf( __( 'This month so far: %1$s · last month total: %2$s. See the Analytics chart for which line moved.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $this_month ) ), wp_strip_all_tags( wceerp_money( $prev ) ) ),
			'link'     => admin_url( 'admin.php?page=wceerp-analytics' ),
		) );
	}

	/** Liquid money ÷ average monthly expenses = months of runway. */
	protected static function insight_cash_runway() {
		global $wpdb;
		$jl  = wceerp_table( 'journal_lines' );
		$j   = wceerp_table( 'journals' );
		$acc = wceerp_table( 'accounts' );
		$liquid = (float) $wpdb->get_var(
			"SELECT COALESCE(SUM(l.debit-l.credit),0)
			 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id=l.account_id AND a.subtype IN ('cash','bank','mobile_banking')"
		);
		$expense3 = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(l.debit-l.credit),0)
			 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id=l.account_id AND a.type='expense'
			 WHERE jr.journal_date >= %s",
			gmdate( 'Y-m-d', strtotime( '-90 days' ) )
		) );
		$monthly = $expense3 / 3;
		if ( $monthly < 1 ) {
			return array();
		}
		$months = $liquid / $monthly;
		if ( $months >= 1.5 ) {
			return array();
		}
		return array( array(
			'severity' => 'warn',
			'title'    => sprintf( __( 'Cash runway is about %s months', 'wc-enterprise-erp' ), number_format( max( 0, $months ), 1 ) ),
			'detail'   => sprintf( __( 'Liquid money (cash + bank + wallets): %1$s vs average monthly spend %2$s. Chase dues and courier COD, and slow non-essential purchases.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $liquid ) ), wp_strip_all_tags( wceerp_money( $monthly ) ) ),
			'link'     => admin_url( 'admin.php?page=wceerp-dues' ),
		) );
	}

	/** Same product bought from 2+ suppliers at 10%+ different prices. */
	protected static function insight_supplier_prices() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT pi.product_id,
			        MIN(t.avg_cost) low, MAX(t.avg_cost) high,
			        SUBSTRING_INDEX(GROUP_CONCAT(t.supplier_name ORDER BY t.avg_cost ASC), ',', 1) cheap_supplier
			 FROM (
			   SELECT pi2.product_id, p2.supplier_id, s2.name supplier_name, AVG(pi2.unit_cost) avg_cost
			   FROM " . wceerp_table( 'purchase_items' ) . ' pi2
			   INNER JOIN ' . wceerp_table( 'purchases' ) . " p2 ON p2.id = pi2.purchase_id AND p2.status <> 'cancelled' AND p2.purchase_date >= %s
			   INNER JOIN " . wceerp_table( 'suppliers' ) . " s2 ON s2.id = p2.supplier_id
			   GROUP BY pi2.product_id, p2.supplier_id
			 ) t
			 INNER JOIN " . wceerp_table( 'purchase_items' ) . " pi ON pi.product_id = t.product_id
			 GROUP BY pi.product_id
			 HAVING COUNT(DISTINCT t.supplier_id) >= 2 AND high > low * 1.10
			 LIMIT 3",
			gmdate( 'Y-m-d', strtotime( '-180 days' ) )
		) );
		$out = array();
		foreach ( (array) $rows as $row ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $row->product_id ) : null;
			$name    = $product ? $product->get_name() : ( 'Product #' . $row->product_id );
			$pct     = round( 100 * ( (float) $row->high - (float) $row->low ) / max( 0.01, (float) $row->low ) );
			$out[]   = array(
				'severity' => 'info',
				'title'    => sprintf( __( 'You pay up to %1$d%% more for %2$s depending on the supplier', 'wc-enterprise-erp' ), $pct, $name ),
				'detail'   => sprintf( __( 'Last 6 months: %1$s vs %2$s per unit. Cheapest so far: %3$s. Run an RFQ before the next big order.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $row->low ) ), wp_strip_all_tags( wceerp_money( $row->high ) ), $row->cheap_supplier ),
				'link'     => admin_url( 'admin.php?page=wceerp-procurement&tab=new' ),
			);
		}
		return $out;
	}

	protected static function insight_cod_aging() {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) n, COALESCE(SUM(cod_amount - collected_amount),0) amt
			 FROM " . wceerp_table( 'consignments' ) . "
			 WHERE status='delivered' AND cod_amount - collected_amount > 0.004 AND last_sync IS NOT NULL AND created_at <= %s",
			gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) )
		) );
		if ( ! $row || (int) $row->n < 1 || (float) $row->amt < 1 ) {
			return array();
		}
		return array( array(
			'severity' => 'warn',
			'title'    => sprintf( __( 'Couriers are sitting on %s of delivered COD', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $row->amt ) ) ),
			'detail'   => sprintf( _n( '%d parcel was delivered over a week ago and the COD is still uncollected — chase the payout.', '%d parcels were delivered over a week ago and the COD is still uncollected — chase the payout.', (int) $row->n, 'wc-enterprise-erp' ), (int) $row->n ),
			'link'     => admin_url( 'admin.php?page=wceerp-courier&tab=payouts' ),
		) );
	}

	/** Expense accounts up sharply vs their own 3-month average. */
	protected static function insight_expense_spikes() {
		global $wpdb;
		$jl  = wceerp_table( 'journal_lines' );
		$j   = wceerp_table( 'journals' );
		$acc = wceerp_table( 'accounts' );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.name,
			        SUM(CASE WHEN jr.journal_date >= %s THEN l.debit - l.credit ELSE 0 END) this_month,
			        SUM(CASE WHEN jr.journal_date <  %s THEN l.debit - l.credit ELSE 0 END) / 3 avg3
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id = l.journal_id AND jr.status='posted' AND jr.journal_date >= %s
			 INNER JOIN $acc a ON a.id = l.account_id AND a.type='expense' AND a.code <> '5000'
			 GROUP BY a.id
			 HAVING avg3 > 500 AND this_month > avg3 * 1.3
			 ORDER BY this_month - avg3 DESC LIMIT 3",
			gmdate( 'Y-m-01' ), gmdate( 'Y-m-01' ), gmdate( 'Y-m-01', strtotime( '-3 months' ) )
		) );
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'severity' => 'info',
				'title'    => sprintf( __( '%1$s is %2$d%% above its usual level', 'wc-enterprise-erp' ), $row->name, round( 100 * ( (float) $row->this_month / max( 1, (float) $row->avg3 ) - 1 ) ) ),
				'detail'   => sprintf( __( 'This month: %1$s vs a 3-month average of %2$s.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $row->this_month ) ), wp_strip_all_tags( wceerp_money( $row->avg3 ) ) ),
				'link'     => admin_url( 'admin.php?page=wceerp-reports' ),
			);
		}
		return $out;
	}

	/** Morning digest: the warnings go to the notification bell. */
	public static function cron_digest() {
		if ( ! class_exists( 'WCEERP_Module_Notifications' ) ) {
			return;
		}
		$warns = array_values( array_filter( self::insights(), function ( $insight ) {
			return 'warn' === $insight['severity'];
		} ) );
		if ( ! $warns ) {
			return;
		}
		WCEERP_Module_Notifications::add(
			'ai',
			sprintf( _n( 'Assistant: %d thing needs attention', 'Assistant: %d things need attention', count( $warns ), 'wc-enterprise-erp' ), count( $warns ) ),
			implode( ' · ', array_map( function ( $insight ) { return $insight['title']; }, array_slice( $warns, 0, 3 ) ) ),
			admin_url( 'admin.php?page=wceerp-ai' )
		);
	}

	/* ---------------------------------------------------------------------
	 * "Ask your books" — optional LLM layer.
	 * ------------------------------------------------------------------- */

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_ai_settings' );
		if ( ! wceerp_user_can( 'wceerp_manage_settings' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		wceerp_update_option( 'ai_provider', in_array( $_POST['provider'] ?? '', array( 'anthropic', 'openai' ), true ) ? $_POST['provider'] : 'anthropic' );
		wceerp_update_option( 'ai_model', sanitize_text_field( wp_unslash( $_POST['model'] ?? '' ) ) );
		wceerp_update_option( 'ai_endpoint', esc_url_raw( wp_unslash( $_POST['endpoint'] ?? '' ) ) );
		if ( ! empty( $_POST['api_key'] ) ) { // blank = keep existing.
			wceerp_update_option( 'ai_api_key', sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) );
		}
		wceerp_log( 'ai', 'settings_save' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/** Compact aggregate context — no raw customer/supplier rows leave the site. */
	protected function build_context() {
		$parts   = array();
		$fy      = wceerp_fiscal_year();
		$rows    = WCEERP_Accounting::trial_balance( $fy['start'], current_time( 'Y-m-d' ) );
		$parts[] = 'Fiscal year ' . $fy['label'] . ' to date, account balances (Taka):';
		foreach ( (array) $rows as $row ) {
			$net = (float) $row->debit - (float) $row->credit;
			if ( abs( $net ) < 1 ) {
				continue;
			}
			$parts[] = sprintf( '%s %s [%s]: %s', $row->code, $row->name, $row->type, number_format( $net, 0 ) );
		}
		$parts[] = 'Current auto-insights:';
		foreach ( array_slice( self::insights(), 0, 8 ) as $insight ) {
			$parts[] = '- (' . $insight['severity'] . ') ' . $insight['title'] . ' — ' . $insight['detail'];
		}
		return implode( "\n", $parts );
	}

	public function handle_ask() {
		$this->verify_nonce( 'wceerp_ai_ask' );
		$question = sanitize_text_field( wp_unslash( $_POST['question'] ?? '' ) );
		$key      = wceerp_get_option( 'ai_api_key', '' );
		if ( ! $question || ! $key ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => $key ? 'question' : 'key' ) ) );
			exit;
		}

		$provider = wceerp_get_option( 'ai_provider', 'anthropic' );
		$system   = 'You are a business advisor for a Bangladeshi WooCommerce shop. Answer briefly and practically in the same language the question is asked in (Bangla or English), using only the data provided. Amounts are in Taka. If the data cannot answer, say so.';
		$prompt   = "DATA:\n" . $this->build_context() . "\n\nQUESTION: " . $question;

		if ( 'anthropic' === $provider ) {
			$endpoint = wceerp_get_option( 'ai_endpoint', '' ) ?: 'https://api.anthropic.com/v1/messages';
			$response = wp_remote_post( $endpoint, array(
				'timeout' => 45,
				'headers' => array(
					'x-api-key'         => $key,
					'anthropic-version' => '2023-06-01',
					'content-type'      => 'application/json',
				),
				'body'    => wp_json_encode( array(
					'model'      => wceerp_get_option( 'ai_model', '' ) ?: 'claude-sonnet-4-5',
					'max_tokens' => 700,
					'system'     => $system,
					'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
				) ),
			) );
			$body   = json_decode( wp_remote_retrieve_body( $response ), true );
			$answer = $body['content'][0]['text'] ?? '';
			$error  = $body['error']['message'] ?? '';
		} else {
			$endpoint = wceerp_get_option( 'ai_endpoint', '' ) ?: 'https://api.openai.com/v1/chat/completions';
			$response = wp_remote_post( $endpoint, array(
				'timeout' => 45,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array(
					'model'    => wceerp_get_option( 'ai_model', '' ) ?: 'gpt-4o-mini',
					'messages' => array(
						array( 'role' => 'system', 'content' => $system ),
						array( 'role' => 'user', 'content' => $prompt ),
					),
				) ),
			) );
			$body   = json_decode( wp_remote_retrieve_body( $response ), true );
			$answer = $body['choices'][0]['message']['content'] ?? '';
			$error  = $body['error']['message'] ?? '';
		}

		if ( is_wp_error( $response ) ) {
			$answer = '';
			$error  = $response->get_error_message();
		}
		set_transient( 'wceerp_ai_chat_' . get_current_user_id(), array(
			'q' => $question,
			'a' => $answer ?: sprintf( __( 'The AI provider returned an error: %s', 'wc-enterprise-erp' ), $error ?: 'empty response' ),
			't' => current_time( 'mysql' ),
		), 15 * MINUTE_IN_SECONDS );

		wceerp_log( 'ai', 'ask', 0, mb_substr( $question, 0, 80 ) );
		wp_safe_redirect( $this->admin_url( array( 'asked' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$insights   = self::insights();
		$key        = wceerp_get_option( 'ai_api_key', '' );
		$chat       = get_transient( 'wceerp_ai_chat_' . get_current_user_id() );
		$icons      = array( 'warn' => '⚠️', 'info' => '💡', 'good' => '✅' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Business Assistant', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>
			<?php if ( ! empty( $_GET['error'] ) && 'key' === $_GET['error'] ) { $this->notice( __( 'Add an API key below to ask questions — the insight cards work without one.', 'wc-enterprise-erp' ), 'error' ); } ?>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'What your books are saying', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Computed directly from your ledger and stock — every card is a real number, refreshed on load, and the urgent ones land in your notifications every morning.', 'wc-enterprise-erp' ); ?></p>
				<?php if ( ! $insights ) : ?>
					<p><?php esc_html_e( 'Nothing needs attention right now — sell more so I have something to say. ✅', 'wc-enterprise-erp' ); ?></p>
				<?php endif; ?>
				<div class="wceerp-insights">
					<?php foreach ( array_slice( $insights, 0, 12 ) as $insight ) : ?>
						<a class="wceerp-insight is-<?php echo esc_attr( $insight['severity'] ); ?>" href="<?php echo esc_url( $insight['link'] ); ?>">
							<span class="ic"><?php echo esc_html( $icons[ $insight['severity'] ] ); ?></span>
							<b><?php echo esc_html( $insight['title'] ); ?></b>
							<small><?php echo esc_html( $insight['detail'] ); ?></small>
						</a>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Ask your books', 'wc-enterprise-erp' ); ?></h2>
					<?php if ( ! $key ) : ?>
						<p class="description"><?php esc_html_e( 'Connect your own AI key (right) to ask free-form questions like "Why is profit down?" or "কোন পণ্য বেশি লাভজনক?". Until then this box stays honest and quiet.', 'wc-enterprise-erp' ); ?></p>
					<?php endif; ?>
					<?php if ( $chat ) : ?>
						<div style="background:#fbf8ee;border-radius:8px;padding:12px;margin-bottom:12px">
							<p style="margin:0 0 8px"><strong>Q:</strong> <?php echo esc_html( $chat['q'] ); ?></p>
							<p style="margin:0;white-space:pre-wrap"><strong>A:</strong> <?php echo esc_html( $chat['a'] ); ?></p>
						</div>
					<?php endif; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px">
						<input type="hidden" name="action" value="wceerp_ai_ask">
						<?php wp_nonce_field( 'wceerp_ai_ask' ); ?>
						<input type="text" name="question" style="flex:1" placeholder="<?php esc_attr_e( 'e.g. Which expenses grew the most this quarter?', 'wc-enterprise-erp' ); ?>" <?php disabled( ! $key ); ?>>
						<button class="button button-primary" <?php disabled( ! $key ); ?>><?php esc_html_e( 'Ask', 'wc-enterprise-erp' ); ?></button>
					</form>
					<p class="description" style="margin-top:8px"><?php esc_html_e( 'Privacy: the model receives fiscal-year account balances and the insight summaries above — aggregates only, never your raw customer or supplier lists.', 'wc-enterprise-erp' ); ?></p>
				</div>

				<?php if ( wceerp_user_can( 'wceerp_manage_settings' ) ) : ?>
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'AI connection', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_ai_settings">
						<?php wp_nonce_field( 'wceerp_ai_settings' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Provider', 'wc-enterprise-erp' ); ?></th>
								<td><select name="provider">
									<option value="anthropic" <?php selected( wceerp_get_option( 'ai_provider', 'anthropic' ), 'anthropic' ); ?>>Anthropic Claude</option>
									<option value="openai" <?php selected( wceerp_get_option( 'ai_provider', 'anthropic' ), 'openai' ); ?>><?php esc_html_e( 'OpenAI-compatible', 'wc-enterprise-erp' ); ?></option>
								</select></td></tr>
							<tr><th><?php esc_html_e( 'API key', 'wc-enterprise-erp' ); ?></th>
								<td><input type="password" name="api_key" class="regular-text" placeholder="<?php echo $key ? esc_attr__( '•••••• saved — leave blank to keep', 'wc-enterprise-erp' ) : ''; ?>" autocomplete="new-password"></td></tr>
							<tr><th><?php esc_html_e( 'Model (optional)', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="model" value="<?php echo esc_attr( wceerp_get_option( 'ai_model', '' ) ); ?>" placeholder="claude-sonnet-4-5 / gpt-4o-mini"></td></tr>
							<tr><th><?php esc_html_e( 'Endpoint (optional)', 'wc-enterprise-erp' ); ?></th>
								<td><input type="url" name="endpoint" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'ai_endpoint', '' ) ); ?>" placeholder="<?php esc_attr_e( 'blank = provider default; supports self-hosted OpenAI-compatible', 'wc-enterprise-erp' ); ?>"></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Save AI settings', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
