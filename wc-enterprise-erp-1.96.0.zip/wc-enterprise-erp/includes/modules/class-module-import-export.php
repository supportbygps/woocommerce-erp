<?php
/**
 * Module: Import / Export — CSV in and out for master data,
 * opening stock and accounting records.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Import_Export extends WCEERP_Module {

	protected $id         = 'import-export';
	protected $title      = 'Import / Export';
	protected $capability = 'wceerp_import_export';
	protected $tier       = 'business';
	protected $order      = 70;

	public function __construct() {
		$this->title = __( 'Import / Export', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_export', array( $this, 'handle_export' ) );
		add_action( 'admin_post_wceerp_import', array( $this, 'handle_import' ) );
		add_action( 'admin_post_wceerp_import_schedule', array( $this, 'handle_schedule_save' ) );

		add_action( 'wceerp_scheduled_import', array( __CLASS__, 'cron_scheduled_import' ) );
		if ( ! wp_next_scheduled( 'wceerp_scheduled_import' ) ) {
			wp_schedule_event( time() + 900, 'hourly', 'wceerp_scheduled_import' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Export.
	 * ------------------------------------------------------------------- */

	protected function datasets() {
		return array(
			'suppliers' => __( 'Suppliers', 'wc-enterprise-erp' ),
			'accounts'  => __( 'Chart of accounts', 'wc-enterprise-erp' ),
			'stock'     => __( 'Stock levels', 'wc-enterprise-erp' ),
			'journals'  => __( 'Journal lines', 'wc-enterprise-erp' ),
			'payments'  => __( 'Payments', 'wc-enterprise-erp' ),
		);
	}

	public function handle_export() {
		$this->verify_nonce( 'wceerp_export' );
		global $wpdb;

		$dataset = sanitize_key( $_POST['dataset'] ?? '' );
		if ( ! array_key_exists( $dataset, $this->datasets() ) ) {
			wp_die( esc_html__( 'Unknown dataset.', 'wc-enterprise-erp' ) );
		}

		switch ( $dataset ) {
			case 'suppliers':
				$rows = $wpdb->get_results( 'SELECT name, company, phone, email, bin_no, tin_no, nid_no, address, payment_terms, status FROM ' . wceerp_table( 'suppliers' ), ARRAY_A );
				break;
			case 'accounts':
				$rows = $wpdb->get_results( 'SELECT code, name, type, subtype, status FROM ' . wceerp_table( 'accounts' ), ARRAY_A );
				break;
			case 'stock':
				$rows = $wpdb->get_results(
					'SELECT s.product_id, w.code AS warehouse_code, s.qty, s.avg_cost FROM ' . wceerp_table( 'stock' ) . ' s LEFT JOIN ' . wceerp_table( 'warehouses' ) . ' w ON w.id = s.warehouse_id',
					ARRAY_A
				);
				break;
			case 'journals':
				$rows = $wpdb->get_results(
					'SELECT j.doc_no, j.journal_date, j.ref_type, j.memo, a.code AS account_code, a.name AS account, l.debit, l.credit, l.party_type, l.party_id
					 FROM ' . wceerp_table( 'journal_lines' ) . ' l
					 INNER JOIN ' . wceerp_table( 'journals' ) . " j ON j.id = l.journal_id AND j.status='posted'
					 INNER JOIN " . wceerp_table( 'accounts' ) . ' a ON a.id = l.account_id
					 ORDER BY j.id, l.id',
					ARRAY_A
				);
				break;
			case 'payments':
			default:
				$rows = $wpdb->get_results( 'SELECT doc_no, payment_date, direction, party_type, party_id, method, amount, txn_no, note FROM ' . wceerp_table( 'payments' ), ARRAY_A );
				break;
		}

		$filename = 'wceerp-' . $dataset . '-' . gmdate( 'Ymd-His' ) . '.csv';
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );

		$out = fopen( 'php://output', 'w' );
		fputs( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM so Bangla text opens correctly in Excel.
		if ( $rows ) {
			fputcsv( $out, array_keys( $rows[0] ) );
			foreach ( $rows as $row ) {
				fputcsv( $out, $row );
			}
		} else {
			fputcsv( $out, array( 'no_data' ) );
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Import.
	 * ------------------------------------------------------------------- */

	public function handle_import() {
		$this->verify_nonce( 'wceerp_import' );
		global $wpdb;

		$dataset = sanitize_key( $_POST['dataset'] ?? '' );
		if ( empty( $_FILES['csv']['tmp_name'] ) ) {
			wp_die( esc_html__( 'Please choose a CSV file.', 'wc-enterprise-erp' ) );
		}

		$handle = fopen( $_FILES['csv']['tmp_name'], 'r' ); // phpcs:ignore
		if ( ! $handle ) {
			wp_die( esc_html__( 'Could not read the uploaded file.', 'wc-enterprise-erp' ) );
		}

		list( $imported, $skipped ) = $this->import_from_handle( $dataset, $handle );

		wceerp_log( 'import-export', 'import', 0, $dataset . ": $imported imported, $skipped skipped" );
		wp_safe_redirect( $this->admin_url( array( 'imported' => $imported, 'skipped' => $skipped ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		if ( isset( $_GET['imported'] ) ) {
			$this->notice( sprintf(
				/* translators: 1: imported count 2: skipped count */
				__( 'Import finished — %1$d rows imported, %2$d skipped (duplicates or invalid).', 'wc-enterprise-erp' ),
				(int) $_GET['imported'], (int) ( $_GET['skipped'] ?? 0 )
			) );
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Import / Export', 'wc-enterprise-erp' ) ) ); ?></h1>

			<div class="wceerp-card" style="max-width:720px">
				<h2><?php esc_html_e( 'Scheduled import', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Pull a CSV from a URL automatically — a Google Sheet "published to the web" as CSV works directly. Same columns as the manual importers.', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_import_schedule">
					<?php wp_nonce_field( 'wceerp_import_schedule' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Enabled', 'wc-enterprise-erp' ); ?></th>
							<td><label><input type="checkbox" name="enabled" value="1" <?php checked( wceerp_get_option( 'sched_import_enabled', 0 ), 1 ); ?>> <?php esc_html_e( 'Run automatically', 'wc-enterprise-erp' ); ?></label></td></tr>
						<tr><th><?php esc_html_e( 'Dataset', 'wc-enterprise-erp' ); ?></th>
							<td><select name="dataset">
								<option value="stock" <?php selected( wceerp_get_option( 'sched_import_dataset', 'stock' ), 'stock' ); ?>><?php esc_html_e( 'Opening / adjustment stock', 'wc-enterprise-erp' ); ?></option>
								<option value="suppliers" <?php selected( wceerp_get_option( 'sched_import_dataset', 'stock' ), 'suppliers' ); ?>><?php esc_html_e( 'Suppliers', 'wc-enterprise-erp' ); ?></option>
							</select></td></tr>
						<tr><th><?php esc_html_e( 'CSV URL', 'wc-enterprise-erp' ); ?></th>
							<td><input type="url" name="url" class="large-text" value="<?php echo esc_attr( wceerp_get_option( 'sched_import_url', '' ) ); ?>" placeholder="https://docs.google.com/spreadsheets/d/…/pub?output=csv"></td></tr>
						<tr><th><?php esc_html_e( 'Frequency', 'wc-enterprise-erp' ); ?></th>
							<td><select name="frequency">
								<option value="daily" <?php selected( wceerp_get_option( 'sched_import_frequency', 'daily' ), 'daily' ); ?>><?php esc_html_e( 'Daily', 'wc-enterprise-erp' ); ?></option>
								<option value="hourly" <?php selected( wceerp_get_option( 'sched_import_frequency', 'daily' ), 'hourly' ); ?>><?php esc_html_e( 'Hourly', 'wc-enterprise-erp' ); ?></option>
							</select></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Save schedule', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Export to CSV', 'wc-enterprise-erp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Files are UTF-8 with BOM so Bangla text opens correctly in Excel.', 'wc-enterprise-erp' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_export">
						<?php wp_nonce_field( 'wceerp_export' ); ?>
						<p>
							<select name="dataset">
								<?php foreach ( $this->datasets() as $slug => $label ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<button class="button button-primary"><?php esc_html_e( 'Download CSV', 'wc-enterprise-erp' ); ?></button>
						</p>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Import from CSV', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="wceerp_import">
						<?php wp_nonce_field( 'wceerp_import' ); ?>
						<p>
							<select name="dataset">
								<option value="suppliers"><?php esc_html_e( 'Suppliers', 'wc-enterprise-erp' ); ?></option>
								<option value="accounts"><?php esc_html_e( 'Chart of accounts', 'wc-enterprise-erp' ); ?></option>
								<option value="stock"><?php esc_html_e( 'Opening stock', 'wc-enterprise-erp' ); ?></option>
							</select>
							<input type="file" name="csv" accept=".csv" required>
						</p>
						<p><button class="button button-primary"><?php esc_html_e( 'Import', 'wc-enterprise-erp' ); ?></button></p>
					</form>
					<h3><?php esc_html_e( 'Expected columns', 'wc-enterprise-erp' ); ?></h3>
					<p><code>suppliers</code>: name, company, phone, email, bin_no, tin_no, nid_no, address, payment_terms<br>
					<code>accounts</code>: code, name, type (asset|liability|equity|income|expense), subtype<br>
					<code>stock</code>: product_id, warehouse_code, qty, avg_cost — <?php esc_html_e( 'posts opening stock into inventory and books Dr 1200 / Cr 3000.', 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Shared CSV importer used by manual upload and the scheduler.
	 * Returns array( imported, skipped ).
	 */
	protected function import_from_handle( $dataset, $handle ) {
		global $wpdb;

		$header = fgetcsv( $handle );
		if ( $header && isset( $header[0] ) ) {
			$header[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $header[0] ); // strip BOM.
		}
		$header = array_map( 'sanitize_key', (array) $header );

		$imported = 0;
		$skipped  = 0;

		while ( ( $data = fgetcsv( $handle ) ) !== false ) {
			$row = array();
			foreach ( $header as $i => $key ) {
				$row[ $key ] = isset( $data[ $i ] ) ? trim( (string) $data[ $i ] ) : '';
			}

			if ( 'suppliers' === $dataset ) {
				if ( empty( $row['name'] ) ) { $skipped++; continue; }
				$exists = $wpdb->get_var( $wpdb->prepare(
					'SELECT id FROM ' . wceerp_table( 'suppliers' ) . ' WHERE name = %s AND phone = %s',
					$row['name'], $row['phone'] ?? ''
				) );
				if ( $exists ) { $skipped++; continue; }
				$wpdb->insert( wceerp_table( 'suppliers' ), array(
					'name'          => sanitize_text_field( $row['name'] ),
					'company'       => sanitize_text_field( $row['company'] ?? '' ),
					'phone'         => sanitize_text_field( $row['phone'] ?? '' ),
					'email'         => sanitize_email( $row['email'] ?? '' ),
					'bin_no'        => sanitize_text_field( $row['bin_no'] ?? '' ),
					'tin_no'        => sanitize_text_field( $row['tin_no'] ?? '' ),
					'nid_no'        => sanitize_text_field( $row['nid_no'] ?? '' ),
					'address'       => sanitize_textarea_field( $row['address'] ?? '' ),
					'payment_terms' => sanitize_text_field( $row['payment_terms'] ?? '' ),
					'status'        => 'active',
					'created_at'    => current_time( 'mysql' ),
				) );
				$imported++;
			} elseif ( 'accounts' === $dataset ) {
				if ( empty( $row['code'] ) || empty( $row['name'] ) || empty( $row['type'] ) ) { $skipped++; continue; }
				$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'accounts' ) . ' WHERE code = %s', $row['code'] ) );
				if ( $exists ) { $skipped++; continue; }
				$type = in_array( $row['type'], array( 'asset', 'liability', 'equity', 'income', 'expense' ), true ) ? $row['type'] : '';
				if ( ! $type ) { $skipped++; continue; }
				$wpdb->insert( wceerp_table( 'accounts' ), array(
					'code'       => sanitize_text_field( $row['code'] ),
					'name'       => sanitize_text_field( $row['name'] ),
					'type'       => $type,
					'subtype'    => sanitize_key( $row['subtype'] ?? '' ),
					'status'     => 'active',
				) );
				$imported++;
			} elseif ( 'stock' === $dataset ) {
				// Opening stock: product_id, warehouse_code, qty, avg_cost.
				$product_id = (int) ( $row['product_id'] ?? 0 );
				$qty        = wceerp_dec( $row['qty'] ?? 0 );
				$cost       = wceerp_dec( $row['avg_cost'] ?? 0 );
				$warehouse  = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'warehouses' ) . ' WHERE code = %s', strtoupper( $row['warehouse_code'] ?? '' ) ) );
				if ( ! $product_id || $qty <= 0 || ! $warehouse ) { $skipped++; continue; }

				WCEERP_Module_Inventory::move_stock( $product_id, (int) $warehouse, $qty, 'in', 'opening', 0, $cost, null, 'Opening stock import' );

				// Book the opening stock value: Dr Inventory / Cr Owner equity.
				$value = $qty * $cost;
				if ( $value > 0.004 ) {
					WCEERP_Accounting::post(
						array( 'ref_type' => 'opening', 'memo' => 'Opening stock — product #' . $product_id ),
						array(
							array( 'account' => '1200', 'debit'  => $value ),
							array( 'account' => '3000', 'credit' => $value ),
						)
					);
				}
				$imported++;
			} else {
				$skipped++;
			}
		}
		fclose( $handle ); // phpcs:ignore

		return array( $imported, $skipped );
	}

	/* ---------------------------------------------------------------------
	 * Scheduled import — pull a CSV from a URL on a schedule. A Google
	 * Sheet "published to the web" as CSV works out of the box.
	 * ------------------------------------------------------------------- */

	public function handle_schedule_save() {
		$this->verify_nonce( 'wceerp_import_schedule' );
		wceerp_update_option( 'sched_import_enabled', empty( $_POST['enabled'] ) ? 0 : 1 );
		wceerp_update_option( 'sched_import_dataset', sanitize_key( $_POST['dataset'] ?? 'stock' ) );
		wceerp_update_option( 'sched_import_url', esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) ) );
		wceerp_update_option( 'sched_import_frequency', in_array( $_POST['frequency'] ?? '', array( 'hourly', 'daily' ), true ) ? $_POST['frequency'] : 'daily' );
		wceerp_log( 'import-export', 'schedule_save' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public static function cron_scheduled_import() {
		if ( ! wceerp_get_option( 'sched_import_enabled', 0 ) ) {
			return;
		}
		$frequency = wceerp_get_option( 'sched_import_frequency', 'daily' );
		$last_run  = (int) get_option( 'wceerp_sched_import_last', 0 );
		if ( 'daily' === $frequency && ( time() - $last_run ) < 20 * HOUR_IN_SECONDS ) {
			return;
		}

		$url = wceerp_get_option( 'sched_import_url', '' );
		if ( ! $url ) {
			return;
		}
		$response = wp_remote_get( $url, array( 'timeout' => 30 ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			wceerp_log( 'import-export', 'schedule_fetch_failed', 0, is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $response ) );
			return;
		}

		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore
		fwrite( $handle, wp_remote_retrieve_body( $response ) ); // phpcs:ignore
		rewind( $handle );

		$module  = new self();
		$dataset = wceerp_get_option( 'sched_import_dataset', 'stock' );
		list( $imported, $skipped ) = $module->import_from_handle( $dataset, $handle );

		update_option( 'wceerp_sched_import_last', time() );
		wceerp_log( 'import-export', 'schedule_run', 0, "$dataset: $imported imported, $skipped skipped" );

		if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'import-export',
				__( 'Scheduled import finished', 'wc-enterprise-erp' ),
				sprintf( __( '%1$s: %2$d rows imported, %3$d skipped.', 'wc-enterprise-erp' ), $dataset, $imported, $skipped ),
				admin_url( 'admin.php?page=wceerp-import-export' )
			);
		}
	}

}
