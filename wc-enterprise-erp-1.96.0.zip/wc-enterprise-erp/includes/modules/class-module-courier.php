<?php
/**
 * Module: Courier & Logistics + COD accounting.
 *
 * Consignment lifecycle:
 *   pending → booked → in_transit → delivered → paid
 *                                  ↘ returned / cancelled
 *
 * Money truth for COD (the important part):
 * - When a COD order posts, the WC bridge debits 1110 Courier COD
 *   Receivable — NOT cash. The shop hasn't been paid yet.
 * - When the courier remits, the payout screen posts:
 *     Dr Bank/bKash (net)  +  Dr 5600 Delivery charges
 *     Cr 1110 Courier COD Receivable (gross collected)
 * - Partial collections and multiple payouts are supported: each payout
 *   only credits what was collected in it.
 *
 * Drivers: Steadfast, Pathao and Bahok ship built in; add more via the
 * wceerp_courier_drivers + wceerp_courier_api_book/track filters.
 * More couriers (RedX, Paperfly, eCourier, Sundarban) can be registered
 * through the `wceerp_courier_drivers` filter without touching this file.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Courier extends WCEERP_Module {

	protected $id         = 'courier';
	protected $title      = 'Orders & Payments';
	protected $capability = 'wceerp_manage_courier';
	protected $tier       = 'starter';
	protected $order      = 28;

	public function __construct() {
		$this->title = __( 'Orders & Payments', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_consignment_create', array( $this, 'handle_create' ) );
		add_action( 'admin_post_wceerp_consignment_action', array( $this, 'handle_action' ) );
		add_action( 'admin_post_wceerp_courier_payout', array( $this, 'handle_payout' ) );
		add_action( 'admin_post_wceerp_courier_settings', array( $this, 'handle_settings' ) );
		add_action( 'admin_post_wceerp_courier_label', array( $this, 'handle_label' ) );
		add_filter( 'woocommerce_admin_order_actions', array( $this, 'order_action_button' ), 20, 2 );

		// Auto-create a pending consignment when a COD order reaches
		// Processing (opt-in; off by default). Priority 30 runs after the
		// accounting bridge so the order is fully settled first.
		add_action( 'woocommerce_order_status_processing', array( $this, 'maybe_auto_create' ), 30 );

		// "Create consignments" bulk action on the orders list.
		// Classic (posts table) screen:
		add_filter( 'bulk_actions-edit-shop_order', array( $this, 'register_bulk_action' ) );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'handle_bulk_action' ), 10, 3 );
		// HPOS (custom orders table) screen:
		add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( $this, 'register_bulk_action' ) );
		add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', array( $this, 'handle_bulk_action' ), 10, 3 );
		add_action( 'admin_notices', array( $this, 'bulk_action_notice' ) );

		add_action( 'rest_api_init', array( $this, 'register_webhook' ) );
		add_action( 'wp_ajax_wceerp_courier_test', array( $this, 'ajax_test_connection' ) );
		add_action( 'admin_post_wceerp_record_payment', array( $this, 'handle_record_payment' ) );
		add_action( 'admin_post_wceerp_cons_bulk', array( $this, 'handle_cons_bulk' ) );
		add_action( 'admin_post_wceerp_cod_refresh', array( $this, 'handle_cod_refresh' ) );
		add_action( 'admin_post_wceerp_payout_upload', array( $this, 'handle_payout_upload' ) );
		add_action( 'admin_post_wceerp_payout_confirm', array( $this, 'handle_payout_confirm' ) );
		add_action( 'admin_post_wceerp_reconcile_old', array( $this, 'handle_reconcile_old' ) );
		add_action( 'wp_ajax_wceerp_sync_batch', array( $this, 'ajax_sync_batch' ) );
		add_action( 'admin_post_wceerp_return_received', array( $this, 'handle_return_received' ) );
		add_action( 'admin_post_wceerp_payout_undo', array( $this, 'handle_payout_undo' ) );
		add_action( 'admin_post_wceerp_payout_map', array( $this, 'handle_payout_map' ) );
		add_action( 'admin_post_wceerp_attach_booking', array( $this, 'handle_attach_booking' ) );
		add_action( 'admin_post_wceerp_lump_payout', array( $this, 'handle_lump_payout' ) );
		add_action( 'admin_post_wceerp_returns_sync', array( $this, 'handle_returns_sync' ) );
		add_action( 'admin_post_wceerp_reconcile_file', array( $this, 'handle_reconcile_file' ) );
		add_action( 'admin_post_wceerp_cod_opening', array( $this, 'handle_opening' ) );
		add_action( 'admin_post_wceerp_cod_opening_receipt', array( $this, 'handle_opening_receipt' ) );

		add_action( 'wceerp_courier_sync', array( __CLASS__, 'cron_sync' ) );
		if ( ! wp_next_scheduled( 'wceerp_courier_sync' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'wceerp_courier_sync' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Drivers.
	 * ------------------------------------------------------------------- */

	/**
	 * slug => [ label, api (bool) ]. Extend via `wceerp_courier_drivers`.
	 */
	public static function drivers() {
		return apply_filters( 'wceerp_courier_drivers', array(
			'steadfast' => array( 'label' => 'Steadfast', 'api' => true ),
			'pathao'    => array( 'label' => 'Pathao Courier', 'api' => true ),
			'bahok'     => array( 'label' => 'Bahok Courier', 'api' => true ),
			'redx'      => array( 'label' => 'RedX', 'api' => true ),
			'carrybee'  => array( 'label' => 'CarryBee', 'api' => true ),
		) );
	}

	/**
	 * Unsaved values supplied by the connection tester.
	 *
	 * Lets "Test connection" check exactly what the user has typed, rather
	 * than what happens to be stored -- testing before saving is the
	 * obvious thing to do, so it has to work.
	 *
	 * @var array
	 */
	protected static $setting_overrides = array();

	protected static function setting( $key, $default = '' ) {
		if ( isset( self::$setting_overrides[ $key ] ) && '' !== self::$setting_overrides[ $key ] ) {
			return self::$setting_overrides[ $key ];
		}
		return wceerp_get_option( 'courier_' . $key, $default );
	}

	/**
	 * Book a consignment with the courier's API.
	 * Returns array( remote_id, tracking_code, status ) or WP_Error.
	 */
	public static function api_book( $consignment ) {
		if ( 'steadfast' === $consignment->courier ) {
			return self::steadfast_book( $consignment );
		}
		if ( 'pathao' === $consignment->courier ) {
			return self::pathao_book( $consignment );
		}
		if ( 'bahok' === $consignment->courier ) {
			return self::bahok_book( $consignment );
		}
		if ( 'redx' === $consignment->courier ) {
			return self::redx_book( $consignment );
		}
		if ( 'carrybee' === $consignment->courier ) {
			return self::carrybee_book( $consignment );
		}
		$result = apply_filters( 'wceerp_courier_api_book', null, $consignment );
		return null === $result ? new WP_Error( 'wceerp_courier', __( 'This courier has no API driver.', 'wc-enterprise-erp' ) ) : $result;
	}

	/**
	 * Fetch the current delivery status. Returns internal status string or WP_Error.
	 */
	public static function api_track( $consignment ) {
		if ( 'steadfast' === $consignment->courier ) {
			return self::steadfast_track( $consignment );
		}
		if ( 'pathao' === $consignment->courier ) {
			return self::pathao_track( $consignment );
		}
		if ( 'bahok' === $consignment->courier ) {
			return self::bahok_track( $consignment );
		}
		if ( 'redx' === $consignment->courier ) {
			return self::redx_track( $consignment );
		}
		if ( 'carrybee' === $consignment->courier ) {
			return self::carrybee_track( $consignment );
		}
		$result = apply_filters( 'wceerp_courier_api_track', null, $consignment );
		return null === $result ? new WP_Error( 'wceerp_courier', __( 'This courier has no API driver.', 'wc-enterprise-erp' ) ) : $result;
	}

	/* ---- Steadfast (portal.packzy.com) ---- */

	protected static function steadfast_request( $route, $body = null ) {
		$base = untrailingslashit( apply_filters( 'wceerp_steadfast_endpoint', 'https://portal.packzy.com/api/v1' ) );
		$args = array(
			'timeout' => 20,
			'headers' => array(
				'Api-Key'      => self::setting( 'steadfast_api_key' ),
				'Secret-Key'   => self::setting( 'steadfast_secret_key' ),
				'Content-Type' => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
			$response     = wp_remote_post( $base . $route, $args );
		} else {
			$response = wp_remote_get( $base . $route, $args );
		}
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : new WP_Error( 'wceerp_courier', __( 'Unexpected response from Steadfast.', 'wc-enterprise-erp' ) );
	}

	protected static function steadfast_book( $c ) {
		$data = self::steadfast_request( '/create_order', array(
			'invoice'           => $c->doc_no,
			'recipient_name'    => $c->recipient_name,
			'recipient_phone'   => $c->recipient_phone,
			'recipient_address' => wp_strip_all_tags( (string) $c->recipient_address ),
			'cod_amount'        => (float) $c->cod_amount,
			'note'              => (string) $c->note,
		) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( empty( $data['consignment'] ) ) {
			return new WP_Error( 'wceerp_courier', isset( $data['message'] ) ? $data['message'] : __( 'Steadfast rejected the consignment.', 'wc-enterprise-erp' ) );
		}
		return array(
			'remote_id'     => (string) $data['consignment']['consignment_id'],
			'tracking_code' => (string) ( $data['consignment']['tracking_code'] ?? '' ),
			'status'        => 'booked',
		);
	}

	protected static function steadfast_track( $c ) {
		$data = self::steadfast_request( '/status_by_cid/' . rawurlencode( $c->remote_id ) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$map = array(
			'pending'          => 'booked',
			'delivered_approval_pending' => 'delivered',
			'partial_delivered_approval_pending' => 'delivered',
			'cancelled_approval_pending' => 'returned',
			'delivered'        => 'delivered',
			'partial_delivered' => 'delivered',
			'in_review'        => 'booked',
			'hold'             => 'in_transit',
			'cancelled'        => 'returned',
			'unknown'          => 'in_transit',
		);
		$remote = strtolower( (string) ( $data['delivery_status'] ?? 'unknown' ) );
		return isset( $map[ $remote ] ) ? $map[ $remote ] : 'in_transit';
	}

	/* ---- Pathao (api-hermes.pathao.com) ---- */

	protected static function pathao_token() {
		$cached = get_transient( 'wceerp_pathao_token' );
		if ( $cached ) {
			return $cached;
		}
		$base     = untrailingslashit( apply_filters( 'wceerp_pathao_endpoint', 'https://api-hermes.pathao.com' ) );
		$response = wp_remote_post( $base . '/aladdin/api/v1/issue-token', array(
			'timeout' => 20,
			'body'    => array(
				'client_id'     => self::setting( 'pathao_client_id' ),
				'client_secret' => self::setting( 'pathao_client_secret' ),
				'username'      => self::setting( 'pathao_username' ),
				'password'      => self::setting( 'pathao_password' ),
				'grant_type'    => 'password',
			),
		) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['access_token'] ) ) {
			return new WP_Error( 'wceerp_courier', __( 'Pathao login failed — check credentials.', 'wc-enterprise-erp' ) );
		}
		set_transient( 'wceerp_pathao_token', $data['access_token'], max( 300, (int) ( $data['expires_in'] ?? 3600 ) - 120 ) );
		return $data['access_token'];
	}

	protected static function pathao_request( $route, $body = null ) {
		$token = self::pathao_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$base = untrailingslashit( apply_filters( 'wceerp_pathao_endpoint', 'https://api-hermes.pathao.com' ) );
		$args = array(
			'timeout' => 20,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
			$response     = wp_remote_post( $base . $route, $args );
		} else {
			$response = wp_remote_get( $base . $route, $args );
		}
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) ? $data : new WP_Error( 'wceerp_courier', __( 'Unexpected response from Pathao.', 'wc-enterprise-erp' ) );
	}

	protected static function pathao_book( $c ) {
		$data = self::pathao_request( '/aladdin/api/v1/orders', array(
			'store_id'          => (int) self::setting( 'pathao_store_id' ),
			'merchant_order_id' => $c->doc_no,
			'recipient_name'    => $c->recipient_name,
			'recipient_phone'   => $c->recipient_phone,
			'recipient_address' => wp_strip_all_tags( (string) $c->recipient_address ),
			'delivery_type'     => 48,
			'item_type'         => 2,
			'item_quantity'     => 1,
			'item_weight'       => (float) apply_filters( 'wceerp_pathao_weight', 0.5, $c ),
			'amount_to_collect' => (float) $c->cod_amount,
			'item_description'  => 'Order #' . $c->order_id,
		) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( empty( $data['data']['consignment_id'] ) ) {
			return new WP_Error( 'wceerp_courier', isset( $data['message'] ) ? $data['message'] : __( 'Pathao rejected the consignment.', 'wc-enterprise-erp' ) );
		}
		return array(
			'remote_id'     => (string) $data['data']['consignment_id'],
			'tracking_code' => (string) $data['data']['consignment_id'],
			'status'        => 'booked',
		);
	}

	protected static function pathao_track( $c ) {
		$data = self::pathao_request( '/aladdin/api/v1/orders/' . rawurlencode( $c->remote_id ) . '/info' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$remote = strtolower( (string) ( $data['data']['order_status'] ?? '' ) );
		$map    = array(
			'pending'            => 'booked',
			'pickup_requested'   => 'booked',
			'assigned_for_pickup' => 'booked',
			'picked'             => 'in_transit',
			'in_transit'         => 'in_transit',
			'at_the_sorting_hub' => 'in_transit',
			'assigned_for_delivery' => 'in_transit',
			'delivered'          => 'delivered',
			/* Bahok sends "Paid" once it has settled the parcel on its own
			 * side. The goods reached the customer, so the parcel is
			 * delivered here — it is not marked paid in the books until the
			 * remittance is actually recorded against a payout. */
			'paid'               => 'delivered',
			'payment_paid'       => 'delivered',
			'cash_collected'     => 'delivered',
			'partial_delivery'   => 'delivered',
			'return'             => 'returned',
			'returned'           => 'returned',
			'pickup_cancelled'   => 'cancelled',
			'delivery_failed'    => 'in_transit',
		);
		return isset( $map[ $remote ] ) ? $map[ $remote ] : 'in_transit';
	}

	/* ---- Bahok Courier (https://api.bahokcourier.com) ---------------------
	 *
	 * Auth is a username/password + client credentials exchange that returns
	 * a bearer token valid for 24 hours; the token is cached and re-issued
	 * automatically on expiry or a 401.
	 *
	 * Booking takes a free-text recipient address, so no district/thana/area
	 * mapping is needed to create an order. Those IDs are only required by
	 * the price-calculation endpoint.
	 * ------------------------------------------------------------------- */

	const BAHOK_TOKEN_KEY = 'wceerp_bahok_token';

	protected static function bahok_base() {
		$base = trim( (string) self::setting( 'bahok_base_url' ) );
		if ( ! $base ) {
			$base = 'https://api.bahokcourier.com';
		}
		/* People paste the full endpoint from the docs rather than the host,
		 * which would produce .../api/v1/baymax/api/v1/baymax/... */
		if ( false !== stripos( $base, '/api/v1' ) ) {
			$base = substr( $base, 0, stripos( $base, '/api/v1' ) );
		}
		if ( $base && ! preg_match( '#^https?://#i', $base ) ) {
			$base = 'https://' . $base;
		}
		return untrailingslashit( apply_filters( 'wceerp_bahok_endpoint', $base ) );
	}

	/** True when every credential needed to talk to Bahok is present. */
	public static function bahok_configured() {
		foreach ( array( 'bahok_client_id', 'bahok_client_secret', 'bahok_username', 'bahok_password' ) as $k ) {
			if ( ! self::setting( $k ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Issue (or reuse) an access token.
	 *
	 * @param bool $force Bypass the cache, e.g. after a 401.
	 * @return string|WP_Error
	 */
	protected static function bahok_token( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::BAHOK_TOKEN_KEY );
			if ( $cached ) {
				return $cached;
			}
		}
		if ( ! self::bahok_configured() ) {
			return new WP_Error( 'wceerp_courier', __( 'Bahok credentials are incomplete. Add the Client ID, Client Secret, Merchant ID and password under Couriers & API keys.', 'wc-enterprise-erp' ) );
		}

		$route = apply_filters( 'wceerp_bahok_token_route', '/api/v1/baymax/issue-token' );
		$res   = wp_remote_post( self::bahok_base() . $route, array(
			'timeout' => 25,
			'headers' => array(
				'Accept'       => 'application/json',
				'Content-Type' => 'application/json',
			),
			'body'    => wp_json_encode( array(
				'client_id'     => self::setting( 'bahok_client_id' ),
				'client_secret' => self::setting( 'bahok_client_secret' ),
				'username'      => self::setting( 'bahok_username' ),
				'password'      => self::setting( 'bahok_password' ),
			) ),
		) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = (string) wp_remote_retrieve_body( $res );
		$data = json_decode( $body, true );

		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			$detail = '';
			if ( is_array( $data ) ) {
				if ( ! empty( $data['message'] ) ) {
					$detail = (string) $data['message'];
				} elseif ( ! empty( $data['error'] ) ) {
					$detail = is_string( $data['error'] ) ? $data['error'] : wp_json_encode( $data['error'] );
				} elseif ( ! empty( $data['errors'] ) ) {
					$detail = wp_json_encode( $data['errors'] );
				}
			}
			if ( ! $detail ) {
				// Not JSON at all -- usually a wrong base URL returning HTML.
				$detail = trim( wp_strip_all_tags( mb_substr( $body, 0, 180 ) ) );
			}

			// Record the raw reply so a failure can actually be diagnosed.
			wceerp_log( 'courier', 'bahok_token_fail', 0, 'HTTP ' . $code . ' @ ' . $route . ' — ' . mb_substr( $body, 0, 400 ) );

			return new WP_Error( 'wceerp_courier', sprintf(
				/* translators: 1: HTTP status, 2: message from Bahok. */
				__( 'Bahok rejected the login (HTTP %1$d). %2$s', 'wc-enterprise-erp' ),
				$code,
				$detail ? $detail : __( 'No message returned — check the Merchant ID, password and Base URL.', 'wc-enterprise-erp' )
			) );
		}

		/* The token's position is not documented, so search the response
		 * rather than assuming a shape. */
		$token = self::find_token( $data );
		if ( ! $token ) {
			wceerp_log( 'courier', 'bahok_token_shape', 0, mb_substr( $body, 0, 400 ) );
			return new WP_Error( 'wceerp_courier', __( 'Bahok accepted the login but no access token was found in the reply. The raw response has been written to the audit log.', 'wc-enterprise-erp' ) );
		}

		/* Documented lifetime is 24h; cache slightly short to avoid using a
		 * token that expires mid-request. */
		$ttl = (int) apply_filters( 'wceerp_bahok_token_ttl', 23 * HOUR_IN_SECONDS );
		set_transient( self::BAHOK_TOKEN_KEY, $token, $ttl );
		return $token;
	}

	/**
	 * Pull an access token out of an arbitrarily nested response.
	 *
	 * @param mixed $data  Decoded JSON.
	 * @param int   $depth Recursion guard.
	 * @return string
	 */
	protected static function find_token( $data, $depth = 0 ) {
		if ( ! is_array( $data ) || $depth > 4 ) {
			return '';
		}
		$keys = array( 'access_token', 'accessToken', 'token', 'bearer_token', 'jwt' );
		foreach ( $keys as $k ) {
			if ( ! empty( $data[ $k ] ) && is_string( $data[ $k ] ) ) {
				return $data[ $k ];
			}
		}
		foreach ( $data as $value ) {
			if ( is_array( $value ) ) {
				$found = self::find_token( $value, $depth + 1 );
				if ( $found ) {
					return $found;
				}
			}
		}
		return '';
	}

	/**
	 * Authenticated request. Retries once with a fresh token on 401.
	 *
	 * @return array|WP_Error Decoded response body.
	 */
	/**
	 * Remember the last exchange with a courier.
	 *
	 * Booking failures are nearly always specific -- a rejected credential,
	 * a field the courier dislikes, a route that has moved. Without the
	 * actual request and reply, diagnosing one is guesswork, and the shop
	 * owner is the only person who can see it happen.
	 */
	protected static function record_exchange( $courier, $url, $payload, $code, $body ) {
		// Credentials must never reach a log that gets sent to support.
		$safe = is_array( $payload ) ? $payload : array();
		foreach ( array( 'client_secret', 'password', 'api_key', 'secret_key', 'token' ) as $secret ) {
			if ( isset( $safe[ $secret ] ) ) {
				$safe[ $secret ] = '••••';
			}
		}
		set_transient( 'wceerp_last_courier_call', array(
			'courier' => $courier,
			'url'     => $url,
			'payload' => $safe,
			'code'    => (int) $code,
			'body'    => mb_substr( (string) $body, 0, 1500 ),
			'at'      => current_time( 'mysql' ),
		), 2 * HOUR_IN_SECONDS );
	}

	public static function last_exchange() {
		return get_transient( 'wceerp_last_courier_call' );
	}

	protected static function bahok_request( $route, $body = null, $method = 'POST', $retry = true ) {
		$token = self::bahok_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$args = array(
			'timeout' => 30,
			'method'  => $method,
			'headers' => apply_filters( 'wceerp_bahok_headers', array(
				'Accept'        => 'application/json',
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $token,
			), $token ),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$url = self::bahok_base() . $route;
		$res = wp_remote_request( $url, $args );

		if ( is_wp_error( $res ) ) {
			// Network-level failure: DNS, TLS, timeout. Worth recording too.
			self::record_exchange( 'bahok', $url, $body, 0, $res->get_error_message() );
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		self::record_exchange( 'bahok', $url, $body, $code, wp_remote_retrieve_body( $res ) );

		if ( 401 === $code && $retry ) {
			delete_transient( self::BAHOK_TOKEN_KEY );
			$fresh = self::bahok_token( true );
			if ( is_wp_error( $fresh ) ) {
				return $fresh;
			}
			return self::bahok_request( $route, $body, $method, false );
		}

		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = ( is_array( $data ) && ! empty( $data['message'] ) )
				? $data['message']
				: sprintf( __( 'Bahok API error (HTTP %d).', 'wc-enterprise-erp' ), $code );
			return new WP_Error( 'wceerp_courier', $msg, array( 'status' => $code ) );
		}
		if ( is_array( $data ) && isset( $data['success'] ) && ! $data['success'] ) {
			$msg = ! empty( $data['message'] ) ? $data['message'] : __( 'Bahok rejected the request.', 'wc-enterprise-erp' );
			return new WP_Error( 'wceerp_courier', $msg );
		}
		return is_array( $data ) ? $data : array();
	}

	protected static function bahok_book( $c ) {
		$order = ( $c->order_id && 'remote' !== $c->order_source ) ? wc_get_order( $c->order_id ) : null;

		$name    = trim( wp_strip_all_tags( (string) $c->recipient_name ) );
		$phone   = self::bahok_phone( $c->recipient_phone );
		$address = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $c->recipient_address ) ) );

		/* Bahok enforces these server-side; checking here turns a vague
		 * remote rejection into a message that names the actual problem. */
		if ( mb_strlen( $name ) < 3 ) {
			return new WP_Error( 'wceerp_courier', __( 'Bahok requires a recipient name of at least 3 characters.', 'wc-enterprise-erp' ) );
		}
		if ( 11 !== strlen( $phone ) ) {
			return new WP_Error( 'wceerp_courier', sprintf(
				/* translators: %s: the phone number as stored. */
				__( 'Bahok requires an 11-digit Bangladeshi phone number; this consignment has "%s".', 'wc-enterprise-erp' ),
				$phone
			) );
		}
		if ( mb_strlen( $address ) < 10 ) {
			return new WP_Error( 'wceerp_courier', __( 'Bahok requires a delivery address of at least 10 characters. Add more detail to the order address and try again.', 'wc-enterprise-erp' ) );
		}

		$payload = array(
			'merchant_order_id'   => (string) $c->doc_no,
			'recipient_name'      => mb_substr( $name, 0, 100 ),
			'recipient_phone'     => $phone,
			'recipient_address'   => mb_substr( $address, 0, 220 ),
			'amount_to_collect'   => (float) $c->cod_amount,
			'special_instruction' => mb_substr( (string) $c->note, 0, 190 ),
			'item_description'    => self::bahok_items( $c, $order ),
			'is_exchange'         => (int) apply_filters( 'wceerp_bahok_is_exchange', 2, $c ),
		);

		$store = self::setting( 'bahok_store_id' );
		if ( $store ) {
			$payload['store_id'] = (string) $store;
		}
		$payload = apply_filters( 'wceerp_bahok_book_payload', $payload, $c, $order );

		/* Bahok's own docs disagree with themselves here: the endpoint
		 * heading says /orders while the working cURL example posts to
		 * /orders/store. Try the cURL path first and fall back only on a
		 * 404 -- a 404 means the route does not exist, so no parcel can
		 * have been created and retrying cannot double-book. */
		$routes = apply_filters( 'wceerp_bahok_book_routes', array(
			'/api/v1/baymax/orders/store',
			'/api/v1/baymax/orders',
		), $c );

		$data = null;
		foreach ( $routes as $i => $route ) {
			$data = self::bahok_request( $route, $payload );
			if ( ! is_wp_error( $data ) ) {
				break;
			}
			$http = (int) ( $data->get_error_data()['status'] ?? 0 );
			if ( 404 !== $http || $i === count( $routes ) - 1 ) {
				return $data;
			}
			wceerp_log( 'courier', 'bahok_route_404', (int) $c->id, $route );
		}
		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$inner = ( isset( $data['data'] ) && is_array( $data['data'] ) ) ? $data['data'] : $data;

		$id = '';
		foreach ( array( 'consignment_id', 'consignmentId', 'id', 'order_id' ) as $k ) {
			if ( isset( $inner[ $k ] ) && '' !== (string) $inner[ $k ] ) {
				$id = (string) $inner[ $k ];
				break;
			}
		}

		/* No id means no parcel, whatever the HTTP status said. Never mark a
		 * consignment booked without a real remote reference. */
		if ( '' === $id ) {
			wceerp_log( 'courier', 'bahok_no_id', (int) $c->id, wp_json_encode( $data ) );
			return new WP_Error( 'wceerp_courier', __( 'Bahok accepted the request but returned no consignment ID. Nothing has been marked as booked — check the parcel list in the Bahok panel before retrying.', 'wc-enterprise-erp' ) );
		}

		$tracking = '';
		foreach ( array( 'tracking_code', 'trackingCode', 'invoice_id', 'tracking' ) as $k ) {
			if ( ! empty( $inner[ $k ] ) ) {
				$tracking = (string) $inner[ $k ];
				break;
			}
		}
		/* Bahok returns a tracking_link rather than a bare code; keep the
		 * trailing id as the code and store the URL for the label/UI. */
		$link = isset( $inner['tracking_link'] ) ? esc_url_raw( (string) $inner['tracking_link'] ) : '';
		if ( ! $tracking && $link ) {
			$tracking = basename( untrailingslashit( wp_parse_url( $link, PHP_URL_PATH ) ) );
		}

		/* The create response already tells us the real starting state
		 * (e.g. "Pick Requested"), so use it instead of assuming booked. */
		$initial = isset( $inner['order_status'] ) ? self::bahok_status( $inner['order_status'], $c ) : 'booked';

		return array(
			'remote_id'     => $id,
			'tracking_code' => $tracking ? $tracking : $id,
			'status'        => $initial ? $initial : 'booked',
		);
	}

	protected static function bahok_track( $c ) {
		if ( '' === (string) $c->remote_id ) {
			return new WP_Error( 'wceerp_courier', __( 'This consignment has no Bahok reference to track.', 'wc-enterprise-erp' ) );
		}
		$route = apply_filters(
			'wceerp_bahok_track_route',
			'/api/v1/baymax/orders/short-info/' . rawurlencode( $c->remote_id ),
			$c
		);
		$data = self::bahok_request( $route, null, 'GET' );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$inner  = ( isset( $data['data'] ) && is_array( $data['data'] ) ) ? $data['data'] : $data;
		$remote = (string) ( $inner['order_status'] ?? $inner['status'] ?? '' );

		/* Bahok tracks delivery and payment separately. A parcel can be
		 * "Delivered" for weeks while payment_status moves to "Paid" only
		 * when they remit — and reading only the delivery status was why a
		 * parcel you had already been paid for looked unchanged on every
		 * sync. Recorded here so the payouts screen can show it; it still
		 * does not settle anything by itself, because their "Paid" means
		 * paid on their side, not money in your account. */
		$pay_state = strtolower( trim( (string) ( $inner['payment_status'] ?? '' ) ) );
		if ( '' !== $pay_state ) {
			global $wpdb;
			$wpdb->update(
				wceerp_table( 'consignments' ),
				array( 'remote_payment_state' => substr( $pay_state, 0, 40 ) ),
				array( 'id' => (int) $c->id )
			);
		}

		/* Carry back whatever the courier says about money, so a delivered
		 * parcel settles itself instead of waiting for someone to key in a
		 * figure from a statement. */
		self::stash_remote_money( $c, array(
			/* Bahok's own names come first.
			 *
			 * Their webhook payload calls these `collected`, `amount` and
			 * `price`, and a tracking reply is the same object — but this
			 * only looked for `collected_amount` and `delivery_charge`, so
			 * the money was sitting in the response all along and being
			 * skipped. That is why a full sync reported nothing collected. */
			'collected' => $inner['collected'] ?? $inner['collected_amount'] ?? $inner['amount_collected'] ?? $inner['cod_collected'] ?? null,
			'charge'    => $inner['delivery_charge'] ?? $inner['charge'] ?? $inner['total_charge'] ?? null,
			'cod'       => $inner['price'] ?? $inner['amount_to_collect'] ?? null,
		) );

		/* `amount` is what Bahok will actually remit after its deductions,
		 * so collected minus amount is the charge. Only used when they have
		 * not given a charge outright. */
		if ( isset( $inner['collected'], $inner['amount'] ) && null === ( $inner['delivery_charge'] ?? null ) ) {
			$collected = wceerp_dec( $inner['collected'] );
			$payable   = wceerp_dec( $inner['amount'] );

			/* `amount` is only meaningful once Bahok has worked out what it
			 * will remit. Before that it comes back as zero, and the earlier
			 * version happily read "collected minus nothing" as the charge —
			 * producing a delivery charge equal to the entire COD.
			 *
			 * A charge is a deduction, so it must be positive, smaller than
			 * what was collected, and plausibly a fee rather than most of
			 * the parcel's value. Anything else is not a charge and is
			 * better left blank than guessed. */
			$plausible = (
				$collected > 0
				&& $payable > 0
				&& $payable < $collected
				&& ( $collected - $payable ) <= $collected * 0.5
			);

			if ( $plausible ) {
				self::stash_remote_money( $c, array(
					'collected' => $collected,
					'charge'    => round( $collected - $payable, 2 ),
					'cod'       => null,
				) );
			} elseif ( $collected > 0 ) {
				// Money is real even when the deduction is not yet known.
				self::stash_remote_money( $c, array(
					'collected' => $collected,
					'charge'    => null,
					'cod'       => null,
				) );
			}
		}

		return self::bahok_status( $remote, $c );
	}

	/**
	 * Record money a courier reports against a consignment.
	 *
	 * Deliberately conservative: it never invents a collected amount, and
	 * only treats a parcel as fully collected when the courier says so on a
	 * delivered parcel. Guessing here would release COD that has not
	 * actually arrived.
	 */
	/**
	 * Work out what a courier will deduct, when it has not said so itself.
	 *
	 * Couriers here price the same way: a flat delivery charge, a weight
	 * charge above some threshold, and a percentage of the money collected.
	 * Reconciled against a real Bahok statement this reproduces their
	 * figures exactly — 1,100 collected less 100 delivery, 30 weight and
	 * 0.5% COD leaves the 964.50 they actually remitted.
	 *
	 * It is only ever an estimate, and the screen says so. The courier's own
	 * figure always wins where one exists; this exists so a payout can be
	 * prepared before the remittance slip arrives, not to replace it.
	 *
	 * @return float|null Null when no rate is configured for this courier.
	 */
	/**
	 * Total COD sitting with couriers.
	 *
	 * Read from the consignments rather than from account 1110, so the
	 * dashboard shows what parcels actually owe even where a ledger entry
	 * is missing — the two should agree, and when they do not this is the
	 * figure to trust for chasing, while 1110 is the one to fix.
	 */
	/**
	 * Has this payment already been recorded?
	 *
	 * Four screens can create a payout, and a form submitted twice — a
	 * double tap, a browser re-posting on refresh — produces the same
	 * remittance in the books more than once. A courier payment reference
	 * is the strongest signal: the same reference twice is always a repeat.
	 * Failing that, the same courier, date and amount within a few minutes.
	 *
	 * @return int Payout id if this looks like a duplicate, else 0.
	 */
	public static function duplicate_payout( $courier, $date, $net, $reference = '' ) {
		global $wpdb;
		$po = wceerp_table( 'courier_payouts' );

		if ( '' !== trim( (string) $reference ) ) {
			$id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$po} WHERE courier = %s AND note = %s LIMIT 1",
				$courier,
				trim( $reference )
			) );
			if ( $id ) {
				return $id;
			}
		}

		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$po}
			 WHERE courier = %s AND payout_date = %s
			   AND ABS( net_amount - %f ) < 0.01
			   AND created_at > %s
			 LIMIT 1",
			$courier,
			$date,
			round( (float) $net, 2 ),
			gmdate( 'Y-m-d H:i:s', strtotime( '-10 minutes' ) )
		) );
	}

	public static function cod_outstanding_total() {
		global $wpdb;
		return (float) $wpdb->get_var(
			'SELECT COALESCE(SUM(cod_amount - collected_amount),0)
			 FROM ' . wceerp_table( 'consignments' ) . "
			 WHERE status IN ('booked','in_transit','delivered')
			   AND cod_amount - collected_amount > 0.004"
		);
	}

	public static function estimate_charge( $courier, $collected, $c = null ) {
		$courier = sanitize_key( $courier );

		/* Published rates as at 2026, used until a shop saves its own.
		 *
		 * These were only placeholders in the settings form before, which
		 * meant the estimate returned nothing until someone happened to
		 * press Save — so courier cost was missing from order profit on a
		 * fresh install, and every COD order looked more profitable than it
		 * was. A shop's own saved rates always win. */
		/* Estimates are off unless asked for.
		 *
		 * A guessed charge in a money column invites someone to treat it as
		 * fact, and a figure that is nearly right is harder to catch than one
		 * that is obviously missing. The rate card stays — it is still useful
		 * for checking a remittance by hand — but nothing is filled in on
		 * your behalf unless you turn it on. */
		/* Estimating was removed from the settings screen: a guessed charge
		 * in a money column is easily mistaken for fact, and the real figure
		 * always arrives with the remittance. The calculation is kept for
		 * anything that wants it explicitly, but nothing turns it on. */
		if ( 'yes' !== wceerp_get_option( 'courier_estimate', '' ) ) {
			return null;
		}

		$defaults = apply_filters( 'wceerp_courier_rate_defaults', array(
			'bahok'     => array( 'flat' => 100, 'weight' => 30, 'pct' => 0.5, 'free_kg' => 1 ),
			'steadfast' => array( 'flat' => 60,  'weight' => 0,  'pct' => 1.0, 'free_kg' => 1 ),
			'pathao'    => array( 'flat' => 60,  'weight' => 0,  'pct' => 1.0, 'free_kg' => 1 ),
			'redx'      => array( 'flat' => 60,  'weight' => 0,  'pct' => 1.0, 'free_kg' => 1 ),
			'carrybee'  => array( 'flat' => 60,  'weight' => 0,  'pct' => 1.0, 'free_kg' => 1 ),
		) );
		$d = $defaults[ $courier ] ?? array( 'flat' => 0, 'weight' => 0, 'pct' => 0, 'free_kg' => 1 );

		$saved   = function ( $key, $fallback ) use ( $courier ) {
			$v = self::setting( $courier . '_rate_' . $key, '' );
			return ( '' === $v || null === $v ) ? $fallback : (float) $v;
		};

		$flat    = $saved( 'flat', $d['flat'] );
		$weight  = $saved( 'weight', $d['weight'] );
		$pct     = $saved( 'cod_pct', $d['pct'] );
		$free_kg = $saved( 'free_kg', $d['free_kg'] );

		if ( $flat <= 0 && $weight <= 0 && $pct <= 0 ) {
			return null; // genuinely nothing to go on
		}

		$charge = $flat;

		/* Weight charge applies only above the included allowance. A parcel
		 * with no recorded weight is assumed to be within it, because
		 * guessing heavy would overstate the deduction. */
		$kg = $c && ! empty( $c->weight ) ? (float) $c->weight : 0;
		if ( $weight > 0 && $kg > $free_kg ) {
			$charge += $weight * ceil( $kg - $free_kg );
		}

		/* The percentage is on money actually collected, so a return pays
		 * no COD fee — only the delivery and weight parts. */
		if ( $pct > 0 && $collected > 0 ) {
			$charge += $collected * ( $pct / 100 );
		}

		return round( $charge, 2 );
	}

	protected static function stash_remote_money( $c, $money ) {
		global $wpdb;
		$update = array();

		/* These are the COURIER's figures: what it took from your customer,
		 * and what it intends to deduct. They are deliberately kept apart
		 * from collected_amount and delivery_charge, which mean money that
		 * has actually reached you and charges actually deducted from a
		 * real payout.
		 *
		 * Writing the courier's collection into collected_amount was wrong
		 * and had a serious consequence: the payout screen treats
		 * cod_amount - collected_amount as what is still owed, so a synced
		 * parcel looked fully settled and could no longer be selected when
		 * the courier's money actually arrived. The cash never reached the
		 * ledger and "COD received" stayed at zero. */
		if ( null !== $money['collected'] && '' !== $money['collected'] ) {
			$collected = wceerp_dec( $money['collected'] );
			if ( $collected >= 0 && abs( $collected - (float) $c->remote_collected ) > 0.004 ) {
				$update['remote_collected'] = $collected;
			}
		}
		if ( null !== $money['charge'] && '' !== $money['charge'] ) {
			$charge = wceerp_dec( $money['charge'] );
			if ( $charge > 0 && abs( $charge - (float) $c->remote_charge ) > 0.004 ) {
				$update['remote_charge'] = $charge;
			}
		}
		/* The courier's own record of what is collectible. Useful when a
		 * customer changed the order after booking. */
		if ( null !== $money['cod'] && '' !== $money['cod'] ) {
			$cod = wceerp_dec( $money['cod'] );
			if ( $cod > 0 && abs( $cod - (float) $c->cod_amount ) > 0.004 ) {
				$update['remote_cod_amount'] = $cod;
			}
		}

		if ( ! $update ) {
			return;
		}
		$wpdb->update( wceerp_table( 'consignments' ), $update, array( 'id' => (int) $c->id ) );
		wceerp_log( 'courier', 'remote_money', (int) $c->id, wp_json_encode( $update ) );
	}

	/**
	 * Map a Bahok status string onto our internal vocabulary.
	 *
	 * Unknown values deliberately leave the consignment where it is and are
	 * logged, rather than being guessed into a state that could release COD
	 * or close an order early.
	 */
	public static function bahok_status( $remote, $c = null ) {
		$key = strtolower( trim( (string) $remote ) );
		$key = preg_replace( '/[^a-z0-9]+/', '_', $key );
		$key = trim( (string) $key, '_' );

		$map = apply_filters( 'wceerp_bahok_status_map', array(
			'pending'            => 'booked',
			'placed'             => 'booked',
			'order_placed'       => 'booked',
			'booked'             => 'booked',
			'pick_requested'     => 'booked',
			'pickup_requested'   => 'booked',
			'pickup_pending'     => 'booked',
			'pick_assigned'      => 'booked',
			'pick_cancelled'     => 'cancelled',
			'under_review'       => 'booked',
			'picked'             => 'in_transit',
			'picked_up'          => 'in_transit',
			'received'           => 'in_transit',
			'received_at_hub'    => 'in_transit',
			'in_transit'         => 'in_transit',
			'on_the_way'         => 'in_transit',
			'out_for_delivery'   => 'in_transit',
			'shipped'            => 'in_transit',
			'hold'               => 'in_transit',
			'on_hold'            => 'in_transit',
			'delivered'          => 'delivered',
			'partial_delivered'  => 'delivered',
			'partially_delivered' => 'delivered',
			'returned'           => 'returned',
			'return'             => 'returned',
			'returned_to_merchant' => 'returned',
			'cancelled'          => 'cancelled',
			'canceled'           => 'cancelled',
			/* Observed in Bahok's own parcel list and their tracking
			 * replies. Missing these was why older parcels appeared not to
			 * sync: the request succeeded, the status came back, and there
			 * was nothing to map it to — so the parcel kept whatever status
			 * it already had and nothing seemed to happen. */
			'cancel'             => 'cancelled',
			'at_sorting_hub'     => 'in_transit',
			'at_destination_hub' => 'in_transit',
			'at_merchant_hub'    => 'booked',
			'on_way'             => 'in_transit',
			'on_the_way_to_hub'  => 'in_transit',
			'rider_assigned'     => 'in_transit',
			'assigned_to_rider'  => 'in_transit',
			'processing'         => 'in_transit',
			'delivery_pending'   => 'in_transit',
			'partial'            => 'delivered',
			'return_pending'     => 'returned',
			'return_on_way'      => 'returned',
			'on_way_to_merchant' => 'returned',
			'merchant_received'  => 'returned',
		) );

		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		wceerp_log( 'courier', 'bahok_status_unknown', $c ? (int) $c->id : 0, (string) $remote );
		/* Record the exact wording of anything unmapped. A courier adding a
		 * status should show up here as a named gap rather than as parcels
		 * that quietly stop updating. */
		if ( '' !== $key && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'courier', 'bahok_status_unknown', $c ? (int) $c->id : 0, (string) $remote );
		}
		return $c && ! empty( $c->status ) ? $c->status : 'in_transit';
	}

	/** Digits-only phone, as Bahok expects a plain 11-digit BD number. */
	protected static function bahok_phone( $phone ) {
		$digits = preg_replace( '/\D+/', '', (string) $phone );
		if ( 0 === strpos( $digits, '880' ) ) {
			$digits = '0' . substr( $digits, 3 );
		}
		return $digits;
	}

	/** Short item description built from the order lines. */
	protected static function bahok_items( $c, $order ) {
		if ( ! $order ) {
			return (string) $c->doc_no;
		}
		$names = array();
		foreach ( $order->get_items() as $item ) {
			$names[] = $item->get_name() . ' x' . $item->get_quantity();
			if ( count( $names ) >= 5 ) {
				break;
			}
		}
		$text = implode( ', ', $names );
		return $text ? mb_substr( $text, 0, 190 ) : (string) $c->doc_no;
	}

	/**
	 * Delivery charge quote. Needs the numeric district/thana/area IDs from
	 * Bahok's location endpoints, so it is optional and only used where the
	 * caller can supply them.
	 *
	 * @return float|WP_Error
	 */
	public static function bahok_price( $district_id, $thana_id, $area_id, $product_price, $weight = 1, $delivery_type = 'regular' ) {
		$data = self::bahok_request( apply_filters( 'wceerp_bahok_price_route', '/api/v1/baymax/price-calculation' ), array(
			'store_id'      => self::setting( 'bahok_store_id' ),
			'product_price' => (float) $product_price,
			'item_weight'   => (float) $weight,
			'delivery_type' => (string) $delivery_type,
			'district_id'   => (int) $district_id,
			'thana_id'      => (int) $thana_id,
			'area_id'       => (int) $area_id,
		) );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$inner = ( isset( $data['data'] ) && is_array( $data['data'] ) ) ? $data['data'] : $data;
		foreach ( array( 'total_charge', 'delivery_charge', 'price', 'total' ) as $k ) {
			if ( isset( $inner[ $k ] ) ) {
				return (float) $inner[ $k ];
			}
		}
		return new WP_Error( 'wceerp_courier', __( 'Bahok returned no price.', 'wc-enterprise-erp' ) );
	}

	/* ---------------------------------------------------------------------
	 * RedX (https://openapi.redx.com.bd)
	 *
	 * Token-based: a long-lived access token is generated in the RedX
	 * merchant panel and sent on every call. Endpoints are filterable
	 * because RedX versions its paths.
	 * ------------------------------------------------------------------- */

	protected static function redx_request( $route, $body = null, $method = 'POST' ) {
		$token = self::setting( 'redx_access_token' );
		if ( ! $token ) {
			return new WP_Error( 'wceerp_courier', __( 'RedX access token is not set.', 'wc-enterprise-erp' ) );
		}
		$base = self::setting( 'redx_base_url' );
		if ( ! $base ) {
			$base = 'https://openapi.redx.com.bd';
		}
		$base = untrailingslashit( apply_filters( 'wceerp_redx_endpoint', $base ) );

		$args = array(
			'timeout' => 30,
			'method'  => $method,
			'headers' => apply_filters( 'wceerp_redx_headers', array(
				'Accept'            => 'application/json',
				'Content-Type'      => 'application/json',
				'API-ACCESS-TOKEN'  => 'Bearer ' . $token,
			), $token ),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		$res = wp_remote_request( $base . $route, $args );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = ( is_array( $data ) && ! empty( $data['message'] ) )
				? $data['message']
				: sprintf( __( 'RedX API error (HTTP %d).', 'wc-enterprise-erp' ), $code );
			return new WP_Error( 'wceerp_courier', $msg, array( 'status' => $code ) );
		}
		return is_array( $data ) ? $data : array();
	}

	protected static function redx_book( $c ) {
		$order = ( $c->order_id && 'remote' !== $c->order_source ) ? wc_get_order( $c->order_id ) : null;

		$payload = apply_filters( 'wceerp_redx_book_payload', array(
			'customer_name'            => (string) $c->recipient_name,
			'customer_phone'           => self::bahok_phone( $c->recipient_phone ),
			'delivery_area'            => (string) apply_filters( 'wceerp_redx_area', '', $c ),
			'delivery_area_id'         => (int) apply_filters( 'wceerp_redx_area_id', 0, $c ),
			'customer_address'         => wp_strip_all_tags( (string) $c->recipient_address ),
			'merchant_invoice_id'      => (string) $c->doc_no,
			'cash_collection_amount'   => (string) (float) $c->cod_amount,
			'parcel_weight'            => (int) apply_filters( 'wceerp_redx_weight', 500, $c ),
			'instruction'              => (string) $c->note,
			'value'                    => (float) $c->cod_amount,
		), $c, $order );

		if ( empty( $payload['delivery_area_id'] ) && '' === trim( (string) $payload['delivery_area'] ) ) {
			return new WP_Error( 'wceerp_courier', __( 'RedX needs a delivery area. Map your orders to a RedX area via the wceerp_redx_area_id filter, or book this parcel with another courier.', 'wc-enterprise-erp' ) );
		}

		$data = self::redx_request( apply_filters( 'wceerp_redx_book_route', '/v1.0.0-beta/parcel' ), $payload );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$id = (string) ( $data['tracking_id'] ?? $data['trackingId'] ?? '' );
		if ( '' === $id ) {
			wceerp_log( 'courier', 'redx_no_id', (int) $c->id, wp_json_encode( $data ) );
			return new WP_Error( 'wceerp_courier', __( 'RedX returned no tracking ID; nothing has been marked as booked.', 'wc-enterprise-erp' ) );
		}
		return array(
			'remote_id'     => $id,
			'tracking_code' => $id,
			'status'        => 'booked',
		);
	}

	/**
	 * Steadfast reports the collectible and its charge on the status call.
	 * Read it if present rather than requiring a second lookup.
	 */
	protected static function steadfast_money( $c, $data ) {
		$inner = ( isset( $data['delivery_status'] ) || isset( $data['cod_amount'] ) ) ? $data : ( $data['data'] ?? array() );
		if ( ! is_array( $inner ) ) {
			return;
		}
		self::stash_remote_money( $c, array(
			'collected' => $inner['collected_amount'] ?? null,
			'charge'    => $inner['delivery_charge'] ?? $inner['charge'] ?? null,
			'cod'       => $inner['cod_amount'] ?? null,
		) );
	}

	/* ------------------------------------------------------------------
	 * CarryBee
	 *
	 * Token-based like most of the others: either a permanent token from
	 * the panel, or email and password exchanged for one that is then
	 * cached. Field names follow CarryBee's documented API; they are not
	 * confirmed against live traffic, so the diagnostic panel on the
	 * consignments screen is the place to look if a booking is refused.
	 * ---------------------------------------------------------------- */

	const CARRYBEE_TOKEN_KEY = 'wceerp_carrybee_token';

	protected static function carrybee_base() {
		$base = trim( (string) self::setting( 'carrybee_base_url' ) );
		return rtrim( $base ?: 'https://api.carrybee.net', '/' );
	}

	protected static function carrybee_token( $force = false ) {
		// A permanent token from the panel skips the login entirely.
		$fixed = trim( (string) self::setting( 'carrybee_token' ) );
		if ( $fixed ) {
			return $fixed;
		}

		if ( ! $force ) {
			$cached = get_transient( self::CARRYBEE_TOKEN_KEY );
			if ( $cached ) {
				return $cached;
			}
		}

		$email    = self::setting( 'carrybee_email' );
		$password = self::setting( 'carrybee_password' );
		if ( ! $email || ! $password ) {
			return new WP_Error( 'wceerp_courier', __( 'Add your CarryBee email and password, or a permanent API token.', 'wc-enterprise-erp' ) );
		}

		$url = self::carrybee_base() . '/api/v1/login';
		$res = wp_remote_post( $url, array(
			'timeout' => 25,
			'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
			'body'    => wp_json_encode( array( 'email' => $email, 'password' => $password ) ),
		) );

		if ( is_wp_error( $res ) ) {
			self::record_exchange( 'carrybee', $url, array( 'email' => $email ), 0, $res->get_error_message() );
			return $res;
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = wp_remote_retrieve_body( $res );
		self::record_exchange( 'carrybee', $url, array( 'email' => $email, 'password' => '••••' ), $code, $body );

		$data  = json_decode( $body, true );
		$token = '';
		if ( is_array( $data ) ) {
			$token = (string) (
				$data['token']
				?? $data['access_token']
				?? $data['data']['token']
				?? $data['data']['access_token']
				?? ''
			);
		}
		if ( ! $token ) {
			return new WP_Error( 'wceerp_courier', sprintf(
				/* translators: %d: HTTP status. */
				__( 'CarryBee did not return a token (HTTP %d). Check the credentials and the base URL.', 'wc-enterprise-erp' ),
				(int) $code
			) );
		}

		// Refreshed well before a typical 24-hour expiry.
		set_transient( self::CARRYBEE_TOKEN_KEY, $token, 12 * HOUR_IN_SECONDS );
		return $token;
	}

	/**
	 * @param bool $retry Re-authenticate once on a 401 — a cached token
	 *                    that expired early must not fail the booking.
	 */
	protected static function carrybee_request( $route, $body = null, $method = 'POST', $retry = true ) {
		$token = self::carrybee_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}

		$url  = self::carrybee_base() . $route;
		$args = array(
			'method'  => $method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			self::record_exchange( 'carrybee', $url, $body, 0, $res->get_error_message() );
			return $res;
		}

		$code = wp_remote_retrieve_response_code( $res );
		$raw  = wp_remote_retrieve_body( $res );
		self::record_exchange( 'carrybee', $url, $body, $code, $raw );

		if ( 401 === $code && $retry ) {
			delete_transient( self::CARRYBEE_TOKEN_KEY );
			self::carrybee_token( true );
			return self::carrybee_request( $route, $body, $method, false );
		}

		$data = json_decode( $raw, true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = '';
			if ( is_array( $data ) ) {
				$msg = (string) ( $data['message'] ?? $data['error'] ?? '' );
				if ( ! empty( $data['errors'] ) && is_array( $data['errors'] ) ) {
					$first = reset( $data['errors'] );
					$msg  .= ' ' . ( is_array( $first ) ? implode( ' ', $first ) : (string) $first );
				}
			}
			return new WP_Error( 'wceerp_courier', sprintf( 'CarryBee HTTP %d — %s', $code, mb_substr( wp_strip_all_tags( $msg ?: $raw ), 0, 200 ) ) );
		}

		return is_array( $data ) ? $data : array();
	}

	protected static function carrybee_book( $c ) {
		$phone = preg_replace( '/\D/', '', (string) $c->recipient_phone );
		if ( 11 !== strlen( $phone ) ) {
			return new WP_Error( 'wceerp_courier', __( 'CarryBee needs an 11-digit mobile number.', 'wc-enterprise-erp' ) );
		}

		$payload = array(
			'merchant_order_id'  => $c->doc_no,
			'recipient_name'     => $c->recipient_name,
			'recipient_phone'    => $phone,
			'recipient_address'  => $c->recipient_address,
			'amount_to_collect'  => round( (float) $c->cod_amount, 2 ),
			'item_description'   => $c->note ?: __( 'Goods', 'wc-enterprise-erp' ),
			'item_quantity'      => max( 1, (int) $c->item_count ),
			'item_weight'        => (float) ( $c->weight ?: 0.5 ),
        );
		if ( self::setting( 'carrybee_store_id' ) ) {
			$payload['store_id'] = self::setting( 'carrybee_store_id' );
		}
		$payload = apply_filters( 'wceerp_carrybee_book_payload', $payload, $c );

		$res = self::carrybee_request( '/api/v1/orders', $payload );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$d = ( isset( $res['data'] ) && is_array( $res['data'] ) ) ? $res['data'] : $res;
		$remote = (string) ( $d['consignment_id'] ?? $d['order_id'] ?? $d['id'] ?? '' );
		if ( ! $remote ) {
			return new WP_Error( 'wceerp_courier', __( 'CarryBee accepted the request but returned no consignment id.', 'wc-enterprise-erp' ) );
		}

		return array(
			'remote_id'     => $remote,
			'tracking_code' => (string) ( $d['tracking_code'] ?? $d['tracking_id'] ?? $remote ),
		);
	}

	protected static function carrybee_track( $c ) {
		$res = self::carrybee_request( '/api/v1/orders/' . rawurlencode( $c->remote_id ), null, 'GET' );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$d      = ( isset( $res['data'] ) && is_array( $res['data'] ) ) ? $res['data'] : $res;
		$remote = (string) ( $d['status'] ?? $d['order_status'] ?? $d['delivery_status'] ?? '' );

		self::stash_remote_money( $c, array(
			'collected' => $d['collected_amount'] ?? $d['collected'] ?? null,
			'charge'    => $d['delivery_charge'] ?? $d['total_charge'] ?? null,
			'cod'       => $d['amount_to_collect'] ?? null,
		) );

		return self::carrybee_status( $remote, $c );
	}

	public static function carrybee_status( $remote, $c = null ) {
		$key = trim( preg_replace( '/[^a-z0-9]+/', '_', strtolower( (string) $remote ) ), '_' );

		$map = apply_filters( 'wceerp_carrybee_status_map', array(
			'pending'            => 'booked',
			'placed'             => 'booked',
			'order_placed'       => 'booked',
			'pickup_pending'     => 'booked',
			'pickup_assigned'    => 'booked',
			'picked'             => 'in_transit',
			'picked_up'          => 'in_transit',
			'in_transit'         => 'in_transit',
			'on_the_way'         => 'in_transit',
			'received_at_hub'    => 'in_transit',
			'out_for_delivery'   => 'in_transit',
			'delivered'          => 'delivered',
			'partial_delivered'  => 'delivered',
			'paid'               => 'delivered',
			'cancelled'          => 'cancelled',
			'canceled'           => 'cancelled',
			'hold'               => 'in_transit',
			'returned'           => 'returned',
			'return_completed'   => 'returned',
			'returned_to_merchant' => 'returned',
		), $c );

		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}
		return $c && ! empty( $c->status ) ? $c->status : 'in_transit';
	}

	protected static function redx_track( $c ) {
		if ( '' === (string) $c->remote_id ) {
			return new WP_Error( 'wceerp_courier', __( 'This consignment has no RedX reference to track.', 'wc-enterprise-erp' ) );
		}
		$data = self::redx_request(
			apply_filters( 'wceerp_redx_track_route', '/v1.0.0-beta/parcel/track/' . rawurlencode( $c->remote_id ), $c ),
			null,
			'GET'
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$tracking = $data['tracking'] ?? array();
		$last     = is_array( $tracking ) && $tracking ? end( $tracking ) : array();
		$remote   = (string) ( $last['message_en'] ?? $data['status'] ?? '' );
		return self::bahok_status( $remote, $c ); // Shared normaliser + map.
	}

	/* ---------------------------------------------------------------------
	 * Connection tests.
	 *
	 * Each test makes the cheapest authenticated call that courier offers,
	 * so credentials can be verified before a real parcel depends on them.
	 * None of these create anything.
	 * ------------------------------------------------------------------- */

	public static function test_connection( $driver ) {
		switch ( $driver ) {
			case 'steadfast':
				if ( ! self::setting( 'steadfast_api_key' ) || ! self::setting( 'steadfast_secret_key' ) ) {
					return new WP_Error( 'wceerp_courier', __( 'Enter and save the API key and secret key first.', 'wc-enterprise-erp' ) );
				}
				$data = self::steadfast_request( '/get_balance' );
				if ( is_wp_error( $data ) ) {
					return $data;
				}
				if ( isset( $data['current_balance'] ) ) {
					return sprintf(
						/* translators: %s: account balance. */
						__( 'Connected. Current Steadfast balance: %s', 'wc-enterprise-erp' ),
						wp_strip_all_tags( wceerp_money( (float) $data['current_balance'] ) )
					);
				}
				if ( ! empty( $data['status'] ) && 200 === (int) $data['status'] ) {
					return __( 'Connected to Steadfast.', 'wc-enterprise-erp' );
				}
				return new WP_Error( 'wceerp_courier', ! empty( $data['message'] ) ? $data['message'] : __( 'Steadfast rejected the credentials.', 'wc-enterprise-erp' ) );

			case 'pathao':
				$token = self::pathao_token();
				if ( is_wp_error( $token ) ) {
					return $token;
				}
				return __( 'Connected to Pathao — access token issued.', 'wc-enterprise-erp' );

			case 'bahok':
				delete_transient( self::BAHOK_TOKEN_KEY ); // Always test live credentials.
				$token = self::bahok_token( true );
				if ( is_wp_error( $token ) ) {
					return new WP_Error( 'wceerp_courier', sprintf(
						/* translators: 1: error text, 2: base URL used. */
						__( '%1$s (called %2$s)', 'wc-enterprise-erp' ),
						$token->get_error_message(),
						self::bahok_base()
					) );
				}
				return __( 'Connected to Bahok — access token issued and cached for 23 hours.', 'wc-enterprise-erp' );

			case 'redx':
				if ( ! self::setting( 'redx_access_token' ) ) {
					return new WP_Error( 'wceerp_courier', __( 'Enter and save the RedX access token first.', 'wc-enterprise-erp' ) );
				}
				$data = self::redx_request( apply_filters( 'wceerp_redx_test_route', '/v1.0.0-beta/areas' ), null, 'GET' );
				if ( is_wp_error( $data ) ) {
					return $data;
				}
				$n = isset( $data['areas'] ) && is_array( $data['areas'] ) ? count( $data['areas'] ) : 0;
				return $n
					? sprintf( __( 'Connected to RedX — %d delivery areas available.', 'wc-enterprise-erp' ), $n )
					: __( 'Connected to RedX.', 'wc-enterprise-erp' );
		}
		return new WP_Error( 'wceerp_courier', __( 'This courier has no connection test.', 'wc-enterprise-erp' ) );
	}

	public function ajax_test_connection() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wc-enterprise-erp' ) ), 403 );
		}
		check_ajax_referer( 'wceerp_courier_test', 'nonce' );

		$driver  = sanitize_key( $_POST['driver'] ?? '' );
		$drivers = self::drivers();
		if ( ! isset( $drivers[ $driver ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown courier.', 'wc-enterprise-erp' ) ) );
		}

		/* Use whatever is currently in the form so the credentials can be
		 * verified before they are committed. Nothing here is persisted. */
		if ( ! empty( $_POST['fields'] ) && is_array( $_POST['fields'] ) ) {
			$allowed = self::setting_keys();
			foreach ( wp_unslash( $_POST['fields'] ) as $k => $v ) {
				$k = sanitize_key( $k );
				if ( in_array( $k, $allowed, true ) ) {
					self::$setting_overrides[ $k ] = trim( (string) $v );
				}
			}
		}

		$result = self::test_connection( $driver );
		self::$setting_overrides = array();
		wceerp_log( 'courier', 'test_connection', 0, $driver . ': ' . ( is_wp_error( $result ) ? 'FAIL ' . $result->get_error_message() : 'OK' ) );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => $result ) );
	}

	/* ---------------------------------------------------------------------
	 * Opening COD.
	 *
	 * A shop that installs the ERP mid-life usually has hundreds of parcels
	 * already out with couriers. Those orders predate the books, so the WC
	 * bridge never debited 1110 for them -- and without an opening entry the
	 * later payout would credit 1110 against nothing and drive it negative.
	 *
	 * This records the outstanding total as a proper opening balance, and
	 * gives a way to draw it down as the couriers settle.
	 * ------------------------------------------------------------------- */

	/**
	 * Rows per page for the list screens.
	 *
	 * 0 means "all". Capped because rendering tens of thousands of rows in
	 * one page will exhaust memory long before it becomes useful.
	 */
	public static function per_page( $default = 25 ) {
		$n = isset( $_GET['per_page'] ) ? sanitize_text_field( wp_unslash( $_GET['per_page'] ) ) : '';
		if ( 'all' === $n ) {
			return 0;
		}
		$n = (int) $n;
		if ( ! $n ) {
			$n = (int) $default;
		}
		return max( 5, min( 500, $n ) );
	}

	/** The 25 / 50 / 100 / All control, preserving current filters. */
	public static function per_page_control( $tab ) {
		$current = isset( $_GET['per_page'] ) ? sanitize_text_field( wp_unslash( $_GET['per_page'] ) ) : '25';
		$base    = $_GET;
		unset( $base['per_page'], $base['paged'] );

		echo '<span style="margin-left:auto;display:inline-flex;align-items:center;gap:6px;font-size:12px">';
		echo '<span style="color:#646970">' . esc_html__( 'Show', 'wc-enterprise-erp' ) . '</span>';

		foreach ( array( '25' => '25', '50' => '50', '100' => '100', 'all' => __( 'All', 'wc-enterprise-erp' ) ) as $value => $label ) {
			$url = add_query_arg( array_merge( $base, array( 'per_page' => $value ) ), admin_url( 'admin.php' ) );
			printf(
				'<a href="%s" class="button button-small" style="%s">%s</a>',
				esc_url( $url ),
				( (string) $current === (string) $value ) ? 'background:#2271b1;border-color:#2271b1;color:#fff' : '',
				esc_html( $label )
			);
		}
		echo '</span>';
	}

	/**
	 * Delivery address for a courier, without the recipient's name.
	 *
	 * WooCommerce's get_formatted_*_address() puts the customer's name (and
	 * company) on the first line, so flattening it into one string produced
	 * "Md. Abul Hossain Milon, Laksam Fair health hospital, ..." — the name
	 * repeated inside the address field. Couriers print name and address
	 * separately, so this composes the address parts only.
	 *
	 * Shipping address wins where present; billing is the fallback.
	 */
	public static function address_for_order( $order ) {
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( (int) $order );
		}
		if ( ! $order ) {
			return '';
		}

		$use_shipping = (bool) $order->get_shipping_address_1();
		$get          = function ( $field ) use ( $order, $use_shipping ) {
			$method = ( $use_shipping ? 'get_shipping_' : 'get_billing_' ) . $field;
			return is_callable( array( $order, $method ) ) ? (string) $order->$method() : '';
		};

		$parts = array(
			$get( 'address_1' ),
			$get( 'address_2' ),
			$get( 'city' ),
			$get( 'state' ),
			$get( 'postcode' ),
		);

		/* Drop empties and any part that merely repeats an earlier one —
		 * shops routinely type the district into both city and state. */
		$clean = array();
		foreach ( $parts as $part ) {
			$part = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $part ) ) );
			if ( '' === $part ) {
				continue;
			}
			$dupe = false;
			foreach ( $clean as $seen ) {
				if ( 0 === strcasecmp( $seen, $part ) ) {
					$dupe = true;
					break;
				}
			}
			if ( ! $dupe ) {
				$clean[] = $part;
			}
		}

		$address = implode( ', ', $clean );

		/* Some shops have no structured address at all and keep everything
		 * in the order notes; fall back rather than sending nothing. */
		if ( '' === $address ) {
			$address = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags(
				str_replace( '<br/>', ', ', $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() )
			) ) );
			// Strip a leading name if the fallback dragged one in.
			$name = trim( $order->get_formatted_billing_full_name() );
			if ( $name && 0 === stripos( $address, $name ) ) {
				$address = trim( ltrim( substr( $address, strlen( $name ) ), ' ,' ) );
			}
		}

		return apply_filters( 'wceerp_courier_address', $address, $order );
	}

	/**
	 * What a courier should actually collect for an order: the total, less
	 * anything already received as an advance or part payment.
	 */
	public static function collectible_for( $order ) {
		if ( is_numeric( $order ) ) {
			$order = wc_get_order( (int) $order );
		}
		if ( ! $order ) {
			return 0.0;
		}
		$total = wceerp_dec( $order->get_total() );
		$paid  = class_exists( 'WCEERP_Order_Payments' ) ? WCEERP_Order_Payments::paid( $order->get_id() ) : 0.0;
		return max( 0, round( $total - $paid, 2 ) );
	}

	/** Total legacy COD already received against the opening balance. */
	public static function opening_received() {
		global $wpdb;
		$acct = WCEERP_Accounting::resolve_account( '1110' );
		if ( ! $acct ) {
			return 0.0;
		}
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(l.credit),0) FROM ' . wceerp_table( 'journal_lines' ) . ' l
			 INNER JOIN ' . wceerp_table( 'journals' ) . " j ON j.id = l.journal_id
			 WHERE j.ref_type = 'cod_opening_receipt' AND l.account_id = %d",
			$acct
		) );
	}

	/**
	 * Bulk actions on the consignments list.
	 *
	 * Booking and syncing hit a courier API per parcel, so the batch is
	 * capped: a hundred bookings inside one request would time out halfway
	 * and leave nobody able to say which ones went through.
	 */
	public function handle_cons_bulk() {
		$this->verify_nonce( 'wceerp_cons_bulk' );
		global $wpdb;

		$action = sanitize_key( $_POST['bulk_action'] ?? '' );
		$raw    = (string) ( $_POST['cons_ids'] ?? '' );
		$ids    = array_filter( array_map( 'absint', array_filter( explode( ',', $raw ) ) ) );

		if ( ! $action || ! $ids ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'consignments', 'error' => 'nothing' ) ) );
			exit;
		}

		$table = wceerp_table( 'consignments' );
		$done       = 0;
		$fail       = 0;
		$changed    = 0;
		$with_money = 0;
		$limit = ( in_array( $action, array( 'book', 'sync' ), true ) ) ? 25 : 200;
		$ids   = array_slice( $ids, 0, $limit );

		foreach ( $ids as $id ) {
			$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			if ( ! $c ) {
				continue;
			}

			switch ( $action ) {
				case 'book':
					if ( $c->remote_id ) {
						continue 2; // already booked
					}
					$res = $this->book_consignment( $id );
					is_wp_error( $res ) ? $fail++ : $done++;
					break;

				case 'sync':
					if ( ! $c->remote_id ) {
						continue 2;
					}
					$status = self::api_track( $c );
					if ( is_wp_error( $status ) ) {
						$fail++;
						break;
					}
					self::apply_status( $c, $status );
					$done++;

					/* Count what actually changed. A sync that returns the
					 * same status the parcel already had looks like it did
					 * nothing, and without this the screen cannot tell the
					 * difference between "no change" and "not working". */
					if ( $status && $status !== $c->status ) {
						$changed++;
					}
					$after = $wpdb->get_row( $wpdb->prepare( "SELECT remote_collected FROM {$table} WHERE id = %d", $id ) );
					if ( $after && (float) $after->remote_collected > 0.004 ) {
						$with_money++;
					}
					break;

				case 'delivered':
				case 'returned':
				case 'cancelled':
					if ( in_array( $c->status, array( 'paid' ), true ) || (float) $c->collected_amount > 0 ) {
						$fail++; // settled parcels are not reopened in bulk
						break;
					}
					$wpdb->update( $table, array( 'status' => $action ), array( 'id' => $id ) );
					wceerp_log( 'courier', 'status_manual', $id, $action . ' (bulk)' );
					$done++;
					break;

				case 'delete':
					if ( in_array( $c->status, array( 'paid', 'delivered' ), true ) || (float) $c->collected_amount > 0 ) {
						$fail++;
						break;
					}
					$wpdb->delete( $table, array( 'id' => $id ) );
					wceerp_log( 'courier', 'deleted', $id, 'bulk' );
					$done++;
					break;
			}
		}

		wceerp_log( 'courier', 'bulk_' . $action, 0, $done . ' ok, ' . $fail . ' failed' );

		wp_safe_redirect( $this->admin_url( array(
			'tab'     => 'consignments',
			'bulk'    => $action,
			'ok'      => $done,
			'bad'     => $fail,
			'changed' => $changed,
			'money'   => $with_money,
		) ) );
		exit;
	}

	/** Printable labels for a selection, opened in one window. */
	public function handle_cons_labels( $ids ) {
		// Labels render through the existing single-label view, batched.
		return $ids;
	}

	/**
	 * Ask each courier what it has collected on the parcels still awaiting
	 * payment, and store those figures for comparison.
	 *
	 * This deliberately does not move any money. A courier saying it holds
	 * your cash is not the same as the cash arriving in your account, and
	 * only the second belongs in the books.
	 */
	public function handle_cod_refresh() {
		$this->verify_nonce( 'wceerp_cod_refresh' );
		global $wpdb;

		$table = wceerp_table( 'consignments' );
		$rows  = $wpdb->get_results(
			"SELECT * FROM {$table}
			 WHERE status = 'delivered'
			   AND cod_amount - collected_amount > 0.004
			   AND remote_id IS NOT NULL AND remote_id <> ''
			 ORDER BY id DESC LIMIT 40"
		);

		$checked = 0;
		$got     = 0;
		foreach ( (array) $rows as $c ) {
			$status = self::api_track( $c );
			$checked++;
			if ( is_wp_error( $status ) ) {
				continue;
			}
			// api_track() stores whatever money the courier reported.
			$fresh = $wpdb->get_row( $wpdb->prepare( "SELECT remote_collected FROM {$table} WHERE id = %d", $c->id ) );
			if ( $fresh && (float) $fresh->remote_collected > 0.004 ) {
				$got++;
			}
		}

		wceerp_log( 'courier', 'cod_refresh', 0, $checked . ' checked, ' . $got . ' reported' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'refreshed' => $checked, 'got' => $got ) ) );
		exit;
	}

	/** Read an uploaded statement and hold the result for confirmation. */
	public function handle_payout_upload() {
		$this->verify_nonce( 'wceerp_payout_upload' );

		if ( empty( $_FILES['statement']['tmp_name'] ) ) {
			$this->stash_import_error( __( 'Choose a file first.', 'wc-enterprise-erp' ) );
		}
		if ( ! empty( $_FILES['statement']['error'] ) ) {
			$this->stash_import_error( __( 'The upload did not complete — the file may be larger than this server accepts.', 'wc-enterprise-erp' ) );
		}

		$rows = WCEERP_Payout_Import::read(
			$_FILES['statement']['tmp_name'],
			sanitize_file_name( $_FILES['statement']['name'] )
		);
		if ( is_wp_error( $rows ) ) {
			$this->stash_import_error( $rows->get_error_message() );
		}

		$courier = sanitize_key( $_POST['map_courier'] ?? '' );

		/* A mapping this shop saved for this courier wins over guessing.
		 * Every courier lays its statement out differently, so once someone
		 * has told us where Steadfast keeps its columns there is no reason
		 * to ever guess again. */
		$found = null;
		$saved = $courier ? WCEERP_Payout_Import::saved_map( $courier ) : null;
		if ( $saved ) {
			$found = array( 'header' => $saved['header'], 'map' => $saved['map'] );
		}
		if ( ! $found ) {
			$found = WCEERP_Payout_Import::map( $rows );
		}

		/* Still unrecognised: hand it to the user to map rather than
		 * refusing the file. Guessing column names can never keep up with
		 * five couriers who each rename things without warning. */
		if ( ! $found ) {
			$header = WCEERP_Payout_Import::guess_header( $rows );
			if ( null === $header ) {
				$this->stash_import_error( __( 'That file does not appear to contain a table of parcels at all. Check you downloaded the payment report rather than a summary.', 'wc-enterprise-erp' ) );
			}
			set_transient( 'wceerp_payout_raw_' . get_current_user_id(), array(
				'rows'    => array_slice( $rows, 0, 400 ),
				'header'  => $header,
				'courier' => $courier,
			), HOUR_IN_SECONDS );
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'mapcols' => 1 ) ) );
			exit;
		}

		$prepared = WCEERP_Payout_Import::prepare( $rows, $found );
		$prepared['payment_id'] = WCEERP_Payout_Import::payment_id( $rows );
		if ( ! $prepared['matched'] ) {
			$this->stash_import_error( __( 'None of the rows matched a consignment awaiting payment. Check you have uploaded the right statement, and that these parcels were booked through the ERP.', 'wc-enterprise-erp' ) );
		}

		set_transient( 'wceerp_payout_import_' . get_current_user_id(), $prepared, HOUR_IN_SECONDS );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'imported' => 1 ) ) );
		exit;
	}

	protected function stash_import_error( $message ) {
		set_transient( 'wceerp_payout_err_' . get_current_user_id(), $message, 60 );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'import_failed' => 1 ) ) );
		exit;
	}

	/**
	 * Post an imported statement as one payout.
	 *
	 * Returned parcels are the subtlety: they collect nothing but still
	 * cost a charge. Crediting the receivable for them would show money
	 * arriving that never did, so only what was actually collected is
	 * credited, and the charge is expensed either way.
	 */
	public function handle_payout_confirm() {
		$this->verify_nonce( 'wceerp_payout_confirm' );
		global $wpdb;

		$prepared = get_transient( 'wceerp_payout_import_' . get_current_user_id() );
		if ( ! $prepared || empty( $prepared['matched'] ) ) {
			$this->stash_import_error( __( 'That import expired. Upload the statement again.', 'wc-enterprise-erp' ) );
		}

		$courier    = sanitize_key( $_POST['courier'] ?? '' );
		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		$date       = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_POST['payout_date'] ?? '' ) ) ? $_POST['payout_date'] : current_time( 'Y-m-d' );
		$reference  = sanitize_text_field( wp_unslash( $_POST['reference'] ?? '' ) );

		if ( ! $account_id ) {
			$this->stash_import_error( __( 'Choose the account the money was deposited into.', 'wc-enterprise-erp' ) );
		}

		$table     = wceerp_table( 'consignments' );
		$collected = 0.0;
		$charges   = 0.0;
		$ids       = array();

		foreach ( $prepared['matched'] as $line ) {
			$collected += (float) $line['collected'];
			$charges   += (float) $line['charge'];
			$ids[]      = (int) $line['id'];
		}
		$net = round( $collected - $charges, 2 );

		/* Same statement uploaded twice, or a refreshed POST. The reference
		 * catches it outright; the amount-and-date window catches the rest. */
		$dupe = self::duplicate_payout( $courier, $date, $net, $reference );
		if ( $dupe ) {
			$this->notice_redirect( 'error', sprintf(
				/* translators: %d: payout id. */
				__( 'This payment is already recorded as payout #%d. Nothing was posted twice.', 'wc-enterprise-erp' ),
				$dupe
			) );
		}

		$wpdb->insert( wceerp_table( 'courier_payouts' ), array(
			'doc_no'      => wceerp_next_doc_number( 'cpo' ),
			'courier'     => $courier,
			'payout_date' => $date,
			'gross_cod'   => round( $collected, 2 ),
			'charges'     => round( $charges, 2 ),
			'net_amount'  => $net,
			'account_id'  => $account_id,
			'note'        => $reference,
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		) );
		$payout_id = (int) $wpdb->insert_id;

		// Settle each parcel.
		foreach ( $prepared['matched'] as $line ) {
			$id = (int) $line['id'];

			$before = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			if ( $before ) {
				self::reverse_accrual( $before );
			}

			/* The breakdown, where the statement gave one. */
			if ( isset( $line['ch_deliv'] ) || isset( $line['ch_cod'] ) ) {
				$wpdb->update(
					$table,
					array(
						'charge_delivery' => (float) ( $line['ch_deliv'] ?? 0 ),
						'charge_cod'      => (float) ( $line['ch_cod'] ?? 0 ),
					),
					array( 'id' => $id )
				);
			}
			$wpdb->update(
				$table,
				array(
					'collected_amount' => (float) $line['collected'],
					'delivery_charge'  => (float) $line['charge'],
					'payout_id'        => $payout_id,
					'status'           => ! empty( $line['is_return'] ) ? 'returned' : 'paid',
				),
				array( 'id' => $id )
			);
		}

		/* One journal for the whole remittance, which is how the bank sees
		 * it too — a single credit on the statement. */
		$lines = array(
			array( 'account' => $account_id, 'debit' => $net ),
		);

		/* Split the deduction where the statement told us what it was made
		 * of. Carrying goods and handling money are different costs: the
		 * first is roughly fixed per parcel, the second scales with what you
		 * sell, so a rising COD fee means volume rather than waste. One
		 * combined line hides that distinction. */
		$fee_cod = 0.0;
		foreach ( $prepared['matched'] as $line ) {
			$fee_cod += (float) ( $line['ch_cod'] ?? 0 );
		}
		$fee_cod   = round( min( $fee_cod, $charges ), 2 );
		$fee_deliv = round( $charges - $fee_cod, 2 );

		if ( $fee_deliv > 0.004 ) {
			$lines[] = array( 'account' => '5600', 'debit' => $fee_deliv );
		}
		if ( $fee_cod > 0.004 ) {
			$lines[] = array( 'account' => '5610', 'debit' => $fee_cod );
		}
		$lines[] = array( 'account' => '1110', 'credit' => round( $collected, 2 ) );

		$journal = WCEERP_Accounting::post( array(
			'journal_date' => $date,
			'ref_type'     => 'courier_payout',
			'ref_id'       => $payout_id,
			'memo'         => sprintf(
				/* translators: 1: courier, 2: parcel count, 3: reference. */
				__( 'COD payout — %1$s, %2$d parcels %3$s', 'wc-enterprise-erp' ),
				ucfirst( $courier ),
				count( $ids ),
				$reference ? '(' . $reference . ')' : ''
			),
			'lines'        => $lines,
		) );

		if ( is_wp_error( $journal ) ) {
			/* The parcels are settled but the ledger is not. Say so loudly
			 * rather than reporting success — a silent half-posting is the
			 * worst outcome for a book that has to balance. */
			wceerp_log( 'courier', 'payout_journal_failed', $payout_id, $journal->get_error_message() );
			$this->stash_import_error( sprintf(
				/* translators: %s: error. */
				__( 'The parcels were marked paid but the ledger entry failed: %s. Fix the cause and post a manual journal, or delete payout #%d and try again.', 'wc-enterprise-erp' ),
				$journal->get_error_message(),
				$payout_id
			) );
		}

		$wpdb->update( wceerp_table( 'courier_payouts' ), array( 'journal_id' => (int) $journal ), array( 'id' => $payout_id ) );
		delete_transient( 'wceerp_payout_import_' . get_current_user_id() );
		wceerp_log( 'courier', 'payout_imported', $payout_id, count( $ids ) . ' parcels, net ' . $net );

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'posted' => count( $ids ) ) ) );
		exit;
	}

	/**
	 * Settle parcels whose money arrived before the ERP was tracking payouts.
	 *
	 * The problem this solves: a shop books parcels through the ERP, the
	 * courier pays for them, but the payout was never recorded here — so
	 * 1110 still shows the money as owing and "COD held by couriers" is
	 * far too high.
	 *
	 * Two ways of clearing it, and choosing correctly matters:
	 *
	 *   The cash landed in a bank or cash account that the ERP already
	 *   knows about, in which case a normal payout is right and the money
	 *   must be posted so the ledger matches the statement.
	 *
	 *   The cash landed before the books started, or was already counted in
	 *   an opening balance. Posting it again would count the same money
	 *   twice, so the receivable is cleared against Opening Balance Equity
	 *   instead — no new cash, just a correction of what was never really
	 *   outstanding.
	 */
	public function handle_reconcile_old() {
		$this->verify_nonce( 'wceerp_reconcile_old' );
		global $wpdb;

		$ids  = array_filter( array_map( 'absint', explode( ',', (string) ( $_POST['cons_ids'] ?? '' ) ) ) );
		$mode = sanitize_key( $_POST['mode'] ?? 'equity' );
		$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_POST['on_date'] ?? '' ) ) ? $_POST['on_date'] : current_time( 'Y-m-d' );
		$acct = (int) ( $_POST['account_id'] ?? 0 );
		$note = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) );

		if ( ! $ids ) {
			$this->notice_redirect( 'error', __( 'Select the parcels to reconcile first.', 'wc-enterprise-erp' ) );
		}
		if ( 'cash' === $mode && ! $acct ) {
			$this->notice_redirect( 'error', __( 'Choose the account the money went into.', 'wc-enterprise-erp' ) );
		}

		$table = wceerp_table( 'consignments' );
		$in    = implode( ',', array_map( 'absint', $ids ) );
		$rows  = $wpdb->get_results(
			"SELECT * FROM {$table}
			 WHERE id IN ({$in})
			   AND payout_id IS NULL
			   AND cod_amount - collected_amount > 0.004"
		);
		if ( ! $rows ) {
			$this->notice_redirect( 'error', __( 'Those parcels are already settled, or have nothing outstanding.', 'wc-enterprise-erp' ) );
		}

		$gross = 0.0;
		foreach ( $rows as $c ) {
			$gross += (float) $c->cod_amount - (float) $c->collected_amount;
		}
		$gross = round( $gross, 2 );

		$wpdb->insert( wceerp_table( 'courier_payouts' ), array(
			'doc_no'      => wceerp_next_doc_number( 'cpo' ),
			'courier'     => sanitize_key( $_POST['courier'] ?? '' ),
			'payout_date' => $date,
			'gross_cod'   => $gross,
			'charges'     => 0,
			'net_amount'  => 'cash' === $mode ? $gross : 0,
			'account_id'  => 'cash' === $mode ? $acct : 0,
			'note'        => $note ?: __( 'Historical reconciliation', 'wc-enterprise-erp' ),
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		) );
		$payout_id = (int) $wpdb->insert_id;

		foreach ( $rows as $c ) {
			$wpdb->update(
				$table,
				array(
					'collected_amount' => (float) $c->cod_amount,
					'payout_id'        => $payout_id,
					'status'           => 'paid',
				),
				array( 'id' => (int) $c->id )
			);
		}

		/* Clear the receivable against either real cash or opening equity. */
		$counter = ( 'cash' === $mode ) ? $acct : '3200';
		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $date,
				'ref_type'     => 'courier_payout',
				'ref_id'       => $payout_id,
				'memo'         => 'cash' === $mode
					? sprintf( __( 'COD payout (historical) — %d parcels', 'wc-enterprise-erp' ), count( $rows ) )
					: sprintf( __( 'COD already received before the books — %d parcels', 'wc-enterprise-erp' ), count( $rows ) ),
			),
			array(
				array( 'account' => $counter, 'debit' => $gross ),
				array( 'account' => '1110', 'credit' => $gross ),
			)
		);

		if ( is_wp_error( $journal ) ) {
			wceerp_log( 'courier', 'reconcile_failed', $payout_id, $journal->get_error_message() );
			$this->notice_redirect( 'error', sprintf(
				/* translators: %s: error. */
				__( 'The parcels were settled but the ledger entry failed: %s', 'wc-enterprise-erp' ),
				$journal->get_error_message()
			) );
		}

		$wpdb->update( wceerp_table( 'courier_payouts' ), array( 'journal_id' => (int) $journal ), array( 'id' => $payout_id ) );
		wceerp_log( 'courier', 'reconciled_history', $payout_id, count( $rows ) . ' parcels, ' . $gross . ', mode ' . $mode );

		$this->notice_redirect( 'success', sprintf(
			/* translators: 1: parcels, 2: amount. */
			__( '%1$d parcels reconciled, clearing %2$s from Courier COD Receivable.', 'wc-enterprise-erp' ),
			count( $rows ),
			wp_strip_all_tags( wceerp_money( $gross ) )
		) );
	}

	/** Mark returned parcels as physically received, and restock them. */
	/**
	 * Re-check returned parcels with the courier.
	 *
	 * Deliberately does not restock anything. A courier saying a parcel
	 * reached the merchant is not the same as the goods being on your shelf,
	 * and the whole point of the two-step return is that only you can
	 * confirm the second part.
	 */
	/**
	 * Read a courier statement and report on it, settling nothing.
	 *
	 * The upload path already exists for recording a payout. This one
	 * deliberately stops short of posting anything: when you are chasing a
	 * disagreement you want to see it, not have it quietly resolved.
	 */
	public function handle_reconcile_file() {
		$this->verify_nonce( 'wceerp_reconcile_file' );

		if ( empty( $_FILES['statement']['tmp_name'] ) ) {
			$this->notice_redirect( 'error', __( 'Choose the payment report file first.', 'wc-enterprise-erp' ) );
		}

		$courier = sanitize_key( $_POST['courier'] ?? '' );
		$ref     = sanitize_text_field( wp_unslash( $_POST['reference'] ?? '' ) );

		$rows = WCEERP_Payout_Import::read(
			$_FILES['statement']['tmp_name'],
			sanitize_file_name( $_FILES['statement']['name'] )
		);
		if ( is_wp_error( $rows ) ) {
			$this->notice_redirect( 'error', $rows->get_error_message() );
		}

		/* Saved layout first, then detection — the same order the payout
		 * import uses, so a courier mapped once works everywhere. */
		$found = $courier ? WCEERP_Payout_Import::saved_map( $courier ) : null;
		if ( $found ) {
			$found = array( 'header' => $found['header'], 'map' => $found['map'] );
		} else {
			$found = WCEERP_Payout_Import::map( $rows );
		}
		if ( ! $found ) {
			$this->notice_redirect(
				'error',
				__( 'That layout is not recognised. Upload it once through "Import the courier\'s payment report" to map the columns, then this will read it too.', 'wc-enterprise-erp' )
			);
		}

		$report               = WCEERP_Payout_Import::analyse( $rows, $found, $courier );
		$report['courier']    = $courier;
		$report['reference']  = $ref ?: WCEERP_Payout_Import::payment_id( $rows );
		$report['file']       = sanitize_file_name( $_FILES['statement']['name'] );

		set_transient( 'wceerp_recon_' . get_current_user_id(), $report, HOUR_IN_SECONDS );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'recon' => 1 ) ) );
		exit;
	}

	public function handle_returns_sync() {
		$this->verify_nonce( 'wceerp_returns_sync' );
		global $wpdb;

		$rows = (array) $wpdb->get_results(
			'SELECT * FROM ' . wceerp_table( 'consignments' ) . "
			 WHERE ( status IN ('returned','cancelled') OR ( reversed_at IS NOT NULL AND restocked_at IS NULL ) )
			   AND remote_id IS NOT NULL AND remote_id <> ''
			 ORDER BY id DESC LIMIT 200"
		);

		$checked = 0;
		$moved   = 0;
		foreach ( $rows as $c ) {
			$before = $c->status;
			$status = self::api_track( $c );
			self::apply_status( $c, is_wp_error( $status ) ? '' : $status );
			$checked++;
			if ( ! is_wp_error( $status ) && $status && $status !== $before ) {
				$moved++;
			}
		}

		$this->notice_redirect( 'success', sprintf(
			/* translators: 1: checked, 2: changed. */
			__( '%1$d returned parcels checked, %2$d changed status. Stock is untouched — tick a parcel once the goods are physically with you.', 'wc-enterprise-erp' ),
			$checked,
			$moved
		) );
	}

	public function handle_return_received() {
		$this->verify_nonce( 'wceerp_return_received' );
		global $wpdb;

		$ids = array_filter( array_map( 'absint', explode( ',', (string) ( $_POST['cons_ids'] ?? '' ) ) ) );
		if ( ! $ids ) {
			$this->notice_redirect( 'error', __( 'Select the parcels you have received back.', 'wc-enterprise-erp' ) );
		}

		$in    = implode( ',', array_map( 'absint', $ids ) );
		$rows  = $wpdb->get_results( "SELECT * FROM " . wceerp_table( 'consignments' ) . " WHERE id IN ({$in})" );
		$lines = 0;
		$done  = 0;

		foreach ( (array) $rows as $c ) {
			// Reverse first if the courier never reported the return itself.
			if ( empty( $c->reversed_at ) ) {
				self::reverse_sale( $c );
				$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . wceerp_table( 'consignments' ) . " WHERE id = %d", (int) $c->id ) );
			}
			$lines += self::restock_return( $c );
			$done++;
		}

		$this->notice_redirect( 'success', sprintf(
			/* translators: 1: parcels, 2: stock lines. */
			__( '%1$d parcels received back and %2$d stock line(s) returned to inventory.', 'wc-enterprise-erp' ),
			$done,
			$lines
		) );
	}

	/** Returned parcels, and what still has to come back. */
	protected function render_returns() {
		global $wpdb;
		$table = wceerp_table( 'consignments' );

		/* Cancelled counts as returned.
		 *
		 * Couriers distinguish the two — Bahok says "Cancel" when a delivery
		 * fails and the parcel starts its way back — but for a shop the
		 * outcome is identical: no money, and goods to receive. Listing only
		 * 'returned' meant every failed delivery vanished from this screen
		 * while its sale stayed on the books. */
		$rows = $wpdb->get_results(
			"SELECT * FROM {$table}
			 WHERE status IN ( 'returned', 'cancelled' )
			    OR ( reversed_at IS NOT NULL AND restocked_at IS NULL )
			 ORDER BY ( restocked_at IS NULL ) DESC, id DESC LIMIT 300"
		);

		$awaiting = 0;
		$value    = 0;
		foreach ( (array) $rows as $r ) {
			if ( empty( $r->restocked_at ) ) {
				$awaiting++;
				$value += (float) $r->cod_amount;
			}
		}
		?>
		<div class="wceerp-kpis">
			<div class="wceerp-kpi <?php echo $awaiting ? 'is-warn' : ''; ?>">
				<span><?php esc_html_e( 'Coming back to you', 'wc-enterprise-erp' ); ?></span>
				<strong><?php echo (int) $awaiting; ?></strong>
				<em><?php esc_html_e( 'not yet on your shelf', 'wc-enterprise-erp' ); ?></em>
			</div>
			<div class="wceerp-kpi">
				<span><?php esc_html_e( 'Order value returning', 'wc-enterprise-erp' ); ?></span>
				<strong><?php echo wp_kses_post( wceerp_money( $value ) ); ?></strong>
			</div>
		</div>

		<div class="wceerp-card">
			<h2><span class="dashicons dashicons-undo"></span><?php esc_html_e( 'Returned parcels', 'wc-enterprise-erp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'When a courier reports a return, the sale is reversed and the COD released immediately — that money is not coming. Stock waits: the goods are still in a van, and counting them as yours would make your stock figure a lie.', 'wc-enterprise-erp' ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( 'Tick a parcel once it is physically back in your hands. Only then does the stock return, at the cost it left at.', 'wc-enterprise-erp' ); ?>
			</p>

			<?php /* Returns move on the courier's side too — a parcel can go
			         from "on the way back" to "merchant received" without
			         anyone here touching it. */ ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:12px">
				<?php wp_nonce_field( 'wceerp_returns_sync' ); ?>
				<input type="hidden" name="action" value="wceerp_returns_sync">
				<button class="button"><span class="dashicons dashicons-update" style="vertical-align:text-top"></span>
					<?php esc_html_e( 'Check these with the courier', 'wc-enterprise-erp' ); ?></button>
				<span class="description" style="margin-left:8px">
					<?php esc_html_e( 'Asks about every parcel on this list and updates its status. It never marks stock as received — only you can confirm the goods are back.', 'wc-enterprise-erp' ); ?>
				</span>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wceerp-ret-form">
				<?php wp_nonce_field( 'wceerp_return_received' ); ?>
				<input type="hidden" name="action" value="wceerp_return_received">
				<input type="hidden" name="cons_ids" id="wceerp-ret-ids" value="">

				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th style="width:26px"><input type="checkbox" id="wceerp-ret-all"></th>
						<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Recipient', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Order value', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Sale reversed', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Stock back', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="8"><?php esc_html_e( 'Nothing returned or cancelled.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $r ) : ?>
						<tr>
							<td>
								<?php if ( empty( $r->restocked_at ) ) : ?>
									<input type="checkbox" class="wceerp-ret-cb" value="<?php echo (int) $r->id; ?>">
								<?php endif; ?>
							</td>
							<td><code><?php echo esc_html( $r->doc_no ); ?></code></td>
							<td>
								<?php if ( $r->order_id ) : ?>
									<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $r->order_id . '&action=edit' ) ); ?>">#<?php echo (int) $r->order_id; ?></a>
								<?php else : ?>—<?php endif; ?>
							</td>
							<td><?php echo esc_html( ucfirst( $r->courier ) ); ?></td>
							<td><?php echo esc_html( $r->recipient_name ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $r->cod_amount ) ); ?></td>
							<td>
								<?php if ( $r->reversed_at ) : ?>
									<span class="wceerp-badge wceerp-badge-ok"><?php echo esc_html( mysql2date( 'j M', $r->reversed_at ) ); ?></span>
								<?php else : ?>
									<span class="wceerp-badge wceerp-badge-warn"><?php esc_html_e( 'not yet', 'wc-enterprise-erp' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $r->restocked_at ) : ?>
									<span class="wceerp-badge wceerp-badge-ok"><?php echo esc_html( mysql2date( 'j M', $r->restocked_at ) ); ?></span>
								<?php else : ?>
									<span class="wceerp-badge"><?php esc_html_e( 'in transit', 'wc-enterprise-erp' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<p style="margin-top:12px">
					<button class="button button-primary" onclick="return wceerpRetConfirm();">
						<?php esc_html_e( 'Mark received and restock', 'wc-enterprise-erp' ); ?>
					</button>
					<span class="description" style="margin-left:8px" id="wceerp-ret-count"></span>
				</p>
			</form>
		</div>

		<script>
		(function () {
			var all   = document.getElementById( 'wceerp-ret-all' );
			var boxes = function () { return Array.prototype.slice.call( document.querySelectorAll( '.wceerp-ret-cb' ) ); };
			var out   = document.getElementById( 'wceerp-ret-count' );

			function refresh() {
				var n = boxes().filter( function ( b ) { return b.checked; } ).length;
				out.textContent = n ? n + ' <?php echo esc_js( __( 'selected', 'wc-enterprise-erp' ) ); ?>' : '';
			}
			if ( all ) {
				all.addEventListener( 'change', function () {
					boxes().forEach( function ( b ) { b.checked = all.checked; } );
					refresh();
				} );
			}
			boxes().forEach( function ( b ) { b.addEventListener( 'change', refresh ); } );

			window.wceerpRetConfirm = function () {
				var sel = boxes().filter( function ( b ) { return b.checked; } );
				if ( ! sel.length ) {
					alert( '<?php echo esc_js( __( 'Select the parcels you have received back.', 'wc-enterprise-erp' ) ); ?>' );
					return false;
				}
				document.getElementById( 'wceerp-ret-ids' ).value = sel.map( function ( b ) { return b.value; } ).join( ',' );
				return confirm( '<?php echo esc_js( __( 'Put these goods back into stock? Do this only once they are physically with you.', 'wc-enterprise-erp' ) ); ?>' );
			};
		})();
		</script>
		<?php
	}

	/**
	 * Undo a payout.
	 *
	 * Recording money that never arrived is the one mistake here that
	 * silently corrupts both the cash book and what a courier appears to
	 * owe, and it is easy to make: the form suggests the courier's own
	 * figures, so a payout can be posted for parcels that are still
	 * unpaid.
	 *
	 * The journal is voided rather than deleted and the parcels are put
	 * back exactly as they were, so the correction is itself auditable.
	 */
	/** Apply a mapping the user chose, and remember it for next time. */
	public function handle_payout_map() {
		$this->verify_nonce( 'wceerp_payout_map' );

		$raw = get_transient( 'wceerp_payout_raw_' . get_current_user_id() );
		if ( ! $raw || empty( $raw['rows'] ) ) {
			$this->stash_import_error( __( 'That upload expired. Please upload the file again.', 'wc-enterprise-erp' ) );
		}

		$header  = (int) ( $_POST['header_row'] ?? $raw['header'] );
		$courier = sanitize_key( $_POST['courier'] ?? $raw['courier'] );
		$chosen  = (array) ( $_POST['col'] ?? array() );

		$map = array();
		foreach ( WCEERP_Payout_Import::fields() as $field => $meta ) {
			$pos = isset( $chosen[ $field ] ) ? (int) $chosen[ $field ] : -1;
			if ( $pos >= 0 ) {
				$map[ $field ] = $pos;
			}
		}

		if ( ! isset( $map['memo'] ) && ! isset( $map['cid'] ) ) {
			$this->stash_import_error( __( 'Choose which column holds your consignment number, or the courier\'s parcel id — without one there is no way to tell which parcel a row belongs to.', 'wc-enterprise-erp' ) );
		}
		if ( ! isset( $map['coll'] ) ) {
			$this->stash_import_error( __( 'Choose which column holds the amount collected from the customer.', 'wc-enterprise-erp' ) );
		}

		$prepared = WCEERP_Payout_Import::prepare( $raw['rows'], array( 'header' => $header, 'map' => $map ) );
		$prepared['payment_id'] = WCEERP_Payout_Import::payment_id( $raw['rows'] );

		if ( ! $prepared['matched'] ) {
			$this->stash_import_error( __( 'Nothing matched with those columns. Check you picked the column holding your own consignment numbers, not the courier\'s.', 'wc-enterprise-erp' ) );
		}

		if ( $courier && ! empty( $_POST['remember'] ) ) {
			WCEERP_Payout_Import::save_map( $courier, $header, $map );
		}

		set_transient( 'wceerp_payout_import_' . get_current_user_id(), $prepared, HOUR_IN_SECONDS );
		delete_transient( 'wceerp_payout_raw_' . get_current_user_id() );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'imported' => 1 ) ) );
		exit;
	}

	/**
	 * Record a parcel that was booked in the courier's own portal.
	 *
	 * Staff book directly on the courier site often enough that refusing to
	 * acknowledge it just leaves the ERP wrong: the order shows as unbooked
	 * for ever, its COD never enters the receivable, and the money arrives
	 * against nothing. Attaching the tracking number brings it back under
	 * management without pretending the ERP made the booking.
	 */
	public function handle_attach_booking() {
		$this->verify_nonce( 'wceerp_attach_booking' );
		global $wpdb;

		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		$courier  = sanitize_key( $_POST['courier'] ?? '' );
		$remote   = sanitize_text_field( wp_unslash( $_POST['remote_id'] ?? '' ) );

		if ( ! $order_id || ! $courier || '' === $remote ) {
			$this->notice_redirect( 'error', __( 'Choose the courier and enter the tracking number they gave you.', 'wc-enterprise-erp' ) );
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( ! $order ) {
			$this->notice_redirect( 'error', __( 'That order no longer exists.', 'wc-enterprise-erp' ) );
		}

		$table = wceerp_table( 'consignments' );

		/* Already known to us? Then this is a correction, not a new parcel —
		 * creating a second consignment would double the receivable. */
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d", $order_id ) );
		if ( $existing ) {
			$wpdb->update(
				$table,
				array( 'courier' => $courier, 'remote_id' => $remote, 'tracking_code' => $remote, 'status' => 'booked' ),
				array( 'id' => (int) $existing->id )
			);
			wceerp_log( 'courier', 'booking_attached', (int) $existing->id, $courier . ' ' . $remote );
			$this->notice_redirect( 'success', __( 'Tracking number attached. The parcel will sync from here on.', 'wc-enterprise-erp' ) );
		}

		/* A new consignment for an order booked elsewhere. It posts COD to
		 * the receivable exactly as a normal booking would, because the
		 * money is genuinely out with a courier either way. */
		/* What the courier still has to collect: the order total less
		 * anything the customer already paid. */
		$cod = (float) $order->get_total();
		if ( class_exists( 'WCEERP_Order_Payments' ) ) {
			$cod = (float) WCEERP_Order_Payments::cod_outstanding( $order_id );
		}

		$doc = wceerp_next_doc_number( 'cn' );
		$wpdb->insert( $table, array(
			'doc_no'            => $doc,
			'order_id'          => $order_id,
			'courier'           => $courier,
			'remote_id'         => $remote,
			'tracking_code'     => $remote,
			'recipient_name'    => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'recipient_phone'   => $order->get_billing_phone(),
			'recipient_address' => wp_strip_all_tags( $order->get_formatted_billing_address() ),
			'cod_amount'        => $cod,
			'collected_amount'  => 0,
			'status'            => 'booked',
			'created_by'        => get_current_user_id(),
			'created_at'        => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;

		if ( $cod > 0.004 && class_exists( 'WCEERP_Accounting' ) ) {
			WCEERP_Accounting::post(
				array(
					'journal_date' => current_time( 'Y-m-d' ),
					'ref_type'     => 'consignment',
					'ref_id'       => $id,
					'memo'         => sprintf(
						/* translators: 1: consignment, 2: courier. */
						__( 'Parcel %1$s booked with %2$s (recorded after the fact)', 'wc-enterprise-erp' ),
						$doc,
						ucfirst( $courier )
					),
				),
				array(
					array( 'account' => '1110', 'debit' => $cod ),
					array( 'account' => '4000', 'credit' => $cod ),
				)
			);
		}

		$order->add_order_note( sprintf(
			/* translators: 1: courier, 2: tracking. */
			__( 'Booked directly with %1$s (%2$s) and recorded in the ERP.', 'wc-enterprise-erp' ),
			ucfirst( $courier ),
			$remote
		) );
		wceerp_log( 'courier', 'booking_recorded', $id, $courier . ' ' . $remote );

		$this->notice_redirect( 'success', sprintf(
			/* translators: %s: consignment number. */
			__( 'Recorded as %s. Its COD is now tracked like any other parcel.', 'wc-enterprise-erp' ),
			$doc
		) );
	}

	/**
	 * Settle a remittance by its total, without ticking parcels.
	 *
	 * Matching two hundred parcels by hand is not work anyone will keep
	 * doing, and a reconciliation nobody performs is worse than a rough one
	 * they do. The courier pays a lump sum against the oldest outstanding
	 * parcels, so that is how this allocates: oldest first, until the money
	 * runs out.
	 *
	 * Deliberately approximate, and the screen says so. It closes the right
	 * *amount* against the right courier; it may close a slightly different
	 * *set* of parcels than the courier had in mind. For a receivable
	 * balance that is fine — the total is what matters, and it beats a
	 * balance that drifts upward for ever because nobody had two hours to
	 * tick boxes.
	 *
	 * Anyone needing parcel-exact settlement should import the statement.
	 */
	public function handle_lump_payout() {
		$this->verify_nonce( 'wceerp_lump_payout' );
		global $wpdb;

		$courier    = sanitize_key( $_POST['courier'] ?? '' );
		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		$received   = wceerp_dec( $_POST['received'] ?? 0 );
		$charges    = wceerp_dec( $_POST['charges'] ?? 0 );
		$date       = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_POST['payout_date'] ?? '' ) ) ? $_POST['payout_date'] : current_time( 'Y-m-d' );
		$reference  = sanitize_text_field( wp_unslash( $_POST['reference'] ?? '' ) );

		if ( ! $courier || ! $account_id || $received <= 0 ) {
			$this->notice_redirect( 'error', __( 'Choose the courier and account, and enter what actually reached you.', 'wc-enterprise-erp' ) );
		}

		/* Gross is what the courier collected from customers: what reached
		 * you plus what they kept. */
		$gross = round( $received + $charges, 2 );
		$table = wceerp_table( 'consignments' );

		$candidates = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table}
			 WHERE courier = %s
			   AND payout_id IS NULL
			   AND status IN ('delivered','paid')
			   AND cod_amount - collected_amount > 0.004
			 ORDER BY created_at ASC, id ASC",
			$courier
		) );

		if ( ! $candidates ) {
			$this->notice_redirect( 'error', __( 'That courier has no delivered parcels awaiting payment.', 'wc-enterprise-erp' ) );
		}

		$remaining = $gross;
		$settle    = array();
		foreach ( $candidates as $c ) {
			if ( $remaining <= 0.004 ) {
				break;
			}
			$due  = (float) $c->cod_amount - (float) $c->collected_amount;
			$take = min( $due, $remaining );
			$settle[] = array( 'c' => $c, 'amount' => round( $take, 2 ), 'full' => ( $take + 0.004 >= $due ) );
			$remaining = round( $remaining - $take, 2 );
		}

		$allocated = round( $gross - $remaining, 2 );

		/* A payout that settles nothing must not exist.
		 *
		 * Submitting the form twice — a double tap, or a browser refreshing
		 * a POST — found no parcels left to allocate the second time, yet
		 * still wrote a payout row and posted the money to the books. The
		 * result was the same remittance counted several times, visible
		 * only as rows showing 0 parcels. */
		if ( $allocated <= 0.004 || ! $settle ) {
			$this->notice_redirect(
				'error',
				__( 'Nothing was left to settle for that courier, so no payout was recorded. If you have just recorded this payment, it is already in Recent payouts.', 'wc-enterprise-erp' )
			);
		}

		/* The same payment, twice.
		 *
		 * Matched on courier, date and amount because that is what a repeat
		 * submission looks like; a genuine second payment on the same day
		 * for the same amount is rare enough to be worth the warning. */
		$dupe = self::duplicate_payout( $courier, $date, round( $allocated - $charges, 2 ), $reference );
		if ( $dupe ) {
			$this->notice_redirect(
				'error',
				sprintf(
					/* translators: %d: payout id. */
					__( 'This looks like the same payment recorded a moment ago (payout #%d). Nothing was posted twice. If it really is a second payment, wait a few minutes and try again.', 'wc-enterprise-erp' ),
					$dupe
				)
			);
		}

		$wpdb->insert( wceerp_table( 'courier_payouts' ), array(
			'doc_no'      => wceerp_next_doc_number( 'cpo' ),
			'courier'     => $courier,
			'payout_date' => $date,
			'gross_cod'   => $allocated,
			'charges'     => round( $charges, 2 ),
			'net_amount'  => round( $allocated - $charges, 2 ),
			'account_id'  => $account_id,
			'note'        => $reference,
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		) );
		$payout_id = (int) $wpdb->insert_id;

		/* Spread the deduction across the parcels it settled.
		 *
		 * A lump sum records one charge total, but each parcel needs its
		 * share or the per-parcel column has nothing to show — and a column
		 * with nothing in it falls back to whatever the courier *reported*,
		 * which is a different number entirely. That is how a payout showing
		 * ৳1,157.80 of charges ended up with rows summing to ৳8,631.45.
		 *
		 * Pro-rata by collected amount, since courier fees scale with the
		 * value carried. The final parcel takes the rounding remainder so
		 * the parts always add back to the whole. */
		$charge_left = round( $charges, 2 );
		$alloc_base  = 0.0;
		foreach ( $settle as $row ) {
			$alloc_base += (float) $row['amount'];
		}
		$last_index = count( $settle ) - 1;

		foreach ( $settle as $idx => $row ) {
			$c = $row['c'];
			self::reverse_accrual( $c );

			$share = 0.0;
			if ( $charges > 0.004 && $alloc_base > 0.004 ) {
				$share = ( $idx === $last_index )
					? $charge_left
					: round( $charges * ( (float) $row['amount'] / $alloc_base ), 2 );
				$charge_left = round( $charge_left - $share, 2 );
			}

			$new = (float) $c->collected_amount + $row['amount'];
			$wpdb->update(
				$table,
				array(
					'collected_amount' => $new,
					'delivery_charge'  => round( (float) $c->delivery_charge + $share, 2 ),
					'status'           => $row['full'] ? 'paid' : 'delivered',
					// Only a fully settled parcel belongs to this payout.
					'payout_id'        => $row['full'] ? $payout_id : null,
				),
				array( 'id' => (int) $c->id )
			);
		}

		$lines = array( array( 'account' => $account_id, 'debit' => round( $allocated - $charges, 2 ) ) );
		if ( $charges > 0.004 ) {
			$lines[] = array( 'account' => '5600', 'debit' => round( $charges, 2 ) );
		}
		$lines[] = array( 'account' => '1110', 'credit' => $allocated );

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $date,
				'ref_type'     => 'courier_payout',
				'ref_id'       => $payout_id,
				'memo'         => sprintf(
					/* translators: 1: courier, 2: reference. */
					__( 'COD payout (by total) — %1$s %2$s', 'wc-enterprise-erp' ),
					ucfirst( $courier ),
					$reference ? '(' . $reference . ')' : ''
				),
			),
			$lines
		);

		if ( is_wp_error( $journal ) ) {
			wceerp_log( 'courier', 'lump_payout_failed', $payout_id, $journal->get_error_message() );
			$this->notice_redirect( 'error', sprintf(
				/* translators: %s: error. */
				__( 'Parcels were settled but the ledger entry failed: %s', 'wc-enterprise-erp' ),
				$journal->get_error_message()
			) );
		}

		$wpdb->update( wceerp_table( 'courier_payouts' ), array( 'journal_id' => (int) $journal ), array( 'id' => $payout_id ) );
		wceerp_log( 'courier', 'lump_payout', $payout_id, count( $settle ) . ' parcels, ' . $allocated );

		$msg = sprintf(
			/* translators: 1: amount, 2: parcels. */
			__( 'Recorded %1$s against %2$d parcels, oldest first.', 'wc-enterprise-erp' ),
			wp_strip_all_tags( wceerp_money( $allocated ) ),
			count( $settle )
		);
		if ( $remaining > 0.004 ) {
			$msg .= ' ' . sprintf(
				/* translators: %s: leftover. */
				__( '%s could not be allocated — that is more than the outstanding parcels are worth, so check the figure.', 'wc-enterprise-erp' ),
				wp_strip_all_tags( wceerp_money( $remaining ) )
			);
		}
		$this->notice_redirect( $remaining > 0.004 ? 'error' : 'success', $msg );
	}

	public function handle_payout_undo() {
		$this->verify_nonce( 'wceerp_payout_undo' );
		global $wpdb;

		$id     = (int) ( $_POST['payout_id'] ?? 0 );
		$payout = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'courier_payouts' ) . ' WHERE id = %d',
			$id
		) );
		if ( ! $payout ) {
			$this->notice_redirect( 'error', __( 'That payout no longer exists.', 'wc-enterprise-erp' ) );
		}

		$table = wceerp_table( 'consignments' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE payout_id = %d", $id ) );

		foreach ( (array) $rows as $c ) {
			/* Put the parcel back to delivered and owing. The collected and
			 * charge figures came from this payout, so they go with it. */
			$wpdb->update(
				$table,
				array(
					'collected_amount' => 0,
					'delivery_charge'  => 0,
					'discount_amount'  => 0,
					'payout_id'        => null,
					'status'           => 'delivered',
				),
				array( 'id' => (int) $c->id )
			);
		}

		if ( $payout->journal_id ) {
			WCEERP_Accounting::void( (int) $payout->journal_id, __( 'Payout reversed', 'wc-enterprise-erp' ) );
		}
		$wpdb->delete( wceerp_table( 'courier_payouts' ), array( 'id' => $id ) );

		wceerp_log( 'courier', 'payout_undone', $id, count( (array) $rows ) . ' parcels released' );

		$this->notice_redirect( 'success', sprintf(
			/* translators: 1: parcels, 2: amount. */
			__( 'Payout reversed. %1$d parcels are owing again and %2$s has been taken back out of your books.', 'wc-enterprise-erp' ),
			count( (array) $rows ),
			wp_strip_all_tags( wceerp_money( $payout->net_amount ) )
		) );
	}

	public function handle_record_payment() {
		$this->verify_nonce( 'wceerp_record_payment' );

		$result = WCEERP_Order_Payments::add( array(
			'order_id' => (int) ( $_POST['order_id'] ?? 0 ),
			'amount'   => $_POST['amount'] ?? 0,
			'method'   => $_POST['method'] ?? 'cash',
			'paid_on'  => sanitize_text_field( wp_unslash( $_POST['paid_on'] ?? '' ) ),
			'kind'     => 'advance',
		) );

		/* Return where the payment was taken from. The same form appears on
		 * the courier order list and on Dues, and bouncing someone to the
		 * other screen loses their place in a chase list. */
		$back = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
		if ( $back && 0 !== strpos( $back, admin_url() ) ) {
			$back = '';
		}

		if ( is_wp_error( $result ) ) {
			set_transient( 'wceerp_courier_err_' . get_current_user_id(), $result->get_error_message(), 60 );
			wp_safe_redirect( $back ? add_query_arg( 'error', rawurlencode( $result->get_error_message() ), $back ) : $this->admin_url( array( 'tab' => 'orders', 'failed' => 1 ) ) );
			exit;
		}
		wp_safe_redirect( $back ? add_query_arg( 'updated', 1, $back ) : $this->admin_url( array( 'tab' => 'orders', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_opening() {
		$this->verify_nonce( 'wceerp_cod_opening' );

		if ( wceerp_get_option( 'cod_opening_journal', 0 ) ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'error' => 'exists' ) ) );
			exit;
		}

		$breakdown = array();
		$total     = 0.0;
		foreach ( array_keys( self::drivers() ) as $slug ) {
			$amt = wceerp_dec( $_POST[ 'amt_' . $slug ] ?? 0 );
			if ( $amt > 0 ) {
				$breakdown[ $slug ] = $amt;
				$total             += $amt;
			}
		}
		$other = wceerp_dec( $_POST['amt_other'] ?? 0 );
		if ( $other > 0 ) {
			$breakdown['other'] = $other;
			$total             += $other;
		}

		if ( $total <= 0 ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'error' => 'empty' ) ) );
			exit;
		}

		$equity = sanitize_text_field( wp_unslash( $_POST['equity_account'] ?? '3200' ) );
		$date   = sanitize_text_field( wp_unslash( $_POST['as_of'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$start = wceerp_start_date();
			$date  = $start ? gmdate( 'Y-m-d', strtotime( $start . ' -1 day' ) ) : current_time( 'Y-m-d' );
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $date,
				'ref_type'     => 'cod_opening',
				'ref_id'       => 0,
				'memo'         => __( 'Opening balance — COD in transit with couriers', 'wc-enterprise-erp' ),
			),
			array(
				array( 'account' => '1110', 'debit' => $total, 'memo' => __( 'COD outstanding at go-live', 'wc-enterprise-erp' ) ),
				array( 'account' => $equity, 'credit' => $total, 'memo' => __( 'Opening balance', 'wc-enterprise-erp' ) ),
			)
		);

		if ( is_wp_error( $journal ) ) {
			set_transient( 'wceerp_courier_err_' . get_current_user_id(), $journal->get_error_message(), 60 );
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'failed' => 1 ) ) );
			exit;
		}

		wceerp_update_option( 'cod_opening_total', $total );
		wceerp_update_option( 'cod_opening_journal', (int) $journal );
		wceerp_update_option( 'cod_opening_date', $date );
		wceerp_update_option( 'cod_opening_breakdown', $breakdown );
		wceerp_log( 'courier', 'cod_opening', (int) $journal, (string) $total );

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Record legacy COD money arriving from a courier.
	 *
	 * Mirrors the normal payout posting exactly, minus the per-parcel
	 * settlement: Dr deposit (net) + Dr 5600 charges / Cr 1110 (gross).
	 */
	public function handle_opening_receipt() {
		$this->verify_nonce( 'wceerp_cod_opening_receipt' );

		$gross   = wceerp_dec( $_POST['gross'] ?? 0 );
		$charges = wceerp_dec( $_POST['charges'] ?? 0 );
		$deposit = sanitize_text_field( wp_unslash( $_POST['deposit_account'] ?? '' ) );
		$courier = sanitize_key( $_POST['courier'] ?? '' );
		$date    = sanitize_text_field( wp_unslash( $_POST['paid_on'] ?? '' ) );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$date = current_time( 'Y-m-d' );
		}
		if ( $gross <= 0 || ! $deposit ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'error' => 'receipt' ) ) );
			exit;
		}
		if ( $charges > $gross ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'error' => 'charges' ) ) );
			exit;
		}

		$outstanding = (float) wceerp_get_option( 'cod_opening_total', 0 ) - self::opening_received();
		if ( $gross > $outstanding + 0.004 ) {
			// Overdrawing would credit 1110 past the opening balance and
			// push it negative again -- exactly what this feature prevents.
			set_transient(
				'wceerp_courier_err_' . get_current_user_id(),
				sprintf(
					/* translators: %s: remaining amount. */
					__( 'That is more than the legacy COD still outstanding (%s). Money above this belongs to a real consignment — record it on the COD payouts tab instead.', 'wc-enterprise-erp' ),
					wp_strip_all_tags( wceerp_money( $outstanding ) )
				),
				60
			);
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'failed' => 1 ) ) );
			exit;
		}

		$lines = array(
			array( 'account' => $deposit, 'debit' => $gross - $charges, 'memo' => __( 'Legacy COD received', 'wc-enterprise-erp' ) ),
		);
		if ( $charges > 0 ) {
			$lines[] = array( 'account' => '5600', 'debit' => $charges, 'memo' => __( 'Delivery charges — legacy parcels', 'wc-enterprise-erp' ) );
		}
		$lines[] = array( 'account' => '1110', 'credit' => $gross, 'memo' => __( 'Legacy COD settled', 'wc-enterprise-erp' ) );

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => $date,
				'ref_type'     => 'cod_opening_receipt',
				'ref_id'       => 0,
				'memo'         => sprintf( __( 'Legacy COD received — %s', 'wc-enterprise-erp' ), $courier ? strtoupper( $courier ) : __( 'courier', 'wc-enterprise-erp' ) ),
			),
			$lines
		);

		if ( is_wp_error( $journal ) ) {
			set_transient( 'wceerp_courier_err_' . get_current_user_id(), $journal->get_error_message(), 60 );
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'failed' => 1 ) ) );
			exit;
		}

		wceerp_log( 'courier', 'cod_opening_receipt', (int) $journal, $courier . ' ' . $gross );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'opening', 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Apply a resolved status to a consignment, with the delivered
	 * notification. Shared by the hourly poll and the Bahok webhook so both
	 * paths behave identically.
	 */
	/**
	 * A parcel came back.
	 *
	 * Until now a returned parcel changed nothing but a label: the sale
	 * stayed on the books, the stock stayed gone, and the COD stayed in the
	 * receivable. All three are wrong once the goods are back on the shelf,
	 * and left alone they quietly overstate revenue, understate stock and
	 * inflate what the courier appears to owe.
	 *
	 * Deliberately split in two, because they happen at different moments:
	 *
	 *   Marked "returned" — the parcel is travelling back. The sale is
	 *   reversed and the COD released, because that money is never coming.
	 *   Stock is NOT restored: the goods are in a van somewhere, not on
	 *   your shelf, and counting them would make the stock figure a lie.
	 *
	 *   Marked "return received" — the goods are physically back. Only then
	 *   does the stock return, at the cost it left at.
	 *
	 * @return true|WP_Error
	 */
	public static function reverse_sale( $c ) {
		global $wpdb;

		if ( ! empty( $c->reversed_at ) ) {
			return true; // already done; never post twice
		}

		$order_id = (int) $c->order_id;
		$cod      = (float) $c->cod_amount - (float) $c->collected_amount;

		/* Release the COD from the courier receivable. Nothing was
		 * collected, so this is a straight reversal of what booking the
		 * parcel debited. */
		if ( $cod > 0.004 ) {
			$journal = WCEERP_Accounting::post(
				array(
					'journal_date' => current_time( 'Y-m-d' ),
					'ref_type'     => 'courier_return',
					'ref_id'       => (int) $c->id,
					'memo'         => sprintf(
						/* translators: %s: consignment number. */
						__( 'Parcel returned — %s', 'wc-enterprise-erp' ),
						$c->doc_no
					),
				),
				array(
					array( 'account' => '4000', 'debit' => round( $cod, 2 ) ),
					array( 'account' => '1110', 'credit' => round( $cod, 2 ) ),
				)
			);
			if ( is_wp_error( $journal ) ) {
				wceerp_log( 'courier', 'return_reverse_failed', (int) $c->id, $journal->get_error_message() );
				return $journal;
			}
		}

		$wpdb->update(
			wceerp_table( 'consignments' ),
			array( 'reversed_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $c->id )
		);
		wceerp_log( 'courier', 'return_reversed', (int) $c->id, wp_strip_all_tags( wceerp_money( $cod ) ) );

		if ( $order_id ) {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
			if ( $order ) {
				$order->add_order_note( sprintf(
					/* translators: %s: consignment number. */
					__( 'Parcel %s returned by the courier. Sale reversed in the ERP.', 'wc-enterprise-erp' ),
					$c->doc_no
				) );
			}
		}
		return true;
	}

	/**
	 * The returned goods are physically back — put them into stock.
	 *
	 * Restored at the cost they left at, taken from the movement written
	 * when the sale was posted. Using today's cost would silently change
	 * the value of stock that never changed hands.
	 *
	 * @return int Number of lines restocked.
	 */
	public static function restock_return( $c ) {
		global $wpdb;

		if ( ! empty( $c->restocked_at ) ) {
			return 0; // goods already back on the shelf
		}
		$order_id = (int) $c->order_id;
		if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
			return 0;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return 0;
		}

		$moves = $wpdb->get_results( $wpdb->prepare(
			"SELECT product_id, warehouse_id, SUM(qty) AS qty, AVG(unit_cost) AS unit_cost
			 FROM " . wceerp_table( 'stock_moves' ) . "
			 WHERE direction = 'out' AND ref_type IN ('wc_order','pos') AND ref_id = %d
			 GROUP BY product_id, warehouse_id",
			$order_id
		) );

		$lines = 0;
		foreach ( (array) $moves as $m ) {
			if ( (float) $m->qty <= 0 ) {
				continue;
			}
			WCEERP_Module_Inventory::move_stock(
				(int) $m->product_id,
				(int) $m->warehouse_id,
				(float) $m->qty,
				'in',
				'return',
				(int) $c->id,
				(float) $m->unit_cost,
				null,
				sprintf(
					/* translators: %s: consignment number. */
					__( 'Returned parcel %s', 'wc-enterprise-erp' ),
					$c->doc_no
				)
			);
			$lines++;
		}

		$wpdb->update(
			wceerp_table( 'consignments' ),
			array( 'restocked_at' => current_time( 'mysql' ), 'status' => 'returned' ),
			array( 'id' => (int) $c->id )
		);
		wceerp_log( 'courier', 'return_restocked', (int) $c->id, $lines . ' line(s)' );

		$order->add_order_note( sprintf(
			/* translators: 1: consignment, 2: lines. */
			__( 'Returned parcel %1$s received back. %2$d stock line(s) restored.', 'wc-enterprise-erp' ),
			$c->doc_no,
			$lines
		) );

		return $lines;
	}

	/**
	 * Recognise a courier charge when the parcel is delivered.
	 *
	 * The charge is incurred the moment the courier does the work, not when
	 * they get round to remitting. Posting it only at payout leaves the sale
	 * in one month and its delivery cost in another, so a busy month looks
	 * more profitable than it was and the next looks worse.
	 *
	 * The estimate goes to Delivery charges against Courier Charges Payable.
	 * When the real payout arrives the accrual is reversed and the actual
	 * figure posted, so the estimate never survives contact with the truth.
	 *
	 * Off by default: it changes what the P&L says, and that is a decision
	 * for the shop rather than something to switch on behind their back.
	 */
	public static function accrue_charge( $c ) {
		global $wpdb;

		/* Accrual was removed from the settings screen too. Charges are
		 * recognised when the courier's payment is recorded, which is the
		 * simpler position and the one that always matches the bank. */
		if ( 'yes' !== wceerp_get_option( 'courier_accrue', '' ) ) {
			return false;
		}
		if ( ! empty( $c->accrued_at ) || (int) $c->payout_id ) {
			return false; // already accrued, or already settled for real
		}

		$basis = (float) $c->cod_amount - (float) $c->collected_amount;
		if ( (float) $c->remote_collected > 0.004 ) {
			$basis = (float) $c->remote_collected;
		}

		$charge = (float) $c->remote_charge;
		if ( $charge <= 0.004 ) {
			$est    = self::estimate_charge( $c->courier, $basis, $c );
			$charge = ( null !== $est ) ? (float) $est : 0;
		}
		if ( $charge <= 0.004 ) {
			return false;
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => current_time( 'Y-m-d' ),
				'ref_type'     => 'courier_accrual',
				'ref_id'       => (int) $c->id,
				'memo'         => sprintf(
					/* translators: 1: consignment, 2: courier. */
					__( 'Courier charge accrued on delivery — %1$s (%2$s)', 'wc-enterprise-erp' ),
					$c->doc_no,
					ucfirst( $c->courier )
				),
			),
			array(
				array( 'account' => '5600', 'debit' => round( $charge, 2 ) ),
				array( 'account' => '2150', 'credit' => round( $charge, 2 ) ),
			)
		);

		if ( is_wp_error( $journal ) ) {
			wceerp_log( 'courier', 'accrual_failed', (int) $c->id, $journal->get_error_message() );
			return false;
		}

		$wpdb->update(
			wceerp_table( 'consignments' ),
			array( 'accrued_charge' => round( $charge, 2 ), 'accrued_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $c->id )
		);
		return true;
	}

	/**
	 * Undo an accrual, because the real charge is now known.
	 *
	 * Called as a payout is posted. Without it the estimate and the actual
	 * would both sit in Delivery charges and the cost would be counted twice.
	 */
	public static function reverse_accrual( $c ) {
		global $wpdb;

		if ( empty( $c->accrued_at ) || (float) $c->accrued_charge <= 0.004 ) {
			return false;
		}
		$amount = (float) $c->accrued_charge;

		WCEERP_Accounting::post(
			array(
				'journal_date' => current_time( 'Y-m-d' ),
				'ref_type'     => 'courier_accrual_reversal',
				'ref_id'       => (int) $c->id,
				'memo'         => sprintf(
					/* translators: %s: consignment. */
					__( 'Accrued courier charge reversed, actual now known — %s', 'wc-enterprise-erp' ),
					$c->doc_no
				),
			),
			array(
				array( 'account' => '2150', 'debit' => $amount ),
				array( 'account' => '5600', 'credit' => $amount ),
			)
		);

		$wpdb->update(
			wceerp_table( 'consignments' ),
			array( 'accrued_charge' => null, 'accrued_at' => null ),
			array( 'id' => (int) $c->id )
		);
		return true;
	}

	public static function apply_status( $c, $status ) {
		global $wpdb;
		$table  = wceerp_table( 'consignments' );
		$update = array( 'last_sync' => current_time( 'mysql' ) );

		if ( $status && $status !== $c->status ) {
			$update['status'] = $status;

			if ( class_exists( 'WCEERP_Messaging' ) && in_array( $status, array( 'delivered', 'returned' ), true ) ) {
				WCEERP_Messaging::send_event( $status, $c );
			}

			/* A return releases the money straight away. The goods are still
			 * in transit back, so stock waits until they are received. */
			/* Both outcomes mean the money is not coming and the goods are
			 * on their way back, so both release the sale. */
			if ( in_array( $status, array( 'returned', 'cancelled' ), true ) ) {
				self::reverse_sale( $c );
			}

			/* Delivered means the courier has done the work and earned its
			 * charge, whether or not it has paid out yet. */
			if ( 'delivered' === $status ) {
				self::accrue_charge( $c );
			}
			if ( 'delivered' === $status && class_exists( 'WCEERP_Module_Notifications' ) ) {
				WCEERP_Module_Notifications::add(
					'courier',
					sprintf( __( 'Parcel delivered — %s', 'wc-enterprise-erp' ), $c->doc_no ),
					sprintf( __( 'COD %s is now awaiting collection from %s.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $c->cod_amount ) ), $c->courier ),
					admin_url( 'admin.php?page=wceerp-courier&tab=payouts' )
				);
			}
		}
		$wpdb->update( $table, $update, array( 'id' => $c->id ) );
		return isset( $update['status'] );
	}

	/* ---------------------------------------------------------------------
	 * Bahok status webhook.
	 *
	 * Bahok pushes delivery updates to a URL configured in their merchant
	 * panel, authenticated with a shared token. This is faster than the
	 * hourly poll, which stays enabled as a fallback in case a webhook is
	 * missed.
	 * ------------------------------------------------------------------- */

	public function register_webhook() {
		register_rest_route( 'wceerp/v1', '/courier/bahok/webhook', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'rest_bahok_webhook' ),
			'permission_callback' => '__return_true', // Authenticated by shared token below.
		) );
	}

	public static function rest_bahok_webhook( WP_REST_Request $request ) {
		global $wpdb;

		$expected = (string) self::setting( 'bahok_webhook_token' );
		if ( '' === $expected ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Webhook not configured.' ), 503 );
		}

		/* Accept the token from the usual places; Bahok's exact transport
		 * is not documented, so check header and body without leaking
		 * which one matched. */
		$body     = $request->get_json_params();
		$body     = is_array( $body ) ? $body : array();
		$supplied = (string) (
			$request->get_header( 'x-webhook-token' )
			?: $request->get_header( 'authorization' )
			?: ( $body['webhook_auth_token'] ?? $body['auth_token'] ?? $body['token'] ?? '' )
		);
		$supplied = trim( preg_replace( '/^Bearer\s+/i', '', $supplied ) );

		if ( ! hash_equals( $expected, $supplied ) ) {
			wceerp_log( 'courier', 'bahok_webhook_denied', 0 );
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Unauthorised.' ), 401 );
		}

		$data = ( isset( $body['data'] ) && is_array( $body['data'] ) ) ? $body['data'] : $body;

		/* Bahok's live payload names things differently from the couriers
		 * this was first written against, which is why every delivery
		 * returned "Missing consignment or status": their identifier is
		 * `id` with the tracking code in `tracking_id`, and our own
		 * consignment number arrives as `ref_id`. All spellings are
		 * accepted so a change at their end cannot break this again. */
		$remote = (string) (
			$data['consignmentId']
			?? $data['consignment_id']
			?? $data['tracking_id']
			?? $data['id']
			?? ''
		);
		$mid = (string) (
			$data['merchant_order_id']
			?? $data['ref_id']
			?? $data['reference']
			?? ''
		);
		$status = (string) (
			$data['order_status']
			?? $data['status']
			?? $data['payment_status']
			?? ''
		);

		if ( '' === $status || ( '' === $remote && '' === $mid ) ) {
			/* Say what arrived. A bare refusal gives the courier's engineers
			 * nothing to act on, and this is the message they will read. */
			wceerp_log( 'courier', 'bahok_webhook_bad_payload', 0, wp_json_encode( array_slice( (array) $data, 0, 20 ) ) );
			return new WP_REST_Response( array(
				'success' => false,
				'message' => 'Missing consignment or status.',
				'expects' => array(
					'identifier' => 'one of: id, tracking_id, ref_id, consignmentId, merchant_order_id',
					'status'     => 'one of: status, order_status, payment_status',
				),
				'received' => array_keys( (array) $data ),
			), 400 );
		}

		$table = wceerp_table( 'consignments' );
		$c     = null;
		if ( '' !== $remote ) {
			$c = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$table} WHERE courier = 'bahok' AND remote_id = %s LIMIT 1", $remote
			) );
		}
		if ( ! $c && '' !== $mid ) {
			$c = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$table} WHERE courier = 'bahok' AND doc_no = %s LIMIT 1", $mid
			) );
		}
		if ( ! $c ) {
			wceerp_log( 'courier', 'bahok_webhook_unmatched', 0, $remote . '/' . $mid );
			return new WP_REST_Response( array( 'success' => true, 'message' => 'No matching consignment.' ), 200 );
		}

		$mapped = self::bahok_status( $status, $c );
		self::apply_status( $c, $mapped );

		/* The payload carries the money as well: `collected` is what was
		 * taken from the customer and `amount` is what Bahok will actually
		 * remit after its charges, so the difference is the charge.
		 *
		 * Both are stored as courier-reported figures only. They do not
		 * settle the parcel: money is not yours until it reaches your
		 * account, and that is recorded when the payout is posted. */
		$collected = isset( $data['collected'] ) ? wceerp_dec( $data['collected'] ) : null;
		$payable   = isset( $data['amount'] ) ? wceerp_dec( $data['amount'] ) : null;
		$charge    = ( null !== $collected && null !== $payable && $collected > 0 )
			? max( 0, $collected - $payable )
			: null;

		self::stash_remote_money( $c, array(
			'collected' => $collected,
			'charge'    => $charge,
			'cod'       => isset( $data['price'] ) ? wceerp_dec( $data['price'] ) : null,
		) );

		wceerp_log(
			'courier',
			'bahok_webhook',
			(int) $c->id,
			sprintf( '%s => %s | collected %s, payable %s', $status, $mapped, (string) $collected, (string) $payable )
		);

		return new WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Background sync.
	 *
	 * Delivered parcels used to be excluded, on the reasoning that their
	 * journey was over. But the money is not: a delivered parcel the
	 * courier has not yet paid for is exactly the row whose collected
	 * amount needs watching, and skipping it meant COD figures never
	 * arrived on their own. Anything still owing is now chased too.
	 */
	public static function cron_sync() {
		self::sync_batch( 40 );
	}

	/**
	 * Sync one batch of parcels through the courier APIs.
	 *
	 * Ordered so the least recently checked go first, which means repeated
	 * runs work through the whole book rather than re-checking the same
	 * few. Returns what it did so a progress display can be honest.
	 *
	 * @return array {done, remaining, money}
	 */
	public static function sync_batch( $limit = 25, $since = '' ) {
		global $wpdb;
		$table = wceerp_table( 'consignments' );

		/* Still moving, or delivered but not yet paid for. */
		$where = "remote_id IS NOT NULL AND remote_id <> ''
		          AND courier IN ('steadfast','pathao','bahok','redx','carrybee')
		          AND (
		            status IN ('booked','in_transit')
		            OR ( status = 'delivered' AND cod_amount - collected_amount > 0.004 )
		          )";

		/* Only parcels not yet touched in this run.
		 *
		 * Without this the sync never finishes. Checking a delivered parcel
		 * the courier has not paid for does not change anything about it, so
		 * it stays in the qualifying set and comes round again — the first
		 * version looped over the same parcels for as long as the page was
		 * open, which is both useless and rude to the courier's API.
		 *
		 * Stamping last_sync on every attempt and excluding anything already
		 * stamped since the run began makes "sync everything" mean exactly
		 * one pass, and lets remaining fall honestly to zero. */
		$params = array();
		if ( $since ) {
			$where   .= ' AND ( last_sync IS NULL OR last_sync < %s )';
			$params[] = $since;
		}

		$sql      = "SELECT * FROM {$table} WHERE {$where} ORDER BY last_sync IS NULL DESC, last_sync ASC LIMIT %d";
		$params[] = (int) $limit;
		$rows     = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		$done  = 0;
		$money = 0;
		foreach ( (array) $rows as $c ) {
			$status = self::api_track( $c );
			self::apply_status( $c, is_wp_error( $status ) ? '' : $status );

			/* api_track() stores whatever the courier said about money. */
			$after = $wpdb->get_row( $wpdb->prepare(
				"SELECT remote_collected FROM {$table} WHERE id = %d",
				(int) $c->id
			) );
			if ( $after && (float) $after->remote_collected > 0.004 ) {
				$money++;
			}
			$done++;
		}

		$remaining = $since
			? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where}", $since ) )
			: (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );

		return array(
			'done'      => $done,
			'remaining' => max( 0, $remaining ),
			'money'     => $money,
		);
	}

	/** AJAX: one batch, so the browser can show progress across many. */
	public function ajax_sync_batch() {
		if ( ! wceerp_user_can( $this->capability ) ) {
			wp_send_json_error( array(), 403 );
		}
		check_ajax_referer( 'wceerp_sync_all', 'nonce' );

		/* A run window is required.
		 *
		 * Defaulting this to "now" was the bug behind a sync that never
		 * ended: every call then excluded nothing, so the same parcels came
		 * back for ever. Refusing outright is better than looping — a
		 * caller that cannot supply a window is not doing a single pass. */
		$since = sanitize_text_field( wp_unslash( $_POST['since'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $since ) ) {
			wp_send_json_error( array(
				'message' => __( 'Reload the page and start the sync again.', 'wc-enterprise-erp' ),
			), 400 );
		}

		$result          = self::sync_batch( 25, $since );
		$result['since'] = $since;

		/* Kept so the outcome survives navigating away — a progress bar that
		 * vanishes when you change page tells you nothing about whether the
		 * work finished. */
		$state = (array) get_option( 'wceerp_sync_state', array() );
		if ( ( $state['since'] ?? '' ) !== $since ) {
			$state = array( 'since' => $since, 'checked' => 0, 'money' => 0 );
		}
		$state['checked']   = (int) $state['checked'] + (int) $result['done'];
		$state['money']     = (int) $state['money'] + (int) $result['money'];
		$state['remaining'] = (int) $result['remaining'];
		$state['at']        = current_time( 'mysql' );
		update_option( 'wceerp_sync_state', $state, false );

		wp_send_json_success( $result );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function order_action_button( $actions, $order ) {
		if ( ! wceerp_user_can( $this->capability ) ) {
			return $actions;
		}
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$cons  = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE order_id = %d ORDER BY id DESC LIMIT 1", $order->get_id() ) );
		if ( $cons ) {
			$actions['wceerp_courier_view'] = array(
				'url'    => admin_url( 'admin.php?page=wceerp-courier&tab=consignments&status=' . rawurlencode( $cons->status ) ),
				'name'   => __( 'View consignment', 'wc-enterprise-erp' ),
				'action' => 'wceerp_courier_view',
			);
		} else {
			$actions['wceerp_courier'] = array(
				'url'    => admin_url( 'admin.php?page=wceerp-courier&tab=new&order_id=' . $order->get_id() ),
				'name'   => __( 'Create consignment', 'wc-enterprise-erp' ),
				'action' => 'wceerp_courier_send',
			);
		}
		return $actions;
	}

	/**
	 * Add "Create consignments" as a bulk action on the orders list, so a
	 * batch of manually-entered orders (Facebook / WhatsApp) can be booked
	 * at once. Works on both the classic (shop_order) and HPOS list.
	 */
	/**
	 * Auto-create a pending consignment for a COD order that just reached
	 * Processing.
	 *
	 * Deliberately conservative:
	 *   - Off unless the operator enables it in settings.
	 *   - COD orders only (prepaid orders don't need COD tracking).
	 *   - Skips POS sales — those are handed over at the counter.
	 *   - Skips an order that already has a consignment (idempotent, so a
	 *     status flip-flop can't create duplicates).
	 *   - Creates it as 'pending' with no courier API call, so nothing is
	 *     booked or charged without a human confirming it.
	 */
	public function maybe_auto_create( $order_id ) {
		if ( 'yes' !== self::setting( 'auto_create', 'no' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		// COD only.
		if ( false === stripos( (string) $order->get_payment_method(), 'cod' ) ) {
			return;
		}
		// POS sales are collected in person.
		if ( 'wceerp_pos' === $order->get_created_via() ) {
			return;
		}

		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d LIMIT 1", $order_id ) );
		if ( $exists ) {
			return;
		}

		$courier = self::setting( 'auto_courier', '' );
		if ( ! array_key_exists( $courier, self::drivers() ) ) {
			$courier = apply_filters( 'wceerp_bulk_default_courier', 'steadfast' );
		}

		$wpdb->insert( $table, array(
			'order_id'         => $order_id,
			'doc_no'           => wceerp_next_consignment_number(),
			'courier'          => $courier,
			'recipient_name'   => $order->get_formatted_billing_full_name(),
			'recipient_phone'  => $order->get_billing_phone(),
			'recipient_address' => self::address_for_order( $order ),
			'cod_amount'       => self::collectible_for( $order ),
			'collected_amount' => 0,
			'status'           => 'pending',
			'created_at'       => current_time( 'mysql' ),
		) );

		$order->add_order_note( __( 'ERP: pending courier consignment created automatically (COD).', 'wc-enterprise-erp' ) );
		wceerp_log( 'courier', 'auto_consignment', $order_id, $courier );
	}

	public function register_bulk_action( $actions ) {
		if ( wceerp_user_can( $this->capability ) ) {
			$actions['wceerp_create_consignments'] = __( 'Create courier consignments', 'wc-enterprise-erp' );
		}
		return $actions;
	}

	public function handle_bulk_action( $redirect, $action, $ids ) {
		if ( 'wceerp_create_consignments' !== $action ) {
			return $redirect;
		}
		global $wpdb;
		$table   = wceerp_table( 'consignments' );
		$created = 0;
		$skipped = 0;
		foreach ( (array) $ids as $oid ) {
			$oid   = (int) $oid;
			$order = wc_get_order( $oid );
			if ( ! $order ) {
				continue;
			}
			// Skip if a consignment already exists for this order.
			if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d LIMIT 1", $oid ) ) ) {
				$skipped++;
				continue;
			}
			$is_cod = false !== stripos( (string) $order->get_payment_method(), 'cod' );
			$wpdb->insert( $table, array(
				'order_id'         => $oid,
				'doc_no'           => wceerp_next_consignment_number(),
				'courier'          => apply_filters( 'wceerp_bulk_default_courier', self::setting( 'auto_courier' ) ?: 'steadfast' ),
				'recipient_name'    => $order->get_formatted_billing_full_name(),
				'recipient_phone'   => $order->get_billing_phone(),
				'recipient_address' => self::address_for_order( $order ),
				'cod_amount'       => $is_cod ? self::collectible_for( $order ) : 0,
				'collected_amount' => 0,
				'status'           => 'pending',
				'created_at'       => current_time( 'mysql' ),
			) );
			$created++;
		}
		return add_query_arg( array(
			'wceerp_cons_created' => $created,
			'wceerp_cons_skipped' => $skipped,
		), $redirect );
	}

	/** Admin notice after the bulk action runs. */
	public function bulk_action_notice() {
		if ( ! isset( $_GET['wceerp_cons_created'] ) ) {
			return;
		}
		$created = (int) $_GET['wceerp_cons_created'];
		$skipped = (int) $_GET['wceerp_cons_skipped'];
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			esc_html( sprintf(
				/* translators: 1: created count 2: skipped count */
				__( '%1$d consignment(s) created as pending. %2$d skipped (already had one). Open Orders & Payments → Consignments to book them with a courier.', 'wc-enterprise-erp' ),
				$created,
				$skipped
			) )
		);
	}

	public function handle_create() {
		$this->verify_nonce( 'wceerp_consignment_create' );

		/* Optional hand-entered CN, for shops that carry a pre-printed book
		 * or must match a number the courier already issued. Rejected if it
		 * clashes, because doc_no is how payouts and webhooks find a row. */
		$manual_doc = strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['doc_no'] ?? '' ) ) ) );
		$manual_doc = preg_replace( '/[^A-Z0-9\-\/]/', '', $manual_doc );
		if ( $manual_doc && wceerp_consignment_number_exists( $manual_doc ) ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'new', 'error' => 'doc_taken' ) ) );
			exit;
		}
		global $wpdb;

		$remote_id = (int) ( $_POST['remote_id'] ?? 0 );
		$order     = null;
		$remote    = null;

		if ( $remote_id ) {
			// Connected-store order: details come from the mirrored copy,
			// since the order itself lives on the customer's own site.
			$remote = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM " . wceerp_table( 'connect_orders' ) . " WHERE remote_id = %d",
				$remote_id
			) );
			if ( ! $remote ) {
				wp_die( esc_html__( 'Connected-store order not found.', 'wc-enterprise-erp' ) );
			}
		} else {
			$order = wc_get_order( (int) ( $_POST['order_id'] ?? 0 ) );
			if ( ! $order ) {
				wp_die( esc_html__( 'Order not found.', 'wc-enterprise-erp' ) );
			}
		}

		$courier = sanitize_key( $_POST['courier'] ?? '' );
		if ( ! array_key_exists( $courier, self::drivers() ) ) {
			$courier = 'steadfast';
		}

		if ( $remote ) {
			$def_name  = $remote->customer_name;
			$def_phone = $remote->customer_phone;
			$def_addr  = $remote->customer_address;
			$order_ref = (int) $remote->remote_id;
			$source    = 'remote';
		} else {
			$def_name  = $order->get_formatted_billing_full_name();
			$def_phone = $order->get_billing_phone();
			$def_addr  = self::address_for_order( $order );
			$order_ref = $order->get_id();
			$source    = 'local';
		}

		$wpdb->insert( wceerp_table( 'consignments' ), array(
			'doc_no'            => $manual_doc ? $manual_doc : wceerp_next_consignment_number(),
			'order_id'          => $order_ref,
			'order_source'      => $source,
			'courier'           => $courier,
			'recipient_name'    => sanitize_text_field( wp_unslash( $_POST['recipient_name'] ?? $def_name ) ),
			'recipient_phone'   => sanitize_text_field( wp_unslash( $_POST['recipient_phone'] ?? $def_phone ) ),
			'recipient_address' => sanitize_textarea_field( wp_unslash( $_POST['recipient_address'] ?? $def_addr ) ),
			'cod_amount'        => wceerp_dec( $_POST['cod_amount'] ?? 0 ),
			'note'              => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'status'            => 'pending',
			'created_at'        => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;

		if ( $order ) {
			$order->update_meta_data( '_wceerp_consignment_id', $id );
			$order->save();
		}

		wceerp_log( 'courier', 'consignment_create', $id, $courier );

		// Book immediately if requested and the driver has an API.
		if ( ! empty( $_POST['book_now'] ) ) {
			$this->book_consignment( $id );
		}

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'consignments', 'updated' => 1 ) ) );
		exit;
	}

	protected function book_consignment( $id ) {
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$c     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
		if ( ! $c || 'pending' !== $c->status ) {
			return;
		}
		$drivers = self::drivers();
		if ( empty( $drivers[ $c->courier ]['api'] ) ) {
			// Manual courier: "booked" just means handed over.
			$wpdb->update( $table, array( 'status' => 'booked' ), array( 'id' => $id ) );
			return;
		}
		$result = self::api_book( $c );
		if ( is_wp_error( $result ) ) {
			wceerp_log( 'courier', 'book_failed', $id, $result->get_error_message() );
			return $result;
		}
		$wpdb->update( $table, array(
			'remote_id'     => $result['remote_id'],
			'tracking_code' => $result['tracking_code'],
			'status'        => $result['status'],
			'last_sync'     => current_time( 'mysql' ),
		), array( 'id' => $id ) );
		wceerp_log( 'courier', 'booked', $id, $c->courier . ' ' . $result['remote_id'] );

		/* Tell the customer their parcel is on the way. Queued, so a slow
		 * SMS gateway never delays the person who pressed Book. */
		if ( class_exists( 'WCEERP_Messaging' ) ) {
			$fresh = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			if ( $fresh ) {
				WCEERP_Messaging::send_event( 'booked', $fresh );
			}
		}

		/* If the shop recognises sales at dispatch rather than at order
		 * placement, this is the moment stock leaves and the sale posts. */
		if ( $c->order_id && 'remote' !== $c->order_source && class_exists( 'WCEERP_WC_Bridge' ) ) {
			WCEERP_WC_Bridge::post_on_booking( (int) $c->order_id );
		}
	}

	public function handle_action() {
		$this->verify_nonce( 'wceerp_consignment_action' );
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$id    = (int) ( $_POST['consignment_id'] ?? 0 );
		$do    = sanitize_key( $_POST['do'] ?? '' );
		$c     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );

		$args = array( 'tab' => 'consignments', 'updated' => 1 );

		if ( $c ) {
			if ( 'book' === $do ) {
				$res = $this->book_consignment( $id );
				if ( is_wp_error( $res ) ) {
					/* Surface the courier's actual complaint. Silently
					 * logging it made a failed booking look successful. */
					set_transient( 'wceerp_courier_err_' . get_current_user_id(), $res->get_error_message(), 60 );
					$args = array( 'tab' => 'consignments', 'failed' => 1 );
				}
			} elseif ( 'sync' === $do && $c->remote_id ) {
				$status = self::api_track( $c );
				if ( is_wp_error( $status ) ) {
					set_transient( 'wceerp_courier_err_' . get_current_user_id(), $status->get_error_message(), 60 );
					$args = array( 'tab' => 'consignments', 'failed' => 1 );
				} else {
					$wpdb->update( $table, array( 'status' => $status, 'last_sync' => current_time( 'mysql' ) ), array( 'id' => $id ) );
				}
			} elseif ( 'unbook' === $do ) {
				/* Detach the consignment from the courier locally. This
				 * cannot recall a parcel that has already been handed over
				 * -- Bahok exposes no cancel endpoint -- so it is only for
				 * clearing test or mistaken bookings. */
				if ( in_array( $c->status, array( 'paid', 'delivered' ), true ) || (float) $c->collected_amount > 0 ) {
					set_transient( 'wceerp_courier_err_' . get_current_user_id(), __( 'This consignment has already been delivered or settled, so it cannot be unbooked.', 'wc-enterprise-erp' ), 60 );
					$args = array( 'tab' => 'consignments', 'failed' => 1 );
				} else {
					$wpdb->update( $table, array(
						'remote_id'     => null,
						'tracking_code' => null,
						'status'        => 'pending',
						'last_sync'     => null,
					), array( 'id' => $id ) );
					wceerp_log( 'courier', 'unbooked', $id, $c->courier . ' ' . $c->remote_id );
					$args = array( 'tab' => 'consignments', 'unbooked' => 1 );
				}
			} elseif ( 'delete' === $do ) {
				/* Only ever removable while no money has moved: a payout
				 * marks the consignment paid and posts to the ledger, and
				 * deleting one of those would orphan a journal. */
				if ( in_array( $c->status, array( 'paid', 'delivered' ), true ) || (float) $c->collected_amount > 0 ) {
					set_transient( 'wceerp_courier_err_' . get_current_user_id(), __( 'This consignment is delivered or settled and has accounting attached, so it cannot be deleted. Mark it cancelled instead.', 'wc-enterprise-erp' ), 60 );
					$args = array( 'tab' => 'consignments', 'failed' => 1 );
				} else {
					$wpdb->delete( $table, array( 'id' => $id ) );
					wceerp_log( 'courier', 'deleted', $id, $c->doc_no );
					$args = array( 'tab' => 'consignments', 'deleted' => 1 );
				}
			} elseif ( in_array( $do, array( 'in_transit', 'delivered', 'returned', 'cancelled' ), true ) && 'paid' !== $c->status ) {
				$wpdb->update( $table, array( 'status' => $do ), array( 'id' => $id ) );
				wceerp_log( 'courier', 'status_manual', $id, $do );
			}
		}
		wp_safe_redirect( $this->admin_url( $args ) );
		exit;
	}

	/**
	 * COD payout: the courier remitted money for a set of delivered parcels.
	 * Posts:  Dr deposit account (net) + Dr 5600 charges / Cr 1110 (gross).
	 */
	public function handle_payout() {
		$this->verify_nonce( 'wceerp_courier_payout' );
		global $wpdb;
		$table = wceerp_table( 'consignments' );

		$courier    = sanitize_key( $_POST['courier'] ?? '' );
		$account_id = (int) ( $_POST['account_id'] ?? 0 );
		$date       = sanitize_text_field( $_POST['payout_date'] ?? current_time( 'Y-m-d' ) );
		$collected  = isset( $_POST['collected'] ) ? (array) $_POST['collected'] : array();
		$charges    = isset( $_POST['charge'] ) ? (array) $_POST['charge'] : array();

		$gross          = 0;
		$total_charges  = 0;
		$total_returns  = 0;
		$total_writeoff = 0;
		$rows          = array();

		foreach ( $collected as $cid => $amount ) {
			$cid    = (int) $cid;
			$amount = wceerp_dec( $amount );
			if ( $amount <= 0 ) {
				continue;
			}
			$c = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d AND status IN ('delivered','paid')", $cid ) );
			if ( ! $c ) {
				continue;
			}
			$outstanding = (float) $c->cod_amount - (float) $c->collected_amount;
			$amount      = min( $amount, max( 0, $outstanding ) );
			if ( $amount <= 0 ) {
				continue;
			}
			$charge = max( 0, wceerp_dec( $charges[ $cid ] ?? 0 ) );

			/* Anything the customer did not pay.
			 *
			 * A courier that hands over less than the COD has either agreed
			 * a discount at the door or brought the parcel back. Left alone
			 * the shortfall sits in the receivable for ever, pretending the
			 * courier still owes it. Ticking "settle in full" writes it off
			 * to the right account so the parcel closes honestly. */
			$shortfall = max( 0, round( $outstanding - $amount, 2 ) );
			$settle    = ! empty( $_POST['settle'][ $cid ] );
			$writeoff  = $settle ? $shortfall : 0;
			$is_return = ( $amount <= 0.004 );

			$gross         += $amount;
			$total_charges += $charge;
			if ( $is_return ) {
				$total_returns += $charge;
				$total_charges -= $charge; // counted under return charges instead
			}
			$total_writeoff += $writeoff;

			$rows[] = array(
				'c'         => $c,
				'amount'    => $amount,
				'charge'    => $charge,
				'writeoff'  => $writeoff,
				'is_return' => $is_return,
			);
		}

		if ( ! $rows || ! $account_id ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'error' => 'empty' ) ) );
			exit;
		}

		/* What actually reaches the bank: collected, less every deduction.
		 * A return charge is money the courier keeps just the same, so it
		 * comes off the remittance even though nothing was sold. */
		$net = round( $gross - $total_charges - $total_returns, 2 );

		/* Nothing ticked, or everything already settled: do not create an
		 * empty payout. A row settling no parcels still posted money to the
		 * books, which is how the same remittance ended up recorded more
		 * than once. */
		if ( ! $rows || ( $gross + $total_writeoff ) <= 0.004 ) {
			$this->notice_redirect(
				'error',
				__( 'No parcels were settled, so nothing was recorded. Tick the parcels this payment covers and enter what was collected.', 'wc-enterprise-erp' )
			);
		}

		$wpdb->insert( wceerp_table( 'courier_payouts' ), array(
			'doc_no'      => wceerp_next_doc_number( 'cpo' ),
			'courier'     => $courier,
			'payout_date' => $date,
			'gross_cod'   => $gross,
			'charges'     => $total_charges,
			'net_amount'  => $net,
			'account_id'  => $account_id,
			'note'        => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		) );
		$payout_id = (int) $wpdb->insert_id;

		/* The journal that finally recognises the cash. */
		$lines = array(
			array( 'account' => $account_id, 'debit' => $net, 'memo' => 'Courier payout — ' . strtoupper( $courier ) ),
		);
		if ( $total_charges > 0.004 ) {
			$lines[] = array( 'account' => '5600', 'debit' => $total_charges, 'memo' => 'Delivery charges — ' . strtoupper( $courier ) );
		}
		if ( $total_returns > 0.004 ) {
			$lines[] = array( 'account' => '5650', 'debit' => $total_returns, 'memo' => 'Return charges — ' . strtoupper( $courier ) );
		}
		if ( $total_writeoff > 0.004 ) {
			$lines[] = array( 'account' => '4200', 'debit' => $total_writeoff, 'memo' => 'Discount given at delivery' );
		}

		/* The receivable is cleared by everything that settled it: cash
		 * collected plus anything written off. */
		$lines[] = array(
			'account' => '1110',
			'credit'  => round( $gross + $total_writeoff, 2 ),
			'memo'    => 'COD settled — ' . count( $rows ) . ' parcels',
		);

		$journal = WCEERP_Accounting::post( array(
			'journal_date' => $date,
			'ref_type'     => 'courier_payout',
			'ref_id'       => $payout_id,
			'memo'         => sprintf( 'COD payout %s — %d parcels', strtoupper( $courier ), count( $rows ) ),
		), $lines );

		if ( ! is_wp_error( $journal ) ) {
			$wpdb->update( wceerp_table( 'courier_payouts' ), array( 'journal_id' => (int) $journal ), array( 'id' => $payout_id ) );
		}

		foreach ( $rows as $row ) {
			/* The real charge is about to be posted, so any estimate accrued
			 * at delivery must come back out or the cost lands twice. */
			self::reverse_accrual( $row['c'] );

			$new_collected = (float) $row['c']->collected_amount + $row['amount'];

			/* A written-off shortfall closes the parcel just as cash does:
			 * nothing further is owed, so it must not keep appearing on the
			 * awaiting list. A return closes as returned, not paid — the
			 * goods came back and only the charge was borne. */
			$settled = ( $new_collected + $row['writeoff'] + 0.004 ) >= (float) $row['c']->cod_amount;

			if ( ! empty( $row['is_return'] ) ) {
				$status = 'returned';
			} elseif ( $settled ) {
				$status = 'paid';
			} else {
				$status = 'delivered';
			}

			$wpdb->update( $table, array(
				'collected_amount' => $new_collected,
				'delivery_charge'  => (float) $row['c']->delivery_charge + $row['charge'],
				'discount_amount'  => (float) $row['c']->discount_amount + $row['writeoff'],
				'status'           => $status,
				'payout_id'        => $payout_id,
			), array( 'id' => $row['c']->id ) );

			/* A parcel settled as a return still has a sale on the books
			 * and stock in a van. Reverse it now so the two agree. */
			if ( ! empty( $row['is_return'] ) && empty( $row['c']->reversed_at ) ) {
				self::reverse_sale( $row['c'] );
			}
		}

		wceerp_log( 'courier', 'payout', $payout_id, $courier . ' ' . $gross );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'payouts', 'updated' => 1 ) ) );
		exit;
	}

	/** Every courier setting key that may be saved or tested. */
	public static function setting_keys() {
		return array(
			'steadfast_api_key', 'steadfast_secret_key',
			'pathao_client_id', 'pathao_client_secret', 'pathao_username', 'pathao_password', 'pathao_store_id',
			'redx_access_token', 'redx_base_url',
			'bahok_base_url', 'bahok_client_id', 'bahok_client_secret',
			'bahok_username', 'bahok_password', 'bahok_store_id', 'bahok_webhook_token',
			'carrybee_base_url', 'carrybee_email', 'carrybee_password', 'carrybee_token', 'carrybee_store_id',
			/* Charge rates, used to estimate a deduction the courier has
			 * not reported. */
			'bahok_rate_flat', 'bahok_rate_weight', 'bahok_rate_free_kg', 'bahok_rate_cod_pct',
			'steadfast_rate_flat', 'steadfast_rate_cod_pct',
			'pathao_rate_flat', 'pathao_rate_cod_pct',
			'redx_rate_flat', 'redx_rate_cod_pct',
			'carrybee_rate_flat', 'carrybee_rate_cod_pct',
			'courier_accrue', 'courier_estimate',
			'auto_create', 'auto_courier',
		);
	}

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_courier_settings' );
		$fields = self::setting_keys();
		/* Secrets are stored verbatim. sanitize_text_field() strips anything
		 * tag-like and percent-encoded octets, which silently corrupts any
		 * password or key containing < > or % -- the credential then looks
		 * correct on screen but fails to authenticate. */
		$raw_fields = array(
			'steadfast_secret_key', 'pathao_client_secret', 'pathao_password',
			'bahok_client_secret', 'bahok_password', 'bahok_webhook_token',
			'redx_access_token',
		);
		$pairs = array();
		foreach ( $fields as $field ) {
			$value = wp_unslash( $_POST[ $field ] ?? '' );
			$value = in_array( $field, $raw_fields, true )
				? trim( (string) $value )
				: sanitize_text_field( $value );
			$pairs[ 'courier_' . $field ] = $value;
		}

		// One write for the whole screen, then verify it landed.
		$failed = wceerp_update_options( $pairs );

		delete_transient( 'wceerp_pathao_token' );
		delete_transient( self::BAHOK_TOKEN_KEY );

		if ( $failed ) {
			wceerp_log( 'courier', 'settings_save_failed', 0, implode( ',', $failed ) );
			set_transient(
				'wceerp_courier_err_' . get_current_user_id(),
				sprintf(
					/* translators: %s: field names. */
					__( 'These settings did not save: %s. This usually means an object cache or security plugin is blocking writes.', 'wc-enterprise-erp' ),
					implode( ', ', $failed )
				),
				60
			);
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'settings', 'failed' => 1 ) ) );
			exit;
		}

		wceerp_log( 'courier', 'settings_save', 0, count( $pairs ) . ' fields' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'settings', 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Printable shipping label.
	 */
	public function handle_label() {
		if ( ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ?? '' ), 'wceerp_courier_label' ) || ! wceerp_user_can( $this->capability ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		global $wpdb;
		$c = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'consignments' ) . ' WHERE id=%d', (int) ( $_GET['consignment_id'] ?? 0 ) ) );
		if ( ! $c ) {
			wp_die( esc_html__( 'Consignment not found.', 'wc-enterprise-erp' ) );
		}
		$company = wceerp_get_option( 'company_name', get_bloginfo( 'name' ) );
		$code    = $c->tracking_code ?: $c->doc_no;
		$barcode = class_exists( 'WCEERP_Module_Barcode' ) ? WCEERP_Module_Barcode::barcode_svg( $code, 46 ) : '';
		?>
		<!DOCTYPE html><html><head><meta charset="utf-8"><title><?php echo esc_html( $c->doc_no ); ?></title>
		<style>
			body{font-family:Arial,'Noto Sans Bengali',sans-serif;margin:0;padding:16px}
			.label{width:100mm;border:2px solid #000;padding:10px 12px}
			.row{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
			h1{font-size:15px;margin:0}
			.courier{font-size:12px;font-weight:bold;text-transform:uppercase;border:1.5px solid #000;padding:2px 8px}
			.to{margin:10px 0;border-top:1px solid #000;border-bottom:1px solid #000;padding:8px 0}
			.to b{font-size:15px}
			.cod{font-size:17px;font-weight:bold}
			.bc{text-align:center;margin-top:8px}
			.bc small{display:block;letter-spacing:2px;font-size:11px}
			@media print{.noprint{display:none}}
		</style></head><body>
		<p class="noprint"><button onclick="window.print()">Print label</button></p>
		<div class="label">
			<div class="row">
				<h1><?php echo esc_html( $company ); ?></h1>
				<span class="courier"><?php echo esc_html( $c->courier ); ?></span>
			</div>
			<div class="to">
				<b><?php echo esc_html( $c->recipient_name ); ?></b><br>
				<?php echo esc_html( $c->recipient_phone ); ?><br>
				<?php echo esc_html( $c->recipient_address ); ?>
			</div>
			<div class="row">
				<span>Order #<?php echo (int) $c->order_id; ?> · <?php echo esc_html( $c->doc_no ); ?></span>
				<span class="cod">COD: <?php echo esc_html( number_format( (float) $c->cod_amount, 0 ) ); ?>/-</span>
			</div>
			<div class="bc"><?php echo $barcode; // phpcs:ignore ?><small><?php echo esc_html( $code ); ?></small></div>
		</div>
		</body></html>
		<?php
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab = sanitize_key( $_GET['tab'] ?? 'dashboard' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Courier & COD', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'dashboard'    => __( 'Dashboard', 'wc-enterprise-erp' ),
					'orders'       => __( 'All Orders (COD)', 'wc-enterprise-erp' ),
					'new'          => __( 'New consignment', 'wc-enterprise-erp' ),
					'consignments' => __( 'Consignments', 'wc-enterprise-erp' ),
					'money'        => __( 'COD money', 'wc-enterprise-erp' ),
					'payouts'      => __( 'COD payouts', 'wc-enterprise-erp' ),
					'returns'      => __( 'Returns', 'wc-enterprise-erp' ),
					'opening'      => __( 'Opening COD', 'wc-enterprise-erp' ),
					'settings'     => __( 'Couriers & API keys', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), $tab === $slug ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); } ?>
			<?php
			if ( ! empty( $_GET['error'] ) ) {
				$emsgs = array(
					'exists'  => __( 'An opening COD balance has already been posted. Reverse its journal in Accounting before posting another.', 'wc-enterprise-erp' ),
					'empty'   => __( 'Enter at least one outstanding amount.', 'wc-enterprise-erp' ),
					'receipt' => __( 'Enter the amount received and choose a deposit account.', 'wc-enterprise-erp' ),
					'charges' => __( 'Delivery charges cannot exceed the amount received.', 'wc-enterprise-erp' ),
					'missing'   => __( 'That consignment no longer exists.', 'wc-enterprise-erp' ),
					'doc_taken' => __( 'That consignment number is already used. Leave it blank to generate the next one automatically.', 'wc-enterprise-erp' ),
				);
				$ekey = sanitize_key( $_GET['error'] );
				$this->notice(
					$emsgs[ $ekey ] ?? __( 'Nothing to pay out — enter at least one collected amount and pick a deposit account.', 'wc-enterprise-erp' ),
					'error'
				);
			}
			?>
			<?php if ( ! empty( $_GET['unbooked'] ) ) { $this->notice( __( 'Consignment unbooked and set back to pending. Note this does not cancel the parcel with the courier — if it was really handed over, contact them directly.', 'wc-enterprise-erp' ) ); } ?>
			<?php if ( ! empty( $_GET['deleted'] ) ) { $this->notice( __( 'Consignment deleted.', 'wc-enterprise-erp' ) ); } ?>
			<?php
			if ( ! empty( $_GET['failed'] ) ) {
				$err = get_transient( 'wceerp_courier_err_' . get_current_user_id() );
				delete_transient( 'wceerp_courier_err_' . get_current_user_id() );
				$this->notice(
					$err ? sprintf( __( 'Courier action failed: %s', 'wc-enterprise-erp' ), $err )
					     : __( 'Courier action failed. Check Audit log for details.', 'wc-enterprise-erp' ),
					'error'
				);
			}
			?>
			<?php
			if ( 'new' === $tab ) {
				$this->render_new();
			} elseif ( 'orders' === $tab ) {
				$this->render_orders();
			} elseif ( 'money' === $tab ) {
				$this->render_cod_money();
			} elseif ( 'consignments' === $tab ) {
				$this->render_consignments();
			} elseif ( 'payouts' === $tab ) {
				$this->render_payouts();
			} elseif ( 'returns' === $tab ) {
			$this->render_returns();
		} elseif ( 'opening' === $tab ) {
				$this->render_opening();
			} elseif ( 'settings' === $tab ) {
				$this->render_settings();
			} else {
				$this->render_dashboard();
			}
			?>
		</div>
		<?php
	}

	/**
	 * Unified "All Orders (COD)" view.
	 *
	 * Every WooCommerce order — POS and online — in one place, focused on
	 * COD collection: which orders are COD, whether they're booked with a
	 * courier, and whether that courier has paid the money in yet. Read
	 * only; booking and payout still happen in their own tabs so the
	 * accounting flow is untouched.
	 */
	protected function render_orders() {
		global $wpdb;

		// ---- Filters ----
		$f_channel = sanitize_key( $_GET['channel'] ?? '' );       // pos | online
		$f_pay     = sanitize_key( $_GET['pay'] ?? '' );           // cod | prepaid
		$f_cod     = sanitize_key( $_GET['cod'] ?? '' );           // unbooked | awaiting | collected
		$f_courier = sanitize_key( $_GET['courier'] ?? '' );
		$f_from    = sanitize_text_field( $_GET['from'] ?? '' );
		$f_to      = sanitize_text_field( $_GET['to'] ?? '' );
		$search    = sanitize_text_field( $_GET['s'] ?? '' );
		$paged     = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
		$per       = self::per_page( 25 );
		if ( ! $per ) {
			// "All" — a ceiling still applies so a large shop cannot
			// exhaust memory building one enormous page.
			$per   = 2000;
			$paged = 1;
		}

		/* Filters that WooCommerce cannot express in a query -- COD state,
		 * courier, payment type -- used to be applied while drawing the
		 * rows, which meant they ran *after* pagination had already chosen
		 * 25 orders. Filtering by "Awaiting courier payment" then showed
		 * whichever handful of that arbitrary 25 happened to match, and the
		 * page count was wrong. It looked broken because it was.
		 *
		 * When such a filter is active the set is fetched wider and paged
		 * here instead, so a page holds 25 matching orders. */
		$post_filtered = ( $f_cod || $f_courier || $f_pay );

		// ---- Pull orders via WooCommerce (HPOS-safe) ----
		$args = array(
			'limit'   => $post_filtered ? 2000 : $per,
			'paged'   => $post_filtered ? 1 : $paged,
			'orderby' => 'date',
			'order'   => 'DESC',
			'return'  => 'objects',
		);
		if ( 'pos' === $f_channel ) {
			$args['created_via'] = 'wceerp_pos';
		}
		/* Never surface orders from before the books started -- booking a
		 * consignment against one would post COD into a period the ledger
		 * has no revenue for. */
		$golive = wceerp_start_date();
		if ( $golive && ( ! $f_from || $f_from < $golive ) ) {
			$f_from = $golive;
		}
		if ( $f_from ) {
			$args['date_created'] = '>=' . $f_from;
		}
		if ( $f_from && $f_to ) {
			$args['date_created'] = $f_from . '...' . $f_to;
		}
		if ( $search ) {
			$args['s'] = $search;
		}
		$orders = function_exists( 'wc_get_orders' ) ? wc_get_orders( $args ) : array();

		/* Connected-store orders. These live only in the ERP (their shop is
		 * on the customer's own server), so they're fetched separately and
		 * rendered from the mirrored snapshot rather than a WC_Order. */
		$remote_rows = array();
		$ct = wceerp_table( 'connect_orders' );
		if ( 'pos' !== $f_channel && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $ct ) ) === $ct ) {
			$rwhere = 'WHERE 1=1';
			$rparams = array();
			if ( $f_from ) {
				$rwhere .= ' AND order_date >= %s';
				$rparams[] = $f_from . ' 00:00:00';
			}
			if ( $f_to ) {
				$rwhere .= ' AND order_date <= %s';
				$rparams[] = $f_to . ' 23:59:59';
			}
			if ( 'cod' === $f_pay ) {
				$rwhere .= ' AND is_cod = 1';
			} elseif ( 'prepaid' === $f_pay ) {
				$rwhere .= ' AND is_cod = 0';
			}
			if ( $search ) {
				$rwhere .= ' AND (customer_name LIKE %s OR number LIKE %s)';
				$like = '%' . $wpdb->esc_like( $search ) . '%';
				$rparams[] = $like;
				$rparams[] = $like;
			}
			$rsql = "SELECT * FROM $ct $rwhere ORDER BY order_date DESC LIMIT %d";
			$rparams[] = $per;
			$remote_rows = $wpdb->get_results( $wpdb->prepare( $rsql, $rparams ) );
		}

		// ---- Consignment index for these orders (one query) ----
		$order_ids = array_map( function ( $o ) { return $o->get_id(); }, $orders );
		$cons_by_order = array();
		if ( $order_ids ) {
			$in    = implode( ',', array_map( 'intval', $order_ids ) );
			$table = wceerp_table( 'consignments' );
			$rows  = $wpdb->get_results( "SELECT * FROM $table WHERE order_id IN ($in)" );
			foreach ( (array) $rows as $r ) {
				$cons_by_order[ (int) $r->order_id ] = $r;
			}
		}

		$this->render_orders_summary();
		?>
		<form method="get" class="wceerp-order-filters" style="margin:14px 0;display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
			<input type="hidden" name="page" value="wceerp-courier">
			<input type="hidden" name="tab" value="orders">
			<label><?php esc_html_e( 'Channel', 'wc-enterprise-erp' ); ?><br>
				<select name="channel">
					<option value=""><?php esc_html_e( 'All channels', 'wc-enterprise-erp' ); ?></option>
					<option value="pos" <?php selected( $f_channel, 'pos' ); ?>><?php esc_html_e( 'POS sale', 'wc-enterprise-erp' ); ?></option>
					<option value="online" <?php selected( $f_channel, 'online' ); ?>><?php esc_html_e( 'Online order', 'wc-enterprise-erp' ); ?></option>
				</select></label>
			<label><?php esc_html_e( 'Payment', 'wc-enterprise-erp' ); ?><br>
				<select name="pay">
					<option value=""><?php esc_html_e( 'All payments', 'wc-enterprise-erp' ); ?></option>
					<option value="cod" <?php selected( $f_pay, 'cod' ); ?>><?php esc_html_e( 'COD only', 'wc-enterprise-erp' ); ?></option>
					<option value="prepaid" <?php selected( $f_pay, 'prepaid' ); ?>><?php esc_html_e( 'Prepaid only', 'wc-enterprise-erp' ); ?></option>
				</select></label>
			<label><?php esc_html_e( 'COD status', 'wc-enterprise-erp' ); ?><br>
				<select name="cod">
					<option value=""><?php esc_html_e( 'Any COD status', 'wc-enterprise-erp' ); ?></option>
					<option value="unbooked" <?php selected( $f_cod, 'unbooked' ); ?>><?php esc_html_e( 'COD · not booked', 'wc-enterprise-erp' ); ?></option>
					<option value="awaiting" <?php selected( $f_cod, 'awaiting' ); ?>><?php esc_html_e( 'Awaiting courier payment', 'wc-enterprise-erp' ); ?></option>
					<option value="collected" <?php selected( $f_cod, 'collected' ); ?>><?php esc_html_e( 'Collected / paid in', 'wc-enterprise-erp' ); ?></option>
				</select></label>
			<label><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?><br>
				<select name="courier">
					<option value=""><?php esc_html_e( 'Any courier', 'wc-enterprise-erp' ); ?></option>
					<?php foreach ( self::drivers() as $slug => $d ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $f_courier, $slug ); ?>><?php echo esc_html( $d['label'] ?? ucfirst( $slug ) ); ?></option>
					<?php endforeach; ?>
				</select></label>
			<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $f_from ); ?>"></label>
			<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $f_to ); ?>"></label>
			<label><?php esc_html_e( 'Search', 'wc-enterprise-erp' ); ?><br><input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Order # / name', 'wc-enterprise-erp' ); ?>"></label>
			<button class="button button-primary"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			<?php self::per_page_control( 'orders' ); ?>
			<a class="button" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'orders' ) ) ); ?>"><?php esc_html_e( 'Reset', 'wc-enterprise-erp' ); ?></a>
		</form>

		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Channel', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Payment', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Paid', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'With courier', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Due', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Courier charge', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'COD status', 'wc-enterprise-erp' ); ?></th>
				<th></th>
			</tr></thead>
			<tbody>
			<?php
			$shown   = 0;
			$matched = 0;
			foreach ( $orders as $order ) {
				$oid       = $order->get_id();
				$is_pos    = ( 'wceerp_pos' === $order->get_created_via() );
				$method    = (string) $order->get_payment_method();
				$is_cod    = ( false !== stripos( $method, 'cod' ) );
				$cons      = isset( $cons_by_order[ $oid ] ) ? $cons_by_order[ $oid ] : null;

				// Derived COD state.
				$cod_state = 'n/a';
				if ( $is_cod ) {
					if ( ! $cons ) {
						$cod_state = 'unbooked';
					} elseif ( 'paid' === $cons->status || ( (float) $cons->collected_amount + 0.004 >= (float) $cons->cod_amount && (float) $cons->cod_amount > 0 ) ) {
						$cod_state = 'collected';
					} else {
						$cod_state = 'awaiting';
					}
				}

				// ---- Apply the filters that WC couldn't ----
				if ( 'online' === $f_channel && $is_pos ) { continue; }
				if ( 'cod' === $f_pay && ! $is_cod ) { continue; }
				if ( 'prepaid' === $f_pay && $is_cod ) { continue; }
				if ( $f_cod && $f_cod !== $cod_state ) { continue; }
				if ( $f_courier && ( ! $cons || $cons->courier !== $f_courier ) ) { continue; }

				/* Page the filtered set here, since WooCommerce paged the
				 * unfiltered one. */
				$matched++;
				if ( $post_filtered ) {
					$offset = ( $paged - 1 ) * $per;
					if ( $matched <= $offset || $matched > $offset + $per ) {
						continue;
					}
				}

				$shown++;
				$cod_amount = $cons ? (float) $cons->cod_amount : ( $is_cod ? (float) $order->get_total() : 0 );
				?>
				<tr>
					<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . $oid . '&action=edit' ) ); ?>">#<?php echo (int) $oid; ?></a></td>
					<td><?php echo esc_html( $order->get_date_created() ? $order->get_date_created()->date_i18n( 'j M Y' ) : '' ); ?></td>
					<td>
						<?php if ( $is_pos ) : ?>
							<span class="wceerp-badge is-pos" style="background:#e8f3ee;color:#075742"><?php esc_html_e( 'POS', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-badge is-online" style="background:#e9f0fb;color:#2271b1"><?php esc_html_e( 'Online', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ?: '—' ); ?></td>
					<td>
						<?php if ( $is_cod ) : ?>
							<span class="wceerp-badge is-cod" style="background:#fff2d9;color:#b98a2f">COD</span>
						<?php else : ?>
							<span style="color:#777"><?php echo esc_html( $order->get_payment_method_title() ?: __( 'Prepaid', 'wc-enterprise-erp' ) ); ?></span>
						<?php endif; ?>
					</td>
					<?php $pic = class_exists( 'WCEERP_Order_Payments' ) ? WCEERP_Order_Payments::picture( $order ) : array( 'paid' => 0, 'cod_pending' => 0, 'cod_collected' => 0, 'due' => 0 ); ?>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $order->get_total() ) ); ?></td>
					<td class="num">
						<?php
						$in_hand = (float) $pic['paid'] + (float) $pic['cod_collected'];
						echo $in_hand > 0.004 ? wp_kses_post( wceerp_money( $in_hand ) ) : '<span style="color:#bbb">—</span>';
						if ( (float) $pic['paid'] > 0.004 && (float) $pic['cod_collected'] > 0.004 ) {
							echo '<br><small style="color:#777">' . esc_html__( 'incl. advance', 'wc-enterprise-erp' ) . '</small>';
						} elseif ( (float) $pic['paid'] > 0.004 ) {
							echo '<br><small style="color:#777">' . esc_html__( 'advance', 'wc-enterprise-erp' ) . '</small>';
						}
						?>
					</td>
					<td class="num"><?php echo (float) $pic['cod_pending'] > 0.004 ? wp_kses_post( wceerp_money( $pic['cod_pending'] ) ) : '<span style="color:#bbb">—</span>'; ?></td>
					<td class="num">
						<?php if ( (float) $pic['due'] > 0.004 ) : ?>
							<strong style="color:#b32d2e"><?php echo wp_kses_post( wceerp_money( $pic['due'] ) ); ?></strong>
						<?php else : ?>
							<span style="color:#bbb">—</span>
						<?php endif; ?>
					</td>
					<td class="num">
						<?php
						/* What the courier deducted, or expects to. Shown
						 * here because a COD order's real margin is the sale
						 * less the goods AND less this — a shop looking only
						 * at the order total is overstating what it earned. */
						$cc = 0;
						$cc_est = false;
						if ( $cons ) {
							if ( (float) $cons->delivery_charge > 0.004 ) {
								$cc = (float) $cons->delivery_charge;
							} elseif ( (float) $cons->remote_charge > 0.004 ) {
								$cc     = (float) $cons->remote_charge;
								$cc_est = true;
							} else {
								$basis = (float) $cons->collected_amount > 0.004 ? (float) $cons->collected_amount : (float) $cons->cod_amount;
								$e     = self::estimate_charge( $cons->courier, $basis, $cons );
								if ( null !== $e && $e > 0 ) {
									$cc     = $e;
									$cc_est = true;
								}
							}
						}
						if ( $cc > 0.004 ) {
							echo wp_kses_post( wceerp_money( $cc ) );
							if ( $cc_est ) {
								echo '<span class="wceerp-sub" style="color:#B7791F">' . esc_html__( 'estimated', 'wc-enterprise-erp' ) . '</span>';
							}
						} else {
							echo '<span style="color:#bbb">—</span>';
						}
						?>
					</td>
					<td>
						<?php echo $cons ? esc_html( ucfirst( $cons->courier ) ) : '<span style="color:#bbb">—</span>'; ?>
						<span class="wceerp-sub" style="white-space:nowrap">
							<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"><?php esc_html_e( 'Edit', 'wc-enterprise-erp' ); ?></a>
							· <a href="<?php echo esc_url( WCEERP_Document::url( 'invoice', $order->get_id() ) ); ?>" target="_blank"><?php esc_html_e( 'Invoice', 'wc-enterprise-erp' ); ?></a>
							· <a href="<?php echo esc_url( WCEERP_Document::url( 'challan', $order->get_id() ) ); ?>" target="_blank"><?php esc_html_e( 'Challan', 'wc-enterprise-erp' ); ?></a>
							<?php if ( ! $cons ) : ?>
								· <a href="#" onclick="wceerpAttach(<?php echo (int) $order->get_id(); ?>);return false;"><?php esc_html_e( 'Already booked?', 'wc-enterprise-erp' ); ?></a>
							<?php endif; ?>
						</span>
					</td>
					<td>
						<?php if ( (float) $pic['due'] > 0.004 ) : ?>
							<details style="margin-bottom:6px">
								<?php /* Not every order goes on a van. A customer collecting
								         in person, or a local hand delivery, is paid for
								         directly — and often only in part. Booking stays
								         available beside this; the two are alternatives,
								         not a sequence. */ ?>
								<summary style="cursor:pointer;font-size:12px;color:#2271b1"><?php esc_html_e( 'Paid directly — no courier', 'wc-enterprise-erp' ); ?></summary>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px">
									<?php wp_nonce_field( 'wceerp_record_payment' ); ?>
									<input type="hidden" name="action" value="wceerp_record_payment">
									<input type="hidden" name="order_id" value="<?php echo (int) $oid; ?>">
									<input type="number" step="0.01" min="0.01" max="<?php echo esc_attr( $pic['due'] ); ?>"
										name="amount" value="<?php echo esc_attr( $pic['due'] ); ?>" style="width:92px" required
										title="<?php esc_attr_e( 'Reduce this for a part payment — the balance stays owing.', 'wc-enterprise-erp' ); ?>">
									<select name="method" style="max-width:110px">
										<?php foreach ( WCEERP_Order_Payments::methods() as $mk => $m ) : ?>
											<option value="<?php echo esc_attr( $mk ); ?>"><?php echo esc_html( $m['label'] ); ?></option>
										<?php endforeach; ?>
									</select>
									<input type="date" name="paid_on" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>">
									<button class="button button-small button-primary"><?php esc_html_e( 'Save', 'wc-enterprise-erp' ); ?></button>
								</form>
							</details>
						<?php endif; ?>
						<?php
						switch ( $cod_state ) {
							case 'unbooked':
								echo '<span class="wceerp-badge" style="background:#fdecec;color:#c8302e">' . esc_html__( 'Not booked', 'wc-enterprise-erp' ) . '</span>';
								break;
							case 'awaiting':
								echo '<span class="wceerp-badge" style="background:#fff2d9;color:#b98a2f">' . esc_html__( 'Awaiting payment', 'wc-enterprise-erp' ) . '</span>';
								if ( $cons ) {
									echo '<br><small>' . esc_html( ucwords( str_replace( '_', ' ', $cons->status ) ) ) . '</small>';
								}
								break;
							case 'collected':
								/* "Paid in" read as "the customer paid", which is true of every
								 * delivered COD parcel and says nothing about whether the
								 * money reached you. This is the only state that means it
								 * actually did. */
								echo '<span class="wceerp-badge" style="background:#e8f3ee;color:#2f8a4c">' . esc_html__( 'Money received', 'wc-enterprise-erp' ) . '</span>';
								break;
							default:
								echo '<span style="color:#bbb">—</span>';
						}
						?>
					</td>
					<td>
						<?php
						/* Any order not yet with a courier can be booked.
						 *
						 * This used to require the order to be COD, which
						 * quietly excluded every POS sale — but a customer who
						 * paid at the counter and wants it delivered still
						 * needs a parcel. Whether money is owed and whether
						 * goods need transporting are separate questions. */
						if ( ! $cons ) :
							?>
							<a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'new', 'order_id' => $oid ) ) ); ?>"
								title="<?php esc_attr_e( 'Send it with a courier. For a customer collecting in person, use "Paid directly" instead.', 'wc-enterprise-erp' ); ?>"><?php esc_html_e( 'Book', 'wc-enterprise-erp' ); ?></a>
						<?php elseif ( 'awaiting' === $cod_state ) : ?>
							<a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'payouts', 'focus' => $c->id ?? 0 ) ) . '#cn-' . (int) ( $c->id ?? 0 ) ); ?>"><?php esc_html_e( 'Collect', 'wc-enterprise-erp' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
				<?php
			}

			// ---- Connected-store orders ----
			foreach ( $remote_rows as $ro ) {
				$is_cod = (int) $ro->is_cod === 1;
				$cons   = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM " . wceerp_table( 'consignments' ) . " WHERE order_id = %d AND order_source = 'remote'",
					(int) $ro->remote_id
				) );

				$cod_state = 'n/a';
				if ( $is_cod ) {
					if ( ! $cons ) {
						$cod_state = 'unbooked';
					} elseif ( 'paid' === $cons->status || ( (float) $cons->collected_amount + 0.004 >= (float) $cons->cod_amount && (float) $cons->cod_amount > 0 ) ) {
						$cod_state = 'collected';
					} else {
						$cod_state = 'awaiting';
					}
				}

				if ( 'cod' === $f_pay && ! $is_cod ) { continue; }
				if ( 'prepaid' === $f_pay && $is_cod ) { continue; }
				if ( $f_cod && $f_cod !== $cod_state ) { continue; }
				if ( $f_courier && ( ! $cons || $cons->courier !== $f_courier ) ) { continue; }

				$shown++;
				?>
				<tr>
					<td>#<?php echo esc_html( $ro->number ); ?></td>
					<td><?php echo esc_html( mysql2date( 'j M Y', $ro->order_date ) ); ?></td>
					<td><span class="wceerp-badge" style="background:#f0ecfa;color:#6b3fa0"><?php esc_html_e( 'Connected', 'wc-enterprise-erp' ); ?></span></td>
					<td><?php echo esc_html( $ro->customer_name ?: '—' ); ?><?php echo $ro->customer_phone ? '<br><small style="color:#888">' . esc_html( $ro->customer_phone ) . '</small>' : ''; ?></td>
					<td>
						<?php if ( $is_cod ) : ?>
							<span class="wceerp-badge" style="background:#fff2d9;color:#b98a2f">COD</span>
						<?php else : ?>
							<span style="color:#777"><?php echo esc_html( $ro->payment_method ?: __( 'Prepaid', 'wc-enterprise-erp' ) ); ?></span>
						<?php endif; ?>
					</td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $ro->total ) ); ?></td>

					<?php /* Connected-store rows share the header above, so
					         they need the same cells or every column after
					         this point shifts one to the left. */ ?>
					<td class="num"><?php echo $cons && (float) $cons->collected_amount > 0.004
						? wp_kses_post( wceerp_money( $cons->collected_amount ) )
						: '<span style="color:#bbb">—</span>'; ?></td>

					<td class="num"><?php echo $is_cod ? wp_kses_post( wceerp_money( $cons ? $cons->cod_amount : $ro->total ) ) : '—'; ?></td>

					<td class="num"><?php
						$ro_due = $cons
							? (float) $cons->cod_amount - (float) $cons->collected_amount
							: ( $is_cod ? (float) $ro->total : 0 );
						echo $ro_due > 0.004 ? wp_kses_post( wceerp_money( $ro_due ) ) : '<span style="color:#bbb">—</span>';
					?></td>

					<td class="num"><?php
						$ro_charge = $cons ? (float) $cons->delivery_charge : 0;
						if ( $ro_charge <= 0.004 && $cons ) { $ro_charge = (float) $cons->remote_charge; }
						echo $ro_charge > 0.004 ? wp_kses_post( wceerp_money( $ro_charge ) ) : '<span style="color:#bbb">—</span>';
					?></td>

					<td><?php echo $cons ? esc_html( ucfirst( $cons->courier ) ) : '<span style="color:#bbb">—</span>'; ?></td>
					<td>
						<?php
						switch ( $cod_state ) {
							case 'unbooked':
								echo '<span class="wceerp-badge" style="background:#fdecec;color:#c8302e">' . esc_html__( 'Not booked', 'wc-enterprise-erp' ) . '</span>';
								break;
							case 'awaiting':
								echo '<span class="wceerp-badge" style="background:#fff2d9;color:#b98a2f">' . esc_html__( 'Awaiting payment', 'wc-enterprise-erp' ) . '</span>';
								break;
							case 'collected':
								echo '<span class="wceerp-badge" style="background:#e8f3ee;color:#2f8a4c">' . esc_html__( 'Paid in', 'wc-enterprise-erp' ) . '</span>';
								break;
							default:
								echo '<span style="color:#bbb">—</span>';
						}
						?>
					</td>
					<td>
						<?php if ( $is_cod && ! $cons ) : ?>
							<a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'new', 'remote_id' => (int) $ro->remote_id ) ) ); ?>"><?php esc_html_e( 'Book', 'wc-enterprise-erp' ); ?></a>
						<?php endif; ?>
					</td>
				</tr>
				<?php
			}

			if ( ! $shown ) {
				echo '<tr><td colspan="12">' . esc_html__( 'No orders match these filters.', 'wc-enterprise-erp' ) . '</td></tr>';
			}
			?>
			</tbody>
		</table>

		<?php if ( $post_filtered && $matched ) : ?>
			<p class="description" style="margin-top:10px">
				<?php
				printf(
					/* translators: 1: shown, 2: total matching. */
					esc_html__( 'Showing %1$d of %2$d matching orders.', 'wc-enterprise-erp' ),
					(int) $shown,
					(int) $matched
				);
				?>
			</p>
		<?php endif; ?>

		<?php /* Booked on the courier's own site? Attach the tracking number
		         so the parcel comes back under management, instead of the
		         order sitting unbooked for ever with its COD untracked. */ ?>
		<div id="wceerp-attach" style="display:none;position:fixed;inset:0;background:rgba(22,32,44,.45);z-index:9999;align-items:center;justify-content:center;padding:16px">
			<div class="wceerp-card" style="max-width:420px;width:100%;margin:0">
				<h2><?php esc_html_e( 'Already booked with a courier', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Enter the tracking number the courier gave you. The parcel then syncs and its COD is tracked exactly like one booked from here.', 'wc-enterprise-erp' ); ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'wceerp_attach_booking' ); ?>
					<input type="hidden" name="action" value="wceerp_attach_booking">
					<input type="hidden" name="order_id" id="wceerp-attach-order" value="">
					<p>
						<label><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?><br>
							<select name="courier" style="width:100%">
								<?php foreach ( self::drivers() as $dk => $dv ) : ?>
									<option value="<?php echo esc_attr( $dk ); ?>"><?php echo esc_html( $dv['label'] ); ?></option>
								<?php endforeach; ?>
							</select></label>
					</p>
					<p>
						<label><?php esc_html_e( 'Tracking / consignment number', 'wc-enterprise-erp' ); ?><br>
							<input type="text" name="remote_id" class="regular-text" style="width:100%" required></label>
					</p>
					<p>
						<button class="button button-primary"><?php esc_html_e( 'Record it', 'wc-enterprise-erp' ); ?></button>
						<button type="button" class="button" onclick="document.getElementById('wceerp-attach').style.display='none';"><?php esc_html_e( 'Cancel', 'wc-enterprise-erp' ); ?></button>
					</p>
				</form>
			</div>
		</div>
		<script>
		function wceerpAttach( id ) {
			document.getElementById( 'wceerp-attach-order' ).value = id;
			var box = document.getElementById( 'wceerp-attach' );
			box.style.display = 'flex';
		}
		</script>

		<div class="wceerp-pager" style="margin-top:12px;display:flex;gap:8px">
			<?php
			$base = $this->admin_url( array( 'tab' => 'orders', 'channel' => $f_channel, 'pay' => $f_pay, 'cod' => $f_cod, 'courier' => $f_courier, 'from' => $f_from, 'to' => $f_to, 's' => $search ) );
			if ( $paged > 1 ) {
				printf( '<a class="button" href="%s">%s</a>', esc_url( add_query_arg( 'paged', $paged - 1, $base ) ), esc_html__( '← Newer', 'wc-enterprise-erp' ) );
			}
			/* With a post-filter active the fetch is deliberately wide, so
			 * "is there another page" has to be answered from how many
			 * orders actually matched, not how many were fetched. */
			$has_more = $post_filtered
				? ( $matched > $paged * $per )
				: ( count( $orders ) >= $per );
			if ( $has_more ) {
				printf( '<a class="button" href="%s">%s</a>', esc_url( add_query_arg( 'paged', $paged + 1, $base ) ), esc_html__( 'Older →', 'wc-enterprise-erp' ) );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Money-focused summary strip above the orders table: how much COD is
	 * still sitting with couriers vs already paid in, this month.
	 */
	protected function render_orders_summary() {
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$awaiting = (float) $wpdb->get_var( "SELECT COALESCE(SUM(cod_amount - collected_amount),0) FROM $table WHERE status IN ('delivered','in_transit','booked')" );
		$collected_month = (float) $wpdb->get_var( "SELECT COALESCE(SUM(net_amount),0) FROM " . wceerp_table( 'courier_payouts' ) . " WHERE payout_date >= '" . esc_sql( gmdate( 'Y-m-01' ) ) . "'" );
		$unbooked = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE status = 'pending'" );
		?>
		<div class="wceerp-kpis" style="margin-top:14px">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'COD held by couriers', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $awaiting ) ); ?></strong></div>
			<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Net paid in (this month)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $collected_month ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Pending consignments', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $unbooked; ?></strong></div>
		</div>
		<?php
	}

	/**
	 * COD money — the reconciliation view.
	 *
	 * Answers the question a shop owner actually asks: "how much money is
	 * out there with couriers, how much have I received, and who owes me?"
	 *
	 * Every figure is read from the consignments and payouts tables, which
	 * are the same records the ledger posts from — so this page and the
	 * accounts always agree.
	 */
	protected function render_cod_money() {
		global $wpdb;
		$cons_t = wceerp_table( 'consignments' );
		$pay_t  = wceerp_table( 'courier_payouts' );

		$from = sanitize_text_field( $_GET['from'] ?? gmdate( 'Y-m-01' ) );
		$to   = sanitize_text_field( $_GET['to'] ?? gmdate( 'Y-m-d' ) );

		// Per-courier position.
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT courier,
					COUNT(*) AS parcels,
					COALESCE(SUM(cod_amount),0) AS cod_total,
					COALESCE(SUM(collected_amount),0) AS collected,
					COALESCE(SUM(CASE WHEN status IN ('booked','in_transit') THEN cod_amount ELSE 0 END),0) AS in_transit,
					COALESCE(SUM(CASE WHEN status = 'delivered' THEN cod_amount - collected_amount ELSE 0 END),0) AS awaiting,
					COALESCE(SUM(CASE WHEN status = 'returned' THEN cod_amount ELSE 0 END),0) AS returned
			 FROM $cons_t
			 WHERE DATE(created_at) BETWEEN %s AND %s
			 GROUP BY courier ORDER BY cod_total DESC",
			$from, $to
		) );

		$paid_in = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(net_amount),0) FROM $pay_t WHERE payout_date BETWEEN %s AND %s", $from, $to
		) );
		$fees = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(charges),0) FROM $pay_t WHERE payout_date BETWEEN %s AND %s", $from, $to
		) );

		$t_cod = 0; $t_coll = 0; $t_transit = 0; $t_await = 0; $t_ret = 0;
		foreach ( $rows as $r ) {
			$t_cod += (float) $r->cod_total; $t_coll += (float) $r->collected;
			$t_transit += (float) $r->in_transit; $t_await += (float) $r->awaiting;
			$t_ret += (float) $r->returned;
		}
		$outstanding = $t_transit + $t_await;
		?>
		<form method="get" style="display:flex;gap:10px;align-items:flex-end;margin:14px 0">
			<input type="hidden" name="page" value="wceerp-courier">
			<input type="hidden" name="tab" value="money">
			<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
			<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
			<button class="button button-primary"><?php esc_html_e( 'Apply', 'wc-enterprise-erp' ); ?></button>
		</form>

		<div class="wceerp-kpis">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Total COD booked', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $t_cod ) ); ?></strong></div>
			<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Still with couriers', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $outstanding ) ); ?></strong></div>
			<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Net paid into bank', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $paid_in ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Courier charges', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $fees ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Returned (no COD)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $t_ret ) ); ?></strong></div>
		</div>

		<h2><?php esc_html_e( 'Position by courier', 'wc-enterprise-erp' ); ?></h2>
		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Parcels', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'COD booked', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'In transit', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Delivered, awaiting payment', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Collected', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Returned', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No consignments in this period.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $r ) : ?>
				<tr>
					<td><strong><?php echo esc_html( ucfirst( $r->courier ) ); ?></strong></td>
					<td class="num"><?php echo (int) $r->parcels; ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->cod_total ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->in_transit ) ); ?></td>
					<td class="num" style="color:<?php echo (float) $r->awaiting > 0.004 ? '#c8302e' : '#8a8f98'; ?>;font-weight:600"><?php echo wp_kses_post( wceerp_money( $r->awaiting ) ); ?></td>
					<td class="num" style="color:#2f8a4c"><?php echo wp_kses_post( wceerp_money( $r->collected ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->returned ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description">
			<?php esc_html_e( '"Delivered, awaiting payment" is money the courier has collected from your customer but not yet paid to you — chase this column first. Record what they send under COD payouts, which moves it from the receivable into your bank.', 'wc-enterprise-erp' ); ?>
		</p>
		<p class="description">
			<?php esc_html_e( 'Where a courier API reports what it collected, that figure is shown for comparison only. It never counts as paid until you record the payout — the money is not yours until it reaches your account.', 'wc-enterprise-erp' ); ?>
		</p>
		<p class="description">
			<strong><?php esc_html_e( 'Collected less than the COD?', 'wc-enterprise-erp' ); ?></strong>
			<?php esc_html_e( 'Tick "settle in full" and the shortfall is written off as a discount given at the door, closing the parcel. Leave it unticked and the balance stays owing, which is what you want if the courier is simply paying in instalments.', 'wc-enterprise-erp' ); ?>
		</p>
		<p class="description">
			<?php esc_html_e( 'A parcel that collected nothing is treated as a return: its charge still comes off the remittance — couriers charge for a failed delivery too — but it goes to Return charges rather than Delivery charges, so the cost of returns is visible on its own line.', 'wc-enterprise-erp' ); ?>
		</p>
		<?php
	}

	protected function render_dashboard() {
		global $wpdb;
		$table = wceerp_table( 'consignments' );
		$kpi   = function ( $where ) use ( $wpdb, $table ) {
			return $wpdb->get_row( "SELECT COUNT(*) AS n, COALESCE(SUM(cod_amount - collected_amount),0) AS amt FROM $table WHERE $where" );
		};
		$pending   = $kpi( "status IN ('pending','booked')" );
		$transit   = $kpi( "status = 'in_transit'" );
		$awaiting  = $kpi( "status = 'delivered'" );
		$returned  = $kpi( "status = 'returned'" );
		$month     = $wpdb->get_var( "SELECT COALESCE(SUM(net_amount),0) FROM " . wceerp_table( 'courier_payouts' ) . " WHERE payout_date >= '" . esc_sql( gmdate( 'Y-m-01' ) ) . "'" );
		$cod_book  = 0;
		$acc_1110  = WCEERP_Accounting::resolve_account( '1110' );
		if ( $acc_1110 ) {
			$balances = WCEERP_Accounting::trial_balance( '1970-01-01', current_time( 'Y-m-d' ) );
			foreach ( (array) $balances as $b ) {
				if ( '1110' === $b->code ) {
					$cod_book = (float) $b->debit - (float) $b->credit;
				}
			}
		}
		?>
		<div class="wceerp-kpis">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Pending / booked parcels', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $pending->n; ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'In transit', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $transit->n; ?></strong></div>
			<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Delivered — COD awaiting', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $awaiting->amt ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Returned parcels', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $returned->n; ?></strong></div>
			<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'COD received this month', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $month ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Courier holds (a/c 1110)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $cod_book ) ); ?></strong></div>
		</div>
		<div class="wceerp-card">
			<p class="description"><?php esc_html_e( 'COD money is booked to "Courier COD Receivable" (a/c 1110) when a parcel ships — it only becomes bank/cash when you record a payout on the COD payouts tab. That is why your cash book never lies about money the courier is still holding.', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php
	}

	protected function render_new() {
		global $wpdb;
		$order_id  = (int) ( $_GET['order_id'] ?? 0 );
		$remote_id = (int) ( $_GET['remote_id'] ?? 0 );
		$order     = $order_id ? wc_get_order( $order_id ) : null;
		$remote    = null;
		$cod       = 0;
		$pre_name  = '';
		$pre_phone = '';
		$pre_addr  = '';

		if ( $remote_id ) {
			$remote = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM " . wceerp_table( 'connect_orders' ) . " WHERE remote_id = %d",
				$remote_id
			) );
			if ( $remote ) {
				$cod       = (int) $remote->is_cod === 1 ? (float) $remote->total : 0;
				$pre_name  = $remote->customer_name;
				$pre_phone = $remote->customer_phone;
				$pre_addr  = $remote->customer_address;
			}
		} elseif ( $order ) {
			$is_cod    = false !== stripos( (string) $order->get_payment_method(), 'cod' );
			$cod       = $is_cod ? (float) $order->get_total() : 0;
			$pre_name  = $order->get_formatted_billing_full_name();
			$pre_phone = $order->get_billing_phone();
			$pre_addr  = self::address_for_order( $order );
		}
		?>
		<div class="wceerp-card" style="max-width:680px">
			<h2><?php esc_html_e( 'Create consignment', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_consignment_create">
				<?php wp_nonce_field( 'wceerp_consignment_create' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'CN number', 'wc-enterprise-erp' ); ?></th>
						<td>
							<input type="text" name="doc_no" class="regular-text"
								placeholder="<?php echo esc_attr( wceerp_next_consignment_number( true ) ); ?>">
							<p class="description">
								<?php esc_html_e( 'Leave blank to use the next number automatically. Enter one only to match a pre-printed book or a number the courier has already issued.', 'wc-enterprise-erp' ); ?>
							</p>
						</td></tr>
					<?php if ( $remote ) : ?>
						<input type="hidden" name="remote_id" value="<?php echo (int) $remote_id; ?>">
						<tr><th><?php esc_html_e( 'Connected-store order', 'wc-enterprise-erp' ); ?></th>
							<td><strong>#<?php echo esc_html( $remote->number ); ?></strong>
								<span class="wceerp-badge" style="background:#f0ecfa;color:#6b3fa0"><?php esc_html_e( 'Connected', 'wc-enterprise-erp' ); ?></span>
								<p class="description"><?php esc_html_e( 'This order lives on the customer\'s own store; details were mirrored at sync.', 'wc-enterprise-erp' ); ?></p></td></tr>
					<?php else : ?>
						<tr><th><?php esc_html_e( 'WooCommerce order ID', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" name="order_id" min="1" value="<?php echo $order_id ? (int) $order_id : ''; ?>" required></td></tr>
					<?php endif; ?>
					<tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
						<td><select name="courier">
							<?php foreach ( self::drivers() as $slug => $driver ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $driver['label'] ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Recipient name', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="recipient_name" class="regular-text" value="<?php echo esc_attr( $order ? $order->get_formatted_billing_full_name() : '' ); ?>" required></td></tr>
					<tr><th><?php esc_html_e( 'Recipient phone', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="recipient_phone" class="regular-text" value="<?php echo esc_attr( $order ? $order->get_billing_phone() : '' ); ?>" required></td></tr>
					<tr><th><?php esc_html_e( 'Delivery address', 'wc-enterprise-erp' ); ?></th>
						<td><textarea name="recipient_address" rows="2" class="large-text"><?php echo esc_textarea( $order ? self::address_for_order( $order ) : '' ); ?></textarea></td></tr>
					<tr><th><?php esc_html_e( 'COD amount to collect', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" step="0.01" min="0" name="cod_amount" value="<?php echo esc_attr( $cod ); ?>">
						<p class="description"><?php esc_html_e( 'Leave 0 for prepaid parcels.', 'wc-enterprise-erp' ); ?></p></td></tr>
					<tr><th><?php esc_html_e( 'Note to courier', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="note" class="regular-text"></td></tr>
					<tr><th></th>
						<td><label><input type="checkbox" name="book_now" value="1" checked> <?php esc_html_e( 'Book with the courier API immediately', 'wc-enterprise-erp' ); ?></label></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Create consignment', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_consignments() {
		global $wpdb;
		$table    = wceerp_table( 'consignments' );
		$status   = sanitize_key( $_GET['status'] ?? '' );
		/* Columns are qualified with c. because the list joins the payouts
		 * table, and `courier`, `doc_no`, `created_at` and `id` exist in
		 * both — an unqualified filter would fail outright. */
		$where    = $status ? $wpdb->prepare( 'WHERE c.status = %s', $status ) : '';
		$per_page = self::per_page( 25 );
		$show_all = ( 0 === $per_page );
		if ( $show_all ) {
			$per_page = 2000;
		}
		/* Drill-down from a payout: which parcels did this remittance
		 * actually settle? Without it a payment covering 183 parcels is a
		 * single number you cannot check. */
		/* Filter by the courier's own payment id, so "show me everything
		 * settled by BHKM-P-38540" is one search rather than a hunt. */
		$ref_filter = isset( $_GET['payref'] ) ? sanitize_text_field( wp_unslash( $_GET['payref'] ) ) : '';
		if ( '' !== $ref_filter ) {
			$where .= $wpdb->prepare(
				( $where ? ' AND' : 'WHERE' ) . ' c.payout_id IN ( SELECT id FROM ' . wceerp_table( 'courier_payouts' ) . ' WHERE note LIKE %s )',
				'%' . $wpdb->esc_like( $ref_filter ) . '%'
			);
		}

		$payout_filter = isset( $_GET['payout'] ) ? (int) $_GET['payout'] : 0;
		if ( $payout_filter ) {
			$where .= $wpdb->prepare( ( $where ? ' AND' : 'WHERE' ) . ' c.payout_id = %d', $payout_filter );
		}

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table c $where" );

		/* The payout's reference is what ties a parcel to the courier's own
		 * payment record, so it is joined in rather than looked up per row.
		 * `id` is qualified because both tables have one. */
		$po       = wceerp_table( 'courier_payouts' );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT c.*, p.note AS payment_ref, p.payout_date AS paid_on
			 FROM $table c
			 LEFT JOIN $po p ON p.id = c.payout_id
			 $where ORDER BY c.id DESC LIMIT %d OFFSET %d",
			$per_page,
			$show_all ? 0 : wceerp_offset( $per_page )
		) );
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-courier">
			<input type="hidden" name="tab" value="consignments">
			<select name="status">
				<option value=""><?php esc_html_e( 'All statuses', 'wc-enterprise-erp' ); ?></option>
				<?php foreach ( array( 'pending', 'booked', 'in_transit', 'delivered', 'returned', 'cancelled', 'paid' ) as $s ) : ?>
					<option value="<?php echo esc_attr( $s ); ?>" <?php selected( $status, $s ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $s ) ) ); ?></option>
				<?php endforeach; ?>
			</select>

			<?php /* Everything one payment settled, in one search. With the
			         totals at the foot of the table, this is how you check a
			         remittance against the courier's own slip. */ ?>
			<input type="search" name="payref"
				value="<?php echo esc_attr( $ref_filter ); ?>"
				placeholder="<?php esc_attr_e( 'Payment ID…', 'wc-enterprise-erp' ); ?>" style="width:150px">

			<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			<?php if ( '' !== $ref_filter ) : ?>
				<a class="button" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'consignments' ) ) ); ?>"><?php esc_html_e( 'Clear', 'wc-enterprise-erp' ); ?></a>
			<?php endif; ?>
			<?php self::per_page_control( 'consignments' ); ?>
		</form>

		<?php
		if ( $payout_filter ) {
			$po = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'courier_payouts' ) . ' WHERE id = %d', $payout_filter ) );
			if ( $po ) {
				printf(
					'<div class="notice notice-info"><p>%s <a href="%s">%s</a></p></div>',
					esc_html( sprintf(
						/* translators: 1: reference, 2: date, 3: amount. */
						__( 'Showing only the parcels settled by payment %1$s on %2$s, worth %3$s.', 'wc-enterprise-erp' ),
						$po->note ?: '#' . $po->id,
						mysql2date( 'j M Y', $po->payout_date ),
						wp_strip_all_tags( wceerp_money( $po->net_amount ) )
					) ),
					esc_url( $this->admin_url( array( 'tab' => 'consignments' ) ) ),
					esc_html__( 'Show all', 'wc-enterprise-erp' )
				);
			}
		}

		/* When a booking fails, show what actually went over the wire. The
		 * courier's own words diagnose this in seconds; a generic message
		 * costs a day of back-and-forth. */
		if ( isset( $_GET['failed'] ) ) {
			$last = self::last_exchange();
			if ( $last ) {
				?>
				<div class="wceerp-card" style="border-left-color:#C0392B;max-width:820px">
					<h2><span class="dashicons dashicons-warning"></span><?php esc_html_e( 'What the courier was sent, and what came back', 'wc-enterprise-erp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Passwords are hidden. Send this to support if the reason is not clear.', 'wc-enterprise-erp' ); ?></p>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
							<td><?php echo esc_html( ucfirst( $last['courier'] ) ); ?> · <?php echo esc_html( $last['at'] ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Endpoint', 'wc-enterprise-erp' ); ?></th>
							<td><code style="word-break:break-all"><?php echo esc_html( $last['url'] ); ?></code></td></tr>
						<tr><th><?php esc_html_e( 'HTTP status', 'wc-enterprise-erp' ); ?></th>
							<td>
								<?php if ( 0 === (int) $last['code'] ) : ?>
									<span class="wceerp-badge wceerp-badge-danger"><?php esc_html_e( 'could not connect', 'wc-enterprise-erp' ); ?></span>
									<span class="description"><?php esc_html_e( 'The server never answered — usually a firewall, DNS, or an outbound connection your host blocks.', 'wc-enterprise-erp' ); ?></span>
								<?php else : ?>
									<code><?php echo (int) $last['code']; ?></code>
									<?php if ( 401 === (int) $last['code'] ) : ?>
										<span class="description"><?php esc_html_e( 'Credentials rejected — check the Client ID, Secret, Merchant ID and password.', 'wc-enterprise-erp' ); ?></span>
									<?php elseif ( 422 === (int) $last['code'] ) : ?>
										<span class="description"><?php esc_html_e( 'The courier refused a field. The reply below names it.', 'wc-enterprise-erp' ); ?></span>
									<?php elseif ( 404 === (int) $last['code'] ) : ?>
										<span class="description"><?php esc_html_e( 'That route does not exist — the API may have moved.', 'wc-enterprise-erp' ); ?></span>
									<?php endif; ?>
								<?php endif; ?>
							</td></tr>
						<tr><th><?php esc_html_e( 'Sent', 'wc-enterprise-erp' ); ?></th>
							<td><pre style="white-space:pre-wrap;font-size:11.5px;background:#F6F5F8;padding:10px;border-radius:6px;margin:0"><?php
								echo esc_html( wp_json_encode( $last['payload'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
							?></pre></td></tr>
						<tr><th><?php esc_html_e( 'Reply', 'wc-enterprise-erp' ); ?></th>
							<td><pre style="white-space:pre-wrap;font-size:11.5px;background:#F6F5F8;padding:10px;border-radius:6px;margin:0"><?php
								echo esc_html( $last['body'] ?: __( '(empty)', 'wc-enterprise-erp' ) );
							?></pre></td></tr>
					</tbody></table>
				</div>
				<?php
			}
		}

		if ( isset( $_GET['bulk'] ) ) {
			$ok  = isset( $_GET['ok'] ) ? (int) $_GET['ok'] : 0;
			$bad = isset( $_GET['bad'] ) ? (int) $_GET['bad'] : 0;
			$msg = sprintf(
				/* translators: 1: succeeded, 2: skipped. */
				__( '%1$d done, %2$d skipped. Anything already settled is never changed in bulk.', 'wc-enterprise-erp' ),
				$ok,
				$bad
			);

			/* A sync where nothing changed is the commonest confusion: the
			 * couriers answered, the parcels were simply already up to date.
			 * Say so, rather than leaving it looking broken. */
			if ( 'sync' === sanitize_key( $_GET['bulk'] ) && $ok ) {
				$changed = isset( $_GET['changed'] ) ? (int) $_GET['changed'] : 0;
				$money   = isset( $_GET['money'] ) ? (int) $_GET['money'] : 0;
				$msg    .= ' ' . sprintf(
					/* translators: 1: status changes, 2: parcels with money reported. */
					__( '%1$d changed status; %2$d reported a collected amount.', 'wc-enterprise-erp' ),
					$changed,
					$money
				);
				if ( ! $changed && ! $money ) {
					$msg .= ' ' . __( 'The couriers replied but had nothing new — these parcels were already up to date. If you are waiting on COD figures, this courier does not report them per parcel; import its payment report on the COD payouts tab instead.', 'wc-enterprise-erp' );
				}
			}

			$this->notice( $msg, ( $bad && ! $ok ) ? 'error' : 'success' );
		}
		?>

		<?php /* Standalone on purpose: wrapping the table would nest the
		         per-row action forms inside this one, and browsers silently
		         drop nested forms — every row button would stop working.
		         Selected ids travel in a hidden field instead. */ ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wceerp-cons-bulk">
			<?php wp_nonce_field( 'wceerp_cons_bulk' ); ?>
			<input type="hidden" name="action" value="wceerp_cons_bulk">
			<input type="hidden" name="cons_ids" id="wceerp-cons-ids" value="">
			<div class="wceerp-filter" style="margin-bottom:10px">
				<select name="bulk_action" style="max-width:200px">
					<option value=""><?php esc_html_e( 'Bulk action…', 'wc-enterprise-erp' ); ?></option>
					<option value="book"><?php esc_html_e( 'Book with courier', 'wc-enterprise-erp' ); ?></option>
					<option value="sync"><?php esc_html_e( 'Sync status &amp; COD', 'wc-enterprise-erp' ); ?></option>
					<option value="delivered"><?php esc_html_e( 'Mark delivered', 'wc-enterprise-erp' ); ?></option>
					<option value="returned"><?php esc_html_e( 'Mark returned', 'wc-enterprise-erp' ); ?></option>
					<option value="cancelled"><?php esc_html_e( 'Mark cancelled', 'wc-enterprise-erp' ); ?></option>
					<option value="delete"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></option>
				</select>
				<button class="button" onclick="return wceerpBulkConfirm();"><?php esc_html_e( 'Apply', 'wc-enterprise-erp' ); ?></button>
				<button type="button" class="button" onclick="wceerpPrintLabels();"><?php esc_html_e( 'Print labels', 'wc-enterprise-erp' ); ?></button>
				<button type="button" class="button" onclick="wceerpPrintChallans();"><?php esc_html_e( 'Print challans', 'wc-enterprise-erp' ); ?></button>
				<span class="wceerp-muted" style="font-size:12px" id="wceerp-selcount"></span>
				<span class="wceerp-spacer"></span>
				<span class="wceerp-muted" style="font-size:11.5px">
					<?php esc_html_e( 'Booking and syncing run 25 at a time — each one calls the courier.', 'wc-enterprise-erp' ); ?>
				</span>
			</div>

			<?php
			/* A count of parcels whose money the courier is holding, with the
			 * one thing worth doing about it. "Something does not add up" is
			 * only useful when it comes with a next step. */
			$holding = (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$table}
				 WHERE status = 'delivered' AND payout_id IS NULL AND remote_collected > 0.004"
			);
			if ( $holding ) :
				?>
				<div class="notice notice-info inline" style="margin:10px 0">
					<p>
						<strong><?php
							printf(
								/* translators: %d: parcels. */
								esc_html__( 'The courier is holding money for %d delivered parcels.', 'wc-enterprise-erp' ),
								$holding
							);
						?></strong>
						<?php esc_html_e( 'That is normal until they remit — it is what a receivable looks like. When their payment arrives, settle it there; never edit these rows by hand.', 'wc-enterprise-erp' ); ?>
					</p>
					<p class="description" style="margin:4px 0 0">
						<?php
						printf(
							/* translators: %s: link to the payouts tab. */
							esc_html__( 'If their figure disagrees with yours, upload their statement on %s. It shows exactly which parcels differ, and which they paid for that were never booked here — then import the same file to settle.', 'wc-enterprise-erp' ),
							'<a href="' . esc_url( $this->admin_url( array( 'tab' => 'payouts' ) ) ) . '">' . esc_html__( 'COD payouts', 'wc-enterprise-erp' ) . '</a>'
						);
						?>
					</p>
				</div>
			<?php endif; ?>
		</form>

		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th style="width:26px"><input type="checkbox" id="wceerp-cons-all" title="<?php esc_attr_e( 'Select all', 'wc-enterprise-erp' ); ?>"></th>
				<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Recipient', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Tracking', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'COD', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Collected', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Courier charge', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Payment ID', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="10"><?php esc_html_e( 'No consignments yet — create one from an order or the "New consignment" tab.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php
			/* Column totals for whatever is on screen — with a payment id
			 * filter applied this is the sum for that remittance, which is
			 * the number to check against the courier's slip. */
			$sum_cod = 0; $sum_coll = 0; $sum_charge = 0;
			foreach ( (array) $rows as $t ) {
				$sum_cod  += (float) $t->cod_amount;
				$sum_coll += (float) $t->collected_amount;
				/* Same rule as the column: settled parcels contribute what
				 * was accounted for, so this total can be checked against
				 * the payout without the two disagreeing. */
				$sum_charge += (float) $t->delivery_charge > 0.004
					? (float) $t->delivery_charge
					: (float) $t->remote_charge;
			}
			?>
			<?php foreach ( (array) $rows as $c ) :
				$label_url = wp_nonce_url( admin_url( 'admin-post.php?action=wceerp_courier_label&consignment_id=' . $c->id ), 'wceerp_courier_label' );
				?>
				<tr>
					<td><input type="checkbox" class="wceerp-cons-cb" value="<?php echo (int) $c->id; ?>"
						data-label="<?php echo esc_attr( $label_url ); ?>"
						data-challan="<?php echo esc_attr( $c->order_id ? WCEERP_Document::url( 'challan', $c->order_id ) : '' ); ?>"></td>
					<td><code><?php echo esc_html( $c->doc_no ); ?></code></td>
					<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $c->order_id . '&action=edit' ) ); ?>">#<?php echo (int) $c->order_id; ?></a></td>
					<td><?php echo esc_html( ucfirst( $c->courier ) ); ?></td>
					<td><?php echo esc_html( $c->recipient_name ); ?><br><small><?php echo esc_html( $c->recipient_phone ); ?></small></td>
					<td><code><?php echo esc_html( $c->tracking_code ?: '—' ); ?></code></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $c->cod_amount ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $c->collected_amount ) ); ?></td>

					<td class="num">
						<?php
						/* The charge the courier actually billed, falling back
						 * to whatever it reported. Never a guess. */
						/* Once a parcel is settled, the only honest figure is
						 * what the payout actually accounted for. Falling back
						 * to the courier's reported charge here made the column
						 * disagree with the payout it belongs to. The reported
						 * figure is still shown, but only where nothing has
						 * been settled and it is clearly a courier estimate. */
						/* Show the figure that was actually accounted for where
						 * one exists, and the courier's own where it does not —
						 * but always say which, so the column can be read
						 * against a payout without the two silently
						 * disagreeing. Blanking it lost a report worth having. */
						if ( (float) $c->delivery_charge > 0.004 ) {
							echo wp_kses_post( wceerp_money( $c->delivery_charge ) );

							/* Split it where the statement told us. Checking a
							 * remittance line by line is far easier against
							 * "100 delivery + 5.50 COD" than one figure. */
							$cd = (float) $c->charge_delivery;
							$cc = (float) $c->charge_cod;
							if ( $cd > 0.004 || $cc > 0.004 ) {
								echo '<span class="wceerp-sub">'
									. esc_html( sprintf(
										/* translators: 1: delivery, 2: COD fee. */
										__( '%1$s delivery + %2$s COD', 'wc-enterprise-erp' ),
										number_format( $cd, 2 ),
										number_format( $cc, 2 )
									) )
									. '</span>';
							}
						} elseif ( (float) $c->remote_charge > 0.004 ) {
							echo wp_kses_post( wceerp_money( $c->remote_charge ) );
							echo '<span class="wceerp-sub" style="color:#B7791F">'
								. ( (int) $c->payout_id
									? esc_html__( 'courier says — not allocated', 'wc-enterprise-erp' )
									: esc_html__( 'courier says', 'wc-enterprise-erp' ) )
								. '</span>';
						} else {
							echo '<span class="wceerp-muted">—</span>';
						}
						?>
					</td>

					<td>
						<?php if ( ! empty( $c->payment_ref ) ) : ?>
							<a href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'consignments', 'payref' => $c->payment_ref ) ) ); ?>"
								title="<?php esc_attr_e( 'Show everything this payment settled', 'wc-enterprise-erp' ); ?>">
								<code><?php echo esc_html( $c->payment_ref ); ?></code>
							</a>
							<?php if ( ! empty( $c->paid_on ) ) : ?>
								<span class="wceerp-sub"><?php echo esc_html( mysql2date( 'j M', $c->paid_on ) ); ?></span>
							<?php endif; ?>
						<?php elseif ( (int) $c->payout_id ) : ?>
							<span class="wceerp-sub"><?php esc_html_e( 'paid, no reference', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-muted">—</span>
						<?php endif; ?>
					</td>

					<td>
						<span class="wceerp-badge is-<?php echo esc_attr( $c->status ); ?>"><?php echo esc_html( str_replace( '_', ' ', $c->status ) ); ?></span>
						<?php
						/* Delivered, the courier says it holds money, and no
						 * payout has settled it. The customer has paid; you
						 * have not been paid. Worth saying out loud. */
						if ( 'delivered' === $c->status && ! (int) $c->payout_id && (float) $c->remote_collected > 0.004 ) :
							?>
							<span class="wceerp-sub" style="color:#B7791F"><?php esc_html_e( 'courier holds the money', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<a class="button button-small" href="<?php echo esc_url( $label_url ); ?>" target="_blank"><?php esc_html_e( 'Label', 'wc-enterprise-erp' ); ?></a>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
							<input type="hidden" name="action" value="wceerp_consignment_action">
							<input type="hidden" name="consignment_id" value="<?php echo (int) $c->id; ?>">
							<?php wp_nonce_field( 'wceerp_consignment_action' ); ?>
							<?php if ( 'pending' === $c->status ) : ?>
								<button class="button button-small" name="do" value="book"><?php esc_html_e( 'Book', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
							<?php if ( $c->remote_id && in_array( $c->status, array( 'booked', 'in_transit' ), true ) ) : ?>
								<button class="button button-small" name="do" value="sync"><?php esc_html_e( 'Sync', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
							<?php if ( in_array( $c->status, array( 'booked', 'in_transit' ), true ) ) : ?>
								<button class="button button-small" name="do" value="delivered"><?php esc_html_e( 'Delivered', 'wc-enterprise-erp' ); ?></button>
								<button class="button button-small" name="do" value="returned"><?php esc_html_e( 'Returned', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
							<?php if ( in_array( $c->status, array( 'booked', 'in_transit', 'cancelled', 'returned' ), true ) && (float) $c->collected_amount <= 0 ) : ?>
								<button class="button button-small" name="do" value="unbook"
									onclick="return confirm('<?php echo esc_js( __( 'Unbook this consignment? It goes back to pending and loses its courier reference. This does NOT cancel the parcel with the courier.', 'wc-enterprise-erp' ) ); ?>');"><?php esc_html_e( 'Unbook', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
							<?php if ( ! in_array( $c->status, array( 'paid', 'delivered' ), true ) && (float) $c->collected_amount <= 0 ) : ?>
								<button class="button button-small button-link-delete" name="do" value="delete"
									onclick="return confirm('<?php echo esc_js( __( 'Delete this consignment permanently? Use this only for test or duplicate rows.', 'wc-enterprise-erp' ) ); ?>');"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>

			<?php if ( $rows ) : ?>
				<tfoot>
					<tr class="wceerp-grand">
						<td colspan="6"><?php
							printf(
								/* translators: %d: parcels on screen. */
								esc_html__( 'Total for these %d parcels', 'wc-enterprise-erp' ),
								count( (array) $rows )
							);
						?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $sum_cod ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $sum_coll ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $sum_charge ) ); ?></td>
						<td colspan="3">
							<?php if ( $sum_cod - $sum_coll > 0.004 ) : ?>
								<span class="wceerp-sub" style="color:#B7791F">
									<?php
									printf(
										/* translators: %s: amount. */
										esc_html__( '%s still owed on this page', 'wc-enterprise-erp' ),
										wp_strip_all_tags( wceerp_money( $sum_cod - $sum_coll ) )
									);
									?>
								</span>
							<?php endif; ?>
						</td>
					</tr>
				</tfoot>
			<?php endif; ?>
		</table>

		<script>
		(function () {
			var all   = document.getElementById( 'wceerp-cons-all' );
			var boxes = function () { return Array.prototype.slice.call( document.querySelectorAll( '.wceerp-cons-cb' ) ); };
			var count = document.getElementById( 'wceerp-selcount' );

			function refresh() {
				var n = boxes().filter( function ( b ) { return b.checked; } ).length;
				count.textContent = n ? n + ' <?php echo esc_js( __( 'selected', 'wc-enterprise-erp' ) ); ?>' : '';
			}
			if ( all ) {
				all.addEventListener( 'change', function () {
					boxes().forEach( function ( b ) { b.checked = all.checked; } );
					refresh();
				} );
			}
			boxes().forEach( function ( b ) { b.addEventListener( 'change', refresh ); } );

			window.wceerpBulkConfirm = function () {
				var sel = boxes().filter( function ( b ) { return b.checked; } );
				var act = document.querySelector( '[name=bulk_action]' ).value;
				document.getElementById( 'wceerp-cons-ids' ).value = sel.map( function ( b ) { return b.value; } ).join( ',' );
				if ( ! sel.length ) { alert( '<?php echo esc_js( __( 'Select at least one consignment first.', 'wc-enterprise-erp' ) ); ?>' ); return false; }
				if ( ! act ) { alert( '<?php echo esc_js( __( 'Choose an action.', 'wc-enterprise-erp' ) ); ?>' ); return false; }
				if ( 'delete' === act ) { return confirm( '<?php echo esc_js( __( 'Delete the selected consignments? This cannot be undone.', 'wc-enterprise-erp' ) ); ?>' ); }
				if ( 'book' === act ) { return confirm( '<?php echo esc_js( __( 'Book these parcels with their couriers now? Real consignments will be created.', 'wc-enterprise-erp' ) ); ?>' ); }
				return true;
			};

			/* Labels open one tab each. Browsers block a burst of popups, so
			   the count is capped and the user is told why. */
			window.wceerpPrintChallans = function () {
				var sel = boxes().filter( function ( b ) { return b.checked && b.dataset.challan; } );
				if ( ! sel.length ) { alert( '<?php echo esc_js( __( 'Select consignments that have an order behind them.', 'wc-enterprise-erp' ) ); ?>' ); return; }
				if ( sel.length > 10 && ! confirm( '<?php echo esc_js( __( 'Your browser may block more than about ten tabs at once. Continue?', 'wc-enterprise-erp' ) ); ?>' ) ) { return; }
				sel.forEach( function ( b, i ) {
					setTimeout( function () { window.open( b.dataset.challan, '_blank' ); }, i * 220 );
				} );
			};

			window.wceerpPrintLabels = function () {
				var sel = boxes().filter( function ( b ) { return b.checked; } );
				if ( ! sel.length ) { alert( '<?php echo esc_js( __( 'Select the consignments to print.', 'wc-enterprise-erp' ) ); ?>' ); return; }
				if ( sel.length > 10 && ! confirm( '<?php echo esc_js( __( 'Your browser may block more than about ten tabs at once. Continue?', 'wc-enterprise-erp' ) ); ?>' ) ) { return; }
				sel.forEach( function ( b, i ) {
					setTimeout( function () { window.open( b.dataset.label, '_blank' ); }, i * 220 );
				} );
			};
		})();
		</script>

		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}

	protected function render_payouts() {
		global $wpdb;
		$table = wceerp_table( 'consignments' );

		$awaiting = $wpdb->get_results(
			"SELECT * FROM $table WHERE status = 'delivered' AND cod_amount - collected_amount > 0.004 ORDER BY courier, id DESC LIMIT 200"
		);
		$accounts = $wpdb->get_results(
			'SELECT id, code, name FROM ' . wceerp_table( 'accounts' ) . " WHERE subtype IN ('cash','bank','mobile_banking') AND status='active' ORDER BY code"
		);
		/* Parcel counts come from the consignments that point at each payout,
		 * so the figure can never drift from what was actually settled. */
		$payouts = $wpdb->get_results(
			'SELECT p.*, (
			     SELECT COUNT(*) FROM ' . wceerp_table( 'consignments' ) . ' c WHERE c.payout_id = p.id
			 ) AS parcels
			 FROM ' . wceerp_table( 'courier_payouts' ) . ' p
			 ORDER BY p.id DESC LIMIT 20'
		);
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Record a COD payout from the courier', 'wc-enterprise-erp' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Tick the parcels covered by this remittance, adjust collected amounts for partial deliveries, and enter the delivery charge deducted per parcel. Posting: Dr deposit account (net) + Dr Delivery charges / Cr Courier COD Receivable (gross).', 'wc-enterprise-erp' ); ?></p>

			<?php
			if ( isset( $_GET['refreshed'] ) ) {
				printf(
					'<div class="notice notice-info inline" style="margin:0 0 12px"><p>%s</p></div>',
					esc_html( sprintf(
						/* translators: 1: parcels checked, 2: parcels with a figure. */
						__( 'Asked the courier about %1$d parcel(s); %2$d came back with a collected amount. Those are filled in below — check them against the remittance slip before posting.', 'wc-enterprise-erp' ),
						(int) $_GET['refreshed'],
						(int) ( $_GET['got'] ?? 0 )
					) )
				);
			}
			?>

			<?php
			$import = get_transient( 'wceerp_payout_import_' . get_current_user_id() );

			if ( isset( $_GET['import_failed'] ) ) {
				$err = get_transient( 'wceerp_payout_err_' . get_current_user_id() );
				delete_transient( 'wceerp_payout_err_' . get_current_user_id() );
				printf( '<div class="notice notice-error inline" style="margin:0 0 12px"><p>%s</p></div>', esc_html( $err ?: __( 'That statement could not be read.', 'wc-enterprise-erp' ) ) );
			}
			if ( isset( $_GET['posted'] ) ) {
				printf(
					'<div class="notice notice-success inline" style="margin:0 0 12px"><p>%s</p></div>',
					esc_html( sprintf(
						/* translators: %d: parcels. */
						__( 'Payout posted. %d parcels settled and the money is in your books.', 'wc-enterprise-erp' ),
						(int) $_GET['posted']
					) )
				);
			}
			?>

			<?php
			/* Why the two figures disagree.
			 *
			 * A courier pays a round number against a set of parcels it
			 * chose, and the ERP holds a different set. Hunting the
			 * difference across hundreds of orders by eye is not work
			 * anyone completes, so the usual causes are counted instead —
			 * each one a specific list you can act on.
			 */
			$gap_courier = isset( $_GET['gap_courier'] ) ? sanitize_key( $_GET['gap_courier'] ) : '';
			$gap_amount  = isset( $_GET['gap_amount'] ) ? wceerp_dec( $_GET['gap_amount'] ) : 0;

			if ( $gap_courier && $gap_amount > 0 ) :
				$erp_total = (float) $wpdb->get_var( $wpdb->prepare(
					"SELECT COALESCE(SUM(cod_amount - collected_amount),0) FROM {$table}
					 WHERE courier = %s AND status = 'delivered' AND cod_amount - collected_amount > 0.004",
					$gap_courier
				) );

				/* Parcels the courier says it collected but we still show as
				 * in transit — the commonest single cause of a gap. */
				$in_transit = (array) $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM {$table}
					 WHERE courier = %s AND status IN ('booked','in_transit')
					   AND remote_collected > 0.004
					 ORDER BY id DESC LIMIT 100",
					$gap_courier
				) );
				$in_transit_value = 0;
				foreach ( $in_transit as $t ) {
					$in_transit_value += (float) $t->remote_collected;
				}

				/* Where the courier's own figure disagrees with the order. */
				$mismatched = (array) $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM {$table}
					 WHERE courier = %s AND status = 'delivered'
					   AND cod_amount - collected_amount > 0.004
					   AND remote_collected IS NOT NULL
					   AND ABS( remote_collected - ( cod_amount - collected_amount ) ) > 0.5
					 ORDER BY ABS( remote_collected - ( cod_amount - collected_amount ) ) DESC LIMIT 100",
					$gap_courier
				) );
				$mismatch_value = 0;
				foreach ( $mismatched as $m ) {
					$mismatch_value += (float) $m->remote_collected - ( (float) $m->cod_amount - (float) $m->collected_amount );
				}

				/* Returned or cancelled but still counted as owing. */
				$returned = (array) $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM {$table}
					 WHERE courier = %s AND status IN ('returned','cancelled')
					   AND cod_amount - collected_amount > 0.004
					 ORDER BY id DESC LIMIT 100",
					$gap_courier
				) );
				$returned_value = 0;
				foreach ( $returned as $r ) {
					$returned_value += (float) $r->cod_amount - (float) $r->collected_amount;
				}

				$difference = round( $erp_total - $gap_amount, 2 );
				?>
				<div class="wceerp-card" style="border-left-color:#B7791F">
					<h2><span class="dashicons dashicons-search"></span><?php esc_html_e( 'Why the two figures differ', 'wc-enterprise-erp' ); ?></h2>

					<div class="wceerp-kpis">
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Your ERP says outstanding', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo wp_kses_post( wceerp_money( $erp_total ) ); ?></strong></div>
						<div class="wceerp-kpi"><span><?php esc_html_e( 'The courier says outstanding', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo wp_kses_post( wceerp_money( $gap_amount ) ); ?></strong></div>
						<div class="wceerp-kpi <?php echo abs( $difference ) > 0.5 ? 'is-warn' : 'is-good'; ?>">
							<span><?php esc_html_e( 'Difference', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo wp_kses_post( wceerp_money( abs( $difference ) ) ); ?></strong>
							<em><?php echo $difference > 0 ? esc_html__( 'your ERP shows more owing', 'wc-enterprise-erp' ) : esc_html__( 'the courier shows more owing', 'wc-enterprise-erp' ); ?></em>
						</div>
					</div>

					<p class="description">
						<?php esc_html_e( 'A small gap is normal — parcels delivered in the last day or two often reach one system before the other. What matters is whether the causes below add up to the difference.', 'wc-enterprise-erp' ); ?>
					</p>

					<table class="widefat striped wceerp-table">
						<thead><tr>
							<th><?php esc_html_e( 'Possible cause', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Parcels', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Value', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'What to do', 'wc-enterprise-erp' ); ?></th>
						</tr></thead>
						<tbody>
							<tr>
								<td><strong><?php esc_html_e( 'Collected but still showing in transit', 'wc-enterprise-erp' ); ?></strong>
									<span class="wceerp-sub"><?php esc_html_e( 'The courier reports money against a parcel we have not marked delivered.', 'wc-enterprise-erp' ); ?></span></td>
								<td class="num"><?php echo count( $in_transit ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $in_transit_value ) ); ?></td>
								<td><small><?php esc_html_e( 'Run Sync all now — these should become delivered and join the outstanding total.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Courier collected a different amount', 'wc-enterprise-erp' ); ?></strong>
									<span class="wceerp-sub"><?php esc_html_e( 'Usually a discount agreed at the door, or a part delivery.', 'wc-enterprise-erp' ); ?></span></td>
								<td class="num"><?php echo count( $mismatched ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $mismatch_value ) ); ?></td>
								<td><small><?php esc_html_e( 'Settle these with "settle in full" ticked so the shortfall closes as a discount.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Returned or cancelled, still counted as owing', 'wc-enterprise-erp' ); ?></strong>
									<span class="wceerp-sub"><?php esc_html_e( 'No money is coming for these, so the courier will never pay them.', 'wc-enterprise-erp' ); ?></span></td>
								<td class="num"><?php echo count( $returned ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $returned_value ) ); ?></td>
								<td><small><?php esc_html_e( 'Open the Returns tab and mark them received so the sale reverses.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
						</tbody>
						<tfoot>
							<tr class="wceerp-grand">
								<td><?php esc_html_e( 'Explained by the above', 'wc-enterprise-erp' ); ?></td>
								<td class="num"><?php echo count( $in_transit ) + count( $mismatched ) + count( $returned ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $returned_value + abs( $mismatch_value ) ) ); ?></td>
								<td>
									<?php
									$unexplained = abs( $difference ) - ( $returned_value + abs( $mismatch_value ) );
									if ( $unexplained > 1 ) {
										printf(
											'<small style="color:#B7791F">%s</small>',
											esc_html( sprintf(
												/* translators: %s: amount. */
												__( '%s still unexplained — most likely parcels not yet settled.', 'wc-enterprise-erp' ),
												wp_strip_all_tags( wceerp_money( $unexplained ) )
											) )
										);
									} else {
										printf( '<small style="color:#0F7B5A">%s</small>', esc_html__( 'The difference is accounted for.', 'wc-enterprise-erp' ) );
									}
									?>
								</td>
							</tr>
						</tfoot>
					</table>

					<p style="margin-top:12px">
						<a class="button" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'payouts' ) ) ); ?>"><?php esc_html_e( 'Clear', 'wc-enterprise-erp' ); ?></a>
					</p>
				</div>
			<?php endif; ?>

			<?php
			/* Booking notifications live in the messaging module, which is
			 * not an obvious place to look when you are on the courier
			 * screen wondering why customers get no SMS. */
			if ( class_exists( 'WCEERP_Messaging' ) && ! WCEERP_Messaging::sms_ready() ) :
				?>
				<div class="notice notice-info" style="margin:0 0 14px">
					<p>
						<strong><?php esc_html_e( 'Want customers told when their parcel ships?', 'wc-enterprise-erp' ); ?></strong>
						<?php
						printf(
							/* translators: %s: link. */
							esc_html__( 'Set up an SMS gateway under %s, then switch on "Parcel booked" so a message goes out automatically at booking.', 'wc-enterprise-erp' ),
							'<a href="' . esc_url( admin_url( 'admin.php?page=wceerp-messaging&tab=settings' ) ) . '">' . esc_html__( 'SMS &amp; WhatsApp', 'wc-enterprise-erp' ) . '</a>'
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php
			$recon = isset( $_GET['recon'] ) ? get_transient( 'wceerp_recon_' . get_current_user_id() ) : null;
			if ( $recon ) :
				$b = function ( $k ) use ( $recon ) {
					return isset( $recon[ $k ] ) ? (array) $recon[ $k ] : array();
				};
				$sum = function ( $rows, $key ) {
					$t = 0;
					foreach ( (array) $rows as $r ) {
						$t += (float) ( $r[ $key ] ?? 0 );
					}
					return $t;
				};
				$unbooked_value = $sum( $b( 'unbooked' ), 'collected' );
				$differs_gap    = $sum( $b( 'differs' ), 'gap' );
				$missing_value  = $sum( $b( 'missing' ), 'due' );
				?>
				<div class="wceerp-card" style="border-left-color:#B7791F">
					<h2><span class="dashicons dashicons-media-spreadsheet"></span><?php esc_html_e( 'Statement compared with your ERP', 'wc-enterprise-erp' ); ?></h2>
					<p class="description">
						<?php
						printf(
							/* translators: 1: file, 2: courier, 3: reference. */
							esc_html__( '%1$s · %2$s %3$s — nothing has been settled or posted.', 'wc-enterprise-erp' ),
							esc_html( $recon['file'] ?? '' ),
							esc_html( ucfirst( $recon['courier'] ?? '' ) ),
							$recon['reference'] ? esc_html( '· ' . $recon['reference'] ) : ''
						);
						?>
					</p>

					<div class="wceerp-kpis">
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Their file totals', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo wp_kses_post( wceerp_money( $recon['file_total'] ?? 0 ) ); ?></strong></div>
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Your ERP outstanding', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo wp_kses_post( wceerp_money( $recon['erp_total'] ?? 0 ) ); ?></strong></div>
						<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Agree', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo count( $b( 'agreed' ) ); ?></strong>
							<em><?php esc_html_e( 'parcels', 'wc-enterprise-erp' ); ?></em></div>
						<div class="wceerp-kpi <?php echo $b( 'unbooked' ) ? 'is-bad' : ''; ?>">
							<span><?php esc_html_e( 'Never booked here', 'wc-enterprise-erp' ); ?></span>
							<strong><?php echo count( $b( 'unbooked' ) ); ?></strong>
							<em><?php echo wp_kses_post( wceerp_money( $unbooked_value ) ); ?></em></div>
					</div>

					<?php if ( $b( 'unbooked' ) ) : ?>
						<div class="notice notice-error inline" style="margin:14px 0">
							<p><strong><?php
								printf(
									/* translators: 1: count, 2: value. */
									esc_html__( '%1$d parcels worth %2$s were paid for by the courier but do not exist in this ERP.', 'wc-enterprise-erp' ),
									count( $b( 'unbooked' ) ),
									wp_kses_post( wceerp_money( $unbooked_value ) )
								);
							?></strong></p>
							<p class="description">
								<?php esc_html_e( 'Booked directly in the courier portal, or the consignment was deleted here. This is the mismatch that loses money quietly: nothing in your books is waiting for this cash, so when it arrives it has nothing to settle against. Find each order and use "Already booked?" on the All Orders tab to bring it under management.', 'wc-enterprise-erp' ); ?>
							</p>
							<table class="widefat striped" style="margin:8px 0">
								<thead><tr>
									<th><?php esc_html_e( 'Their reference', 'wc-enterprise-erp' ); ?></th>
									<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
									<th class="num"><?php esc_html_e( 'They collected', 'wc-enterprise-erp' ); ?></th>
								</tr></thead>
								<tbody>
								<?php foreach ( array_slice( $b( 'unbooked' ), 0, 100 ) as $u ) : ?>
									<tr>
										<td><code><?php echo esc_html( $u['memo'] ?: $u['cid'] ); ?></code></td>
										<td><?php echo esc_html( $u['name'] ?: '—' ); ?></td>
										<td class="num"><?php echo wp_kses_post( wceerp_money( $u['collected'] ) ); ?></td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					<?php endif; ?>

					<table class="widefat striped wceerp-table" style="margin-top:14px">
						<thead><tr>
							<th><?php esc_html_e( 'Outcome', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Parcels', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Value', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'What it means', 'wc-enterprise-erp' ); ?></th>
						</tr></thead>
						<tbody>
							<tr>
								<td><strong style="color:#0F7B5A"><?php esc_html_e( 'Agree', 'wc-enterprise-erp' ); ?></strong></td>
								<td class="num"><?php echo count( $b( 'agreed' ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $sum( $b( 'agreed' ), 'collected' ) ) ); ?></td>
								<td><small><?php esc_html_e( 'Ready to settle through the payout import.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong style="color:#B7791F"><?php esc_html_e( 'Amounts differ', 'wc-enterprise-erp' ); ?></strong></td>
								<td class="num"><?php echo count( $b( 'differs' ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $differs_gap ) ); ?></td>
								<td><small><?php esc_html_e( 'Usually a discount at the door or a part delivery. Settle with "settle in full" so the shortfall closes as a discount.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong style="color:#C0392B"><?php esc_html_e( 'Never booked here', 'wc-enterprise-erp' ); ?></strong></td>
								<td class="num"><?php echo count( $b( 'unbooked' ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $unbooked_value ) ); ?></td>
								<td><small><?php esc_html_e( 'Listed above. Attach each with "Already booked?".', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Already settled', 'wc-enterprise-erp' ); ?></strong></td>
								<td class="num"><?php echo count( $b( 'settled' ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $sum( $b( 'settled' ), 'collected' ) ) ); ?></td>
								<td><small><?php esc_html_e( 'Covered by an earlier payout. Re-importing will skip them.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Not in this file', 'wc-enterprise-erp' ); ?></strong></td>
								<td class="num"><?php echo count( $b( 'missing' ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $missing_value ) ); ?></td>
								<td><small><?php esc_html_e( 'Your ERP is waiting for money this statement does not mention — normally just parcels the courier has not settled yet.', 'wc-enterprise-erp' ); ?></small></td>
							</tr>
						</tbody>
					</table>

					<?php if ( $b( 'differs' ) ) : ?>
						<details style="margin-top:12px">
							<summary style="cursor:pointer;font-weight:600"><?php esc_html_e( 'Show the parcels whose amounts differ', 'wc-enterprise-erp' ); ?></summary>
							<table class="widefat striped" style="margin-top:8px">
								<thead><tr>
									<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
									<th class="num"><?php esc_html_e( 'You expect', 'wc-enterprise-erp' ); ?></th>
									<th class="num"><?php esc_html_e( 'They paid', 'wc-enterprise-erp' ); ?></th>
									<th class="num"><?php esc_html_e( 'Difference', 'wc-enterprise-erp' ); ?></th>
								</tr></thead>
								<tbody>
								<?php foreach ( array_slice( $b( 'differs' ), 0, 200 ) as $d ) : ?>
									<tr>
										<td><code><?php echo esc_html( $d['doc_no'] ?? '' ); ?></code></td>
										<td class="num"><?php echo wp_kses_post( wceerp_money( $d['due'] ?? 0 ) ); ?></td>
										<td class="num"><?php echo wp_kses_post( wceerp_money( $d['collected'] ?? 0 ) ); ?></td>
										<td class="num" style="color:<?php echo ( $d['gap'] ?? 0 ) < 0 ? '#C0392B' : '#0F7B5A'; ?>">
											<?php echo wp_kses_post( wceerp_money( $d['gap'] ?? 0 ) ); ?></td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</details>
					<?php endif; ?>

					<p style="margin-top:14px">
						<a class="button" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'payouts' ) ) ); ?>"><?php esc_html_e( 'Clear this report', 'wc-enterprise-erp' ); ?></a>
						<span class="description" style="margin-left:8px"><?php esc_html_e( 'When you are ready to settle, upload the same file through the payout import above.', 'wc-enterprise-erp' ); ?></span>
					</p>
				</div>
			<?php endif; ?>

			<div class="wceerp-card">
				<h2><span class="dashicons dashicons-search"></span><?php esc_html_e( 'Figures not matching?', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Open the courier\'s own panel and find the total it still owes you — Bahok calls this the unpaid or pending COD. Type that figure below and this works out where it disagrees with your ERP, instead of leaving you to compare hundreds of orders by hand.', 'wc-enterprise-erp' ); ?>
				</p>
				<p class="description">
					<?php esc_html_e( 'Both figures answer the same question: how much is still owed. If they match, your books agree with the courier. If not, the causes are listed with what to do about each.', 'wc-enterprise-erp' ); ?>
				</p>
				<?php /* The file is the better route: a courier pays in no
				         particular order, so a total alone cannot tell you
				         which parcels are involved. */ ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
					enctype="multipart/form-data" class="wceerp-filter" style="align-items:flex-end;margin-bottom:14px">
					<?php wp_nonce_field( 'wceerp_reconcile_file' ); ?>
					<input type="hidden" name="action" value="wceerp_reconcile_file">
					<label><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?><br>
						<select name="courier">
							<?php foreach ( self::drivers() as $dk => $dv ) : ?>
								<option value="<?php echo esc_attr( $dk ); ?>"><?php echo esc_html( $dv['label'] ); ?></option>
							<?php endforeach; ?>
						</select></label>
					<label><?php esc_html_e( 'Payment ID', 'wc-enterprise-erp' ); ?><br>
						<input type="text" name="reference" placeholder="BHKM-P-38540" style="width:160px"></label>
					<label><?php esc_html_e( 'Their payment report', 'wc-enterprise-erp' ); ?><br>
						<input type="file" name="statement" accept=".xlsx,.csv,.txt" required></label>
					<button class="button button-primary"><?php esc_html_e( 'Compare with my ERP', 'wc-enterprise-erp' ); ?></button>
				</form>
				<p class="description" style="margin:-6px 0 14px">
					<?php esc_html_e( 'Nothing is settled or posted — this only reports. It finds parcels the courier paid for that were never booked here, which is the mismatch that quietly loses money.', 'wc-enterprise-erp' ); ?>
				</p>

				<hr style="border:0;border-top:1px solid #E3E0E8;margin:14px 0">
				<p class="description"><strong><?php esc_html_e( 'Or compare totals only', 'wc-enterprise-erp' ); ?></strong></p>

				<form method="get" class="wceerp-filter">
					<input type="hidden" name="page" value="wceerp-courier">
					<input type="hidden" name="tab" value="payouts">
					<label><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?><br>
						<select name="gap_courier">
							<?php foreach ( self::drivers() as $dk => $dv ) : ?>
								<option value="<?php echo esc_attr( $dk ); ?>" <?php selected( $gap_courier, $dk ); ?>><?php echo esc_html( $dv['label'] ); ?></option>
							<?php endforeach; ?>
						</select></label>
					<label><?php esc_html_e( 'Courier says it still owes you', 'wc-enterprise-erp' ); ?><br>
						<input type="number" step="0.01" min="0" name="gap_amount"
							value="<?php echo esc_attr( $gap_amount ?: '' ); ?>"
							placeholder="<?php esc_attr_e( 'e.g. 158590', 'wc-enterprise-erp' ); ?>" style="width:170px"></label>
					<button class="button button-primary"><?php esc_html_e( 'Explain the difference', 'wc-enterprise-erp' ); ?></button>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><span class="dashicons dashicons-money-alt"></span><?php esc_html_e( 'Just record the total received', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'For when the courier has paid a lump sum and matching it parcel by parcel is not realistic. Enter what reached your account and what they deducted; the oldest outstanding parcels are settled first until the money is used up.', 'wc-enterprise-erp' ); ?>
				</p>
				<p class="description">
					<strong><?php esc_html_e( 'This closes the right amount, not necessarily the exact parcels the courier had in mind.', 'wc-enterprise-erp' ); ?></strong>
					<?php esc_html_e( 'Your receivable total ends up correct, which is what the accounts care about. Where you need parcel-exact settlement — a dispute, or an audit — import the statement above instead.', 'wc-enterprise-erp' ); ?>
				</p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-filter" style="align-items:flex-end;gap:12px">
					<?php wp_nonce_field( 'wceerp_lump_payout' ); ?>
					<input type="hidden" name="action" value="wceerp_lump_payout">
					<label><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?><br>
						<select name="courier">
							<?php foreach ( self::drivers() as $dk => $dv ) : ?>
								<option value="<?php echo esc_attr( $dk ); ?>"><?php echo esc_html( $dv['label'] ); ?></option>
							<?php endforeach; ?>
						</select></label>
					<label><?php esc_html_e( 'Reached your account', 'wc-enterprise-erp' ); ?><br>
						<input type="number" step="0.01" min="0" name="received" required style="width:130px"></label>
					<label><?php esc_html_e( 'They deducted', 'wc-enterprise-erp' ); ?><br>
						<input type="number" step="0.01" min="0" name="charges" value="0" style="width:120px"></label>
					<label><?php esc_html_e( 'Into', 'wc-enterprise-erp' ); ?><br>
						<select name="account_id" required>
							<?php foreach ( (array) $accounts as $a ) : ?>
								<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
							<?php endforeach; ?>
						</select></label>
					<label><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?><br>
						<input type="date" name="payout_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></label>
					<label><?php esc_html_e( 'Payment ID', 'wc-enterprise-erp' ); ?><br>
						<input type="text" name="reference" placeholder="BHKM-P-38540" style="width:150px"></label>
					<button class="button button-primary" onclick="return confirm('<?php echo esc_js( __( 'Record this payment and settle the oldest outstanding parcels? It can be reversed from Recent payouts if wrong.', 'wc-enterprise-erp' ) ); ?>');">
						<?php esc_html_e( 'Record payment', 'wc-enterprise-erp' ); ?>
					</button>
				</form>
			</div>

			<div class="wceerp-card" style="background:#FBFAFC">
				<h2><span class="dashicons dashicons-upload"></span><?php esc_html_e( 'Import the courier\'s payment report', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'The fastest way to settle a large remittance. Download the payment report from your courier portal as Excel or CSV and upload it here — every parcel is matched, the collected amounts and charges are read from the file, and the whole payout posts as one entry.', 'wc-enterprise-erp' ); ?>
				</p>
				<p class="description">
					<?php esc_html_e( 'Parcels are matched on the memo or reference column, which carries the consignment number printed on your label. Anything that cannot be matched is listed rather than skipped quietly.', 'wc-enterprise-erp' ); ?>
				</p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
					<?php wp_nonce_field( 'wceerp_payout_upload' ); ?>
					<input type="hidden" name="action" value="wceerp_payout_upload">
					<select name="map_courier" style="max-width:170px">
						<?php foreach ( self::drivers() as $ck => $cd ) : ?>
							<option value="<?php echo esc_attr( $ck ); ?>"><?php echo esc_html( $cd['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<input type="file" name="statement" accept=".xlsx,.csv,.txt" required>
					<button class="button button-primary"><?php esc_html_e( 'Read statement', 'wc-enterprise-erp' ); ?></button>
				</form>
				<p class="description" style="margin-top:8px">
					<?php esc_html_e( 'Every courier lays its report out differently. If the columns are not recognised you will be asked to point them out once, and that layout is remembered for that courier from then on.', 'wc-enterprise-erp' ); ?>
					<?php
					$maps = (array) get_option( 'wceerp_payout_maps', array() );
					if ( $maps ) {
						echo '<br>' . esc_html__( 'Layouts saved for:', 'wc-enterprise-erp' ) . ' ';
						$bits = array();
						foreach ( $maps as $mk => $mv ) {
							$bits[] = ucfirst( $mk );
						}
						echo esc_html( implode( ', ', $bits ) );
					}
					?>
				</p>
			</div>

			<?php
			$raw_map = isset( $_GET['mapcols'] ) ? get_transient( 'wceerp_payout_raw_' . get_current_user_id() ) : null;
			if ( $raw_map && ! empty( $raw_map['rows'] ) ) :
				$headings = WCEERP_Payout_Import::headings( $raw_map['rows'], $raw_map['header'] );
				$fields   = WCEERP_Payout_Import::fields();
				?>
				<div class="wceerp-card" style="border-left-color:#B7791F">
					<h2><span class="dashicons dashicons-editor-table"></span><?php esc_html_e( 'Tell us which column is which', 'wc-enterprise-erp' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'This courier\'s layout is not one we recognise. Point out the columns once and it will be remembered — the next statement from them imports without asking.', 'wc-enterprise-erp' ); ?>
					</p>

					<h3 style="margin-top:14px"><?php esc_html_e( 'First rows of your file', 'wc-enterprise-erp' ); ?></h3>
					<div class="wceerp-scroll" style="overflow-x:auto;border:1px solid var(--wceerp-rule,#E3E0E8);border-radius:7px">
						<table class="widefat" style="margin:0;font-size:11.5px">
							<tbody>
							<?php foreach ( array_slice( $raw_map['rows'], 0, 6, true ) as $ri => $row ) : ?>
								<tr <?php echo $ri === (int) $raw_map['header'] ? 'style="background:#F3EEF6;font-weight:600"' : ''; ?>>
									<td style="color:#8B94A1"><?php echo (int) $ri; ?></td>
									<?php foreach ( (array) $row as $cell ) : ?>
										<td><?php echo esc_html( mb_substr( (string) $cell, 0, 22 ) ); ?></td>
									<?php endforeach; ?>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px">
						<?php wp_nonce_field( 'wceerp_payout_map' ); ?>
						<input type="hidden" name="action" value="wceerp_payout_map">

						<table class="form-table"><tbody>
							<tr>
								<th><?php esc_html_e( 'Header row', 'wc-enterprise-erp' ); ?></th>
								<td>
									<input type="number" name="header_row" value="<?php echo (int) $raw_map['header']; ?>" min="0" style="width:80px">
									<span class="description"><?php esc_html_e( 'The highlighted row above. Change it if the wrong one is picked out.', 'wc-enterprise-erp' ); ?></span>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
								<td>
									<select name="courier">
										<?php foreach ( self::drivers() as $ck => $cd ) : ?>
											<option value="<?php echo esc_attr( $ck ); ?>" <?php selected( $raw_map['courier'], $ck ); ?>><?php echo esc_html( $cd['label'] ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							<?php foreach ( $fields as $fk => $meta ) : ?>
								<tr>
									<th>
										<?php echo esc_html( $meta[0] ); ?>
										<?php if ( $meta[1] ) : ?><span style="color:#C0392B">*</span><?php endif; ?>
									</th>
									<td>
										<select name="col[<?php echo esc_attr( $fk ); ?>]">
											<option value="-1"><?php esc_html_e( '— not in this file —', 'wc-enterprise-erp' ); ?></option>
											<?php foreach ( $headings as $pos => $label ) : ?>
												<option value="<?php echo (int) $pos; ?>"><?php echo esc_html( $label ); ?></option>
											<?php endforeach; ?>
										</select>
									</td>
								</tr>
							<?php endforeach; ?>
							<tr>
								<th></th>
								<td>
									<label>
										<input type="checkbox" name="remember" value="1" checked>
										<?php esc_html_e( 'Remember this layout for this courier', 'wc-enterprise-erp' ); ?>
									</label>
								</td>
							</tr>
						</tbody></table>

						<button class="button button-primary"><?php esc_html_e( 'Read the statement with these columns', 'wc-enterprise-erp' ); ?></button>
						<span class="description" style="margin-left:8px"><?php esc_html_e( 'Nothing is posted yet — you will see the totals to check first.', 'wc-enterprise-erp' ); ?></span>
					</form>
				</div>
			<?php endif; ?>

			<?php if ( $import && ! empty( $import['matched'] ) ) : ?>
				<div class="wceerp-card" style="border-left-color:#0F7B5A">
					<h2><?php esc_html_e( 'Ready to post', 'wc-enterprise-erp' ); ?></h2>

					<div class="wceerp-kpis">
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Parcels matched', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $import['totals']['count']; ?></strong></div>
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Collected', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $import['totals']['collected'] ) ); ?></strong></div>
						<div class="wceerp-kpi"><span><?php esc_html_e( 'Charges', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $import['totals']['charges'] ) ); ?></strong></div>
						<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Net to your account', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $import['totals']['net'] ) ); ?></strong></div>
					</div>

					<p class="description">
						<?php esc_html_e( 'Check the net figure against the "Received Amount" on the courier\'s slip. If they agree, the file has been read correctly.', 'wc-enterprise-erp' ); ?>
					</p>

					<?php
					$groups = $import['issues'] ?? array();
					$labels = array(
						'unmatched' => array(
							__( 'No matching parcel in the ERP', 'wc-enterprise-erp' ),
							__( 'Usually booked directly in the courier portal rather than here, so there is nothing to settle against. Settle these through Opening COD or leave them.', 'wc-enterprise-erp' ),
						),
						'duplicate' => array(
							__( 'Listed more than once in this file', 'wc-enterprise-erp' ),
							__( 'Only the first occurrence was used, so nothing is double-counted.', 'wc-enterprise-erp' ),
						),
						'settled'   => array(
							__( 'Already settled in an earlier payout', 'wc-enterprise-erp' ),
							__( 'Skipped so the same money cannot be recorded twice. If an earlier payout was wrong, reverse it first.', 'wc-enterprise-erp' ),
						),
						'no_amount' => array(
							__( 'No amount given on the row', 'wc-enterprise-erp' ),
							__( 'The collected column was blank, which is not the same as zero — a blank is not treated as a return. Check these rows in the sheet.', 'wc-enterprise-erp' ),
						),
						'over'      => array(
							__( 'More collected than was owed', 'wc-enterprise-erp' ),
							__( 'Capped at what the parcel actually owed. Often the sheet lists the order value rather than what was taken.', 'wc-enterprise-erp' ),
						),
					);

					$total_issues = 0;
					foreach ( $groups as $g ) {
						$total_issues += count( (array) $g );
					}

					if ( $total_issues ) :
						?>
						<div class="notice notice-warning inline" style="margin:12px 0">
							<p><strong><?php
								printf(
									/* translators: 1: problem rows, 2: usable rows. */
									esc_html__( '%1$d row(s) need your attention. The other %2$d were read normally and are ready to post.', 'wc-enterprise-erp' ),
									(int) $total_issues,
									(int) $import['totals']['count']
								);
							?></strong></p>

							<?php foreach ( $groups as $key => $rows ) : ?>
								<?php if ( empty( $rows ) ) { continue; } ?>
								<details style="margin:8px 0">
									<summary style="cursor:pointer;font-weight:600">
										<?php echo esc_html( $labels[ $key ][0] ?? $key ); ?>
										(<?php echo count( (array) $rows ); ?>)
									</summary>
									<p class="description" style="margin:6px 0"><?php echo esc_html( $labels[ $key ][1] ?? '' ); ?></p>
									<ul style="margin:0 0 8px 18px;list-style:disc;max-height:170px;overflow:auto;font-size:12.5px">
										<?php foreach ( array_slice( (array) $rows, 0, 80 ) as $u ) : ?>
											<li>
												<code><?php echo esc_html( $u['doc_no'] ?? ( $u['memo'] ?: $u['cid'] ) ); ?></code>
												<?php echo esc_html( ! empty( $u['name'] ) ? ' — ' . $u['name'] : '' ); ?>
												<?php if ( isset( $u['reported'] ) ) : ?>
													<em>(<?php printf(
														/* translators: 1: reported, 2: owed. */
														esc_html__( 'sheet says %1$s, owed %2$s', 'wc-enterprise-erp' ),
														esc_html( number_format( (float) $u['reported'], 2 ) ),
														esc_html( number_format( (float) $u['due'], 2 ) )
													); ?>)</em>
												<?php endif; ?>
											</li>
										<?php endforeach; ?>
										<?php if ( count( (array) $rows ) > 80 ) : ?>
											<li><em><?php printf( esc_html__( '…and %d more', 'wc-enterprise-erp' ), count( (array) $rows ) - 80 ); ?></em></li>
										<?php endif; ?>
									</ul>
								</details>
							<?php endforeach; ?>

							<p class="description">
								<?php esc_html_e( 'Nothing here blocks the import. These rows are simply left alone, so you can post the payout now and deal with them separately.', 'wc-enterprise-erp' ); ?>
							</p>
						</div>
					<?php endif; ?>

					<details style="margin:12px 0">
						<summary style="cursor:pointer;font-weight:600"><?php esc_html_e( 'Show the matched parcels', 'wc-enterprise-erp' ); ?></summary>
						<table class="widefat striped wceerp-table" style="margin-top:8px">
							<thead><tr>
								<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
								<th><?php esc_html_e( 'Recipient', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Due', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Collected', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Charge', 'wc-enterprise-erp' ); ?></th>
								<th></th>
							</tr></thead>
							<tbody>
							<?php foreach ( $import['matched'] as $m ) : ?>
								<tr>
									<td><code><?php echo esc_html( $m['doc_no'] ); ?></code></td>
									<td><?php echo esc_html( $m['recipient'] ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $m['due'] ) ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $m['collected'] ) ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( $m['charge'] ) ); ?></td>
									<td>
										<?php if ( ! empty( $m['is_return'] ) ) : ?>
											<span class="wceerp-badge wceerp-badge-warn"><?php esc_html_e( 'returned', 'wc-enterprise-erp' ); ?></span>
										<?php elseif ( abs( $m['collected'] - $m['due'] ) > 0.004 ) : ?>
											<span class="wceerp-badge wceerp-badge-warn"><?php esc_html_e( 'part paid', 'wc-enterprise-erp' ); ?></span>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</details>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'wceerp_payout_confirm' ); ?>
						<input type="hidden" name="action" value="wceerp_payout_confirm">
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
								<td><select name="courier">
									<?php foreach ( self::drivers() as $key => $drv ) : ?>
										<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $drv['label'] ); ?></option>
									<?php endforeach; ?>
								</select></td></tr>
							<tr><th><?php esc_html_e( 'Deposited into', 'wc-enterprise-erp' ); ?></th>
								<td><select name="account_id" required>
									<?php foreach ( (array) $accounts as $a ) : ?>
										<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
									<?php endforeach; ?>
								</select></td></tr>
							<tr><th><?php esc_html_e( 'Payout date', 'wc-enterprise-erp' ); ?></th>
								<td><input type="date" name="payout_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Courier payment ID', 'wc-enterprise-erp' ); ?></th>
								<td>
									<input type="text" name="reference" class="regular-text"
										value="<?php echo esc_attr( $import['payment_id'] ?? '' ); ?>"
										placeholder="<?php esc_attr_e( 'e.g. BHKM-P-38540', 'wc-enterprise-erp' ); ?>">
									<p class="description">
										<?php esc_html_e( 'Read from the statement where possible. Keep it — this is what you quote when querying a remittance, and what ties this payout to the courier\'s own record.', 'wc-enterprise-erp' ); ?>
									</p>
								</td></tr>
						</tbody></table>
						<button class="button button-primary" onclick="return confirm('<?php echo esc_js( __( 'Post this payout? The parcels will be settled and the money entered in your books.', 'wc-enterprise-erp' ) ); ?>');">
							<?php
							printf(
								/* translators: %d: parcels. */
								esc_html__( 'Post payout for %d parcels', 'wc-enterprise-erp' ),
								(int) $import['totals']['count']
							);
							?>
						</button>
					</form>
				</div>
			<?php endif; ?>

			<?php
			/* Parcels delivered a long time ago whose money almost certainly
			 * arrived before payouts were being recorded here. Surfacing
			 * them explicitly matters: they are what inflates "COD held by
			 * couriers", and they will never clear on their own. */
			$stale_days = 21;
			$stale = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$table}
				 WHERE status = 'delivered'
				   AND payout_id IS NULL
				   AND cod_amount - collected_amount > 0.004
				   AND created_at < %s
				 ORDER BY created_at ASC LIMIT 500",
				gmdate( 'Y-m-d H:i:s', strtotime( '-' . $stale_days . ' days' ) )
			) );
			$stale_total = 0;
			foreach ( (array) $stale as $sc ) {
				$stale_total += (float) $sc->cod_amount - (float) $sc->collected_amount;
			}
			?>

			<?php if ( $stale ) : ?>
			<div class="wceerp-card" style="border-left-color:#B7791F">
				<h2><span class="dashicons dashicons-backup"></span><?php esc_html_e( 'Older parcels never settled', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php
					printf(
						/* translators: 1: count, 2: amount, 3: days. */
						esc_html__( '%1$d parcels worth %2$s were booked more than %3$d days ago, are marked delivered, and still show as owing. If the courier has already paid for them, they are inflating "COD held by couriers" and will never clear by themselves.', 'wc-enterprise-erp' ),
						count( $stale ),
						wp_kses_post( wceerp_money( $stale_total ) ),
						(int) $stale_days
					);
					?>
				</p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="wceerp-recon-form">
					<?php wp_nonce_field( 'wceerp_reconcile_old' ); ?>
					<input type="hidden" name="action" value="wceerp_reconcile_old">
					<input type="hidden" name="cons_ids" id="wceerp-recon-ids" value="">

					<div style="max-height:260px;overflow:auto;border:1px solid var(--wceerp-rule,#E3E0E8);border-radius:7px;margin-bottom:12px">
						<table class="widefat striped">
							<thead><tr>
								<th style="width:26px"><input type="checkbox" id="wceerp-recon-all"></th>
								<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
								<th><?php esc_html_e( 'Booked', 'wc-enterprise-erp' ); ?></th>
								<th><?php esc_html_e( 'Recipient', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Outstanding', 'wc-enterprise-erp' ); ?></th>
							</tr></thead>
							<tbody>
							<?php foreach ( $stale as $sc ) : ?>
								<tr>
									<td><input type="checkbox" class="wceerp-recon-cb" value="<?php echo (int) $sc->id; ?>"></td>
									<td><code><?php echo esc_html( $sc->doc_no ); ?></code></td>
									<td><small><?php echo esc_html( mysql2date( 'j M Y', $sc->created_at ) ); ?></small></td>
									<td><?php echo esc_html( $sc->recipient_name ); ?></td>
									<td class="num"><?php echo wp_kses_post( wceerp_money( (float) $sc->cod_amount - (float) $sc->collected_amount ) ); ?></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<table class="form-table"><tbody>
						<tr>
							<th><?php esc_html_e( 'Where did this money go?', 'wc-enterprise-erp' ); ?></th>
							<td>
								<div class="wceerp-choices">
									<label class="wceerp-choice is-on">
										<input type="radio" name="mode" value="equity" checked>
										<span><b><?php esc_html_e( 'It arrived before my books started', 'wc-enterprise-erp' ); ?></b>
										<span class="wceerp-choice-desc"><?php esc_html_e( 'Clears the receivable against Opening Balance Equity. No new cash is recorded, because that money is already inside your opening balances.', 'wc-enterprise-erp' ); ?></span></span>
									</label>
									<label class="wceerp-choice">
										<input type="radio" name="mode" value="cash">
										<span><b><?php esc_html_e( 'It reached my bank or cash after the books started', 'wc-enterprise-erp' ); ?></b>
										<span class="wceerp-choice-desc"><?php esc_html_e( 'Posts the money into the account you choose, exactly like a normal payout.', 'wc-enterprise-erp' ); ?></span></span>
									</label>
								</div>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th>
							<td><select name="account_id">
								<option value=""><?php esc_html_e( '— only needed for the second option —', 'wc-enterprise-erp' ); ?></option>
								<?php foreach ( (array) $accounts as $a ) : ?>
									<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
								<?php endforeach; ?>
							</select></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Dated', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="on_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="note" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. settled by Bahok before ERP tracking', 'wc-enterprise-erp' ); ?>"></td>
						</tr>
					</tbody></table>

					<button class="button button-primary" onclick="return wceerpReconConfirm();">
						<?php esc_html_e( 'Reconcile selected parcels', 'wc-enterprise-erp' ); ?>
					</button>
					<span class="description" style="margin-left:8px" id="wceerp-recon-count"></span>
				</form>
			</div>

			<script>
			(function () {
				var all   = document.getElementById( 'wceerp-recon-all' );
				var boxes = function () { return Array.prototype.slice.call( document.querySelectorAll( '.wceerp-recon-cb' ) ); };
				var out   = document.getElementById( 'wceerp-recon-count' );

				function refresh() {
					var sel = boxes().filter( function ( b ) { return b.checked; } );
					out.textContent = sel.length ? sel.length + ' <?php echo esc_js( __( 'selected', 'wc-enterprise-erp' ) ); ?>' : '';
				}
				if ( all ) {
					all.addEventListener( 'change', function () {
						boxes().forEach( function ( b ) { b.checked = all.checked; } );
						refresh();
					} );
				}
				boxes().forEach( function ( b ) { b.addEventListener( 'change', refresh ); } );

				document.querySelectorAll( '#wceerp-recon-form .wceerp-choice input' ).forEach( function ( r ) {
					r.addEventListener( 'change', function () {
						document.querySelectorAll( '#wceerp-recon-form .wceerp-choice' ).forEach( function ( c ) {
							c.classList.toggle( 'is-on', c.querySelector( 'input' ).checked );
						} );
					} );
				} );

				window.wceerpReconConfirm = function () {
					var sel = boxes().filter( function ( b ) { return b.checked; } );
					if ( ! sel.length ) {
						alert( '<?php echo esc_js( __( 'Select the parcels to reconcile.', 'wc-enterprise-erp' ) ); ?>' );
						return false;
					}
					document.getElementById( 'wceerp-recon-ids' ).value = sel.map( function ( b ) { return b.value; } ).join( ',' );
					return confirm( '<?php echo esc_js( __( 'Reconcile the selected parcels? This clears them from Courier COD Receivable and cannot be undone from this screen.', 'wc-enterprise-erp' ) ); ?>' );
				};
			})();
			</script>
			<?php endif; ?>

			<?php
			$pending_sync = (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$table}
				 WHERE remote_id IS NOT NULL AND remote_id <> ''
				   AND ( status IN ('booked','in_transit')
				         OR ( status = 'delivered' AND cod_amount - collected_amount > 0.004 ) )"
			);
			?>
			<div class="wceerp-card">
				<h2><span class="dashicons dashicons-update"></span><?php esc_html_e( 'Sync everything from the courier', 'wc-enterprise-erp' ); ?></h2>
				<p class="description">
					<?php
					printf(
						/* translators: %d: parcels. */
						esc_html__( '%d parcels are still moving or delivered but unpaid. This asks the courier about each one and brings back its status and whatever it says it has collected — no files, straight from their API.', 'wc-enterprise-erp' ),
						$pending_sync
					);
					?>
				</p>
				<p class="description">
					<?php esc_html_e( 'It works in batches of 25 so a slow courier cannot time the page out, and keeps going until every parcel is current. You can leave the page — the same work continues hourly in the background.', 'wc-enterprise-erp' ); ?>
				</p>

				<p>
					<button type="button" class="button button-primary" id="wceerp-sync-all" <?php disabled( ! $pending_sync ); ?>>
						<?php esc_html_e( 'Sync all now', 'wc-enterprise-erp' ); ?>
					</button>
					<button type="button" class="button" id="wceerp-sync-stop" style="display:none"
						title="<?php esc_attr_e( 'Safe at any time — each parcel is saved as it is checked, so nothing is left half-done.', 'wc-enterprise-erp' ); ?>"><?php esc_html_e( 'Stop', 'wc-enterprise-erp' ); ?></button>
					<span class="description" style="margin-left:8px" id="wceerp-sync-status"></span>
				</p>

				<div id="wceerp-sync-bar" style="display:none;height:6px;background:#EFEDF2;border-radius:99px;overflow:hidden;max-width:420px">
					<div id="wceerp-sync-fill" style="height:100%;width:0;background:#8B5A9E;transition:width .3s"></div>
				</div>

				<?php
				/* The courier's last reply, verbatim.
				 *
				 * When a sync finds no money this is the only way to tell
				 * "the courier sent none" from "we looked for the wrong
				 * field name" — a distinction that has already cost a week
				 * here once. */
				$last_call = self::last_exchange();
				if ( $last_call && ! empty( $last_call['body'] ) ) :
					?>
					<details style="margin-top:12px">
						<summary style="cursor:pointer;font-size:12.5px;color:#5B6675">
							<?php esc_html_e( 'Show what the courier actually replied', 'wc-enterprise-erp' ); ?>
						</summary>
						<p class="description" style="margin:8px 0 4px">
							<?php
							printf(
								/* translators: 1: courier, 2: when. */
								esc_html__( '%1$s, %2$s. If you can see a collected amount in here that the system did not pick up, send this over — it means a field is named differently and can be mapped in minutes.', 'wc-enterprise-erp' ),
								esc_html( ucfirst( $last_call['courier'] ) ),
								esc_html( $last_call['at'] )
							);
							?>
						</p>
						<pre style="white-space:pre-wrap;font-size:11.5px;background:#F6F5F8;padding:10px;border-radius:6px;max-height:200px;overflow:auto"><?php
							echo esc_html( $last_call['body'] );
						?></pre>
					</details>
					<?php
				endif;
				?>

				<?php
				/* The previous run's outcome, so leaving the page and coming
				 * back still tells you whether the work finished. Hidden the
				 * moment a new run starts, or it sits there contradicting
				 * the live counter. */
				$sync_state = (array) get_option( 'wceerp_sync_state', array() );
				if ( ! empty( $sync_state['at'] ) ) :
					?>
					<p class="description" style="margin-top:10px" id="wceerp-sync-last">
						<?php
						printf(
							/* translators: 1: when, 2: checked, 3: with money, 4: left. */
							esc_html__( 'Last run %1$s — %2$d parcels checked, %3$d reported a collected amount, %4$d still unchecked.', 'wc-enterprise-erp' ),
							esc_html( mysql2date( 'j M Y H:i', $sync_state['at'] ) ),
							(int) ( $sync_state['checked'] ?? 0 ),
							(int) ( $sync_state['money'] ?? 0 ),
							(int) ( $sync_state['remaining'] ?? 0 )
						);
						?>
					</p>
				<?php endif; ?>
			</div>

			<script>
			(function () {
				var btn   = document.getElementById( 'wceerp-sync-all' );
				var stop  = document.getElementById( 'wceerp-sync-stop' );
				var out   = document.getElementById( 'wceerp-sync-status' );
				var bar   = document.getElementById( 'wceerp-sync-bar' );
				var fill  = document.getElementById( 'wceerp-sync-fill' );
				if ( ! btn ) { return; }

				var ajax  = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
				var nonce = <?php echo wp_json_encode( wp_create_nonce( 'wceerp_sync_all' ) ); ?>;
				var total = <?php echo (int) $pending_sync; ?>;
				/* One timestamp for the entire run. The server skips parcels
				 * already stamped since this moment, which is what makes the
				 * run finish. Sending nothing meant the server defaulted it
				 * to "now" on every call, so nothing was ever excluded and
				 * the same parcels came round for as long as the page stayed
				 * open. */
				var runStart = <?php echo wp_json_encode( current_time( 'mysql' ) ); ?>;
				/* Belt and braces: one pass needs total/25 rounds, so well
				 * past that means it is not progressing and should stop
				 * rather than keep hitting the courier. */
				var maxRounds = Math.max( 8, Math.ceil( total / 25 ) * 2 + 5 );
				var rounds = 0;
				var doneTotal = 0, moneyTotal = 0, cancelled = false;

				function run() {
					if ( cancelled ) { return; }
					var body = new FormData();
					rounds++;
					if ( rounds > maxRounds ) {
						out.textContent = <?php echo wp_json_encode( __( 'Stopped — the sync was not making progress. Everything checked so far is saved.', 'wc-enterprise-erp' ) ); ?>;
						finish( true );
						return;
					}

					body.append( 'action', 'wceerp_sync_batch' );
					body.append( 'nonce', nonce );
					body.append( 'since', runStart );

					fetch( ajax, { method: 'POST', body: body, credentials: 'same-origin' } )
						.then( function ( r ) { return r.json(); } )
						.then( function ( j ) {
							if ( ! j || ! j.success ) { throw new Error( 'bad response' ); }
							doneTotal  += j.data.done;
							moneyTotal += j.data.money;

							var pct = total ? Math.min( 100, Math.round( doneTotal / total * 100 ) ) : 100;
							fill.style.width = pct + '%';
							out.textContent = doneTotal + ' <?php echo esc_js( __( 'checked', 'wc-enterprise-erp' ) ); ?>, ' +
								j.data.remaining + ' <?php echo esc_js( __( 'to go', 'wc-enterprise-erp' ) ); ?>' +
								( moneyTotal ? ' · ' + moneyTotal + ' <?php echo esc_js( __( 'reported an amount', 'wc-enterprise-erp' ) ); ?>' : '' );

							/* Nothing left, or a batch that moved nothing —
							   stopping on no progress avoids looping for ever
							   when every remaining parcel is failing. */
							if ( j.data.remaining <= 0 || j.data.done === 0 ) {
								finish();
								return;
							}
							setTimeout( run, 400 );
						} )
						.catch( function () {
							out.textContent = <?php echo wp_json_encode( __( 'The sync stopped — the courier or your host refused the connection. What was already checked has been saved.', 'wc-enterprise-erp' ) ); ?>;
							finish( true );
						} );
				}

				function finish( failed ) {
					btn.disabled = false;
					stop.style.display = 'none';
					if ( ! failed ) {
						fill.style.width = '100%';
						out.textContent = doneTotal + ' <?php echo esc_js( __( 'parcels checked.', 'wc-enterprise-erp' ) ); ?>' +
							( moneyTotal
								? ' ' + moneyTotal + ' <?php echo esc_js( __( 'now show a collected amount — reload to see them.', 'wc-enterprise-erp' ) ); ?>'
								: ' <?php echo esc_js( __( 'This courier does not report collected amounts on its tracking API, so COD has to come from its payment report or its webhook instead.', 'wc-enterprise-erp' ) ); ?>' );
					}
				}

				btn.addEventListener( 'click', function () {
					var last = document.getElementById( 'wceerp-sync-last' );
					if ( last ) { last.style.display = 'none'; }
					btn.disabled = true;
					cancelled = false;
					stop.style.display = '';
					bar.style.display = '';
					out.textContent = <?php echo wp_json_encode( __( 'Asking the courier…', 'wc-enterprise-erp' ) ); ?>;
					run();
				} );

				stop.addEventListener( 'click', function () {
					cancelled = true;
					finish();
					out.textContent = <?php echo wp_json_encode( __( 'Stopped. What was checked has been saved.', 'wc-enterprise-erp' ) ); ?>;
				} );
			})();
			</script>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:12px">
				<?php wp_nonce_field( 'wceerp_cod_refresh' ); ?>
				<input type="hidden" name="action" value="wceerp_cod_refresh">
				<button class="button"><?php esc_html_e( 'Fetch collected amounts only', 'wc-enterprise-erp' ); ?></button>
				<span class="description" style="margin-left:8px">
					<?php esc_html_e( 'A single pass over 40 delivered parcels, without the full sync above.', 'wc-enterprise-erp' ); ?>
				</span>
			</form>

			<?php
			/* When a fetch returns nothing, the usual reason is that the
			 * courier names these fields differently from what we look for.
			 * Showing the raw reply makes that a two-minute fix instead of
			 * a guessing game. */
			if ( isset( $_GET['refreshed'] ) && empty( $_GET['got'] ) ) {
				$last = self::last_exchange();
				if ( $last ) {
					?>
					<div class="notice notice-warning inline" style="margin:0 0 12px">
						<p><strong><?php esc_html_e( 'No collected amounts came back.', 'wc-enterprise-erp' ); ?></strong>
						<?php esc_html_e( 'Either the courier has not paid out yet, or it reports these figures under names this plugin does not recognise. Here is the last reply in full — if you can see a collected amount in it, send me this and I will map the field.', 'wc-enterprise-erp' ); ?></p>
						<pre style="white-space:pre-wrap;font-size:11.5px;background:#fff;padding:10px;border-radius:6px;max-height:220px;overflow:auto"><?php
							echo esc_html( $last['body'] ?: __( '(empty reply)', 'wc-enterprise-erp' ) );
						?></pre>
					</div>
					<?php
				}
			}
			?>

			<?php
			$claimed = 0;
			foreach ( (array) $awaiting as $ac ) {
				if ( ! empty( $ac->remote_payment_state ) && in_array( $ac->remote_payment_state, array( 'paid', 'payment paid', 'settled' ), true ) ) {
					$claimed++;
				}
			}
			if ( $claimed ) :
				?>
				<div class="notice notice-info inline" style="margin:0 0 12px"><p>
					<?php
					printf(
						/* translators: %d: parcels. */
						esc_html__( 'Bahok reports that it has already paid for %d of these parcels. Match them against the remittance on your bank statement, then record the payout — they stay listed here until you do, because the courier saying it has paid is not the same as the money arriving.', 'wc-enterprise-erp' ),
						(int) $claimed
					);
					?>
				</p></div>
				<?php
			endif;
			?>

			<?php if ( ! $awaiting ) : ?>
				<p><?php esc_html_e( 'No delivered parcels are awaiting COD right now.', 'wc-enterprise-erp' ); ?></p>
			<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_courier_payout">
				<?php wp_nonce_field( 'wceerp_courier_payout' ); ?>

				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'CN no.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Recipient', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'COD due', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Courier says', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Collected now', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Delivery charge', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Close it', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( (array) $awaiting as $c ) :
						$due = (float) $c->cod_amount - (float) $c->collected_amount;

						/* Pre-fill from what the courier reported, capped at
						 * what is actually outstanding. Left blank when the
						 * courier has told us nothing — a guessed figure in a
						 * money field is worse than an empty one. */
						$remote            = (float) $c->remote_collected;
						/* Deliberately NOT pre-filled.
						 *
						 * Filling this in made it one click to record money
						 * that had not arrived — the courier reporting a
						 * collection is not the same as it paying you. The
						 * figure is offered beside the box instead, so using
						 * it is a decision rather than a default. */
						$suggest_collected = '';
						$offer_collected   = $remote > 0.004 ? round( min( $remote, $due ), 2 ) : 0;

						/* The courier's own charge if it gave one; otherwise
						 * an estimate from its rate card, flagged as such so
						 * nobody mistakes it for a reported figure. */
						$charge_is_estimate = false;
						if ( (float) $c->remote_charge > 0.004 ) {
							$suggest_charge = number_format( (float) $c->remote_charge, 2, '.', '' );
						} else {
							$basis = $remote > 0.004 ? min( $remote, $due ) : $due;
							$est   = self::estimate_charge( $c->courier, $basis, $c );
							if ( null !== $est && $est > 0 ) {
								$suggest_charge     = number_format( $est, 2, '.', '' );
								$charge_is_estimate = true;
							} else {
								$suggest_charge = '';
							}
						}
						?>
						<?php $focused = isset( $_GET['focus'] ) && (int) $_GET['focus'] === (int) $c->id; ?>
						<tr id="cn-<?php echo (int) $c->id; ?>" <?php echo $focused ? 'style="background:#F3EEF6;box-shadow:inset 3px 0 0 #8B5A9E"' : ''; ?>>
							<td><code><?php echo esc_html( $c->doc_no ); ?></code></td>
							<td><?php echo esc_html( ucfirst( $c->courier ) ); ?></td>
							<td><?php echo esc_html( $c->recipient_name ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $due ) ); ?></td>
							<td class="num">
								<?php if ( ! empty( $c->remote_payment_state ) && in_array( $c->remote_payment_state, array( 'paid', 'payment paid', 'settled' ), true ) ) : ?>
									<span class="wceerp-badge wceerp-badge-ok" title="<?php esc_attr_e( 'The courier says it has already paid for this parcel', 'wc-enterprise-erp' ); ?>">
										<?php esc_html_e( 'they say paid', 'wc-enterprise-erp' ); ?>
									</span><br>
								<?php endif; ?>
								<?php if ( null !== $c->remote_collected && (float) $c->remote_collected > 0.004 ) : ?>
									<?php echo wp_kses_post( wceerp_money( $c->remote_collected ) ); ?>
									<?php if ( abs( (float) $c->remote_collected - $due ) > 0.004 ) : ?>
										<span class="wceerp-sub" style="color:#B7791F"><?php esc_html_e( 'differs from due', 'wc-enterprise-erp' ); ?></span>
									<?php endif; ?>
								<?php else : ?>
									<span class="wceerp-muted">—</span>
								<?php endif; ?>
							</td>
							<td class="num">
								<input type="number" step="0.01" min="0" max="<?php echo esc_attr( $due ); ?>"
									name="collected[<?php echo (int) $c->id; ?>]"
									value="<?php echo esc_attr( $suggest_collected ); ?>"
									placeholder="0.00" style="width:110px"
									id="col-<?php echo (int) $c->id; ?>">
								<?php if ( $offer_collected > 0 ) : ?>
									<span class="wceerp-sub">
										<a href="#" onclick="document.getElementById('col-<?php echo (int) $c->id; ?>').value='<?php echo esc_js( number_format( $offer_collected, 2, '.', '' ) ); ?>';return false;">
											<?php printf( esc_html__( 'use %s', 'wc-enterprise-erp' ), esc_html( number_format( $offer_collected, 2 ) ) ); ?>
										</a>
									</span>
								<?php endif; ?>
							</td>
							<td class="num">
								<input type="number" step="0.01" min="0"
									name="charge[<?php echo (int) $c->id; ?>]"
									value="<?php echo esc_attr( $suggest_charge ); ?>"
									placeholder="0.00"
									style="width:100px<?php echo $charge_is_estimate ? ';border-color:#B7791F' : ''; ?>">
								<?php if ( $charge_is_estimate ) : ?>
									<span class="wceerp-sub" style="color:#B7791F"><?php esc_html_e( 'estimated', 'wc-enterprise-erp' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<label style="font-size:12px;white-space:nowrap">
									<input type="checkbox" name="settle[<?php echo (int) $c->id; ?>]" value="1">
									<?php esc_html_e( 'settle in full', 'wc-enterprise-erp' ); ?>
								</label>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
						<td><select name="courier">
							<?php foreach ( self::drivers() as $slug => $driver ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $driver['label'] ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Deposited into', 'wc-enterprise-erp' ); ?></th>
						<td><select name="account_id" required>
							<?php foreach ( (array) $accounts as $a ) : ?>
								<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Payout date', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="payout_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Reference / note', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="note" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. Steadfast payment ID', 'wc-enterprise-erp' ); ?>"></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Record payout & post to books', 'wc-enterprise-erp' ) ); ?>
			</form>
			<?php endif; ?>
		</div>

		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Recent payouts', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Doc no.', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Gross COD', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Charges', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Net received', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Parcels', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Courier payment ID', 'wc-enterprise-erp' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php if ( ! $payouts ) : ?>
					<tr><td colspan="9"><?php esc_html_e( 'No payouts recorded yet.', 'wc-enterprise-erp' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $payouts as $p ) : ?>
					<tr>
						<td><code><?php echo esc_html( $p->doc_no ); ?></code></td>
						<td><?php echo esc_html( $p->payout_date ); ?></td>
						<td><?php echo esc_html( ucfirst( $p->courier ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $p->gross_cod ) ); ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $p->charges ) ); ?></td>
						<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $p->net_amount ) ); ?></strong></td>
						<td class="num">
							<a href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'consignments', 'payout' => $p->id ) ) ); ?>">
								<?php echo (int) $p->parcels; ?>
							</a>
						</td>
						<td>
							<?php if ( $p->note ) : ?>
								<code><?php echo esc_html( $p->note ); ?></code>
							<?php else : ?>
								<span class="wceerp-muted">—</span>
							<?php endif; ?>
						</td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
								onsubmit="return confirm('<?php echo esc_js( __( 'Reverse this payout? Its parcels go back to owing and the money comes out of your books. Do this if it was recorded in error.', 'wc-enterprise-erp' ) ); ?>');">
								<?php wp_nonce_field( 'wceerp_payout_undo' ); ?>
								<input type="hidden" name="action" value="wceerp_payout_undo">
								<input type="hidden" name="payout_id" value="<?php echo (int) $p->id; ?>">
								<button class="button button-small button-link-delete"><?php esc_html_e( 'Reverse', 'wc-enterprise-erp' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	protected function render_opening() {
		global $wpdb;

		$total     = (float) wceerp_get_option( 'cod_opening_total', 0 );
		$journal   = (int) wceerp_get_option( 'cod_opening_journal', 0 );
		$as_of     = (string) wceerp_get_option( 'cod_opening_date', '' );
		$breakdown = (array) wceerp_get_option( 'cod_opening_breakdown', array() );
		$received  = self::opening_received();
		$remaining = max( 0, $total - $received );
		$drivers   = self::drivers();

		$start   = wceerp_start_date();
		$default = $start ? gmdate( 'Y-m-d', strtotime( $start . ' -1 day' ) ) : current_time( 'Y-m-d' );

		$accounts = $wpdb->get_results(
			'SELECT id, code, name, type, subtype FROM ' . wceerp_table( 'accounts' ) . " WHERE status = 'active' ORDER BY code"
		);
		?>
		<p class="description" style="max-width:760px">
			<?php esc_html_e( 'Parcels that shipped before your books started were never posted to the accounts, so the money still owed by couriers is invisible to the ERP. Record that total here once and it becomes a proper opening balance — then log each courier settlement below as the cash arrives.', 'wc-enterprise-erp' ); ?>
		</p>

		<?php if ( ! $journal ) : ?>

			<div class="wceerp-card" style="max-width:640px">
				<h2><?php esc_html_e( 'Record the opening balance', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_cod_opening">
					<?php wp_nonce_field( 'wceerp_cod_opening' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'As at', 'wc-enterprise-erp' ); ?></th>
							<td><input type="date" name="as_of" value="<?php echo esc_attr( $default ); ?>">
							<p class="description"><?php esc_html_e( 'Normally the day before your books start.', 'wc-enterprise-erp' ); ?></p></td></tr>
						<?php foreach ( $drivers as $slug => $d ) : ?>
							<tr><th><?php echo esc_html( sprintf( __( 'Outstanding with %s', 'wc-enterprise-erp' ), $d['label'] ?? ucfirst( $slug ) ) ); ?></th>
								<td><input type="number" step="0.01" min="0" name="amt_<?php echo esc_attr( $slug ); ?>" value="0" style="width:160px"></td></tr>
						<?php endforeach; ?>
						<tr><th><?php esc_html_e( 'Other couriers', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" step="0.01" min="0" name="amt_other" value="0" style="width:160px"></td></tr>
						<tr><th><?php esc_html_e( 'Balancing account', 'wc-enterprise-erp' ); ?></th>
							<td>
								<select name="equity_account">
									<?php foreach ( $accounts as $a ) : ?>
										<?php if ( 'equity' !== $a->type ) { continue; } ?>
										<option value="<?php echo esc_attr( $a->code ); ?>" <?php selected( '3200', $a->code ); ?>>
											<?php echo esc_html( $a->code . ' — ' . $a->name ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Opening Balance Equity is the usual choice. The entry is Dr 1110 Courier COD Receivable / Cr this account.', 'wc-enterprise-erp' ); ?></p>
							</td></tr>
					</tbody></table>
					<p class="description" style="max-width:560px">
						<strong><?php esc_html_e( 'This can only be posted once.', 'wc-enterprise-erp' ); ?></strong>
						<?php esc_html_e( 'Check your courier statements first. If you get it wrong, reverse the journal in Accounting and post a correction.', 'wc-enterprise-erp' ); ?>
					</p>
					<?php submit_button( __( 'Post opening balance', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

		<?php else : ?>

			<div class="wceerp-cards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin:16px 0;max-width:760px">
				<div class="wceerp-card"><h3 style="margin:0 0 4px"><?php esc_html_e( 'Opening COD', 'wc-enterprise-erp' ); ?></h3>
					<p style="font-size:20px;margin:0"><?php echo wp_kses_post( wceerp_money( $total ) ); ?></p>
					<small><?php echo esc_html( $as_of ); ?></small></div>
				<div class="wceerp-card"><h3 style="margin:0 0 4px"><?php esc_html_e( 'Received so far', 'wc-enterprise-erp' ); ?></h3>
					<p style="font-size:20px;margin:0"><?php echo wp_kses_post( wceerp_money( $received ) ); ?></p></div>
				<div class="wceerp-card"><h3 style="margin:0 0 4px"><?php esc_html_e( 'Still outstanding', 'wc-enterprise-erp' ); ?></h3>
					<p style="font-size:20px;margin:0"><?php echo wp_kses_post( wceerp_money( $remaining ) ); ?></p></div>
			</div>

			<?php if ( $breakdown ) : ?>
				<table class="widefat striped wceerp-table" style="max-width:420px;margin-bottom:18px">
					<thead><tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Recorded', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $breakdown as $slug => $amt ) : ?>
						<tr>
							<td><?php echo esc_html( $drivers[ $slug ]['label'] ?? ucfirst( $slug ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $amt ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<?php if ( $remaining > 0.004 ) : ?>
				<div class="wceerp-card" style="max-width:640px">
					<h2><?php esc_html_e( 'Record a legacy courier settlement', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_cod_opening_receipt">
						<?php wp_nonce_field( 'wceerp_cod_opening_receipt' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Courier', 'wc-enterprise-erp' ); ?></th>
								<td><select name="courier">
									<?php foreach ( $drivers as $slug => $d ) : ?>
										<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $d['label'] ?? ucfirst( $slug ) ); ?></option>
									<?php endforeach; ?>
									<option value="other"><?php esc_html_e( 'Other', 'wc-enterprise-erp' ); ?></option>
								</select></td></tr>
							<tr><th><?php esc_html_e( 'Date received', 'wc-enterprise-erp' ); ?></th>
								<td><input type="date" name="paid_on" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Gross COD settled', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0" max="<?php echo esc_attr( $remaining ); ?>" name="gross" required style="width:160px">
								<p class="description"><?php printf( esc_html__( 'Maximum %s — anything above that belongs to a real consignment, not the legacy balance.', 'wc-enterprise-erp' ), wp_kses_post( wceerp_money( $remaining ) ) ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Delivery charges deducted', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0" name="charges" value="0" style="width:160px"></td></tr>
							<tr><th><?php esc_html_e( 'Deposit into', 'wc-enterprise-erp' ); ?></th>
								<td><select name="deposit_account" required>
									<?php foreach ( $accounts as $a ) : ?>
										<?php if ( ! in_array( $a->subtype, array( 'cash', 'bank', 'mobile_banking' ), true ) ) { continue; } ?>
										<option value="<?php echo esc_attr( $a->code ); ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
									<?php endforeach; ?>
								</select></td></tr>
						</tbody></table>
						<p class="description"><?php esc_html_e( 'Posts Dr deposit account (net) + Dr 5600 Delivery charges / Cr 1110 Courier COD Receivable — the same entry a normal payout makes.', 'wc-enterprise-erp' ); ?></p>
						<?php submit_button( __( 'Record settlement', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>
			<?php else : ?>
				<p><strong><?php esc_html_e( 'All legacy COD has been settled. Everything from here on runs through the normal COD payouts tab.', 'wc-enterprise-erp' ); ?></strong></p>
			<?php endif; ?>

		<?php endif; ?>
		<?php
	}

	protected function render_settings() {
		$drivers      = self::drivers();
		$auto_on      = ( 'yes' === self::setting( 'auto_create', 'no' ) );
		$auto_courier = self::setting( 'auto_courier', 'steadfast' );

		/* Field definitions per courier. Keeping these in data rather than
		 * markup means adding a courier is one array entry, not a new form. */
		$cards = array(
			'steadfast' => array(
				'label'  => 'Steadfast',
				'note'   => __( 'Get these from the Steadfast merchant panel under API settings.', 'wc-enterprise-erp' ),
				'fields' => array(
					'steadfast_api_key'    => array( __( 'API key', 'wc-enterprise-erp' ), 'text', true ),
					'steadfast_secret_key' => array( __( 'Secret key', 'wc-enterprise-erp' ), 'password', true ),
				),
			),
			'pathao' => array(
				'label'  => 'Pathao Courier',
				'note'   => __( 'From Pathao Merchant → Developer API.', 'wc-enterprise-erp' ),
				'fields' => array(
					'pathao_client_id'     => array( __( 'Client ID', 'wc-enterprise-erp' ), 'text', true ),
					'pathao_client_secret' => array( __( 'Client secret', 'wc-enterprise-erp' ), 'password', true ),
					'pathao_username'      => array( __( 'Merchant email', 'wc-enterprise-erp' ), 'text', true ),
					'pathao_password'      => array( __( 'Merchant password', 'wc-enterprise-erp' ), 'password', true ),
					'pathao_store_id'      => array( __( 'Store ID', 'wc-enterprise-erp' ), 'text', false ),
				),
			),
			'bahok' => array(
				'label'  => 'Bahok Courier',
				'note'   => __( 'From merchant.bahokcourier.com → Developer API.', 'wc-enterprise-erp' ),
				'fields' => array(
					'bahok_base_url'      => array( __( 'Base URL', 'wc-enterprise-erp' ), 'text', false, 'https://api.bahokcourier.com', __( 'Leave blank to use the default.', 'wc-enterprise-erp' ) ),
					'bahok_client_id'     => array( __( 'Client ID', 'wc-enterprise-erp' ), 'text', true ),
					'bahok_client_secret' => array( __( 'Client secret', 'wc-enterprise-erp' ), 'password', true ),
					'bahok_username'      => array( __( 'Merchant ID', 'wc-enterprise-erp' ), 'text', true, 'BHKM0000' ),
					'bahok_password'      => array( __( 'Merchant password', 'wc-enterprise-erp' ), 'password', true ),
					'bahok_store_id'      => array( __( 'Store ID', 'wc-enterprise-erp' ), 'text', false, '', __( 'Only needed for delivery-charge quotes.', 'wc-enterprise-erp' ) ),
				),
			),
			'carrybee' => array(
				'label'  => 'CarryBee',
				'note'   => __( 'From the CarryBee merchant panel → API / Developer. The base URL is configurable because CarryBee has moved it before.', 'wc-enterprise-erp' ),
				'fields' => array(
					'carrybee_base_url' => array( __( 'Base URL', 'wc-enterprise-erp' ), 'text', false, 'https://api.carrybee.net', __( 'Leave blank to use the default.', 'wc-enterprise-erp' ) ),
					'carrybee_email'    => array( __( 'Account email', 'wc-enterprise-erp' ), 'text', true ),
					'carrybee_password' => array( __( 'Password', 'wc-enterprise-erp' ), 'password', true ),
					'carrybee_token'    => array( __( 'API token', 'wc-enterprise-erp' ), 'password', false, '', __( 'Optional. If your panel issues a permanent token, paste it here and leave the email and password blank.', 'wc-enterprise-erp' ) ),
					'carrybee_store_id' => array( __( 'Store ID', 'wc-enterprise-erp' ), 'text', false ),
				),
			),
			'redx' => array(
				'label'  => 'RedX',
				'note'   => __( 'Generate an access token in the RedX merchant panel under API.', 'wc-enterprise-erp' ),
				'fields' => array(
					'redx_access_token' => array( __( 'Access token', 'wc-enterprise-erp' ), 'password', true ),
					'redx_base_url'     => array( __( 'Base URL', 'wc-enterprise-erp' ), 'text', false, 'https://openapi.redx.com.bd', __( 'Leave blank to use the default.', 'wc-enterprise-erp' ) ),
				),
			),
		);
		?>
		<style>
			.wceerp-cour-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;margin:16px 0}
			.wceerp-cour{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:0;overflow:hidden}
			.wceerp-cour header{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 16px;border-bottom:1px solid #f0f0f1;background:#fbfbfc}
			.wceerp-cour header h3{margin:0;font-size:14px}
			.wceerp-cour .body{padding:14px 16px}
			.wceerp-cour .row{margin-bottom:12px}
			.wceerp-cour .row:last-child{margin-bottom:0}
			.wceerp-cour label{display:block;font-weight:600;font-size:12px;margin-bottom:4px;color:#1d2327}
			.wceerp-cour input[type=text],.wceerp-cour input[type=password]{width:100%}
			.wceerp-cour .hint{font-size:11px;color:#646970;margin:4px 0 0}
			.wceerp-pill{font-size:11px;font-weight:600;padding:2px 9px;border-radius:10px;white-space:nowrap}
			.wceerp-pill.ok{background:#edfaef;color:#00652b;border:1px solid #b8e6c4}
			.wceerp-pill.no{background:#f6f7f7;color:#646970;border:1px solid #dcdcde}
			.wceerp-cour footer{padding:10px 16px;border-top:1px solid #f0f0f1;display:flex;align-items:center;gap:10px;flex-wrap:wrap}

			/* Collapsed courier cards. The summary carries the name and the
			 * configured state, so the row is still useful shut. */
			.wceerp-cour > summary{
				list-style:none;cursor:pointer;padding:12px 16px;
				display:flex;align-items:center;justify-content:space-between;gap:10px;
			}
			.wceerp-cour > summary::-webkit-details-marker{display:none}
			.wceerp-cour > summary::after{
				content:"\203A";font-size:19px;line-height:1;color:#8B94A1;
				transform:rotate(90deg);transition:transform .15s;
			}
			.wceerp-cour[open] > summary::after{transform:rotate(-90deg)}
			.wceerp-cour > summary:hover{background:#FAF9FB}
			.wceerp-cour > summary h3{margin:0;font-size:14.5px}
			.wceerp-cour[open] > summary{border-bottom:1px solid #f0f0f1}
			.wceerp-test-out{font-size:12px;flex:1 1 100%}
			.wceerp-test-out.ok{color:#00652b}
			.wceerp-test-out.err{color:#b32d2e}
			.wceerp-req{color:#b32d2e}
		</style>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wceerp_courier_settings">
			<?php wp_nonce_field( 'wceerp_courier_settings' ); ?>

			<p class="description" style="margin-top:12px">
				<?php esc_html_e( 'Test connection checks the details currently on screen, so you can verify them before saving. Remember to save afterwards — testing alone does not store anything.', 'wc-enterprise-erp' ); ?>
			</p>

			<div class="wceerp-cour-grid">
				<?php foreach ( $cards as $slug => $card ) : ?>
					<?php
					$ready = true;
					foreach ( $card['fields'] as $key => $f ) {
						if ( ! empty( $f[2] ) && ! self::setting( $key ) ) {
							$ready = false;
							break;
						}
					}
					?>
					<?php
					/* One courier open at a time.
					 *
					 * Five providers with a dozen credential fields each is a
					 * wall of boxes where only one matters at any moment. An
					 * unconfigured courier opens by default, because that is
					 * the one you came here to fill in; a working one stays
					 * shut. */
					?>
					<details class="wceerp-cour" <?php echo $ready ? '' : 'open'; ?>>
						<summary>
							<h3><?php echo esc_html( $card['label'] ); ?></h3>
							<span class="wceerp-pill <?php echo $ready ? 'ok' : 'no'; ?>">
								<?php echo $ready ? esc_html__( 'Configured', 'wc-enterprise-erp' ) : esc_html__( 'Not configured', 'wc-enterprise-erp' ); ?>
							</span>
						</summary>
						<div class="body">
							<?php if ( ! empty( $card['note'] ) ) : ?>
								<p class="hint" style="margin-top:0;margin-bottom:12px"><?php echo esc_html( $card['note'] ); ?></p>
							<?php endif; ?>
							<?php foreach ( $card['fields'] as $key => $f ) : ?>
								<?php
								$label       = $f[0];
								$type        = $f[1];
								$required    = ! empty( $f[2] );
								$placeholder = $f[3] ?? '';
								$hint        = $f[4] ?? '';
								?>
								<div class="row">
									<label for="fld-<?php echo esc_attr( $key ); ?>">
										<?php echo esc_html( $label ); ?><?php echo $required ? ' <span class="wceerp-req">*</span>' : ''; ?>
									</label>
									<?php if ( 'checkbox' === $type ) : ?>
										<?php /* A checkbox needs `checked`, not `value`, and a
										         hidden partner so unticking actually saves —
										         an unticked box sends nothing at all. */ ?>
										<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="">
										<label class="wceerp-switch" style="margin-top:4px">
											<input
												id="fld-<?php echo esc_attr( $key ); ?>"
												type="checkbox"
												name="<?php echo esc_attr( $key ); ?>"
												value="yes"
												<?php checked( 'yes', self::setting( $key ) ); ?>>
											<span class="wceerp-track"></span>
										</label>
									<?php else : ?>
									<input
										id="fld-<?php echo esc_attr( $key ); ?>"
										type="<?php echo esc_attr( $type ); ?>"
										name="<?php echo esc_attr( $key ); ?>"
										value="<?php echo esc_attr( self::setting( $key ) ); ?>"
										placeholder="<?php echo esc_attr( $placeholder ); ?>"
										<?php echo 'password' === $type ? 'autocomplete="new-password"' : ''; ?>>
									<?php endif; ?>
									<?php if ( $hint ) : ?>
										<p class="hint"><?php echo esc_html( $hint ); ?></p>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>

							<?php if ( 'bahok' === $slug ) : ?>
								<div class="row">
									<label for="fld-bahok_webhook_token"><?php esc_html_e( 'Webhook auth token', 'wc-enterprise-erp' ); ?></label>
									<input id="fld-bahok_webhook_token" type="password" name="bahok_webhook_token"
										value="<?php echo esc_attr( self::setting( 'bahok_webhook_token' ) ); ?>" autocomplete="new-password">
									<p class="hint">
										<?php esc_html_e( 'Optional — enables real-time status updates. Set the same token in the Bahok panel along with this URL:', 'wc-enterprise-erp' ); ?>
										<br><code style="font-size:11px;word-break:break-all"><?php echo esc_html( rest_url( 'wceerp/v1/courier/bahok/webhook' ) ); ?></code>
									</p>
								</div>
							<?php endif; ?>
						</div>
						<footer>
							<button type="button" class="button wceerp-test" data-driver="<?php echo esc_attr( $slug ); ?>">
								<?php esc_html_e( 'Test connection', 'wc-enterprise-erp' ); ?>
							</button>
							<span class="wceerp-test-out" data-out="<?php echo esc_attr( $slug ); ?>"></span>
						</footer>
					</details>
				<?php endforeach; ?>
			</div>

			<div class="wceerp-card" style="max-width:720px">
				<h2><?php esc_html_e( 'Automation', 'wc-enterprise-erp' ); ?></h2>
				<table class="form-table"><tbody>
					<tr>
						<th><?php esc_html_e( 'Auto-create consignments', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="auto_create" value="yes" <?php checked( $auto_on ); ?>>
								<?php esc_html_e( 'When an online COD order reaches Processing, create a pending consignment automatically', 'wc-enterprise-erp' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Creates a pending record only — nothing is booked with the courier and no API call is made until you book it yourself. POS sales and prepaid orders are skipped, and an order that already has a consignment is never duplicated.', 'wc-enterprise-erp' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Default courier', 'wc-enterprise-erp' ); ?></th>
						<td>
							<select name="auto_courier">
								<?php foreach ( $drivers as $slug => $d ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $auto_courier, $slug ); ?>><?php echo esc_html( $d['label'] ?? ucfirst( $slug ) ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Used for auto-created and bulk-created consignments. You can change the courier when booking.', 'wc-enterprise-erp' ); ?></p>
						</td>
					</tr>
				</tbody></table>
				<?php submit_button( __( 'Save courier settings', 'wc-enterprise-erp' ) ); ?>
			</div>
		</form>

		<script>
		(function () {
			var nonce = <?php echo wp_json_encode( wp_create_nonce( 'wceerp_courier_test' ) ); ?>;
			var ajax  = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			document.querySelectorAll('.wceerp-test').forEach(function (btn) {
				btn.addEventListener('click', function () {
					var driver = btn.dataset.driver;
					var out = document.querySelector('[data-out="' + driver + '"]');
					btn.disabled = true;
					out.className = 'wceerp-test-out';
					out.textContent = <?php echo wp_json_encode( __( 'Testing…', 'wc-enterprise-erp' ) ); ?>;
					var body = new FormData();
					body.append('action', 'wceerp_courier_test');
					body.append('driver', driver);
					body.append('nonce', nonce);
					/* Test what is on screen, saved or not. */
					var card = btn.closest('.wceerp-cour');
					if (card) {
						card.querySelectorAll('input[name]').forEach(function (inp) {
							if (inp.value !== '') { body.append('fields[' + inp.name + ']', inp.value); }
						});
					}
					fetch(ajax, { method: 'POST', body: body, credentials: 'same-origin' })
						.then(function (r) { return r.json(); })
						.then(function (j) {
							var ok = j && j.success;
							out.className = 'wceerp-test-out ' + (ok ? 'ok' : 'err');
							out.textContent = (ok ? '\u2713 ' : '\u2717 ') + ((j.data && j.data.message) || 'Unknown response');
						})
						.catch(function () {
							out.className = 'wceerp-test-out err';
							out.textContent = <?php echo wp_json_encode( __( 'Request failed — check the browser console.', 'wc-enterprise-erp' ) ); ?>;
						})
						.finally(function () { btn.disabled = false; });
				});
			});
		})();
		</script>
		<?php
	}
}
