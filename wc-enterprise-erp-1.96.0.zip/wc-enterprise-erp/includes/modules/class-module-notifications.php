<?php
/**
 * Module: Notifications (low stock, dues, purchase receipts, commissions, expiring batches).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Notifications extends WCEERP_Module {

	protected $id         = 'notifications';
	protected $title      = 'Notifications';
	protected $capability = 'wceerp_view_dashboard';
	protected $tier       = 'starter';
	protected $order      = 90;

	public function __construct() {
		$this->title = __( 'Notifications', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_notifications_read', array( $this, 'handle_mark_read' ) );
		add_action( 'wceerp_daily_checks', array( $this, 'daily_checks' ) );

		if ( ! wp_next_scheduled( 'wceerp_daily_checks' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wceerp_daily_checks' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Static API used by other modules.
	 * ------------------------------------------------------------------- */

	/**
	 * Add a notification. $user_id 0 = broadcast to all ERP users.
	 */
	public static function add( $type, $title, $message = '', $link = '', $user_id = 0 ) {
		global $wpdb;

		$wpdb->insert( wceerp_table( 'notifications' ), array(
			'type'       => sanitize_key( $type ),
			'title'      => sanitize_text_field( $title ),
			'message'    => sanitize_textarea_field( $message ),
			'link'       => esc_url_raw( $link ),
			'user_id'    => (int) $user_id,
			'is_read'    => 0,
			'created_at' => current_time( 'mysql' ),
		) );

		do_action( 'wceerp_notification_added', (int) $wpdb->insert_id, $type );
		return (int) $wpdb->insert_id;
	}

	/**
	 * Unread count for the current user (their own + broadcast rows).
	 */
	public static function unread_count() {
		global $wpdb;
		$table = wceerp_table( 'notifications' );
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table WHERE is_read = 0 AND ( user_id = 0 OR user_id = %d )",
			get_current_user_id()
		) );
	}

	/* ---------------------------------------------------------------------
	 * Scheduled checks: expiring batches + overdue customer balances.
	 * ------------------------------------------------------------------- */

	public function daily_checks() {
		global $wpdb;

		// Batches expiring within 30 days that still hold stock.
		$batches = wceerp_table( 'batches' );
		$rows    = $wpdb->get_results(
			"SELECT * FROM $batches
			 WHERE exp_date IS NOT NULL AND qty > 0
			   AND exp_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND exp_date >= CURDATE()"
		);

		$already = (array) get_option( 'wceerp_notified_batches', array() );
		foreach ( (array) $rows as $batch ) {
			if ( in_array( (int) $batch->id, $already, true ) ) {
				continue;
			}
			$product = get_the_title( $batch->product_id );
			self::add(
				'batch_expiry',
				__( 'Batch expiring soon', 'wc-enterprise-erp' ),
				sprintf(
					/* translators: 1: batch no 2: product 3: date */
					__( 'Batch %1$s of %2$s expires on %3$s.', 'wc-enterprise-erp' ),
					$batch->batch_no,
					$product ? $product : ( '#' . $batch->product_id ),
					$batch->exp_date
				),
				admin_url( 'admin.php?page=wceerp-barcode&tab=batches' )
			);
			$already[] = (int) $batch->id;
		}
		update_option( 'wceerp_notified_batches', $already, false );
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function handle_mark_read() {
		$this->verify_nonce( 'wceerp_notifications_read' );
		global $wpdb;
		$table = wceerp_table( 'notifications' );
		$id    = (int) ( $_POST['notification_id'] ?? 0 );

		if ( $id ) {
			$wpdb->update( $table, array( 'is_read' => 1 ), array( 'id' => $id ) );
		} else {
			$wpdb->query( $wpdb->prepare(
				"UPDATE $table SET is_read = 1 WHERE user_id = 0 OR user_id = %d",
				get_current_user_id()
			) );
		}

		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		global $wpdb;
		$table = wceerp_table( 'notifications' );
		$per_page = 30;
		$total    = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table WHERE user_id = 0 OR user_id = %d", get_current_user_id()
		) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table WHERE user_id = 0 OR user_id = %d ORDER BY id DESC LIMIT %d OFFSET %d",
			get_current_user_id(), $per_page, wceerp_offset( $per_page )
		) );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Notifications', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( ! empty( $_GET['updated'] ) ) { $this->notice( __( 'Notifications updated.', 'wc-enterprise-erp' ) ); } ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:12px 0">
				<input type="hidden" name="action" value="wceerp_notifications_read">
				<?php wp_nonce_field( 'wceerp_notifications_read' ); ?>
				<button class="button"><?php esc_html_e( 'Mark all as read', 'wc-enterprise-erp' ); ?></button>
			</form>

			<div class="wceerp-card">
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'When', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Notification', 'wc-enterprise-erp' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No notifications yet.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $n ) : ?>
						<tr class="<?php echo $n->is_read ? '' : 'wceerp-unread'; ?>">
							<td><?php echo esc_html( mysql2date( 'j M Y H:i', $n->created_at ) ); ?></td>
							<td><span class="wceerp-badge is-<?php echo esc_attr( $n->type ); ?>"><?php echo esc_html( str_replace( '_', ' ', $n->type ) ); ?></span></td>
							<td>
								<strong><?php echo esc_html( $n->title ); ?></strong>
								<?php if ( $n->message ) : ?><br><span class="description"><?php echo esc_html( $n->message ); ?></span><?php endif; ?>
								<?php if ( $n->link ) : ?> — <a href="<?php echo esc_url( $n->link ); ?>"><?php esc_html_e( 'View', 'wc-enterprise-erp' ); ?></a><?php endif; ?>
							</td>
							<td>
								<?php if ( ! $n->is_read ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="wceerp_notifications_read">
									<input type="hidden" name="notification_id" value="<?php echo (int) $n->id; ?>">
									<?php wp_nonce_field( 'wceerp_notifications_read' ); ?>
									<button class="button button-small"><?php esc_html_e( 'Mark read', 'wc-enterprise-erp' ); ?></button>
								</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php wceerp_pagination( $total, $per_page ); ?>
			</div>
		</div>
		<?php
	}
}
