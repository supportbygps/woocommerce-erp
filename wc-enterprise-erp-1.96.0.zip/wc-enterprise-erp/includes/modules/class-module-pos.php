<?php
/**
 * Module: Offline POS.
 *
 * The terminal lives at  yourshop.com/wceerp-pos  — a standalone,
 * full-screen, touch-friendly page (no wp-admin chrome).
 *
 * Offline strategy (honest about what browsers allow):
 *  - A service worker at /wceerp-pos/sw.js caches the app shell, so the
 *    terminal reopens with no internet.
 *  - The product catalog is cached in IndexedDB and refreshed whenever
 *    online.
 *  - Every sale gets a client UUID and is queued in IndexedDB first,
 *    then synced to POST /wceerp/v1/pos/sale — the endpoint is
 *    idempotent on the UUID, so retries can never double-post.
 *  - Sync requires the WordPress login cookie to still be valid; the
 *    queue survives in IndexedDB until it is.
 *
 * Money truth:
 *  - Each synced sale becomes a REAL WooCommerce order (status
 *    completed), so stock, COGS, VAT and the sales journal flow through
 *    the same bridge as web orders. Payment methods map to the right
 *    ledger account (pos_bkash → 1020, etc.).
 *  - Shifts: opening float, expected vs counted cash on close; any
 *    difference posts as an over/short journal (5900 / 4100).
 *
 * Hardware, honestly: USB barcode scanners work out of the box (they
 * type + Enter). Receipts print via the browser on 80 mm paper; cash
 * drawers connected through a receipt printer open on print when the
 * printer driver's "kick drawer" option is on. Networked ESC/POS
 * printing and kitchen printers are roadmap items — browsers cannot
 * talk to them directly without a local agent.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_POS extends WCEERP_Module {

	protected $id         = 'pos';
	protected $title      = 'POS';
	protected $capability = 'wceerp_use_pos';
	protected $tier       = 'starter';
	protected $order      = 8;

	public function __construct() {
		$this->title = __( 'POS', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'init', array( $this, 'add_routes' ) );
		add_filter( 'query_vars', array( $this, 'add_query_var' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render_terminal' ), 5 );
		add_action( 'rest_api_init', array( $this, 'register_rest' ) );
		add_action( 'admin_post_wceerp_pos_settings', array( $this, 'handle_settings' ) );
	}

	/* ---------------------------------------------------------------------
	 * Front-end routes.
	 * ------------------------------------------------------------------- */

	public function add_query_var( $vars ) {
		$vars[] = 'wceerp_pos';
		return $vars;
	}

	public function add_routes() {
		add_rewrite_rule( '^wceerp-pos/sw\.js$', 'index.php?wceerp_pos=sw', 'top' );
		add_rewrite_rule( '^wceerp-pos/?$', 'index.php?wceerp_pos=app', 'top' );

		/* Self-heal: if our rule isn't in the compiled rewrite table
		 * (module was enabled/licensed after the last permalink flush),
		 * flush once. A one-time option guard stops it flushing forever. */
		$rules = get_option( 'rewrite_rules' );
		if ( is_array( $rules ) && ! isset( $rules['^wceerp-pos/?$'] ) ) {
			if ( 'done' !== get_option( 'wceerp_pos_flushed' ) ) {
				flush_rewrite_rules( false );
				update_option( 'wceerp_pos_flushed', 'done' );
			}
		}
	}

	public function maybe_render_terminal() {
		$route = get_query_var( 'wceerp_pos' );
		if ( ! $route ) {
			return;
		}
		if ( 'sw' === $route ) {
			$this->render_service_worker();
		}
		// The terminal is a front-end route, so it must honour the licence
		// lock independently of the admin gate — otherwise it would be an
		// open back door into a locked install.
		if ( class_exists( 'WCEERP_License' ) && WCEERP_License::is_locked() ) {
			wp_die(
				esc_html( WCEERP_License::lock_reason() . ' ' . __( 'Activate the licence in WordPress admin to use the POS.', 'wc-enterprise-erp' ) ),
				esc_html__( 'Licence required', 'wc-enterprise-erp' ),
				array( 'response' => 403 )
			);
		}
		if ( ! is_user_logged_in() || ! wceerp_user_can( $this->capability ) ) {
			wp_safe_redirect( wp_login_url( home_url( '/wceerp-pos' ) ) );
			exit;
		}
		$this->render_terminal();
	}

	protected function render_service_worker() {
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /wceerp-pos/' );
		?>
const SHELL = 'wceerp-pos-shell-v<?php echo esc_js( WCEERP_VERSION ); ?>';
self.addEventListener('install', function (e) {
	e.waitUntil(caches.open(SHELL).then(function (c) { return c.add('/wceerp-pos/'); }).then(function(){ return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
	e.waitUntil(caches.keys().then(function (keys) {
		return Promise.all(keys.filter(function (k) { return k !== SHELL; }).map(function (k) { return caches.delete(k); }));
	}).then(function(){ return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
	var url = new URL(e.request.url);
	if (e.request.mode === 'navigate' && url.pathname.replace(/\/$/, '') === '/wceerp-pos') {
		e.respondWith(fetch(e.request).then(function (r) {
			var copy = r.clone();
			caches.open(SHELL).then(function (c) { c.put('/wceerp-pos/', copy); });
			return r;
		}).catch(function () { return caches.match('/wceerp-pos/'); }));
	}
});
		<?php
		exit;
	}

	/* ---------------------------------------------------------------------
	 * REST — catalog, shifts, sales (all idempotent where it matters).
	 * ------------------------------------------------------------------- */

	public function register_rest() {
		$guard = function () {
			if ( ! is_user_logged_in() || ! wceerp_user_can( 'wceerp_use_pos' ) ) {
				return new WP_Error( 'wceerp_forbidden', __( 'POS permission required.', 'wc-enterprise-erp' ), array( 'status' => rest_authorization_required_code() ) );
			}
			return true;
		};
		register_rest_route( 'wceerp/v1', '/pos/catalog', array(
			'methods' => 'GET', 'callback' => array( $this, 'rest_catalog' ), 'permission_callback' => $guard,
		) );
		register_rest_route( 'wceerp/v1', '/pos/sale', array(
			'methods' => 'POST', 'callback' => array( $this, 'rest_sale' ), 'permission_callback' => $guard,
		) );
		register_rest_route( 'wceerp/v1', '/pos/shift', array(
			'methods' => 'POST', 'callback' => array( $this, 'rest_shift' ), 'permission_callback' => $guard,
		) );
		register_rest_route( 'wceerp/v1', '/pos/customers', array(
			'methods' => 'GET', 'callback' => array( $this, 'rest_customers' ), 'permission_callback' => $guard,
		) );
		register_rest_route( 'wceerp/v1', '/pos/order/(?P<id>\\d+)', array(
			'methods' => 'GET', 'callback' => array( $this, 'rest_order_lookup' ), 'permission_callback' => $guard,
		) );
		register_rest_route( 'wceerp/v1', '/pos/refund', array(
			'methods' => 'POST', 'callback' => array( $this, 'rest_refund' ), 'permission_callback' => $guard,
		) );
	}

	public function rest_catalog( WP_REST_Request $request ) {
		$page  = max( 1, (int) $request->get_param( 'page' ) );
		/* Variations are what actually sell.
		 *
		 * Restricting this to simple products meant a variable product —
		 * "Ghee 500g / 1kg" — was missing from the counter entirely, because
		 * the parent is a container and the variations were never asked for.
		 * Both types are fetched and the parent of a variable product is
		 * dropped, since it has no price or stock of its own. */
		$query = new WC_Product_Query( array(
			'limit'   => 200,
			'page'    => $page,
			'status'  => 'publish',
			'orderby' => 'title',
			'order'   => 'ASC',
			'type'    => array( 'simple', 'variable' ),
		) );

		$products = array();
		foreach ( $query->get_products() as $product ) {
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $child_id ) {
					$child = wc_get_product( $child_id );
					if ( $child && $child->exists() && 'publish' === $child->get_status() ) {
						$products[] = $child;
					}
				}
				continue; // the parent itself is never sellable
			}
			$products[] = $product;
		}
		$out      = array();
		$has_tier = class_exists( 'WCEERP_Module_Dealers' );
		foreach ( $products as $product ) {
			/* A variation's own name is the parent's, so without the
			 * attributes every size of the same product looks identical on
			 * the tile grid. */
			$name = $product->get_name();
			if ( $product->is_type( 'variation' ) ) {
				$bits = array();
				foreach ( (array) $product->get_attributes() as $value ) {
					if ( '' !== $value ) {
						$bits[] = $value;
					}
				}
				if ( $bits ) {
					$name .= ' — ' . implode( ', ', $bits );
				}
			}

			$row = array(
				'id'    => $product->get_id(),
				'name'  => $name,
				'sku'   => (string) $product->get_sku(),
				'price' => (float) wc_get_price_including_tax( $product ),
			);
			/* Fixed per-product dealer/wholesale prices travel with the
			 * catalogue so the terminal can re-price the cart when a trade
			 * buyer is selected, without a second round trip. The group
			 * discount % is customer-specific and comes from /pos/customers. */
			if ( $has_tier ) {
				$tiers = array();
				foreach ( array_keys( WCEERP_Module_Dealers::tiers() ) as $tier ) {
					$fixed = WCEERP_Module_Dealers::product_tier_price( $product->get_id(), $tier );
					if ( null !== $fixed && $fixed > 0 ) {
						$tiers[ $tier ] = (float) $fixed;
					}
				}
				if ( $tiers ) {
					$row['tiers'] = $tiers;
				}
			}
			$out[] = $row;
		}
		return array( 'page' => $page, 'count' => count( $out ), 'more' => count( $out ) === 200, 'products' => $out );
	}

	/**
	 * Open or close a shift. Idempotent on the client-side UUID.
	 * Close posts an over/short journal for any cash difference.
	 */
	public function rest_shift( WP_REST_Request $request ) {
		global $wpdb;
		$table = wceerp_table( 'pos_shifts' );
		$do    = sanitize_key( (string) $request->get_param( 'do' ) );
		$uuid  = substr( sanitize_text_field( (string) $request->get_param( 'uuid' ) ), 0, 40 );
		if ( ! $uuid ) {
			return new WP_Error( 'wceerp_bad_request', 'uuid required', array( 'status' => 400 ) );
		}
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE uuid=%s", $uuid ) );

		if ( 'open' === $do ) {
			if ( $existing ) {
				return array( 'ok' => true, 'shift_id' => (int) $existing->id, 'duplicate' => true );
			}
			$wpdb->insert( $table, array(
				'uuid'          => $uuid,
				'user_id'       => get_current_user_id(),
				'warehouse_id'  => (int) wceerp_get_option( 'pos_warehouse_id', 0 ),
				'opened_at'     => current_time( 'mysql' ),
				'opening_float' => wceerp_dec( $request->get_param( 'opening_float' ) ),
				'status'        => 'open',
			) );
			wceerp_log( 'pos', 'shift_open', (int) $wpdb->insert_id );
			return array( 'ok' => true, 'shift_id' => (int) $wpdb->insert_id );
		}

		if ( 'close' === $do ) {
			if ( ! $existing ) {
				return new WP_Error( 'wceerp_not_found', 'shift unknown — sync the open event first', array( 'status' => 409 ) );
			}
			if ( 'closed' === $existing->status ) {
				return array( 'ok' => true, 'duplicate' => true );
			}
			$counted  = wceerp_dec( $request->get_param( 'counted_cash' ) );
			$cash     = (float) $wpdb->get_var( $wpdb->prepare(
				'SELECT COALESCE(SUM(total),0) FROM ' . wceerp_table( 'pos_sales' ) . " WHERE shift_uuid=%s AND pay_method='cash'", $uuid
			) );
			$cash_refunds = (float) $wpdb->get_var( $wpdb->prepare(
				'SELECT COALESCE(SUM(total),0) FROM ' . wceerp_table( 'pos_refunds' ) . " WHERE shift_uuid=%s AND pay_method='cash'", $uuid
			) );
			$expected = (float) $existing->opening_float + $cash - $cash_refunds;
			$diff     = $counted - $expected;

			$wpdb->update( $table, array(
				'closed_at'     => current_time( 'mysql' ),
				'expected_cash' => $expected,
				'counted_cash'  => $counted,
				'note'          => sanitize_text_field( (string) $request->get_param( 'note' ) ),
				'status'        => 'closed',
			), array( 'id' => $existing->id ) );

			/* Cash over/short: real money differences belong in the books. */
			if ( abs( $diff ) > 0.99 ) {
				$lines = $diff < 0
					? array(
						array( 'account' => '5900', 'debit' => -$diff, 'memo' => 'POS cash short — shift #' . $existing->id ),
						array( 'account' => '1000', 'credit' => -$diff ),
					)
					: array(
						array( 'account' => '1000', 'debit' => $diff ),
						array( 'account' => '4100', 'credit' => $diff, 'memo' => 'POS cash over — shift #' . $existing->id ),
					);
				WCEERP_Accounting::post( array(
					'ref_type' => 'pos_shift',
					'ref_id'   => (int) $existing->id,
					'memo'     => 'POS shift close over/short',
				), $lines );
			}
			wceerp_log( 'pos', 'shift_close', (int) $existing->id, 'diff ' . $diff );
			return array( 'ok' => true, 'expected' => $expected, 'difference' => round( $diff, 2 ) );
		}
		return new WP_Error( 'wceerp_bad_request', 'do must be open|close', array( 'status' => 400 ) );
	}

	/**
	 * Sync one sale. Idempotent: the same UUID always returns the same
	 * order. Creates a genuine WooCommerce order so the ERP bridge does
	 * stock, COGS, VAT and the journal exactly as for a web order.
	 */
	public function rest_sale( WP_REST_Request $request ) {
		/* Thin adapter: HTTP in, service out. The logic lives in
		 * WCEERP_POS_Service so the public API calls exactly the same code. */
		$result = WCEERP_POS_Service::create_sale( array(
			'uuid'              => $request->get_param( 'uuid' ),
			'items'             => $request->get_param( 'items' ),
			'discount'          => $request->get_param( 'discount' ),
			'received'          => $request->get_param( 'received' ),
			'pay_method'        => $request->get_param( 'pay_method' ),
			'customer_id'       => $request->get_param( 'customer_id' ),
			'customer_name'     => $request->get_param( 'customer_name' ),
			'customer_address'  => $request->get_param( 'customer_address' ),
			'shipping'          => $request->get_param( 'shipping' ),
			'shipping_label'    => $request->get_param( 'shipping_label' ),
			'customer_phone'    => $request->get_param( 'customer_phone' ),
			'tier'              => $request->get_param( 'tier' ),
			'shift_uuid'        => $request->get_param( 'shift_uuid' ),
			'sold_at'           => $request->get_param( 'sold_at' ),
			'exchange_ref'      => $request->get_param( 'exchange_ref' ),
			'exchange_order_id' => $request->get_param( 'exchange_order_id' ),
		) );
		return $result;
	}

	public function rest_customers( WP_REST_Request $request ) {
		global $wpdb;
		$q = sanitize_text_field( (string) $request->get_param( 'q' ) );
		if ( strlen( $q ) < 2 ) {
			return array();
		}
		$like = '%' . $wpdb->esc_like( $q ) . '%';
		$ids  = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT u.ID FROM {$wpdb->users} u
			 LEFT JOIN {$wpdb->usermeta} m ON m.user_id = u.ID AND m.meta_key IN ('billing_phone','first_name','last_name')
			 WHERE u.display_name LIKE %s OR u.user_email LIKE %s OR m.meta_value LIKE %s
			 LIMIT 10",
			$like, $like, $like
		) );
		$out = array();
		foreach ( $ids as $id ) {
			$user  = get_userdata( $id );
			if ( ! $user ) {
				continue;
			}
			$tier     = class_exists( 'WCEERP_Module_Dealers' ) ? WCEERP_Module_Dealers::tier_for_user( $id ) : '';
			$dealer   = ( $tier && class_exists( 'WCEERP_Module_Dealers' ) ) ? WCEERP_Module_Dealers::by_user( $id ) : null;
			$out[] = array(
				'tier'         => $tier,
				'tier_label'   => $tier ? ( WCEERP_Module_Dealers::tiers()[ $tier ] ?? $tier ) : '',
				'discount_pct' => $dealer ? (float) $dealer->discount_pct : 0,
				'id'    => (int) $id,
				'name'  => $user->display_name,
				'phone' => (string) get_user_meta( $id, 'billing_phone', true ),
				'email' => $user->user_email,
			);
		}
		return $out;
	}

	/**
	 * Look up a POS/web order for the returns screen: each line with how
	 * much quantity is still refundable.
	 */
	public function rest_order_lookup( WP_REST_Request $request ) {
		$order = wc_get_order( (int) $request['id'] );
		if ( ! $order ) {
			return new WP_Error( 'wceerp_not_found', __( 'Order not found.', 'wc-enterprise-erp' ), array( 'status' => 404 ) );
		}
		$items = array();
		foreach ( $order->get_items() as $item_id => $item ) {
			$qty          = (float) $item->get_quantity();
			$already_back = abs( (float) $order->get_qty_refunded_for_item( $item_id ) );
			$refundable   = max( 0, $qty - $already_back );
			$unit         = $qty > 0 ? round( (float) $item->get_total() / $qty, 2 ) : 0;
			$items[]      = array(
				'item_id'    => (int) $item_id,
				'product_id' => (int) ( $item->get_variation_id() ?: $item->get_product_id() ),
				'name'       => $item->get_name(),
				'qty'        => $qty,
				'refundable' => $refundable,
				'unit_price' => $unit,
			);
		}
		return array(
			'order_id' => $order->get_id(),
			'number'   => $order->get_order_number(),
			'date'     => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i' ) : '',
			'total'    => (float) $order->get_total(),
			'refunded' => (float) $order->get_total_refunded(),
			'gateway'  => $order->get_payment_method(),
			'items'    => $items,
		);
	}

	/**
	 * POS return. Idempotent on the client UUID. Does three things that
	 * must all agree:
	 *  1. A real WooCommerce refund (partial or full, WC stock restocked).
	 *  2. ERP stock back into the POS warehouse at current average cost.
	 *  3. Reversal journal: Dr Sales / Cr money account for the refund,
	 *     plus Dr Inventory / Cr COGS for the goods coming back.
	 * Cost note: goods return at TODAY'S average cost — the honest
	 * approximation a moving-average system can make.
	 */
	public function rest_refund( WP_REST_Request $request ) {
		global $wpdb;
		$refunds = wceerp_table( 'pos_refunds' );

		$uuid = substr( sanitize_text_field( (string) $request->get_param( 'uuid' ) ), 0, 40 );
		if ( ! $uuid ) {
			return new WP_Error( 'wceerp_bad_request', 'uuid required', array( 'status' => 400 ) );
		}
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $refunds WHERE uuid=%s", $uuid ) );
		if ( $existing ) {
			return array( 'ok' => true, 'refund_id' => (int) $existing->refund_id, 'duplicate' => true );
		}

		$order = wc_get_order( (int) $request->get_param( 'order_id' ) );
		if ( ! $order ) {
			return new WP_Error( 'wceerp_not_found', __( 'Order not found.', 'wc-enterprise-erp' ), array( 'status' => 404 ) );
		}
		$lines  = (array) $request->get_param( 'lines' ); // item_id => qty.
		$method = sanitize_key( (string) ( $request->get_param( 'pay_method' ) ?: 'cash' ) );

		$amount     = 0;
		$line_items = array();
		$restock    = array(); // product_id => [ qty, value ].
		foreach ( $order->get_items() as $item_id => $item ) {
			$want = wceerp_dec( $lines[ $item_id ] ?? 0 );
			if ( $want <= 0 ) {
				continue;
			}
			$qty        = (float) $item->get_quantity();
			$refundable = max( 0, $qty - abs( (float) $order->get_qty_refunded_for_item( $item_id ) ) );
			$want       = min( $want, $refundable );
			if ( $want <= 0 ) {
				continue;
			}
			$unit   = $qty > 0 ? (float) $item->get_total() / $qty : 0;
			$value  = round( $unit * $want, 2 );
			$amount += $value;
			$line_items[ $item_id ] = array( 'qty' => $want, 'refund_total' => $value );
			$product_id = (int) ( $item->get_variation_id() ?: $item->get_product_id() );
			if ( $product_id ) {
				$restock[ $product_id ] = ( $restock[ $product_id ] ?? 0 ) + $want;
			}
		}
		if ( $amount <= 0.004 ) {
			return new WP_Error( 'wceerp_bad_request', __( 'Nothing refundable in those lines.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		$exchange_ref = substr( sanitize_text_field( (string) $request->get_param( 'exchange_ref' ) ), 0, 40 );
		$refund = wc_create_refund( array(
			'order_id'       => $order->get_id(),
			'amount'         => $amount,
			'reason'         => $exchange_ref
				? sprintf( __( 'POS exchange %s', 'wc-enterprise-erp' ), $exchange_ref )
				: __( 'POS return', 'wc-enterprise-erp' ),
			'line_items'     => $line_items,
			'restock_items'  => true,
			'refund_payment' => false,
		) );
		if ( is_wp_error( $refund ) ) {
			return $refund;
		}

		/* ERP stock back in + COGS reversal at current average cost. */
		$warehouse  = (int) wceerp_get_option( 'pos_warehouse_id', 0 );
		if ( ! $warehouse ) {
			$warehouse = (int) $wpdb->get_var( 'SELECT id FROM ' . wceerp_table( 'warehouses' ) . ' ORDER BY is_default DESC, id LIMIT 1' );
		}
		$cost_total = 0;
		foreach ( $restock as $product_id => $qty ) {
			$avg = (float) $wpdb->get_var( $wpdb->prepare(
				'SELECT avg_cost FROM ' . wceerp_table( 'stock' ) . ' WHERE product_id=%d AND warehouse_id=%d', $product_id, $warehouse
			) );
			WCEERP_Module_Inventory::move_stock( $product_id, $warehouse, $qty, 'in', 'pos_refund', $order->get_id(), $avg, null, 'POS return' );
			$cost_total += round( $avg * $qty, 2 );
		}

		$money = WCEERP_WC_Bridge::map_gateway_account( 'pos_' . $method, WCEERP_Accounting::account_by_subtype( 'cash' ) );
		$journal_lines = array(
			array( 'account' => '4000', 'debit' => $amount, 'memo' => 'POS return — order #' . $order->get_id() ),
			array( 'account' => $money, 'credit' => $amount, 'memo' => 'Refund paid — ' . strtoupper( $method ) ),
		);
		if ( $cost_total > 0.004 ) {
			$journal_lines[] = array( 'account' => '1200', 'debit' => $cost_total, 'memo' => 'Goods returned to stock' );
			$journal_lines[] = array( 'account' => '5000', 'credit' => $cost_total, 'memo' => 'COGS reversed' );
		}
		$journal = WCEERP_Accounting::post( array(
			'ref_type' => 'pos_refund',
			'ref_id'   => (int) $refund->get_id(),
			'memo'     => sprintf( 'POS return — order #%d', $order->get_id() ),
		), $journal_lines );

		$wpdb->insert( $refunds, array(
			'uuid'       => $uuid,
			'shift_uuid' => substr( sanitize_text_field( (string) $request->get_param( 'shift_uuid' ) ), 0, 40 ),
			'order_id'   => $order->get_id(),
			'refund_id'  => (int) $refund->get_id(),
			'user_id'    => get_current_user_id(),
			'total'      => $amount,
			'pay_method' => $method,
			'journal_id' => is_wp_error( $journal ) ? null : (int) $journal,
			'created_at' => current_time( 'mysql' ),
		) );

		wceerp_log( 'pos', 'refund', $order->get_id(), $uuid . ' ' . $amount );
		return array( 'ok' => true, 'refund_id' => (int) $refund->get_id(), 'amount' => round( $amount, 2 ) );
	}

	/* ---------------------------------------------------------------------
	 * Admin screen: settings + shift history.
	 * ------------------------------------------------------------------- */

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_pos_settings' );
		wceerp_update_option( 'pos_warehouse_id', (int) ( $_POST['warehouse_id'] ?? 0 ) );
		wceerp_update_option( 'pos_receipt_footer', sanitize_text_field( wp_unslash( $_POST['receipt_footer'] ?? '' ) ) );
		wceerp_update_option( 'pos_paper', in_array( $_POST['paper'] ?? '', array( '80', 'a4', 'ask' ), true ) ? $_POST['paper'] : '80' );
		wceerp_update_option( 'pos_invoice_address', sanitize_textarea_field( wp_unslash( $_POST['invoice_address'] ?? '' ) ) );
		wceerp_update_option( 'pos_invoice_bin', sanitize_text_field( wp_unslash( $_POST['invoice_bin'] ?? '' ) ) );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		global $wpdb;
		if ( ! empty( $_GET['updated'] ) ) {
			$this->notice( __( 'Saved.', 'wc-enterprise-erp' ) );
		}
		$warehouses = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'warehouses' ) . ' ORDER BY is_default DESC, name' );
		$shifts     = $wpdb->get_results( 'SELECT s.*, (SELECT COALESCE(SUM(total),0) FROM ' . wceerp_table( 'pos_sales' ) . ' x WHERE x.shift_uuid = s.uuid) AS sales_total, (SELECT COALESCE(SUM(total),0) FROM ' . wceerp_table( 'pos_refunds' ) . ' r WHERE r.shift_uuid = s.uuid) AS refund_total FROM ' . wceerp_table( 'pos_shifts' ) . ' s ORDER BY s.id DESC LIMIT 20' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php esc_html_e( 'POS', 'wc-enterprise-erp' ); ?>
				<a href="<?php echo esc_url( home_url( '/wceerp-pos' ) ); ?>" target="_blank" class="page-title-action"><?php esc_html_e( 'Open the POS terminal ↗', 'wc-enterprise-erp' ); ?></a></h1>
			<p class="description"><?php esc_html_e( 'The terminal is a full-screen page that works offline once loaded: sales queue on the device and sync automatically as real WooCommerce orders. USB barcode scanners work out of the box; receipts print on 80 mm paper via the browser.', 'wc-enterprise-erp' ); ?></p>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Settings', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_pos_settings">
						<?php wp_nonce_field( 'wceerp_pos_settings' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'POS warehouse', 'wc-enterprise-erp' ); ?></th>
								<td><select name="warehouse_id">
									<?php foreach ( $warehouses as $warehouse ) : ?>
										<option value="<?php echo (int) $warehouse->id; ?>" <?php selected( (int) wceerp_get_option( 'pos_warehouse_id', 0 ), (int) $warehouse->id ); ?>><?php echo esc_html( $warehouse->name ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Stock for POS sales moves out of this warehouse.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Receipt footer', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="receipt_footer" class="regular-text" value="<?php echo esc_attr( wceerp_get_option( 'pos_receipt_footer', __( 'Thank you — please come again!', 'wc-enterprise-erp' ) ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Print size after sale', 'wc-enterprise-erp' ); ?></th>
								<td><select name="paper">
									<option value="80" <?php selected( wceerp_get_option( 'pos_paper', '80' ), '80' ); ?>><?php esc_html_e( '80mm thermal receipt', 'wc-enterprise-erp' ); ?></option>
									<option value="a4" <?php selected( wceerp_get_option( 'pos_paper', '80' ), 'a4' ); ?>><?php esc_html_e( 'A4 invoice', 'wc-enterprise-erp' ); ?></option>
									<option value="ask" <?php selected( wceerp_get_option( 'pos_paper', '80' ), 'ask' ); ?>><?php esc_html_e( 'Ask every time', 'wc-enterprise-erp' ); ?></option>
								</select>
								<p class="description"><?php esc_html_e( 'Returns, exchanges and X/Z reports always print 80mm. Pick the matching printer in the browser print dialog.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Invoice address block (A4)', 'wc-enterprise-erp' ); ?></th>
								<td><textarea name="invoice_address" rows="3" class="regular-text" placeholder="<?php esc_attr_e( 'Shop address, phone, email…', 'wc-enterprise-erp' ); ?>"><?php echo esc_textarea( wceerp_get_option( 'pos_invoice_address', '' ) ); ?></textarea></td></tr>
							<tr><th><?php esc_html_e( 'BIN / VAT reg. no (A4)', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="invoice_bin" value="<?php echo esc_attr( wceerp_get_option( 'pos_invoice_bin', '' ) ); ?>"></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Save POS settings', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Recent shifts', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped wceerp-table">
						<thead><tr>
							<th><?php esc_html_e( 'Opened', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Cashier', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Sales', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Refunds', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Expected cash', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Counted', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
						</tr></thead>
						<tbody>
						<?php if ( ! $shifts ) : ?>
							<tr><td colspan="7"><?php esc_html_e( 'No shifts yet — open one from the terminal.', 'wc-enterprise-erp' ); ?></td></tr>
						<?php endif; ?>
						<?php foreach ( (array) $shifts as $shift ) :
							$cashier = get_userdata( $shift->user_id );
							?>
							<tr>
								<td><?php echo esc_html( $shift->opened_at ); ?></td>
								<td><?php echo esc_html( $cashier ? $cashier->display_name : '#' . $shift->user_id ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $shift->sales_total ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $shift->refund_total ) ); ?></td>
								<td class="num"><?php echo 'closed' === $shift->status ? wp_kses_post( wceerp_money( $shift->expected_cash ) ) : '—'; ?></td>
								<td class="num"><?php echo null !== $shift->counted_cash ? wp_kses_post( wceerp_money( $shift->counted_cash ) ) : '—'; ?></td>
								<td><span class="wceerp-badge is-<?php echo esc_attr( 'open' === $shift->status ? 'open' : 'completed' ); ?>"><?php echo esc_html( $shift->status ); ?></span></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p class="description"><?php esc_html_e( 'Cash over/short on close posts automatically to Misc Expense / Other Income, so the drawer and the books always reconcile.', 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * The terminal itself — one self-contained page.
	 * ------------------------------------------------------------------- */

	protected function render_terminal() {
		$user   = wp_get_current_user();
		$footer = wceerp_get_option( 'pos_receipt_footer', 'Thank you — please come again!' );
		$shop   = wceerp_get_option( 'company_name', get_bloginfo( 'name' ) );
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>POS — <?php echo esc_html( $shop ); ?></title>
<style>
:root{--g:#075742;--r:#c8302e;--bg:#f2f0e8;--ink:#1e2a26}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{font:15px/1.4 -apple-system,'Segoe UI',Roboto,'Noto Sans Bengali',sans-serif;background:var(--bg);color:var(--ink);height:100vh;display:flex;flex-direction:column;overflow:hidden}
header{background:var(--g);color:#fff;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;gap:10px}
header b{font-size:16px}
#net{font-size:12px;padding:3px 10px;border-radius:20px;background:#0d7a5c}
#net.off{background:var(--r)}
#queue-badge{font-size:12px;background:#b98a2f;padding:3px 10px;border-radius:20px;display:none}
main{flex:1;display:grid;grid-template-columns:1.2fr 1fr;gap:10px;padding:10px;min-height:0}
.panel{background:#fff;border-radius:10px;display:flex;flex-direction:column;min-height:0;box-shadow:0 1px 4px rgba(0,0,0,.08)}
#search{margin:10px;padding:12px 14px;font-size:17px;border:2px solid #ddd;border-radius:8px}
#search:focus{outline:none;border-color:var(--g)}
#products{flex:1;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;padding:0 10px 10px;align-content:start}
.prod{border:1.5px solid #e5e1d4;border-radius:8px;padding:10px;cursor:pointer;user-select:none}
.prod:active{background:#eef7f1;border-color:var(--g)}
.prod b{display:block;font-size:13.5px;line-height:1.25;margin-bottom:6px}
.prod span{color:var(--g);font-weight:600}
.prod small{display:block;color:#999;font-size:10.5px}
#cart{flex:1;overflow-y:auto;padding:10px}
.line{display:grid;grid-template-columns:1fr 84px 74px 26px;gap:6px;align-items:center;padding:7px 0;border-bottom:1px dashed #e8e4d6;font-size:14px}
.line input{width:100%;padding:5px;border:1px solid #ddd;border-radius:5px;text-align:right}
.line .rm{color:var(--r);font-size:18px;background:none;border:0;cursor:pointer}
#totals{padding:10px 14px;border-top:2px solid var(--ink);font-size:15px}
#totals .row{display:flex;justify-content:space-between;padding:2px 0}
#totals .grand{font-size:22px;font-weight:700}
#pay{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:0 10px}
#pay button{padding:12px 4px;border:2px solid #ddd;background:#fff;border-radius:8px;font-weight:600;cursor:pointer;font-size:13px}
#pay button.sel{border-color:var(--g);background:#eef7f1;color:var(--g)}
#actions{display:flex;gap:8px;padding:10px}
#actions button{flex:1;padding:15px;border:0;border-radius:8px;font-size:16px;font-weight:700;cursor:pointer}
#checkout{background:var(--g);color:#fff}
#checkout:disabled{background:#aaa}
#clear{background:#eee}
#shiftbar{padding:6px 14px;background:#fbf8ee;border-top:1px solid #eee;display:flex;justify-content:space-between;align-items:center;font-size:12.5px;color:#666}
#shiftbar button{border:1px solid #ccc;background:#fff;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:12px}
dialog{border:0;border-radius:12px;padding:20px;max-width:340px;width:92%;box-shadow:0 20px 60px rgba(0,0,0,.3)}
dialog::backdrop{background:rgba(10,30,22,.5)}
dialog h3{margin-bottom:10px}
dialog input{width:100%;padding:10px;font-size:16px;border:2px solid #ddd;border-radius:8px;margin:6px 0}
dialog .btns{display:flex;gap:8px;margin-top:10px}
dialog button{flex:1;padding:11px;border:0;border-radius:8px;font-weight:600;cursor:pointer}
.primary{background:var(--g);color:#fff}
#receipt{display:none}
#receipt.a4 .inv-head{display:flex;justify-content:space-between;border-bottom:3px solid #222;padding:10px 12px}
#receipt.a4 .inv-head h1{margin:0;font-size:24px}
#receipt.a4 .inv-head p{margin:4px 0 0;font-size:12px;line-height:1.5}
#receipt.a4 .inv-meta{text-align:right}
#receipt.a4 .inv-meta h2{margin:0;letter-spacing:3px;font-size:18px}
#receipt.a4 .inv-cust{margin:14px 0;font-size:13px;line-height:1.5}
#receipt.a4 .inv-table{width:100%;border-collapse:collapse;font-size:13px}
#receipt.a4 .inv-table th,#receipt.a4 .inv-table td{padding:6px 8px;text-align:left}
#receipt.a4 .inv-table.lined th,#receipt.a4 .inv-table.lined td{border:1px solid #bbb}
#receipt.a4 .inv-table.zebra tbody tr:nth-child(even){background:#f6f6f4}
#receipt.a4 .inv-table th.r,#receipt.a4 .inv-table td.r{text-align:right}
#receipt.a4 .inv-totals{margin:10px 0 0 auto;width:46%;font-size:13px;border-collapse:collapse}
#receipt.a4 .inv-totals td{padding:4px 8px}
#receipt.a4 .inv-totals .grand td{border-top:2px solid #222;font-weight:bold;font-size:15px}
#receipt.a4 .inv-terms{margin-top:18px;font-size:11.5px;line-height:1.5;color:#444;border-top:1px solid #ddd;padding-top:8px}
#receipt.a4 .inv-sign{display:flex;justify-content:space-between;margin-top:70px;font-size:12px}
#receipt.a4 .inv-sign span{border-top:1px solid #222;padding-top:5px;width:40%;text-align:center}
#receipt.a4 .inv-foot{text-align:center;margin-top:24px;font-size:11px;color:#555}
@media print{
	body>*{display:none!important}
	#receipt{display:block!important;font:12px/1.5 monospace;width:72mm;padding:2mm}
	#receipt.a4{width:190mm!important;font:13px/1.6 Georgia,'Times New Roman',serif;padding:10mm}
	#receipt h2{text-align:center;font-size:14px}
	#receipt table{width:100%;border-collapse:collapse}
	#receipt td{padding:1px 0;vertical-align:top}
	#receipt .r{text-align:right}
	#receipt hr{border:0;border-top:1px dashed #000;margin:4px 0}
	#receipt .c{text-align:center}
}
@media(max-width:760px){main{grid-template-columns:1fr;grid-template-rows:1fr 1fr}}
</style>
</head>
<body>
<header>
	<b>🛒 <?php echo esc_html( $shop ); ?> POS</b>
	<div style="display:flex;gap:8px;align-items:center">
		<span id="queue-badge">0 queued</span>
		<span id="net">online</span>
		<span style="font-size:12.5px"><?php echo esc_html( $user->display_name ); ?></span>
	</div>
</header>
<main>
	<section class="panel">
		<input id="search" placeholder="<?php esc_attr_e( 'Search or scan barcode…', 'wc-enterprise-erp' ); ?>" autofocus autocomplete="off">
		<div id="products"></div>
	</section>
	<section class="panel">
		<div id="cart"></div>
		<div id="totals">
			<div class="row"><span><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></span>
				<span><button id="cust-btn" style="border:1px solid #ddd;background:#fff;border-radius:6px;padding:3px 10px;cursor:pointer">＋ <?php esc_html_e( 'Add', 'wc-enterprise-erp' ); ?></button>
				<span id="cust-chip" style="display:none;background:#eef6f2;border-radius:6px;padding:3px 8px"><span id="cust-name"></span> <a href="#" id="cust-clear" style="text-decoration:none;color:#c8302e">✕</a></span></span></div>
			<div class="row"><span><?php esc_html_e( 'Price list', 'wc-enterprise-erp' ); ?></span>
				<span>
					<select id="tier-sel" style="border:1px solid #ddd;border-radius:6px;padding:3px 8px">
						<option value=""><?php esc_html_e( 'Retail', 'wc-enterprise-erp' ); ?></option>
						<?php
						if ( class_exists( 'WCEERP_Module_Dealers' ) ) {
							foreach ( WCEERP_Module_Dealers::tiers() as $tk => $tl ) {
								printf( '<option value="%s">%s</option>', esc_attr( $tk ), esc_html( $tl ) );
							}
						}
						?>
					</select>
				</span></div>
			<div class="row"><span><?php esc_html_e( 'Items', 'wc-enterprise-erp' ); ?></span><span id="t-items">0</span></div>
			<?php /* What you charge the customer to deliver. Not what the
			         courier charges you — those differ, and the gap is a real
			         cost worth seeing rather than burying in the price. */ ?>
			<div class="row"><span><?php esc_html_e( 'Delivery', 'wc-enterprise-erp' ); ?></span><span><input id="shipping" type="number" min="0" value="0" style="width:90px;text-align:right;padding:4px;border:1px solid #ddd;border-radius:5px"></span></div>
			<div class="row"><span><?php esc_html_e( 'Discount', 'wc-enterprise-erp' ); ?></span><span><input id="discount" type="number" min="0" value="0" style="width:90px;text-align:right;padding:4px;border:1px solid #ddd;border-radius:5px"></span></div>
			<div class="row" id="exch-row" style="display:none;color:#8a6d00"><span><?php esc_html_e( 'Return credit', 'wc-enterprise-erp' ); ?> <button id="exch-cancel" style="border:1px solid #d8c98f;background:#fff;border-radius:5px;padding:1px 8px;font-size:11px;cursor:pointer;color:#8a6d00"><?php esc_html_e( 'cancel', 'wc-enterprise-erp' ); ?></button></span><span id="exch-credit">−৳0</span></div>
			<div class="row grand"><span><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></span><span id="t-grand">৳0</span></div>
		</div>
		<div id="pay">
			<button data-m="cash" class="sel">Cash</button>
			<button data-m="bkash">bKash</button>
			<button data-m="nagad">Nagad</button>
			<button data-m="card">Card</button>
		</div>
		<div id="received-row" style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin:6px 0">
			<span><?php esc_html_e( 'Received', 'wc-enterprise-erp' ); ?></span>
			<span style="display:flex;gap:6px;align-items:center">
				<button type="button" id="recv-exact" title="<?php esc_attr_e( 'Exact amount', 'wc-enterprise-erp' ); ?>" style="border:1px solid #ddd;background:#fff;border-radius:6px;padding:5px 9px;cursor:pointer">=</button>
				<input id="received" type="number" min="0" step="0.01" placeholder="0" style="width:110px;text-align:right;padding:7px;border:2px solid #ddd;border-radius:7px;font-size:15px">
			</span>
		</div>
		<div id="changedue" style="text-align:right;font-size:14px;min-height:20px;margin-bottom:4px"></div>
		<div id="actions">
			<button id="clear"><?php esc_html_e( 'Clear', 'wc-enterprise-erp' ); ?></button>
			<button id="checkout" disabled><?php esc_html_e( 'Charge', 'wc-enterprise-erp' ); ?></button>
		</div>
		<div id="shiftbar">
			<span id="shift-info"><?php esc_html_e( 'No shift open', 'wc-enterprise-erp' ); ?></span>
			<span style="display:flex;gap:6px">
				<button id="hold-btn"><?php esc_html_e( 'Hold', 'wc-enterprise-erp' ); ?></button>
				<button id="resume-btn"><?php esc_html_e( 'Resume', 'wc-enterprise-erp' ); ?> (<span id="hold-count">0</span>)</button>
				<button id="return-btn">⟲ <?php esc_html_e( 'Return', 'wc-enterprise-erp' ); ?></button>
				<button id="xreport-btn"><?php esc_html_e( 'X report', 'wc-enterprise-erp' ); ?></button>
				<button id="shift-btn"><?php esc_html_e( 'Open shift', 'wc-enterprise-erp' ); ?></button>
			</span>
		</div>
	</section>
</main>

<dialog id="dlg-shift">
	<h3 id="dlg-shift-title"></h3>
	<input id="shift-amount" type="number" min="0" step="1" placeholder="0">
	<input id="shift-note" placeholder="<?php esc_attr_e( 'Note (optional)', 'wc-enterprise-erp' ); ?>">
	<div class="btns"><button id="dlg-shift-cancel"><?php esc_html_e( 'Cancel', 'wc-enterprise-erp' ); ?></button><button class="primary" id="dlg-shift-ok">OK</button></div>
</dialog>

<dialog id="dlg-return" style="max-width:420px">
	<h3><?php esc_html_e( 'Return items', 'wc-enterprise-erp' ); ?></h3>
	<div style="display:flex;gap:8px">
		<input id="ret-order" type="number" min="1" placeholder="<?php esc_attr_e( 'Order # from receipt', 'wc-enterprise-erp' ); ?>" style="flex:1">
		<button class="primary" id="ret-lookup" style="flex:0 0 auto;padding:0 16px"><?php esc_html_e( 'Find', 'wc-enterprise-erp' ); ?></button>
	</div>
	<p id="ret-msg" style="font-size:12.5px;color:#888;margin-top:6px"><?php esc_html_e( 'Looking up an order needs internet; the refund itself queues offline.', 'wc-enterprise-erp' ); ?></p>
	<div id="ret-lines" style="max-height:220px;overflow-y:auto"></div>
	<div id="ret-foot" style="display:none">
		<div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px">
			<b><?php esc_html_e( 'Refund total', 'wc-enterprise-erp' ); ?></b><b id="ret-total">৳0</b>
		</div>
		<select id="ret-method" style="width:100%;padding:9px;margin-top:6px;border:2px solid #ddd;border-radius:8px">
			<option value="cash"><?php esc_html_e( 'Refund from cash drawer', 'wc-enterprise-erp' ); ?></option>
			<option value="bkash">bKash</option>
			<option value="nagad">Nagad</option>
			<option value="card"><?php esc_html_e( 'Card reversal', 'wc-enterprise-erp' ); ?></option>
		</select>
	</div>
	<div class="btns">
		<button id="ret-cancel"><?php esc_html_e( 'Cancel', 'wc-enterprise-erp' ); ?></button>
		<button id="ret-exchange" disabled style="background:#b98a2f;color:#fff"><?php esc_html_e( 'Exchange →', 'wc-enterprise-erp' ); ?></button>
		<button class="primary" id="ret-ok" disabled><?php esc_html_e( 'Refund', 'wc-enterprise-erp' ); ?></button>
	</div>
</dialog>

<dialog id="dlg-holds" style="max-width:400px">
	<h3><?php esc_html_e( 'Held carts', 'wc-enterprise-erp' ); ?></h3>
	<div id="holds-list" style="max-height:260px;overflow-y:auto"></div>
	<div class="btns"><button id="holds-close"><?php esc_html_e( 'Close', 'wc-enterprise-erp' ); ?></button></div>
</dialog>

<dialog id="dlg-cust" style="max-width:400px">
	<h3><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></h3>
	<input id="cust-q" placeholder="<?php esc_attr_e( 'Search name / phone / email (online)…', 'wc-enterprise-erp' ); ?>" style="width:100%;padding:9px;border:2px solid #ddd;border-radius:8px">
	<div id="cust-results" style="max-height:160px;overflow-y:auto;margin-top:6px"></div>
	<p style="font-size:12px;color:#888;margin:10px 0 4px"><?php esc_html_e( 'Or a walk-in customer (works offline):', 'wc-enterprise-erp' ); ?></p>
	<div style="display:flex;gap:6px">
		<input id="cust-mname" placeholder="<?php esc_attr_e( 'Name', 'wc-enterprise-erp' ); ?>" style="flex:1;padding:8px;border:2px solid #ddd;border-radius:8px">
		<input id="cust-mphone" placeholder="01…" style="flex:1;padding:8px;border:2px solid #ddd;border-radius:8px">
	</div>
	<?php /* Address matters at the counter too: a walk-in who asks for
	         delivery needs one, and capturing it here saves telephoning
	         them back before a parcel can be booked. */ ?>
	<textarea id="cust-maddr" rows="2" placeholder="<?php esc_attr_e( 'Address (needed if you will deliver)', 'wc-enterprise-erp' ); ?>"
		style="width:100%;margin-top:6px;padding:8px;border:2px solid #ddd;border-radius:8px;font:inherit"></textarea>
	<div class="btns">
		<button id="cust-cancel"><?php esc_html_e( 'Cancel', 'wc-enterprise-erp' ); ?></button>
		<button class="primary" id="cust-use"><?php esc_html_e( 'Use customer', 'wc-enterprise-erp' ); ?></button>
	</div>
</dialog>

<dialog id="dlg-print" style="max-width:340px">
	<h3><?php esc_html_e( 'Print as…', 'wc-enterprise-erp' ); ?></h3>
	<div class="btns" style="justify-content:flex-start">
		<button class="primary" id="print-80"><?php esc_html_e( '80mm receipt', 'wc-enterprise-erp' ); ?></button>
		<button class="primary" id="print-a4" style="background:#134e3f"><?php esc_html_e( 'A4 invoice', 'wc-enterprise-erp' ); ?></button>
		<button id="print-skip"><?php esc_html_e( 'Skip', 'wc-enterprise-erp' ); ?></button>
	</div>
</dialog>

<div id="receipt"></div>

<script>
(function () {
'use strict';
var REST = <?php echo wp_json_encode( esc_url_raw( rest_url( 'wceerp/v1' ) ) ); ?>;
var NONCE = <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>;
var SHOP = <?php echo wp_json_encode( $shop ); ?>;
var FOOTER = <?php echo wp_json_encode( $footer ); ?>;
var CASHIER = <?php echo wp_json_encode( $user->display_name ); ?>;
var PAPER = <?php echo wp_json_encode( wceerp_get_option( 'pos_paper', '80' ) ); ?>;
var T = {
	recvHint: <?php echo wp_json_encode( __( 'Enter amount received (blank = exact)', 'wc-enterprise-erp' ) ); ?>,
	change: <?php echo wp_json_encode( __( 'Change', 'wc-enterprise-erp' ) ); ?>,
	due: <?php echo wp_json_encode( __( 'Due', 'wc-enterprise-erp' ) ); ?>,
	dueNeedsCust: <?php echo wp_json_encode( __( 'Add a customer for the due', 'wc-enterprise-erp' ) ); ?>,
	received: <?php echo wp_json_encode( __( 'Received', 'wc-enterprise-erp' ) ); ?>
};
var SHOP_ADDR = <?php echo wp_json_encode( wceerp_get_option( 'pos_invoice_address', '' ) ); ?>;
var SHOP_BIN = <?php echo wp_json_encode( wceerp_get_option( 'pos_invoice_bin', '' ) ); ?>;
<?php $inv = WCEERP_Invoice_Settings::get(); ?>
var INV = <?php echo wp_json_encode( $inv ); ?>;
var INV_FONT = <?php echo wp_json_encode( WCEERP_Invoice_Settings::css_font( $inv['font'] ) ); ?>;

/* ---------- IndexedDB ---------- */
var db;
function idb() {
	return new Promise(function (res, rej) {
		if (db) { return res(db); }
		var rq = indexedDB.open('wceerp-pos', 2);
		rq.onupgradeneeded = function () {
			var d = rq.result;
			if (!d.objectStoreNames.contains('catalog')) { d.createObjectStore('catalog', { keyPath: 'id' }); }
			if (!d.objectStoreNames.contains('queue')) { d.createObjectStore('queue', { keyPath: 'uuid' }); }
			if (!d.objectStoreNames.contains('kv')) { d.createObjectStore('kv'); }
			if (!d.objectStoreNames.contains('holds')) { d.createObjectStore('holds', { keyPath: 'id' }); }
		};
		rq.onsuccess = function () { db = rq.result; res(db); };
		rq.onerror = function () { rej(rq.error); };
	});
}
function tx(store, mode, fn) {
	return idb().then(function (d) {
		return new Promise(function (res, rej) {
			var t = d.transaction(store, mode), s = t.objectStore(store), out = fn(s);
			t.oncomplete = function () { res(out && out.result !== undefined ? out.result : out); };
			t.onerror = function () { rej(t.error); };
		});
	});
}
function kvGet(k) { return tx('kv', 'readonly', function (s) { return s.get(k); }); }
function kvSet(k, v) { return tx('kv', 'readwrite', function (s) { s.put(v, k); }); }

/* ---------- helpers ---------- */
function uuid() { return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10); }
function money(n) { return '৳' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 }); }
function api(path, body) {
	return fetch(REST + path, {
		method: body ? 'POST' : 'GET',
		credentials: 'same-origin',
		headers: body ? { 'Content-Type': 'application/json', 'X-WP-Nonce': NONCE } : { 'X-WP-Nonce': NONCE },
		body: body ? JSON.stringify(body) : undefined
	}).then(function (r) { if (!r.ok && r.status !== 409) { throw new Error('HTTP ' + r.status); } return r.json(); });
}

/* ---------- catalog ---------- */
var catalog = [];
function loadCatalogFromDB() {
	return tx('catalog', 'readonly', function (s) { return s.getAll(); }).then(function (rows) {
		catalog = rows || []; renderProducts('');
	});
}
function refreshCatalog() {
	if (!navigator.onLine) { return Promise.resolve(); }
	var page = 1, all = [];
	function next() {
		return api('/pos/catalog?page=' + page).then(function (r) {
			all = all.concat(r.products || []);
			if (r.more && page < 25) { page++; return next(); }
		});
	}
	return next().then(function () {
		if (!all.length) { return; }
		return tx('catalog', 'readwrite', function (s) { s.clear(); all.forEach(function (p) { s.put(p); }); })
			.then(function () { catalog = all; renderProducts(document.getElementById('search').value); });
	}).catch(function () {});
}
function renderProducts(q) {
	q = (q || '').toLowerCase().trim();
	var wrap = document.getElementById('products'), html = '', shown = 0;
	for (var i = 0; i < catalog.length && shown < 60; i++) {
		var p = catalog[i];
		if (q && p.name.toLowerCase().indexOf(q) < 0 && String(p.sku).toLowerCase() !== q) { continue; }
		var shelf = tierPrice(p);
		var tag = (shelf !== p.price)
			? '<span>' + money(shelf) + ' <s style="opacity:.55;font-weight:400">' + money(p.price) + '</s></span>'
			: '<span>' + money(p.price) + '</span>';
		html += '<div class="prod" data-i="' + i + '"><b>' + esc(p.name) + '</b>' + tag + (p.sku ? '<small>' + esc(p.sku) + '</small>' : '') + '</div>';
		shown++;
	}
	wrap.innerHTML = html || '<p style="padding:14px;color:#999">No products' + (navigator.onLine ? '' : ' — connect once to load the catalog') + '.</p>';
}
function esc(s) { var d = document.createElement('i'); d.textContent = s; return d.innerHTML; }

/* ---------- cart ---------- */
var cart = [];

/* Trade pricing: a fixed per-product price for the buyer's group wins;
   otherwise their group discount % comes off retail. Mirrors the server
   side in WCEERP_Module_Dealers::price_for(). */
/* The active price list. Normally set by the customer's buyer group, but a
   cashier can override it for a walk-in trade buyer who has no account. */
var tier = '';
var tierPct = 0;

function tierPrice(p) {
	if (!tier) { return p.price; }
	if (p.tiers && p.tiers[tier] > 0) { return Number(p.tiers[tier]); }
	var pct = Number(tierPct) || 0;
	if (pct <= 0) { return p.price; }
	return Math.round(p.price * (1 - pct / 100) * 100) / 100;
}

function setTier(t, pct, silent) {
	tier = t || '';
	tierPct = Number(pct) || 0;
	var sel = document.getElementById('tier-sel');
	if (sel && sel.value !== tier) { sel.value = tier; }
	if (!silent) { repriceCart(); renderProducts(document.getElementById('search').value); }
}

function addToCart(p) {
	for (var i = 0; i < cart.length; i++) { if (cart[i].id === p.id) { cart[i].qty++; return renderCart(); } }
	cart.push({ id: p.id, name: p.name, price: tierPrice(p), retail: p.price, tiers: p.tiers || null, qty: 1 });
	renderCart();
}

/* Re-price the open cart when the customer changes. Any line the cashier
   typed a price into by hand is left alone. */
function repriceCart() {
	cart.forEach(function (l) {
		if (l.manual) { return; }
		l.price = tierPrice({ id: l.id, price: l.retail !== undefined ? l.retail : l.price, tiers: l.tiers });
	});
	renderCart();
}
function renderCart() {
	var html = '';
	cart.forEach(function (l, i) {
		html += '<div class="line"><span>' + esc(l.name) + '</span>'
			+ '<input type="number" step="1" min="0.01" value="' + l.qty + '" data-q="' + i + '">'
			+ '<input type="number" step="0.01" min="0" value="' + l.price + '" data-p="' + i + '">'
			+ '<button class="rm" data-r="' + i + '">×</button></div>';
	});
	document.getElementById('cart').innerHTML = html || '<p style="padding:14px;color:#999">Cart is empty — tap products or scan.</p>';
	var items = 0, total = 0;
	cart.forEach(function (l) { items += Number(l.qty); total += l.qty * l.price; });
	var disc = Number(document.getElementById('discount').value) || 0;
	var ship = Number(document.getElementById('shipping').value) || 0;
	document.getElementById('t-items').textContent = items;
	/* Delivery is charged on top of the goods, then the discount comes off
	   whatever the customer is being asked for. */
	var net = total + ship - disc - (exch ? exch.credit : 0);
	document.getElementById('exch-row').style.display = exch ? 'flex' : 'none';
	if (exch) { document.getElementById('exch-credit').textContent = '−' + money(exch.credit); }
	document.getElementById('t-grand').textContent = (exch && net < 0 ? 'Refund ' : '') + money(Math.abs(exch ? net : Math.max(0, net)));
	var btn = document.getElementById('checkout');
	btn.textContent = exch ? 'Complete exchange' : 'Charge';
	btn.disabled = !cart.length || !shift;
	window._grand = exch ? net : Math.max(0, net);
	updateChangeDue();
}

/* Live change / due readout under the Received box. Exchanges settle
 * net at the counter, so received/due doesn't apply to them. */
function updateChangeDue() {
	var el = document.getElementById('changedue');
	var recvInput = document.getElementById('received');
	if (exch) { el.textContent = ''; recvInput.disabled = true; return; }
	recvInput.disabled = false;
	var grand = window._grand || 0;
	var raw = recvInput.value.trim();
	if (raw === '') { el.innerHTML = '<span style="color:#999">' + T.recvHint + '</span>'; return; }
	var recv = Number(raw) || 0;
	if (recv >= grand) {
		var change = recv - grand;
		el.innerHTML = '<b style="color:#2f8a4c">' + T.change + ': ' + money(change) + '</b>';
	} else {
		var due = grand - recv;
		el.innerHTML = '<b style="color:#c8302e">' + T.due + ': ' + money(due) + '</b>'
			+ (cust ? '' : '<br><small style="color:#c8302e">' + T.dueNeedsCust + '</small>');
	}
}

/* ---------- shift ---------- */
var shift = null;
function updateShiftBar() {
	document.getElementById('shift-info').textContent = shift ? ('Shift open · float ' + money(shift.float)) : 'No shift open';
	document.getElementById('shift-btn').textContent = shift ? 'Close shift' : 'Open shift';
	renderCart();
}
function openShiftDialog() {
	var dlg = document.getElementById('dlg-shift');
	document.getElementById('dlg-shift-title').textContent = shift ? 'Close shift — count the cash drawer' : 'Open shift — opening float';
	document.getElementById('shift-amount').value = '';
	document.getElementById('shift-note').value = '';
	dlg.showModal();
	setTimeout(function(){ document.getElementById('shift-amount').focus(); }, 50);
}
function shiftOk() {
	var amount = Number(document.getElementById('shift-amount').value) || 0;
	var note = document.getElementById('shift-note').value;
	document.getElementById('dlg-shift').close();
	if (!shift) {
		shift = { uuid: uuid(), float: amount, openedAt: new Date().toISOString(),
			t: { cash: {s:0,r:0,n:0}, bkash: {s:0,r:0,n:0}, nagad: {s:0,r:0,n:0}, card: {s:0,r:0,n:0} } };
		kvSet('shift', shift);
		enqueue({ kind: 'shift', uuid: shift.uuid, do: 'open', opening_float: amount });
	} else {
		printShiftReport('Z REPORT — SHIFT CLOSE', amount);
		enqueue({ kind: 'shift', uuid: shift.uuid, do: 'close', counted_cash: amount, note: note });
		shift = null; kvSet('shift', null);
	}
	updateShiftBar(); sync();
}

/* ---------- queue & sync ---------- */
function enqueue(job) {
	job.uuid = job.uuid || uuid();
	job.ts = Date.now();
	return tx('queue', 'readwrite', function (s) { s.put(job); }).then(updateBadge).then(sync);
}
function updateBadge() {
	return tx('queue', 'readonly', function (s) { return s.count(); }).then(function (n) {
		var badge = document.getElementById('queue-badge');
		badge.style.display = n ? 'inline' : 'none';
		badge.textContent = n + ' queued';
	});
}
var syncing = false;
function sync() {
	if (syncing || !navigator.onLine) { return; }
	syncing = true;
	tx('queue', 'readonly', function (s) { return s.getAll(); }).then(function (jobs) {
		jobs.sort(function (a, b) { return a.ts - b.ts; });
		var chain = Promise.resolve();
		jobs.forEach(function (job) {
			chain = chain.then(function () {
				var path = job.kind === 'shift' ? '/pos/shift' : (job.kind === 'refund' ? '/pos/refund' : '/pos/sale');
				return api(path, job).then(function (r) {
					if (r && (r.ok || r.duplicate)) {
						return tx('queue', 'readwrite', function (s) { s.delete(job.uuid); });
					}
					throw new Error('rejected');
				});
			});
		});
		return chain;
	}).catch(function () {}).then(function () { syncing = false; updateBadge(); });
}

/* ---------- checkout & receipt ---------- */
function checkout() {
	var method = document.querySelector('#pay .sel').dataset.m;
	var disc = Number(document.getElementById('discount').value) || 0;
	var ship = Number(document.getElementById('shipping').value) || 0;
	var total = 0;
	cart.forEach(function (l) { total += l.qty * l.price; });
	/* Same order as the cart display, or the amount charged would not match
	   the amount shown — which is the fastest way to lose a cashier's
	   trust in the till. */
	total = Math.max(0, total + ship - disc);

	if (exch) { return completeExchange(method, disc, total); }

	// Received amount → change/due. Blank means exact (fully paid).
	var recvRaw = document.getElementById('received').value.trim();
	var received = recvRaw === '' ? total : (Number(recvRaw) || 0);
	var due = Math.max(0, Math.round((total - received) * 100) / 100);
	var change = Math.max(0, Math.round((received - total) * 100) / 100);
	if (due > 0.004 && !cust) {
		alert(T.dueNeedsCust);
		document.getElementById('cust-btn').click();
		return;
	}

	var sale = {
		kind: 'sale', uuid: uuid(), shift_uuid: shift.uuid,
		items: cart.map(function (l) { return { id: l.id, qty: l.qty, price: l.price }; }),
		discount: disc, pay_method: method, received: received,
		sold_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
	};
	sale.shipping = ship;
	if (cust) { sale.customer_id = cust.id || 0; sale.customer_name = cust.name; sale.customer_phone = cust.phone || ''; sale.customer_address = cust.address || ''; }
	sale.tier = tier || '';
	window._pay = { received: received, change: change, due: due };
	enqueue(sale);
	// Only the collected portion counts toward the drawer.
	tally(method, Math.min(received, total), false);
	printSale(cart.slice(), disc, total, method, sale.uuid);
	cart = []; document.getElementById('discount').value = 0; document.getElementById('shipping').value = 0; document.getElementById('received').value = ''; setCust(null); renderCart();
	document.getElementById('search').focus();
}

/* ---------- Exchange: return credit + new items, one net settlement ----------
 * Two idempotent jobs share an exchange ref: the refund credits the money
 * account for the returned goods, the sale debits it for the new goods —
 * both in the SAME method the difference is settled in, so the drawer and
 * the books both move by exactly the net amount. */
var exch = null;
function startExchange() {
	var lines = {}, printable = [], credit = 0;
	document.querySelectorAll('[data-ret]').forEach(function (inp) {
		var it = retOrder.items[Number(inp.dataset.ret)];
		var q = Math.min(Number(inp.value) || 0, it.refundable);
		if (q > 0) { lines[it.item_id] = q; printable.push({ name: it.name, qty: q, price: it.unit_price }); credit += q * it.unit_price; }
	});
	if (!credit) { return; }
	exch = { ref: uuid(), orderId: retOrder.order_id, number: retOrder.number, lines: lines, printable: printable, credit: credit };
	document.getElementById('dlg-return').close();
	renderCart();
	document.getElementById('search').focus();
}
function cancelExchange() { exch = null; renderCart(); }
function completeExchange(method, disc, total) {
	var x = exch;
	var net = total - x.credit;
	enqueue({ kind: 'refund', uuid: uuid(), shift_uuid: shift.uuid, order_id: x.orderId,
		lines: x.lines, pay_method: method, exchange_ref: x.ref });
	var xsale = { kind: 'sale', uuid: uuid(), shift_uuid: shift.uuid,
		items: cart.map(function (l) { return { id: l.id, qty: l.qty, price: l.price }; }),
		discount: disc, pay_method: method, exchange_ref: x.ref, exchange_order_id: x.orderId,
		sold_at: new Date().toISOString().slice(0, 19).replace('T', ' ') };
	if (cust) { xsale.customer_id = cust.id || 0; xsale.customer_name = cust.name; xsale.customer_phone = cust.phone || ''; xsale.customer_address = cust.address || ''; }
	xsale.tier = tier || '';
	enqueue(xsale);
	tally(method, total, false);
	tally(method, x.credit, true);
	printExchangeReceipt(x, cart.slice(), disc, total, net, method);
	exch = null; cart = []; document.getElementById('discount').value = 0; document.getElementById('shipping').value = 0; setCust(null); renderCart();
	document.getElementById('search').focus();
}
function printExchangeReceipt(x, newLines, disc, total, net, method) {
	var h = '<h2>' + esc(SHOP) + '</h2><p class="c"><b>EXCHANGE</b> — order #' + x.number + '<br>'
		+ new Date().toLocaleString() + '<br>Cashier: ' + esc(CASHIER) + '</p><hr>'
		+ '<p><b>Returned</b></p><table>';
	x.printable.forEach(function (l) { h += '<tr><td>' + esc(l.name) + '<br>' + l.qty + ' × ' + money(l.price) + '</td><td class="r">-' + money(l.qty * l.price) + '</td></tr>'; });
	h += '</table><p style="margin-top:4px"><b>New items</b></p><table>';
	newLines.forEach(function (l) { h += '<tr><td>' + esc(l.name) + '<br>' + l.qty + ' × ' + money(l.price) + '</td><td class="r">' + money(l.qty * l.price) + '</td></tr>'; });
	h += '</table><hr><table>';
	if (disc > 0) { h += '<tr><td>Discount</td><td class="r">-' + money(disc) + '</td></tr>'; }
	h += '<tr><td>Return credit</td><td class="r">-' + money(x.credit) + '</td></tr>'
		+ '<tr><td><b>' + (net >= 0 ? 'TO PAY' : 'REFUNDED') + '</b></td><td class="r"><b>' + money(Math.abs(net)) + '</b></td></tr>'
		+ '<tr><td>Method</td><td class="r">' + method.toUpperCase() + '</td></tr></table><hr><p class="c">' + esc(FOOTER) + '</p>';
	output(h, '');
}
function printReceipt(lines, disc, total, method) {
	var h = '<h2>' + esc(SHOP) + '</h2><p class="c">' + new Date().toLocaleString() + '<br>Cashier: ' + esc(CASHIER)
		+ (cust ? '<br>Customer: ' + esc(cust.name) + (cust.phone ? ' (' + esc(cust.phone) + ')' : '') : '') + '</p><hr><table>';
	lines.forEach(function (l) {
		h += '<tr><td>' + esc(l.name) + '<br>' + l.qty + ' × ' + money(l.price) + '</td><td class="r">' + money(l.qty * l.price) + '</td></tr>';
	});
	h += '</table><hr><table>';
	if (disc > 0) { h += '<tr><td>Discount</td><td class="r">-' + money(disc) + '</td></tr>'; }
	h += '<tr><td><b>TOTAL</b></td><td class="r"><b>' + money(total) + '</b></td></tr>';
	h += '<tr><td>Paid by</td><td class="r">' + method.toUpperCase() + '</td></tr>';
	var pay = window._pay || {};
	if (pay.received !== undefined) {
		h += '<tr><td>Received</td><td class="r">' + money(pay.received) + '</td></tr>';
		if (pay.change > 0.004) { h += '<tr><td>Change</td><td class="r">' + money(pay.change) + '</td></tr>'; }
		if (pay.due > 0.004) { h += '<tr><td><b>DUE</b></td><td class="r"><b>' + money(pay.due) + '</b></td></tr>'; }
	}
	h += '</table><hr><p class="c">' + esc(FOOTER) + '</p>';
	output(h, '');
}

function tally(method, amount, isRefund) {
	if (!shift) { return; }
	if (!shift.t) { shift.t = { cash:{s:0,r:0,n:0}, bkash:{s:0,r:0,n:0}, nagad:{s:0,r:0,n:0}, card:{s:0,r:0,n:0} }; }
	var t = shift.t[method] || (shift.t[method] = {s:0,r:0,n:0});
	if (isRefund) { t.r += amount; } else { t.s += amount; t.n++; }
	kvSet('shift', shift);
}

/* ---------- X / Z reports (from local shift tallies) ---------- */
function printShiftReport(title, counted) {
	if (!shift) { return; }
	var t = shift.t || {}, totalSales = 0, totalRefunds = 0, count = 0;
	var rows = '';
	['cash','bkash','nagad','card'].forEach(function (m) {
		var x = t[m] || {s:0,r:0,n:0};
		totalSales += x.s; totalRefunds += x.r; count += x.n;
		if (x.s || x.r) {
			rows += '<tr><td>' + m.toUpperCase() + ' (' + x.n + ')</td><td class="r">' + money(x.s) + (x.r ? '<br>-' + money(x.r) : '') + '</td></tr>';
		}
	});
	var cash = t.cash || {s:0,r:0};
	var expected = Number(shift.float) + cash.s - cash.r;
	var h = '<h2>' + esc(SHOP) + '</h2><p class="c"><b>' + title + '</b><br>'
		+ 'Opened: ' + new Date(shift.openedAt).toLocaleString() + '<br>Cashier: ' + esc(CASHIER) + '</p><hr><table>'
		+ rows
		+ '<tr><td><b>Sales (' + count + ')</b></td><td class="r"><b>' + money(totalSales) + '</b></td></tr>'
		+ (totalRefunds ? '<tr><td>Refunds</td><td class="r">-' + money(totalRefunds) + '</td></tr>' : '')
		+ '</table><hr><table>'
		+ '<tr><td>Opening float</td><td class="r">' + money(shift.float) + '</td></tr>'
		+ '<tr><td><b>Expected cash</b></td><td class="r"><b>' + money(expected) + '</b></td></tr>';
	if (counted !== undefined) {
		h += '<tr><td>Counted</td><td class="r">' + money(counted) + '</td></tr>'
			+ '<tr><td><b>Over / short</b></td><td class="r"><b>' + money(counted - expected) + '</b></td></tr>';
	}
	h += '</table><hr><p class="c">' + (counted !== undefined ? 'Shift closed' : 'Shift still open — interim report') + '</p>';
	output(h, '');
}

/* ---------- Returns ---------- */
var retOrder = null;
function retReset() {
	retOrder = null;
	document.getElementById('ret-lines').innerHTML = '';
	document.getElementById('ret-foot').style.display = 'none';
	document.getElementById('ret-ok').disabled = true;
	document.getElementById('ret-exchange').disabled = true;
	document.getElementById('ret-msg').style.color = '#888';
}
function retLookup() {
	var id = Number(document.getElementById('ret-order').value);
	var msg = document.getElementById('ret-msg');
	if (!id) { return; }
	if (!navigator.onLine) { msg.textContent = 'Offline — order lookup needs internet.'; msg.style.color = '#c8302e'; return; }
	msg.textContent = 'Looking up…'; msg.style.color = '#888';
	api('/pos/order/' + id).then(function (o) {
		if (!o || !o.items) { throw new Error('bad'); }
		retOrder = o;
		msg.textContent = 'Order #' + o.number + ' · ' + o.date + ' · paid ' + money(o.total) + (o.refunded ? ' · already refunded ' + money(o.refunded) : '');
		var h = '<table style="width:100%;font-size:13.5px;margin-top:8px">';
		o.items.forEach(function (it, i) {
			h += '<tr><td style="padding:4px 0">' + esc(it.name) + '<br><small style="color:#888">' + money(it.unit_price) + ' × max ' + it.refundable + '</small></td>'
				+ '<td style="text-align:right"><input type="number" min="0" max="' + it.refundable + '" step="1" value="0" data-ret="' + i + '" style="width:64px;padding:5px;border:1px solid #ddd;border-radius:5px;text-align:right"' + (it.refundable ? '' : ' disabled') + '></td></tr>';
		});
		document.getElementById('ret-lines').innerHTML = h + '</table>';
		document.getElementById('ret-foot').style.display = 'block';
		retRecalc();
	}).catch(function () { msg.textContent = 'Order not found (or no permission).'; msg.style.color = '#c8302e'; });
}
function retRecalc() {
	if (!retOrder) { return; }
	var total = 0, any = false;
	document.querySelectorAll('[data-ret]').forEach(function (inp) {
		var it = retOrder.items[Number(inp.dataset.ret)];
		var q = Math.min(Number(inp.value) || 0, it.refundable);
		if (q > 0) { any = true; total += q * it.unit_price; }
	});
	document.getElementById('ret-total').textContent = money(total);
	document.getElementById('ret-ok').disabled = !any || !shift;
	document.getElementById('ret-exchange').disabled = !any || !shift;
	return total;
}
function retConfirm() {
	var lines = {}, printable = [], total = 0;
	document.querySelectorAll('[data-ret]').forEach(function (inp) {
		var it = retOrder.items[Number(inp.dataset.ret)];
		var q = Math.min(Number(inp.value) || 0, it.refundable);
		if (q > 0) { lines[it.item_id] = q; printable.push({ name: it.name, qty: q, price: it.unit_price }); total += q * it.unit_price; }
	});
	var method = document.getElementById('ret-method').value;
	enqueue({ kind: 'refund', uuid: uuid(), shift_uuid: shift.uuid, order_id: retOrder.order_id, lines: lines, pay_method: method });
	tally(method, total, true);
	document.getElementById('dlg-return').close();
	/* Refund receipt. */
	var h = '<h2>' + esc(SHOP) + '</h2><p class="c"><b>RETURN</b> — order #' + retOrder.number + '<br>' + new Date().toLocaleString() + '</p><hr><table>';
	printable.forEach(function (l) { h += '<tr><td>' + esc(l.name) + '<br>' + l.qty + ' × ' + money(l.price) + '</td><td class="r">-' + money(l.qty * l.price) + '</td></tr>'; });
	h += '</table><hr><table><tr><td><b>REFUNDED</b></td><td class="r"><b>' + money(total) + '</b></td></tr>'
		+ '<tr><td>Method</td><td class="r">' + method.toUpperCase() + '</td></tr></table><hr><p class="c">' + esc(FOOTER) + '</p>';
	output(h, '');
}

/* ---------- Held carts ---------- */
function updateHoldCount() {
	return tx('holds', 'readonly', function (s) { return s.count(); }).then(function (n) {
		document.getElementById('hold-count').textContent = n;
	});
}
function holdCart() {
	if (!cart.length) { return; }
	var total = 0; cart.forEach(function (l) { total += l.qty * l.price; });
	var hold = { id: uuid(), ts: Date.now(), label: cart[0].name + (cart.length > 1 ? ' +' + (cart.length - 1) : ''), total: total, cart: cart.slice(), discount: Number(document.getElementById('discount').value) || 0 };
	tx('holds', 'readwrite', function (s) { s.put(hold); }).then(function () {
		cart = []; document.getElementById('discount').value = 0; renderCart(); updateHoldCount();
		document.getElementById('search').focus();
	});
}
function openHolds() {
	tx('holds', 'readonly', function (s) { return s.getAll(); }).then(function (holds) {
		holds.sort(function (a, b) { return b.ts - a.ts; });
		var h = holds.length ? '' : '<p style="color:#999;padding:8px 0">Nothing on hold.</p>';
		holds.forEach(function (x) {
			h += '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 0;border-bottom:1px dashed #eee">'
				+ '<span><b>' + esc(x.label) + '</b><br><small style="color:#888">' + new Date(x.ts).toLocaleTimeString() + ' · ' + money(x.total) + '</small></span>'
				+ '<span style="display:flex;gap:6px"><button class="primary" data-resume="' + x.id + '" style="padding:7px 12px;border-radius:6px;border:0">Resume</button>'
				+ '<button data-drop="' + x.id + '" style="padding:7px 10px;border-radius:6px;border:1px solid #ddd;background:#fff;color:#c8302e">✕</button></span></div>';
		});
		document.getElementById('holds-list').innerHTML = h;
		document.getElementById('dlg-holds').showModal();
	});
}
function resumeHold(id) {
	tx('holds', 'readonly', function (s) { return s.get(id); }).then(function (hold) {
		if (!hold) { return; }
		if (cart.length) { holdCart(); } // park the current one first — nothing gets lost.
		cart = hold.cart; document.getElementById('discount').value = hold.discount || 0;
		return tx('holds', 'readwrite', function (s) { s.delete(id); });
	}).then(function () { renderCart(); updateHoldCount(); document.getElementById('dlg-holds').close(); });
}

/* ---------- Customer ---------- */
var cust = null;
function setCust(c) {
	cust = c;
	document.getElementById('cust-chip').style.display = c ? 'inline-block' : 'none';
	document.getElementById('cust-btn').style.display = c ? 'none' : 'inline-block';
	if (c) {
		var trade = c.tier_label ? ' · ' + c.tier_label : '';
		document.getElementById('cust-name').textContent = c.name + (c.phone ? ' · ' + c.phone : '') + trade;
		setTier(c.tier || '', c.discount_pct || 0, true);
	} else {
		setTier('', 0, true);
	}
	repriceCart();
	renderProducts(document.getElementById('search').value);
}
var custTimer = null;
function custSearch() {
	var q = document.getElementById('cust-q').value.trim();
	var box = document.getElementById('cust-results');
	if (q.length < 2) { box.innerHTML = ''; return; }
	if (!navigator.onLine) { box.innerHTML = '<p style="color:#c8302e;font-size:12px">Offline — use the walk-in fields below.</p>'; return; }
	clearTimeout(custTimer);
	custTimer = setTimeout(function () {
		api('/pos/customers?q=' + encodeURIComponent(q)).then(function (rows) {
			box.innerHTML = rows.length ? '' : '<p style="color:#999;font-size:12px">No matches.</p>';
			rows.forEach(function (r) {
				var d = document.createElement('div');
				d.style.cssText = 'padding:7px 8px;border-bottom:1px dashed #eee;cursor:pointer';
				d.innerHTML = '<b>' + esc(r.name) + '</b> <small style="color:#888">' + esc(r.phone || r.email || '') + '</small>'
					+ (r.tier_label ? ' <small style="background:#eef;color:#334;padding:1px 6px;border-radius:9px">' + esc(r.tier_label) + '</small>' : '');
				d.addEventListener('click', function () {
					setCust({ id: r.id, name: r.name, phone: r.phone, tier: r.tier || '', tier_label: r.tier_label || '', discount_pct: r.discount_pct || 0 });
					document.getElementById('dlg-cust').close();
				});
				box.appendChild(d);
			});
		}).catch(function () { box.innerHTML = '<p style="color:#c8302e;font-size:12px">Search failed.</p>'; });
	}, 250);
}

/* ---------- A4 invoice + paper routing ---------- */
function output(html, mode) {
	var r = document.getElementById('receipt');
	r.className = mode === 'a4' ? 'a4' : '';
	r.style.fontFamily = mode === 'a4' ? INV_FONT : '';
	r.innerHTML = html;
	window.print();
}
function invoiceA4(lines, disc, total, method, saleUuid, c) {
	var d = new Date();
	var pay = window._pay || {};
	var logo = INV.logo ? '<img src="' + INV.logo + '" style="max-height:54px;margin-bottom:6px">' : '';
	var contact = [];
	if (INV.phone) { contact.push('Phone: ' + esc(INV.phone)); }
	if (INV.email) { contact.push(esc(INV.email)); }
	var h = '<div class="inv-head" style="background:' + INV.header_bg + '"><div>' + logo + '<h1 style="color:' + INV.accent + '">' + esc(INV.company_name) + '</h1><p>'
		+ esc(INV.address).replace(/\n/g, '<br>')
		+ (contact.length ? '<br>' + contact.join(' · ') : '')
		+ (INV.bin ? '<br>BIN: ' + esc(INV.bin) : '') + '</p></div>'
		+ '<div class="inv-meta"><h2 style="color:' + INV.accent + '">INVOICE</h2><p>No: ' + esc(saleUuid.slice(0, 8).toUpperCase()) + '<br>Date: ' + d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) + '<br>Cashier: ' + esc(CASHIER) + '</p></div></div>'
		+ '<div class="inv-cust"><b>Billed to</b><br>' + esc(c ? c.name : 'Walk-in customer') + (c && c.phone ? '<br>' + esc(c.phone) : '') + '</div>'
		+ '<table class="inv-table ' + (INV.zebra === 'yes' ? 'zebra' : '') + ' ' + (INV.show_lines === 'yes' ? 'lined' : '') + '"><thead><tr style="background:' + INV.accent + ';color:#fff"><th>#</th><th>Item</th><th class="r">Qty</th><th class="r">Unit</th><th class="r">Amount</th></tr></thead><tbody>';
	lines.forEach(function (l, i) {
		h += '<tr><td>' + (i + 1) + '</td><td>' + esc(l.name) + '</td><td class="r">' + l.qty + '</td><td class="r">' + money(l.price) + '</td><td class="r">' + money(l.qty * l.price) + '</td></tr>';
	});
	var sub = 0; lines.forEach(function (l) { sub += l.qty * l.price; });
	h += '</tbody></table><table class="inv-totals">'
		+ '<tr><td>Subtotal</td><td class="r">' + money(sub) + '</td></tr>'
		+ (disc > 0 ? '<tr><td>Discount</td><td class="r">-' + money(disc) + '</td></tr>' : '')
		+ '<tr class="grand"><td>Total (VAT incl.)</td><td class="r">' + money(total) + '</td></tr>'
		+ '<tr><td>Paid by</td><td class="r">' + method.toUpperCase() + '</td></tr>';
	if (pay.received !== undefined) {
		h += '<tr><td>Received</td><td class="r">' + money(pay.received) + '</td></tr>';
		if (pay.change > 0.004) { h += '<tr><td>Change</td><td class="r">' + money(pay.change) + '</td></tr>'; }
		if (pay.due > 0.004) { h += '<tr class="grand"><td>Balance due</td><td class="r">' + money(pay.due) + '</td></tr>'; }
	}
	h += '</table>';
	if (INV.terms) { h += '<div class="inv-terms"><b>Terms</b><br>' + esc(INV.terms).replace(/\n/g, '<br>') + '</div>'; }
	if (INV.signature === 'yes') { h += '<div class="inv-sign"><span>Customer signature</span><span>Authorised signature</span></div>'; }
	h += '<p class="inv-foot">' + esc(INV.footer) + '</p>';
	return h;
}
var pendingPrint = null;
function printSale(lines, disc, total, method, saleUuid) {
	var snap = cust;
	if (PAPER === 'a4') { output(invoiceA4(lines, disc, total, method, saleUuid, snap), 'a4'); return; }
	if (PAPER === 'ask') { pendingPrint = { lines: lines, disc: disc, total: total, method: method, uuid: saleUuid, cust: snap }; document.getElementById('dlg-print').showModal(); return; }
	printReceipt(lines, disc, total, method);
}

/* ---------- events ---------- */
document.getElementById('search').addEventListener('input', function () { renderProducts(this.value); });
document.getElementById('search').addEventListener('keydown', function (e) {
	if (e.key !== 'Enter') { return; }
	var code = this.value.trim().toLowerCase();
	if (!code) { return; }
	for (var i = 0; i < catalog.length; i++) {
		if (String(catalog[i].sku).toLowerCase() === code) { addToCart(catalog[i]); this.value = ''; renderProducts(''); return; }
	}
	var visible = document.querySelector('#products .prod');
	if (visible) { addToCart(catalog[Number(visible.dataset.i)]); this.value = ''; renderProducts(''); }
});
document.getElementById('products').addEventListener('click', function (e) {
	var el = e.target.closest('.prod');
	if (el) { addToCart(catalog[Number(el.dataset.i)]); }
});
document.getElementById('cart').addEventListener('input', function (e) {
	if (e.target.dataset.q !== undefined) { cart[Number(e.target.dataset.q)].qty = Number(e.target.value) || 0; }
	if (e.target.dataset.p !== undefined) {
		var li = Number(e.target.dataset.p);
		cart[li].price = Number(e.target.value) || 0;
		cart[li].manual = true;
	}
	renderCart();
});
document.getElementById('cart').addEventListener('click', function (e) {
	if (e.target.dataset.r !== undefined) { cart.splice(Number(e.target.dataset.r), 1); renderCart(); }
});
document.getElementById('discount').addEventListener('input', renderCart);
document.getElementById('shipping').addEventListener('input', renderCart);
document.getElementById('received').addEventListener('input', updateChangeDue);
document.getElementById('recv-exact').addEventListener('click', function () {
	document.getElementById('received').value = (window._grand || 0).toFixed(2);
	updateChangeDue();
});
document.getElementById('pay').addEventListener('click', function (e) {
	if (e.target.dataset.m) {
		document.querySelectorAll('#pay button').forEach(function (b) { b.classList.remove('sel'); });
		e.target.classList.add('sel');
	}
});
document.getElementById('clear').addEventListener('click', function () { cart = []; renderCart(); });
document.getElementById('checkout').addEventListener('click', checkout);
document.getElementById('shift-btn').addEventListener('click', openShiftDialog);
document.getElementById('xreport-btn').addEventListener('click', function () { if (shift) { printShiftReport('X REPORT — INTERIM'); } });
document.getElementById('hold-btn').addEventListener('click', holdCart);
document.getElementById('resume-btn').addEventListener('click', openHolds);
document.getElementById('holds-close').addEventListener('click', function () { document.getElementById('dlg-holds').close(); });
document.getElementById('holds-list').addEventListener('click', function (e) {
	if (e.target.dataset.resume) { resumeHold(e.target.dataset.resume); }
	if (e.target.dataset.drop) { var id = e.target.dataset.drop; tx('holds', 'readwrite', function (s) { s.delete(id); }).then(function () { updateHoldCount(); openHolds(); }); }
});
document.getElementById('return-btn').addEventListener('click', function () { retReset(); document.getElementById('dlg-return').showModal(); setTimeout(function(){ document.getElementById('ret-order').focus(); }, 50); });
document.getElementById('ret-lookup').addEventListener('click', retLookup);
document.getElementById('ret-order').addEventListener('keydown', function (e) { if (e.key === 'Enter') { retLookup(); } });
document.getElementById('ret-lines').addEventListener('input', retRecalc);
document.getElementById('ret-cancel').addEventListener('click', function () { document.getElementById('dlg-return').close(); });
document.getElementById('ret-ok').addEventListener('click', retConfirm);
document.getElementById('ret-exchange').addEventListener('click', startExchange);
document.getElementById('tier-sel').addEventListener('change', function () {
	/* A manual change keeps the customer's own discount % only when the
	   cashier picks that customer's own group again; otherwise the group's
	   fixed product prices apply with no percentage fallback. */
	var chosen = this.value;
	var pct = (cust && cust.tier === chosen) ? (cust.discount_pct || 0) : 0;
	setTier(chosen, pct);
});

document.getElementById('cust-btn').addEventListener('click', function () {
	document.getElementById('cust-q').value = ''; document.getElementById('cust-results').innerHTML = '';
	document.getElementById('cust-mname').value = ''; document.getElementById('cust-mphone').value = '';
	document.getElementById('dlg-cust').showModal();
	setTimeout(function () { document.getElementById('cust-q').focus(); }, 50);
});
document.getElementById('cust-q').addEventListener('input', custSearch);
document.getElementById('cust-cancel').addEventListener('click', function () { document.getElementById('dlg-cust').close(); });
document.getElementById('cust-use').addEventListener('click', function () {
	var name = document.getElementById('cust-mname').value.trim();
	var phone = document.getElementById('cust-mphone').value.trim();
	var addr = document.getElementById('cust-maddr').value.trim();
	if (name || phone || addr) { setCust({ id: 0, name: name || 'Walk-in', phone: phone, address: addr }); }
	document.getElementById('dlg-cust').close();
});
document.getElementById('cust-clear').addEventListener('click', function (e) { e.preventDefault(); setCust(null); });
document.getElementById('print-80').addEventListener('click', function () {
	document.getElementById('dlg-print').close();
	if (pendingPrint) { printReceipt(pendingPrint.lines, pendingPrint.disc, pendingPrint.total, pendingPrint.method); pendingPrint = null; }
});
document.getElementById('print-a4').addEventListener('click', function () {
	document.getElementById('dlg-print').close();
	if (pendingPrint) { output(invoiceA4(pendingPrint.lines, pendingPrint.disc, pendingPrint.total, pendingPrint.method, pendingPrint.uuid, pendingPrint.cust), 'a4'); pendingPrint = null; }
});
document.getElementById('print-skip').addEventListener('click', function () { pendingPrint = null; document.getElementById('dlg-print').close(); });
document.getElementById('exch-cancel').addEventListener('click', cancelExchange);
document.getElementById('dlg-shift-ok').addEventListener('click', shiftOk);
document.getElementById('dlg-shift-cancel').addEventListener('click', function () { document.getElementById('dlg-shift').close(); });

function net() {
	var el = document.getElementById('net');
	el.textContent = navigator.onLine ? 'online' : 'offline';
	el.className = navigator.onLine ? '' : 'off';
	if (navigator.onLine) { sync(); refreshCatalog(); }
}
window.addEventListener('online', net);
window.addEventListener('offline', net);
setInterval(function () { if (navigator.onLine) { sync(); } }, 30000);

/* ---------- boot ---------- */
if ('serviceWorker' in navigator) { navigator.serviceWorker.register('/wceerp-pos/sw.js', { scope: '/wceerp-pos/' }).catch(function () {}); }
kvGet('shift').then(function (s) { shift = s || null; updateShiftBar(); });
loadCatalogFromDB().then(function () { net(); updateBadge(); updateHoldCount(); });
})();
</script>
</body>
</html>
		<?php
		exit;
	}
}
