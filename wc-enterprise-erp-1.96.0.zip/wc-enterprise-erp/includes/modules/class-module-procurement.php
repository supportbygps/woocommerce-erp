<?php
/**
 * Module: Procurement — RFQ, vendor comparison & purchase approvals.
 *
 * Flow:
 *   RFQ (items + quantities)
 *     → collect quotes from several suppliers (per-item unit prices)
 *     → comparison matrix, cheapest total highlighted
 *     → award: creates a draft PO at the quoted prices
 *   PO approval:
 *     → thresholds decide how many approval levels a PO needs
 *     → a PO cannot be received while approval is pending or rejected
 *       (gate lives in the Purchases module)
 *
 * Supplier performance combines hard numbers (spend, open POs, receipt
 * completion) with a manual 1–5 rating.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Procurement extends WCEERP_Module {

	protected $id         = 'procurement';
	protected $title      = 'Procurement';
	protected $capability = 'wceerp_manage_rfq';
	protected $tier       = 'business';
	protected $order      = 26;

	public function __construct() {
		$this->title = __( 'Procurement', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_rfq_save', array( $this, 'handle_rfq_save' ) );
		add_action( 'admin_post_wceerp_rfq_quote_save', array( $this, 'handle_quote_save' ) );
		add_action( 'admin_post_wceerp_rfq_award', array( $this, 'handle_award' ) );
		add_action( 'admin_post_wceerp_purchase_approve', array( $this, 'handle_approve' ) );
		add_action( 'admin_post_wceerp_approval_settings', array( $this, 'handle_settings' ) );
		add_action( 'admin_post_wceerp_supplier_rate', array( $this, 'handle_rate' ) );
	}

	/* ---------------------------------------------------------------------
	 * Approval engine (called from the Purchases module).
	 * ------------------------------------------------------------------- */

	/**
	 * Number of approval levels a PO of this value needs (0, 1 or 2).
	 */
	public static function required_levels( $grand_total ) {
		$l1 = (float) wceerp_get_option( 'approval_threshold_l1', 0 );
		$l2 = (float) wceerp_get_option( 'approval_threshold_l2', 0 );
		$levels = 0;
		if ( $l1 > 0 && $grand_total >= $l1 ) {
			$levels = 1;
		}
		if ( $l2 > 0 && $grand_total >= $l2 ) {
			$levels = 2;
		}
		return $levels;
	}

	/**
	 * Attach approval requirements to a freshly created PO.
	 */
	public static function after_po_created( $purchase_id ) {
		global $wpdb;
		$purchases = wceerp_table( 'purchases' );
		$purchase  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $purchases WHERE id=%d", $purchase_id ) );
		if ( ! $purchase ) {
			return;
		}
		$levels = self::required_levels( (float) $purchase->grand_total );
		if ( $levels < 1 ) {
			return;
		}
		for ( $level = 1; $level <= $levels; $level++ ) {
			$wpdb->insert( wceerp_table( 'purchase_approvals' ), array(
				'purchase_id' => $purchase_id,
				'level'       => $level,
				'status'      => 'pending',
				'created_at'  => current_time( 'mysql' ),
			) );
		}
		$wpdb->update( $purchases, array( 'approval_status' => 'pending' ), array( 'id' => $purchase_id ) );

		if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'procurement',
				sprintf( __( 'PO %s needs approval', 'wc-enterprise-erp' ), $purchase->doc_no ),
				sprintf( __( '%1$s — %2$d approval level(s) required.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $purchase->grand_total ) ), $levels ),
				admin_url( 'admin.php?page=wceerp-procurement&tab=approvals' )
			);
		}
		wceerp_log( 'procurement', 'approval_required', $purchase_id, "levels: $levels" );
	}

	public function handle_approve() {
		if ( ! wceerp_user_can( 'wceerp_approve_purchases' ) ) {
			wp_die( esc_html__( 'You are not allowed to approve purchases.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_purchase_approve' );
		global $wpdb;
		$approvals = wceerp_table( 'purchase_approvals' );
		$purchases = wceerp_table( 'purchases' );

		$approval_id = (int) ( $_POST['approval_id'] ?? 0 );
		$decision    = 'reject' === ( $_POST['decision'] ?? '' ) ? 'rejected' : 'approved';
		$row         = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $approvals WHERE id=%d AND status='pending'", $approval_id ) );
		if ( ! $row ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'approvals' ) ) );
			exit;
		}

		/* Levels approve in order: level 2 waits for level 1. */
		$earlier_open = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $approvals WHERE purchase_id=%d AND level < %d AND status <> 'approved'",
			$row->purchase_id, $row->level
		) );
		if ( $earlier_open && 'approved' === $decision ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'approvals', 'error' => 'order' ) ) );
			exit;
		}

		$wpdb->update( $approvals, array(
			'status'   => $decision,
			'user_id'  => get_current_user_id(),
			'note'     => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'acted_at' => current_time( 'mysql' ),
		), array( 'id' => $approval_id ) );

		if ( 'rejected' === $decision ) {
			$wpdb->update( $purchases, array( 'approval_status' => 'rejected' ), array( 'id' => $row->purchase_id ) );
		} else {
			$open = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $approvals WHERE purchase_id=%d AND status='pending'", $row->purchase_id ) );
			if ( ! $open ) {
				$wpdb->update( $purchases, array( 'approval_status' => 'approved' ), array( 'id' => $row->purchase_id ) );
			}
		}

		wceerp_log( 'procurement', 'approval_' . $decision, (int) $row->purchase_id, 'level ' . $row->level );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'approvals', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_settings() {
		$this->verify_nonce( 'wceerp_approval_settings' );
		wceerp_update_option( 'approval_threshold_l1', wceerp_dec( $_POST['threshold_l1'] ?? 0 ) );
		wceerp_update_option( 'approval_threshold_l2', wceerp_dec( $_POST['threshold_l2'] ?? 0 ) );
		wceerp_log( 'procurement', 'settings_save' );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'approvals', 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * RFQ handlers.
	 * ------------------------------------------------------------------- */

	public function handle_rfq_save() {
		$this->verify_nonce( 'wceerp_rfq_save' );
		global $wpdb;

		$title    = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
		$products = array_map( 'intval', (array) ( $_POST['item_product'] ?? array() ) );
		$qtys     = array_map( 'wceerp_dec', (array) ( $_POST['item_qty'] ?? array() ) );
		$specs    = array_map( 'sanitize_text_field', (array) ( $_POST['item_spec'] ?? array() ) );

		$items = array();
		foreach ( $products as $i => $pid ) {
			if ( $pid && $qtys[ $i ] > 0 ) {
				$items[] = array( 'product_id' => $pid, 'qty' => $qtys[ $i ], 'spec' => $specs[ $i ] ?? '' );
			}
		}
		if ( ! $title || ! $items ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'new', 'error' => 'incomplete' ) ) );
			exit;
		}

		$wpdb->insert( wceerp_table( 'rfqs' ), array(
			'doc_no'     => wceerp_next_doc_number( 'rfq' ),
			'title'      => $title,
			'needed_by'  => ! empty( $_POST['needed_by'] ) ? sanitize_text_field( $_POST['needed_by'] ) : null,
			'status'     => 'open',
			'note'       => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_by' => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		) );
		$rfq_id = (int) $wpdb->insert_id;

		foreach ( $items as $item ) {
			$item['rfq_id'] = $rfq_id;
			$wpdb->insert( wceerp_table( 'rfq_items' ), $item );
		}

		wceerp_log( 'procurement', 'rfq_create', $rfq_id );
		wp_safe_redirect( $this->admin_url( array( 'view' => $rfq_id, 'updated' => 1 ) ) );
		exit;
	}

	public function handle_quote_save() {
		$this->verify_nonce( 'wceerp_rfq_quote_save' );
		global $wpdb;

		$rfq_id   = (int) ( $_POST['rfq_id'] ?? 0 );
		$supplier = (int) ( $_POST['supplier_id'] ?? 0 );
		$rfq      = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfqs' ) . ' WHERE id=%d', $rfq_id ) );
		if ( ! $rfq || 'open' !== $rfq->status || ! $supplier ) {
			wp_safe_redirect( $this->admin_url() );
			exit;
		}

		$items  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfq_items' ) . ' WHERE rfq_id=%d', $rfq_id ) );
		$prices = (array) ( $_POST['price'] ?? array() );
		$total  = 0;
		$rows   = array();
		foreach ( $items as $item ) {
			$price = wceerp_dec( $prices[ $item->id ] ?? 0 );
			$total += $price * (float) $item->qty;
			$rows[] = array( 'rfq_item_id' => (int) $item->id, 'unit_price' => $price );
		}

		$wpdb->insert( wceerp_table( 'rfq_quotes' ), array(
			'rfq_id'        => $rfq_id,
			'supplier_id'   => $supplier,
			'quote_date'    => sanitize_text_field( $_POST['quote_date'] ?? current_time( 'Y-m-d' ) ),
			'valid_until'   => ! empty( $_POST['valid_until'] ) ? sanitize_text_field( $_POST['valid_until'] ) : null,
			'delivery_days' => (int) ( $_POST['delivery_days'] ?? 0 ),
			'total'         => $total,
			'note'          => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'    => current_time( 'mysql' ),
		) );
		$quote_id = (int) $wpdb->insert_id;

		foreach ( $rows as $row ) {
			$row['quote_id'] = $quote_id;
			$wpdb->insert( wceerp_table( 'rfq_quote_items' ), $row );
		}

		wceerp_log( 'procurement', 'quote_add', $rfq_id, 'supplier ' . $supplier );
		wp_safe_redirect( $this->admin_url( array( 'view' => $rfq_id, 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Award a quote → create a PO at the quoted prices.
	 * The PO enters the normal purchases pipeline (incl. approval gates).
	 */
	public function handle_award() {
		$this->verify_nonce( 'wceerp_rfq_award' );
		global $wpdb;

		$quote_id  = (int) ( $_POST['quote_id'] ?? 0 );
		$warehouse = (int) ( $_POST['warehouse_id'] ?? 0 );
		$quote     = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfq_quotes' ) . ' WHERE id=%d', $quote_id ) );
		$rfq       = $quote ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfqs' ) . ' WHERE id=%d', $quote->rfq_id ) ) : null;
		if ( ! $quote || ! $rfq || 'open' !== $rfq->status || ! $warehouse ) {
			wp_safe_redirect( $this->admin_url() );
			exit;
		}

		$items  = $wpdb->get_results( $wpdb->prepare(
			'SELECT qi.unit_price, ri.product_id, ri.qty
			 FROM ' . wceerp_table( 'rfq_quote_items' ) . ' qi
			 INNER JOIN ' . wceerp_table( 'rfq_items' ) . ' ri ON ri.id = qi.rfq_item_id
			 WHERE qi.quote_id=%d', $quote_id
		) );

		$subtotal = 0;
		foreach ( $items as $item ) {
			$subtotal += (float) $item->unit_price * (float) $item->qty;
		}

		$wpdb->insert( wceerp_table( 'purchases' ), array(
			'doc_no'        => wceerp_next_doc_number( 'po' ),
			'supplier_id'   => (int) $quote->supplier_id,
			'warehouse_id'  => $warehouse,
			'status'        => 'ordered',
			'subtotal'      => $subtotal,
			'tax_total'     => 0,
			'discount'      => 0,
			'shipping'      => 0,
			'grand_total'   => $subtotal,
			'purchase_date' => current_time( 'Y-m-d' ),
			'note'          => sprintf( 'Awarded from %s — %s', $rfq->doc_no, $rfq->title ),
			'created_by'    => get_current_user_id(),
			'created_at'    => current_time( 'mysql' ),
		) );
		$purchase_id = (int) $wpdb->insert_id;

		foreach ( $items as $item ) {
			$wpdb->insert( wceerp_table( 'purchase_items' ), array(
				'purchase_id' => $purchase_id,
				'product_id'  => (int) $item->product_id,
				'qty'         => (float) $item->qty,
				'unit_cost'   => (float) $item->unit_price,
				'tax_rate'    => 0,
				'line_total'  => (float) $item->unit_price * (float) $item->qty,
			) );
		}

		self::after_po_created( $purchase_id );

		$wpdb->update( wceerp_table( 'rfqs' ), array( 'status' => 'awarded', 'awarded_quote_id' => $quote_id ), array( 'id' => $rfq->id ) );
		wceerp_log( 'procurement', 'award', $rfq->id, 'quote ' . $quote_id . ' → PO ' . $purchase_id );
		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-purchases&view=' . $purchase_id . '&updated=1' ) );
		exit;
	}

	public function handle_rate() {
		$this->verify_nonce( 'wceerp_supplier_rate' );
		global $wpdb;
		$supplier = (int) ( $_POST['supplier_id'] ?? 0 );
		if ( $supplier ) {
			$wpdb->update( wceerp_table( 'suppliers' ), array(
				'rating'      => max( 0, min( 5, (int) ( $_POST['rating'] ?? 0 ) ) ),
				'rating_note' => sanitize_text_field( wp_unslash( $_POST['rating_note'] ?? '' ) ),
			), array( 'id' => $supplier ) );
			wceerp_log( 'procurement', 'supplier_rate', $supplier );
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'performance', 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$tab  = sanitize_key( $_GET['tab'] ?? 'rfqs' );
		$view = (int) ( $_GET['view'] ?? 0 );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Procurement', 'wc-enterprise-erp' ) ) ); ?></h1>
			<nav class="nav-tab-wrapper">
				<?php
				$tabs = array(
					'rfqs'        => __( 'RFQs', 'wc-enterprise-erp' ),
					'new'         => __( 'New RFQ', 'wc-enterprise-erp' ),
					'approvals'   => __( 'PO approvals', 'wc-enterprise-erp' ),
					'performance' => __( 'Supplier performance', 'wc-enterprise-erp' ),
				);
				foreach ( $tabs as $slug => $label ) {
					printf( '<a href="%s" class="nav-tab %s">%s</a>', esc_url( $this->admin_url( array( 'tab' => $slug ) ) ), ( $tab === $slug && ! $view ) ? 'nav-tab-active' : '', esc_html( $label ) );
				}
				?>
			</nav>
			<?php
			if ( ! empty( $_GET['updated'] ) ) {
				$this->notice( __( 'Saved.', 'wc-enterprise-erp' ) );
			}
			if ( ! empty( $_GET['error'] ) && 'order' === $_GET['error'] ) {
				$this->notice( __( 'Level 1 must approve before level 2.', 'wc-enterprise-erp' ), 'error' );
			}
			if ( $view ) {
				$this->render_rfq_view( $view );
			} elseif ( 'new' === $tab ) {
				$this->render_rfq_form();
			} elseif ( 'approvals' === $tab ) {
				$this->render_approvals();
			} elseif ( 'performance' === $tab ) {
				$this->render_performance();
			} else {
				$this->render_rfq_list();
			}
			?>
		</div>
		<?php
	}

	protected function render_rfq_list() {
		global $wpdb;
		$table    = wceerp_table( 'rfqs' );
		$per_page = 25;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$rows     = $wpdb->get_results( $wpdb->prepare( "SELECT r.*, (SELECT COUNT(*) FROM " . wceerp_table( 'rfq_quotes' ) . " q WHERE q.rfq_id=r.id) AS quotes FROM $table r ORDER BY r.id DESC LIMIT %d OFFSET %d", $per_page, wceerp_offset( $per_page ) ) );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'RFQ no.', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Title', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Needed by', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Quotes', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'No RFQs yet — create one and collect quotes from your suppliers.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( (array) $rows as $rfq ) : ?>
				<tr>
					<td><code><?php echo esc_html( $rfq->doc_no ); ?></code></td>
					<td><strong><?php echo esc_html( $rfq->title ); ?></strong></td>
					<td><?php echo esc_html( $rfq->needed_by ?: '—' ); ?></td>
					<td class="num"><?php echo (int) $rfq->quotes; ?></td>
					<td><span class="wceerp-badge is-<?php echo esc_attr( $rfq->status ); ?>"><?php echo esc_html( $rfq->status ); ?></span></td>
					<td><a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'view' => $rfq->id ) ) ); ?>"><?php esc_html_e( 'Open', 'wc-enterprise-erp' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}

	protected function render_rfq_form() {
		?>
		<div class="wceerp-card" style="max-width:760px">
			<h2><?php esc_html_e( 'New request for quotation', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_rfq_save">
				<?php wp_nonce_field( 'wceerp_rfq_save' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Title', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="title" class="regular-text" required placeholder="<?php esc_attr_e( 'e.g. Eid stock — polo shirts', 'wc-enterprise-erp' ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Needed by', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="needed_by"></td></tr>
					<tr><th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th>
						<td><textarea name="note" rows="2" class="large-text"></textarea></td></tr>
				</tbody></table>

				<h3><?php esc_html_e( 'Items', 'wc-enterprise-erp' ); ?></h3>
				<table class="widefat wceerp-lines" id="wceerp-rfq-lines">
					<thead><tr>
						<th style="width:50%"><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Spec / note', 'wc-enterprise-erp' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
						<tr class="wceerp-line">
							<td><?php wceerp_product_select( 'item_product[]' ); ?></td>
							<td><input type="number" step="0.01" min="0" name="item_qty[]" value="1"></td>
							<td><input type="text" name="item_spec[]"></td>
							<td><button type="button" class="button-link wceerp-remove-line">&times;</button></td>
						</tr>
					</tbody>
				</table>
				<p><button type="button" class="button wceerp-add-line" data-target="#wceerp-rfq-lines"><?php esc_html_e( '+ Add item', 'wc-enterprise-erp' ); ?></button></p>
				<?php submit_button( __( 'Create RFQ', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_rfq_view( $rfq_id ) {
		global $wpdb;
		$rfq = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfqs' ) . ' WHERE id=%d', $rfq_id ) );
		if ( ! $rfq ) {
			echo '<p>' . esc_html__( 'RFQ not found.', 'wc-enterprise-erp' ) . '</p>';
			return;
		}
		$items  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfq_items' ) . ' WHERE rfq_id=%d ORDER BY id', $rfq_id ) );
		$quotes = $wpdb->get_results( $wpdb->prepare(
			'SELECT q.*, s.name AS supplier_name FROM ' . wceerp_table( 'rfq_quotes' ) . ' q
			 INNER JOIN ' . wceerp_table( 'suppliers' ) . ' s ON s.id = q.supplier_id
			 WHERE q.rfq_id=%d ORDER BY q.total ASC', $rfq_id
		) );
		$quote_items = array();
		foreach ( $quotes as $quote ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'rfq_quote_items' ) . ' WHERE quote_id=%d', $quote->id ) );
			foreach ( $rows as $row ) {
				$quote_items[ $quote->id ][ $row->rfq_item_id ] = (float) $row->unit_price;
			}
		}
		$suppliers  = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'suppliers' ) . " WHERE status='active' ORDER BY name" );
		$warehouses = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'warehouses' ) . ' ORDER BY is_default DESC, name' );
		$best       = $quotes ? (float) $quotes[0]->total : 0;
		?>
		<div class="wceerp-card">
			<h2><?php echo esc_html( $rfq->doc_no . ' — ' . $rfq->title ); ?>
				<span class="wceerp-badge is-<?php echo esc_attr( $rfq->status ); ?>"><?php echo esc_html( $rfq->status ); ?></span></h2>
			<?php if ( $rfq->needed_by ) : ?><p class="description"><?php printf( esc_html__( 'Needed by %s', 'wc-enterprise-erp' ), esc_html( $rfq->needed_by ) ); ?></p><?php endif; ?>

			<h3><?php esc_html_e( 'Vendor comparison', 'wc-enterprise-erp' ); ?></h3>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Item', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
					<?php foreach ( $quotes as $quote ) : ?>
						<th class="num"><?php echo esc_html( $quote->supplier_name ); ?><br>
							<small><?php printf( esc_html__( '%d day delivery', 'wc-enterprise-erp' ), (int) $quote->delivery_days ); ?></small></th>
					<?php endforeach; ?>
				</tr></thead>
				<tbody>
				<?php foreach ( $items as $item ) :
					$product = function_exists( 'wc_get_product' ) ? wc_get_product( $item->product_id ) : null;
					?>
					<tr>
						<td><?php echo esc_html( $product ? $product->get_name() : ( 'Product #' . $item->product_id ) ); ?>
							<?php if ( $item->spec ) : ?><br><small><?php echo esc_html( $item->spec ); ?></small><?php endif; ?></td>
						<td class="num"><?php echo esc_html( wceerp_dec( $item->qty ) ); ?></td>
						<?php foreach ( $quotes as $quote ) : ?>
							<td class="num"><?php echo isset( $quote_items[ $quote->id ][ $item->id ] ) ? wp_kses_post( wceerp_money( $quote_items[ $quote->id ][ $item->id ] ) ) : '—'; ?></td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr>
					<th colspan="2"><?php esc_html_e( 'Quote total', 'wc-enterprise-erp' ); ?></th>
					<?php foreach ( $quotes as $quote ) : ?>
						<th class="num" <?php echo ( $best && abs( (float) $quote->total - $best ) < 0.005 ) ? 'style="color:#00701f"' : ''; ?>>
							<?php echo wp_kses_post( wceerp_money( $quote->total ) ); ?>
							<?php if ( 'open' === $rfq->status ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:6px">
								<input type="hidden" name="action" value="wceerp_rfq_award">
								<input type="hidden" name="quote_id" value="<?php echo (int) $quote->id; ?>">
								<?php wp_nonce_field( 'wceerp_rfq_award' ); ?>
								<select name="warehouse_id" style="max-width:120px">
									<?php foreach ( $warehouses as $warehouse ) : ?>
										<option value="<?php echo (int) $warehouse->id; ?>"><?php echo esc_html( $warehouse->name ); ?></option>
									<?php endforeach; ?>
								</select>
								<button class="button button-small button-primary wceerp-confirm" data-confirm="<?php esc_attr_e( 'Award this quote and create the PO?', 'wc-enterprise-erp' ); ?>"><?php esc_html_e( 'Award → PO', 'wc-enterprise-erp' ); ?></button>
							</form>
							<?php elseif ( (int) $rfq->awarded_quote_id === (int) $quote->id ) : ?>
								<br><span class="wceerp-badge is-completed"><?php esc_html_e( 'awarded', 'wc-enterprise-erp' ); ?></span>
							<?php endif; ?>
						</th>
					<?php endforeach; ?>
				</tr></tfoot>
			</table>
			<?php if ( ! $quotes ) : ?><p><?php esc_html_e( 'No quotes yet — add the first one below.', 'wc-enterprise-erp' ); ?></p><?php endif; ?>
		</div>

		<?php if ( 'open' === $rfq->status ) : ?>
		<div class="wceerp-card" style="max-width:760px">
			<h3><?php esc_html_e( 'Add a supplier quote', 'wc-enterprise-erp' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_rfq_quote_save">
				<input type="hidden" name="rfq_id" value="<?php echo (int) $rfq_id; ?>">
				<?php wp_nonce_field( 'wceerp_rfq_quote_save' ); ?>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
						<td><select name="supplier_id" required>
							<?php foreach ( $suppliers as $supplier ) : ?>
								<option value="<?php echo (int) $supplier->id; ?>"><?php echo esc_html( $supplier->name ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Quote date', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="quote_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>">
							&nbsp; <?php esc_html_e( 'Valid until', 'wc-enterprise-erp' ); ?> <input type="date" name="valid_until">
							&nbsp; <?php esc_html_e( 'Delivery days', 'wc-enterprise-erp' ); ?> <input type="number" name="delivery_days" min="0" value="3" style="width:70px"></td></tr>
				</tbody></table>
				<table class="widefat wceerp-lines">
					<thead><tr><th><?php esc_html_e( 'Item', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Unit price', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $items as $item ) :
						$product = function_exists( 'wc_get_product' ) ? wc_get_product( $item->product_id ) : null;
						?>
						<tr>
							<td><?php echo esc_html( $product ? $product->get_name() : ( 'Product #' . $item->product_id ) ); ?></td>
							<td class="num"><?php echo esc_html( wceerp_dec( $item->qty ) ); ?></td>
							<td><input type="number" step="0.0001" min="0" name="price[<?php echo (int) $item->id; ?>]" required></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p><input type="text" name="note" class="regular-text" placeholder="<?php esc_attr_e( 'Terms, warranty…', 'wc-enterprise-erp' ); ?>"></p>
				<?php submit_button( __( 'Save quote', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php endif; ?>
		<?php
	}

	protected function render_approvals() {
		global $wpdb;
		$approvals = wceerp_table( 'purchase_approvals' );
		$purchases = wceerp_table( 'purchases' );

		$pending = $wpdb->get_results(
			"SELECT a.*, p.doc_no, p.grand_total, p.purchase_date, s.name AS supplier_name
			 FROM $approvals a
			 INNER JOIN $purchases p ON p.id = a.purchase_id
			 LEFT JOIN " . wceerp_table( 'suppliers' ) . " s ON s.id = p.supplier_id
			 WHERE a.status = 'pending'
			 ORDER BY a.purchase_id, a.level LIMIT 100"
		);
		$can_approve = wceerp_user_can( 'wceerp_approve_purchases' );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Waiting for approval', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'PO', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Level', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Decision', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $pending ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'Nothing waiting — all purchases are cleared.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $pending as $row ) : ?>
						<tr>
							<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=wceerp-purchases&view=' . (int) $row->purchase_id ) ); ?>"><code><?php echo esc_html( $row->doc_no ); ?></code></a><br><small><?php echo esc_html( $row->purchase_date ); ?></small></td>
							<td><?php echo esc_html( $row->supplier_name ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $row->grand_total ) ); ?></td>
							<td><span class="wceerp-badge"><?php printf( esc_html__( 'Level %d', 'wc-enterprise-erp' ), (int) $row->level ); ?></span></td>
							<td>
							<?php if ( $can_approve ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;align-items:center;flex-wrap:wrap">
									<input type="hidden" name="action" value="wceerp_purchase_approve">
									<input type="hidden" name="approval_id" value="<?php echo (int) $row->id; ?>">
									<?php wp_nonce_field( 'wceerp_purchase_approve' ); ?>
									<input type="text" name="note" placeholder="<?php esc_attr_e( 'note', 'wc-enterprise-erp' ); ?>" style="width:110px">
									<button class="button button-small button-primary" name="decision" value="approve"><?php esc_html_e( 'Approve', 'wc-enterprise-erp' ); ?></button>
									<button class="button button-small wceerp-danger" name="decision" value="reject"><?php esc_html_e( 'Reject', 'wc-enterprise-erp' ); ?></button>
								</form>
							<?php else : ?>
								<em><?php esc_html_e( 'No approval permission', 'wc-enterprise-erp' ); ?></em>
							<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Approval thresholds', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'POs at or above Level 1 need one approval; at or above Level 2 they need two, in order. Set 0 to disable a level. Users approve with the "Approve purchase orders" permission.', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_approval_settings">
					<?php wp_nonce_field( 'wceerp_approval_settings' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Level 1 from', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" step="0.01" min="0" name="threshold_l1" value="<?php echo esc_attr( wceerp_get_option( 'approval_threshold_l1', 0 ) ); ?>"></td></tr>
						<tr><th><?php esc_html_e( 'Level 2 from', 'wc-enterprise-erp' ); ?></th>
							<td><input type="number" step="0.01" min="0" name="threshold_l2" value="<?php echo esc_attr( wceerp_get_option( 'approval_threshold_l2', 0 ) ); ?>"></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Save thresholds', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	protected function render_performance() {
		global $wpdb;
		$suppliers = wceerp_table( 'suppliers' );
		$purchases = wceerp_table( 'purchases' );

		$rows = $wpdb->get_results(
			"SELECT s.id, s.name, s.company, s.rating, s.rating_note,
			        COUNT(p.id) AS po_count,
			        COALESCE(SUM(p.grand_total),0) AS spend,
			        SUM(p.status = 'received') AS completed,
			        SUM(p.status IN ('ordered','partial')) AS open_pos
			 FROM $suppliers s
			 LEFT JOIN $purchases p ON p.supplier_id = s.id AND p.status <> 'cancelled'
			 WHERE s.status = 'active'
			 GROUP BY s.id ORDER BY spend DESC LIMIT 100"
		);
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Supplier performance', 'wc-enterprise-erp' ); ?></h2>
			<table class="widefat striped wceerp-table">
				<thead><tr>
					<th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'POs', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Total spend', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Completed', 'wc-enterprise-erp' ); ?></th>
					<th class="num"><?php esc_html_e( 'Open', 'wc-enterprise-erp' ); ?></th>
					<th><?php esc_html_e( 'Rating', 'wc-enterprise-erp' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( (array) $rows as $row ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $row->name ); ?></strong><?php echo $row->company ? '<br><small>' . esc_html( $row->company ) . '</small>' : ''; ?></td>
						<td class="num"><?php echo (int) $row->po_count; ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $row->spend ) ); ?></td>
						<td class="num"><?php echo (int) $row->completed; ?></td>
						<td class="num"><?php echo (int) $row->open_pos; ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;align-items:center;flex-wrap:wrap">
								<input type="hidden" name="action" value="wceerp_supplier_rate">
								<input type="hidden" name="supplier_id" value="<?php echo (int) $row->id; ?>">
								<?php wp_nonce_field( 'wceerp_supplier_rate' ); ?>
								<select name="rating">
									<?php for ( $star = 0; $star <= 5; $star++ ) : ?>
										<option value="<?php echo (int) $star; ?>" <?php selected( (int) $row->rating, $star ); ?>><?php echo esc_html( $star ? str_repeat( '★', $star ) : '—' ); ?></option>
									<?php endfor; ?>
								</select>
								<input type="text" name="rating_note" value="<?php echo esc_attr( $row->rating_note ); ?>" placeholder="<?php esc_attr_e( 'note', 'wc-enterprise-erp' ); ?>" style="width:110px">
								<button class="button button-small"><?php esc_html_e( 'Save', 'wc-enterprise-erp' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
