<?php
/**
 * Module: Inventory (multi-warehouse stock, adjustments, transfers).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Inventory extends WCEERP_Module {

	protected $id         = 'inventory';
	protected $title      = 'Inventory';
	protected $capability = 'wceerp_manage_inventory';
	protected $tier       = 'starter';
	protected $order      = 10;

	public function __construct() {
		$this->title = __( 'Inventory', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_stock_adjust', array( $this, 'handle_adjust' ) );
		add_action( 'admin_post_wceerp_stock_transfer', array( $this, 'handle_transfer' ) );
		add_action( 'admin_post_wceerp_stock_archive', array( $this, 'handle_archive' ) );
		add_action( 'admin_post_wceerp_stock_delete', array( $this, 'handle_delete' ) );
		add_action( 'admin_post_wceerp_stock_sync', array( $this, 'handle_sync' ) );
	}

	/* ------------------------------------------------------------------ */
	/*  Stock engine (used by purchases, sales bridge, manufacturing)      */
	/* ------------------------------------------------------------------ */

	/**
	 * Move stock in/out of a warehouse with moving-average costing.
	 *
	 * @return float Total cost of the movement (qty × unit cost) — used as COGS on 'out'.
	 */
	public static function move_stock( $product_id, $warehouse_id, $qty, $direction, $ref_type, $ref_id = 0, $unit_cost = null, $batch_id = null, $note = '' ) {
		global $wpdb;
		$table = wceerp_table( 'stock' );
		$qty   = abs( (float) $qty );

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table WHERE product_id = %d AND warehouse_id = %d",
			$product_id, $warehouse_id
		) );

		if ( ! $row ) {
			$wpdb->insert( $table, array(
				'product_id'   => (int) $product_id,
				'warehouse_id' => (int) $warehouse_id,
				'qty'          => 0,
				'avg_cost'     => 0,
			) );
			$row = (object) array( 'id' => $wpdb->insert_id, 'qty' => 0, 'avg_cost' => 0 );
		}

		$old_qty  = (float) $row->qty;
		$old_cost = (float) $row->avg_cost;

		if ( 'in' === $direction ) {
			$in_cost  = null !== $unit_cost ? (float) $unit_cost : $old_cost;
			$new_qty  = $old_qty + $qty;
			$new_cost = $new_qty > 0 ? ( ( $old_qty * $old_cost ) + ( $qty * $in_cost ) ) / $new_qty : $in_cost;
			$move_cost = $qty * $in_cost;
		} else {
			$new_qty   = $old_qty - $qty;
			$new_cost  = $old_cost;
			$move_cost = $qty * $old_cost;
		}

		$wpdb->update( $table, array( 'qty' => $new_qty, 'avg_cost' => round( $new_cost, 4 ) ), array( 'id' => $row->id ) );

		$wpdb->insert( wceerp_table( 'stock_moves' ), array(
			'product_id'   => (int) $product_id,
			'warehouse_id' => (int) $warehouse_id,
			'qty'          => $qty,
			'unit_cost'    => 'in' === $direction ? ( null !== $unit_cost ? (float) $unit_cost : $old_cost ) : $old_cost,
			'direction'    => $direction,
			'ref_type'     => sanitize_key( $ref_type ),
			'ref_id'       => (int) $ref_id,
			'batch_id'     => $batch_id ? (int) $batch_id : null,
			'note'         => sanitize_text_field( $note ),
			'user_id'      => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
		) );

		// Keep WooCommerce total stock in sync (sum across warehouses).
		self::sync_wc_stock( $product_id );

		// Low-stock notification.
		$threshold = (float) ( $row->reorder_level ?? 0 );
		if ( ! $threshold ) {
			$threshold = (float) wceerp_get_option( 'low_stock_threshold', 5 );
		}
		if ( 'out' === $direction && $new_qty <= $threshold && class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'low_stock',
				sprintf( __( 'Low stock: %s', 'wc-enterprise-erp' ), get_the_title( $product_id ) ),
				sprintf( __( 'Only %1$s left in warehouse #%2$d.', 'wc-enterprise-erp' ), $new_qty, $warehouse_id ),
				admin_url( 'admin.php?page=wceerp-inventory' )
			);
		}

		do_action( 'wceerp_stock_moved', $product_id, $warehouse_id, $qty, $direction, $ref_type, $ref_id );
		return round( $move_cost, 4 );
	}

	/** Push the ERP multi-warehouse total into WooCommerce's stock field. */
	public static function sync_wc_stock( $product_id ) {
		global $wpdb;
		$total   = (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(qty),0) FROM ' . wceerp_table( 'stock' ) . ' WHERE product_id = %d',
			$product_id
		) );
		$product = wc_get_product( $product_id );
		if ( $product && $product->managing_stock() ) {
			// Direct set to avoid re-triggering our own bridge hooks.
			wc_update_product_stock( $product, max( 0, (int) $total ), 'set' );
		}
	}

	public static function stock_of( $product_id, $warehouse_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT qty FROM ' . wceerp_table( 'stock' ) . ' WHERE product_id = %d AND warehouse_id = %d',
			$product_id, $warehouse_id
		) );
	}

	/* ------------------------------------------------------------------ */
	/*  Handlers                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * Why stock is being adjusted, and where the other side of the entry
	 * belongs.
	 *
	 * Everything used to post to Miscellaneous Expense, which is wrong in
	 * three different ways at once. Correcting stock that was never entered
	 * is not a cost — nothing was consumed, you are describing what you
	 * already had. Sending goods back to a supplier is not a cost either —
	 * it reduces what you owe. Only genuine loss is an expense.
	 *
	 * Posting all three to one expense account is what puts a figure like
	 * ৳8,30,854 into Miscellaneous and turns a profitable month into a
	 * reported loss.
	 *
	 * 'equity' means Opening Balance Equity: the account for "this is what
	 * was already here", which affects the balance sheet and leaves the
	 * profit and loss alone — exactly right for a shop entering its real
	 * stock for the first time.
	 */
	public static function adjust_reasons() {
		return apply_filters( 'wceerp_adjust_reasons', array(
			'opening' => array(
				'label'   => __( 'Correcting stock never entered before', 'wc-enterprise-erp' ),
				'help'    => __( 'Setting the ERP to what is actually on your shelf. Not a profit or a loss — it describes what you already owned, so it goes to Opening Balance Equity.', 'wc-enterprise-erp' ),
				'account' => '3200',
				'both'    => true,
			),
			'damage'  => array(
				'label'   => __( 'Damaged, spoiled or expired', 'wc-enterprise-erp' ),
				'help'    => __( 'Goods you can no longer sell. A real cost, recorded against Stock Loss so you can see spoilage month by month.', 'wc-enterprise-erp' ),
				'account' => '5550',
				'both'    => false,
			),
			'lost'    => array(
				'label'   => __( 'Lost, stolen or short on a count', 'wc-enterprise-erp' ),
				'help'    => __( 'Stock that should be there and is not. Also a real cost, and worth investigating if it recurs.', 'wc-enterprise-erp' ),
				'account' => '5550',
				'both'    => false,
			),
			'found'   => array(
				'label'   => __( 'Found — more stock than recorded', 'wc-enterprise-erp' ),
				'help'    => __( 'Usually an earlier count was wrong rather than goods appearing. Reverses against Stock Loss.', 'wc-enterprise-erp' ),
				'account' => '5550',
				'both'    => false,
			),
			'supplier' => array(
				'label'   => __( 'Returned to the supplier', 'wc-enterprise-erp' ),
				'help'    => __( 'Not a loss. The goods went back, so this reduces what you owe that supplier — choose which one, or it never reaches their account.', 'wc-enterprise-erp' ),
				'account' => '2000',
				'both'    => false,
				'party'   => 'supplier',
			),
			'other'   => array(
				'label'   => __( 'Something else', 'wc-enterprise-erp' ),
				'help'    => __( 'Goes to Miscellaneous. Write a note saying why, or it will be a mystery in three months.', 'wc-enterprise-erp' ),
				'account' => '5900',
				'both'    => false,
			),
		) );
	}

	public function handle_adjust() {
		$this->verify_nonce( 'wceerp_stock_adjust' );

		$product   = (int) $_POST['product_id'];
		$warehouse = (int) $_POST['warehouse_id'];
		$qty       = wceerp_dec( $_POST['qty'] );
		$direction = 'in' === $_POST['direction'] ? 'in' : 'out';
		$cost      = 'in' === $direction ? wceerp_dec( $_POST['unit_cost'] ) : null;
		$note      = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) );

		if ( $product && $warehouse && $qty > 0 ) {
			$reason_key   = sanitize_key( $_POST['reason'] ?? 'other' );
			$reason_all   = self::adjust_reasons();
			$reason_label = $reason_all[ $reason_key ]['label'] ?? __( 'Adjustment', 'wc-enterprise-erp' );

			/* The reason travels with the movement, so the adjustment
			 * history can be read months later without guesswork. */
			$move_note = $note ? $reason_label . ' — ' . $note : $reason_label;

			$value = self::move_stock( $product, $warehouse, $qty, $direction, 'adjustment', 0, $cost, null, $move_note );

			/* Post to the ledger so stock value and books agree — against
			 * the account the reason actually calls for, not a catch-all. */
			$reasons = self::adjust_reasons();
			$reason  = sanitize_key( $_POST['reason'] ?? 'other' );
			if ( ! isset( $reasons[ $reason ] ) ) {
				$reason = 'other';
			}

			$inv  = WCEERP_Accounting::account_by_subtype( 'inventory' );
			$misc = WCEERP_Accounting::resolve_account( $reasons[ $reason ]['account'] );

			/* A supplier return has to name the supplier.
			 *
			 * Posting to a general account left the value floating: the books
			 * balanced, but the supplier's ledger never moved, so what you
			 * owed them stayed too high and nothing recorded the return. */
			$party_type = $reasons[ $reason ]['party'] ?? '';
			$party_id   = (int) ( $_POST['supplier_id'] ?? 0 );

			if ( 'supplier' === $party_type && ! $party_id ) {
				$this->notice_redirect(
					'error',
					__( 'Choose which supplier the goods went back to, or the return never reaches their account and you will still appear to owe for it.', 'wc-enterprise-erp' )
				);
			}

			// A missing account must not silently swallow the entry.
			if ( ! $misc ) {
				$misc = WCEERP_Accounting::resolve_account( '5900' );
			}
			if ( $inv && $misc && $value > 0 ) {
				/* Attach the supplier where the reason calls for one, so the
				 * value lands on their ledger rather than floating in a
				 * general account. */
				$counter = array( 'account' => $misc );
				if ( $party_type && $party_id ) {
					$counter['party_type'] = $party_type;
					$counter['party_id']   = $party_id;
				}

				$lines = 'in' === $direction
					? array(
						array( 'account' => $inv->id, 'debit' => $value, 'memo' => $move_note ),
						array_merge( $counter, array( 'credit' => $value, 'memo' => $move_note ) ),
					)
					: array(
						array_merge( $counter, array( 'debit' => $value, 'memo' => $move_note ) ),
						array( 'account' => $inv->id, 'credit' => $value, 'memo' => $move_note ),
					);
				WCEERP_Accounting::post(
					array(
						'ref_type' => 'stock_adjustment',
						'memo'     => $move_note,
					),
					$lines
				);
			}
			wceerp_log( 'inventory', 'adjust', $product, $direction . ' ' . $qty );
		}

		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function handle_transfer() {
		$this->verify_nonce( 'wceerp_stock_transfer' );

		$product = (int) $_POST['product_id'];
		$from    = (int) $_POST['from_warehouse'];
		$to      = (int) $_POST['to_warehouse'];
		$qty     = wceerp_dec( $_POST['qty'] );

		if ( $product && $from && $to && $from !== $to && $qty > 0 ) {
			if ( self::stock_of( $product, $from ) < $qty ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'insufficient' ) ) );
				exit;
			}
			global $wpdb;
			$cost = (float) $wpdb->get_var( $wpdb->prepare(
				'SELECT avg_cost FROM ' . wceerp_table( 'stock' ) . ' WHERE product_id=%d AND warehouse_id=%d',
				$product, $from
			) );
			self::move_stock( $product, $from, $qty, 'out', 'transfer', $to );
			self::move_stock( $product, $to, $qty, 'in', 'transfer', $from, $cost );
			wceerp_log( 'inventory', 'transfer', $product, "$qty from WH$from to WH$to" );
		}

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'transfer', 'updated' => 1 ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/*  Screens                                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * Products being sold with no cost basis.
	 *
	 * A product only gains an average cost when stock is received. Sell one
	 * that never was and COGS posts as zero — revenue lands in full, cost
	 * lands as nothing, and the profit figure is fiction. It is silent,
	 * which is what makes it dangerous: the books look healthy while the
	 * margin is meaningless.
	 *
	 * @return array Rows of product_id => qty sold at zero cost.
	 */
	public static function zero_cost_sales( $limit = 50 ) {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare(
			'SELECT m.product_id, SUM(m.qty) AS qty, COUNT(*) AS moves
			 FROM ' . wceerp_table( 'stock_moves' ) . " m
			 WHERE m.direction = 'out' AND m.unit_cost <= 0
			 GROUP BY m.product_id
			 ORDER BY qty DESC
			 LIMIT %d",
			(int) $limit
		) );
	}

	/** Stock rows sitting below zero — sold more than was ever received. */
	public static function negative_stock() {
		global $wpdb;
		return (array) $wpdb->get_results(
			'SELECT s.*, p.post_title AS product
			 FROM ' . wceerp_table( 'stock' ) . ' s
			 LEFT JOIN ' . $wpdb->posts . ' p ON p.ID = s.product_id
			 WHERE s.qty < 0
			 ORDER BY s.qty ASC'
		);
	}

	/* ---------------------------------------------------------------------
	 * Product lifecycle: archive, guarded delete, and WooCommerce sync.
	 *
	 * Deleting a product that already carries history would orphan ledger
	 * and movement rows, so a hard delete is only ever allowed when the
	 * product has zero transactions anywhere. Everything else archives.
	 * ------------------------------------------------------------------- */

	/** Tables that constitute "this product has history". */
	protected static function txn_tables() {
		return apply_filters( 'wceerp_product_txn_tables', array(
			'stock_moves'     => __( 'stock movements', 'wc-enterprise-erp' ),
			'purchase_items'  => __( 'purchase lines', 'wc-enterprise-erp' ),
			'quotation_items' => __( 'quotation lines', 'wc-enterprise-erp' ),
			'rfq_items'       => __( 'RFQ lines', 'wc-enterprise-erp' ),
			'batches'         => __( 'batches', 'wc-enterprise-erp' ),
			'serials'         => __( 'serial numbers', 'wc-enterprise-erp' ),
			'boms'            => __( 'bills of material', 'wc-enterprise-erp' ),
			'connect_costs'   => __( 'connected-store costs', 'wc-enterprise-erp' ),
		) );
	}

	/**
	 * Count every transactional reference to a product.
	 *
	 * @return array Map of human label => row count, only for non-zero counts.
	 */
	public static function txn_references( $product_id ) {
		global $wpdb;
		$product_id = (int) $product_id;
		$found      = array();
		foreach ( self::txn_tables() as $table => $label ) {
			$name = wceerp_table( $table );
			// Guard against tables a given install may not have yet.
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) !== $name ) {
				continue;
			}
			$n = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM {$name} WHERE product_id = %d", $product_id
			) );
			if ( $n > 0 ) {
				$found[ $label ] = $n;
			}
		}
		return $found;
	}

	/** True when the product has no history and may be hard-deleted. */
	public static function can_delete( $product_id ) {
		return ! self::txn_references( $product_id );
	}

	/** Count ERP stock rows whose WooCommerce product no longer exists. */
	public static function orphan_count() {
		global $wpdb;
		return (int) $wpdb->get_var(
			'SELECT COUNT(*) FROM ' . wceerp_table( 'stock' ) . ' s
			 LEFT JOIN ' . $wpdb->posts . " p ON p.ID = s.product_id
			 WHERE p.ID IS NULL"
		);
	}

	public function handle_archive() {
		$this->verify_nonce( 'wceerp_stock_archive' );
		global $wpdb;
		$id     = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$status = ( isset( $_POST['to'] ) && 'active' === $_POST['to'] ) ? 'active' : 'archived';
		if ( $id ) {
			$wpdb->update( wceerp_table( 'stock' ), array( 'status' => $status ), array( 'id' => $id ) );
			wceerp_log( 'inventory', 'product_' . $status, $id );
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'stock', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_delete() {
		$this->verify_nonce( 'wceerp_stock_delete' );
		global $wpdb;
		$id  = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$row = $id ? $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'stock' ) . ' WHERE id = %d', $id
		) ) : null;

		if ( ! $row ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'stock', 'error' => 'missing' ) ) );
			exit;
		}

		$refs = self::txn_references( $row->product_id );
		if ( $refs ) {
			// Has history: refuse the delete and archive instead.
			$wpdb->update( wceerp_table( 'stock' ), array( 'status' => 'archived' ), array( 'id' => $id ) );
			wceerp_log( 'inventory', 'delete_blocked', $id, 'Has transactions; archived instead.' );
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'stock', 'blocked' => 1 ) ) );
			exit;
		}

		$wpdb->delete( wceerp_table( 'stock' ), array( 'id' => $id ) );
		$wpdb->delete( wceerp_table( 'product_prices' ), array( 'product_id' => $row->product_id ) );
		wceerp_log( 'inventory', 'product_deleted', $id );

		// Only touch the catalogue when explicitly asked to.
		if ( ! empty( $_POST['also_wc'] ) && current_user_can( 'delete_products' ) ) {
			wp_trash_post( (int) $row->product_id );
		}

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'stock', 'deleted' => 1 ) ) );
		exit;
	}

	/**
	 * Manual WooCommerce reconciliation.
	 *
	 * Deliberately never adjusts a quantity: quantities only ever change
	 * through move_stock() so the ledger stays the source of truth. This
	 * creates missing rows at qty 0 and archives orphans, nothing more.
	 */
	public function handle_sync() {
		$this->verify_nonce( 'wceerp_stock_sync' );
		global $wpdb;

		$warehouse = isset( $_POST['warehouse_id'] ) ? (int) $_POST['warehouse_id'] : 0;
		if ( ! $warehouse ) {
			$warehouse = (int) $wpdb->get_var( 'SELECT id FROM ' . wceerp_table( 'warehouses' ) . " WHERE status='active' ORDER BY id LIMIT 1" );
		}
		$created  = 0;
		$archived = 0;

		if ( ! empty( $_POST['do_create'] ) && $warehouse ) {
			/* Variations hold the stock, not their parent.
			 *
			 * A variable product is a container: its price, its cost and its
			 * quantity all live on the individual variations. Creating a row
			 * for the parent and none for the variations meant a variation
			 * only ever got a row when something was sold, and move_stock()
			 * then created it with no cost — which is why variable products
			 * show negative quantities at zero cost while simple products
			 * are correct.
			 *
			 * So: include product_variation, and exclude the parents of
			 * variable products, which can never hold stock of their own. */
			$missing = $wpdb->get_col( $wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				 LEFT JOIN " . wceerp_table( 'stock' ) . " s
				   ON s.product_id = p.ID AND s.warehouse_id = %d
				 WHERE p.post_type IN ('product','product_variation')
				   AND p.post_status IN ('publish','private','draft')
				   AND s.id IS NULL
				   AND NOT EXISTS (
				       SELECT 1 FROM {$wpdb->posts} v
				       WHERE v.post_type = 'product_variation'
				         AND v.post_parent = p.ID
				         AND v.post_status IN ('publish','private','draft')
				   )",
				$warehouse
			) );
			foreach ( $missing as $pid ) {
				$wpdb->insert( wceerp_table( 'stock' ), array(
					'product_id'   => (int) $pid,
					'warehouse_id' => $warehouse,
					'qty'          => 0,
					'avg_cost'     => 0,
					'status'       => 'active',
				) );
				$created++;
			}
		}

		/* A simple product turned variable keeps the stock row it was given
		 * as a simple one. It is now a container and should not sit in the
		 * list showing a quantity, so it is archived rather than deleted —
		 * the movement history behind it stays intact. */
		if ( ! empty( $_POST['do_create'] ) ) {
			$parents = $wpdb->get_col(
				'SELECT s.id FROM ' . wceerp_table( 'stock' ) . " s
				 INNER JOIN {$wpdb->posts} p ON p.ID = s.product_id
				 WHERE s.status = 'active'
				   AND p.post_type = 'product'
				   AND EXISTS (
				       SELECT 1 FROM {$wpdb->posts} v
				       WHERE v.post_type = 'product_variation' AND v.post_parent = p.ID
				   )"
			);
			foreach ( $parents as $sid ) {
				$wpdb->update( wceerp_table( 'stock' ), array( 'status' => 'archived' ), array( 'id' => (int) $sid ) );
				$archived++;
			}
		}

		if ( ! empty( $_POST['do_archive'] ) ) {
			$orphans = $wpdb->get_col(
				'SELECT s.id FROM ' . wceerp_table( 'stock' ) . ' s
				 LEFT JOIN ' . $wpdb->posts . " p ON p.ID = s.product_id
				 WHERE p.ID IS NULL AND s.status <> 'archived'"
			);
			foreach ( $orphans as $sid ) {
				$wpdb->update( wceerp_table( 'stock' ), array( 'status' => 'archived' ), array( 'id' => (int) $sid ) );
				$archived++;
			}
		}

		wceerp_log( 'inventory', 'wc_sync', 0, sprintf( 'created %d, archived %d', $created, $archived ) );
		wp_safe_redirect( $this->admin_url( array(
			'tab' => 'sync', 'created' => $created, 'archived' => $archived, 'synced' => 1,
		) ) );
		exit;
	}

	public function render_page() {
		global $wpdb;
		$tab        = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'stock';
		$warehouses = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'warehouses' ) . " WHERE status='active' ORDER BY name" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Inventory', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Inventory updated.', 'wc-enterprise-erp' ) ); ?>
			<?php if ( isset( $_GET['error'] ) ) $this->notice( __( 'Not enough stock in the source warehouse.', 'wc-enterprise-erp' ), 'error' ); ?>
			<?php if ( isset( $_GET['deleted'] ) ) $this->notice( __( 'Product removed from the ERP.', 'wc-enterprise-erp' ) ); ?>
			<?php if ( isset( $_GET['blocked'] ) ) $this->notice( __( 'That product already has transactions, so it cannot be deleted — it has been archived instead. Archived products keep every past report and valuation intact.', 'wc-enterprise-erp' ), 'error' ); ?>
			<?php
			$neg = self::negative_stock();
			if ( $neg ) {
				$this->notice( sprintf(
					/* translators: %d: number of products. */
					_n(
						'%d product has negative stock — more has been sold than was ever received, so its cost of goods sold is understated. Enter the missing purchase or opening stock.',
						'%d products have negative stock — more has been sold than was ever received, so their cost of goods sold is understated. Enter the missing purchases or opening stock.',
						count( $neg ), 'wc-enterprise-erp'
					), count( $neg )
				), 'error' );
			}

			$zero = self::zero_cost_sales( 1 );
			if ( $zero ) {
				$this->notice( __( 'Some sales have been recorded against products with no purchase cost. Those sales posted zero cost of goods sold, which inflates profit. Check Reports → Stock valuation for products showing a zero average cost.', 'wc-enterprise-erp' ), 'error' );
			}

			$orphans = self::orphan_count();
			if ( $orphans && 'sync' !== $tab ) {
				$this->notice( sprintf(
					/* translators: %d: number of stock rows. */
					_n(
						'%d product in the ERP no longer exists in WooCommerce. Run Sync with WooCommerce to clean it up.',
						'%d products in the ERP no longer exist in WooCommerce. Run Sync with WooCommerce to clean them up.',
						$orphans, 'wc-enterprise-erp'
					), $orphans
				), 'error' );
			}
			?>

			<nav class="nav-tab-wrapper">
				<?php
				foreach ( array(
					'stock'    => __( 'Stock levels', 'wc-enterprise-erp' ),
					'adjust'   => __( 'Adjustment', 'wc-enterprise-erp' ),
					'transfer' => __( 'Warehouse transfer', 'wc-enterprise-erp' ),
					'moves'    => __( 'Movement log', 'wc-enterprise-erp' ),
					'adjhist'  => __( 'Adjustment history', 'wc-enterprise-erp' ),
					'trfhist'  => __( 'Transfer history', 'wc-enterprise-erp' ),
					'sync'     => __( 'Sync with WooCommerce', 'wc-enterprise-erp' ),
				) as $key => $label ) {
					printf(
						'<a class="nav-tab %s" href="%s">%s</a>',
						$tab === $key ? 'nav-tab-active' : '',
						esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php
			if ( 'stock' === $tab )    $this->tab_stock( $warehouses );
			if ( 'adjust' === $tab )   $this->tab_adjust( $warehouses );
			if ( 'transfer' === $tab ) $this->tab_transfer( $warehouses );
			if ( 'moves' === $tab )    $this->tab_moves();
			if ( 'adjhist' === $tab )  $this->render_movement_report( 'adjustment' );
			if ( 'trfhist' === $tab )  $this->render_movement_report( 'transfer' );
			if ( 'sync' === $tab )     $this->tab_sync( $warehouses );
			?>
		</div>
		<?php
	}

	protected function tab_stock( $warehouses ) {
		global $wpdb;
		$wh_filter = isset( $_GET['wh'] ) ? (int) $_GET['wh'] : 0;
		$search    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';

		$status_f = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'active';

		/* LEFT JOIN on purpose: a stock row whose WooCommerce product was
		 * deleted must stay visible so it can be archived or removed. An
		 * INNER JOIN silently hid those rows while they still counted
		 * towards stock valuation. */
		$sql    = 'SELECT s.*, w.name AS warehouse, p.post_title AS product, p.ID AS wc_id,
		           p.post_type AS wc_type, p.post_parent AS wc_parent,
		           pp.post_title AS parent_title
		           FROM ' . wceerp_table( 'stock' ) . ' s
		           INNER JOIN ' . wceerp_table( 'warehouses' ) . ' w ON w.id = s.warehouse_id
		           LEFT JOIN ' . $wpdb->posts . ' p ON p.ID = s.product_id
		           LEFT JOIN ' . $wpdb->posts . ' pp ON pp.ID = p.post_parent WHERE 1=1';
		$params = array();
		if ( $wh_filter ) { $sql .= ' AND s.warehouse_id = %d'; $params[] = $wh_filter; }
		if ( $search ) {
			/* Search the parent title as well: a variation's own post_title
			 * is usually blank, so searching only p.post_title would never
			 * find a variable product's variations. */
			$sql     .= ' AND ( p.post_title LIKE %s OR pp.post_title LIKE %s )';
			$params[] = '%' . $wpdb->esc_like( $search ) . '%';
			$params[] = '%' . $wpdb->esc_like( $search ) . '%';
		}
		if ( 'all' !== $status_f ) {
			if ( 'orphan' === $status_f ) {
				$sql .= ' AND p.ID IS NULL';
			} else {
				$sql .= ' AND s.status = %s';
				$params[] = $status_f;
			}
		}
		$per_page  = 50;
		$count_sql = preg_replace( '/^SELECT s\.\*.*?FROM/s', 'SELECT COUNT(*) FROM', $sql );
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );
		$sql      .= ' ORDER BY p.post_title, w.name LIMIT ' . $per_page . ' OFFSET ' . wceerp_offset( $per_page );
		$rows      = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-inventory">
			<input type="hidden" name="tab" value="stock">
			<select name="wh">
				<option value="0"><?php esc_html_e( 'All warehouses', 'wc-enterprise-erp' ); ?></option>
				<?php foreach ( $warehouses as $w ) : ?>
					<option value="<?php echo (int) $w->id; ?>" <?php selected( $wh_filter, $w->id ); ?>><?php echo esc_html( $w->name ); ?></option>
				<?php endforeach; ?>
			</select>
			<select name="status">
				<?php
				foreach ( array(
					'active'   => __( 'Active only', 'wc-enterprise-erp' ),
					'archived' => __( 'Archived only', 'wc-enterprise-erp' ),
					'orphan'   => __( 'Deleted in WooCommerce', 'wc-enterprise-erp' ),
					'all'      => __( 'All', 'wc-enterprise-erp' ),
				) as $sk => $sl ) {
					printf( '<option value="%s" %s>%s</option>', esc_attr( $sk ), selected( $status_f, $sk, false ), esc_html( $sl ) );
				}
				?>
			</select>
			<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search product…', 'wc-enterprise-erp' ); ?>">
			<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			<a class="button" href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'sync' ) ) ); ?>"><?php esc_html_e( 'Sync with WooCommerce', 'wc-enterprise-erp' ); ?></a>
		</form>

		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Avg cost', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Stock value', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No stock yet — receive a purchase to fill this list.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php $total_value = 0; foreach ( $rows as $r ) : $total_value += $r->qty * $r->avg_cost; ?>
				<?php
				$is_orphan  = empty( $r->wc_id );
				$is_arch    = ( isset( $r->status ) && 'archived' === $r->status );
				$deletable  = self::can_delete( $r->product_id );
				/* A variation's own post_title is normally blank, so fall
				 * back to its parent's name and add the attributes that
				 * distinguish it — otherwise the row is nameless. */
				$is_variation = ( isset( $r->wc_type ) && 'product_variation' === $r->wc_type );
				$name         = $is_orphan
					? sprintf( __( '(deleted in WooCommerce) #%d', 'wc-enterprise-erp' ), (int) $r->product_id )
					: $r->product;

				if ( ! $is_orphan && $is_variation ) {
					$name = $r->parent_title ? $r->parent_title : $name;
					if ( function_exists( 'wc_get_product' ) ) {
						$vp = wc_get_product( (int) $r->product_id );
						if ( $vp ) {
							$bits = array();
							foreach ( (array) $vp->get_attributes() as $label => $value ) {
								if ( '' !== $value ) {
									$bits[] = $value;
								}
							}
							if ( $bits ) {
								$name .= ' — ' . implode( ', ', $bits );
							}
						}
					}
				}
				?>
				<tr class="<?php echo $r->qty <= 0 ? 'wceerp-danger' : ''; ?>">
					<td><?php echo esc_html( $name ); ?> <small>#<?php echo (int) $r->product_id; ?></small></td>
					<td><?php echo esc_html( $r->warehouse ); ?></td>
					<td class="num"><?php echo esc_html( wc_format_decimal( $r->qty, 2 ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->avg_cost ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->qty * $r->avg_cost ) ); ?></td>
					<td>
						<?php if ( $is_orphan ) : ?>
							<span class="wceerp-badge wceerp-badge-danger"><?php esc_html_e( 'Orphaned', 'wc-enterprise-erp' ); ?></span>
						<?php elseif ( $is_arch ) : ?>
							<span class="wceerp-badge"><?php esc_html_e( 'Archived', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-badge wceerp-badge-ok"><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
							<?php wp_nonce_field( 'wceerp_stock_archive' ); ?>
							<input type="hidden" name="action" value="wceerp_stock_archive">
							<input type="hidden" name="id" value="<?php echo (int) $r->id; ?>">
							<input type="hidden" name="to" value="<?php echo $is_arch ? 'active' : 'archived'; ?>">
							<button class="button button-small"><?php echo $is_arch ? esc_html__( 'Restore', 'wc-enterprise-erp' ) : esc_html__( 'Archive', 'wc-enterprise-erp' ); ?></button>
						</form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"
							onsubmit="return confirm('<?php echo esc_js( __( 'Permanently remove this product from the ERP? This cannot be undone.', 'wc-enterprise-erp' ) ); ?>');">
							<?php wp_nonce_field( 'wceerp_stock_delete' ); ?>
							<input type="hidden" name="action" value="wceerp_stock_delete">
							<input type="hidden" name="id" value="<?php echo (int) $r->id; ?>">
							<?php if ( $deletable ) : ?>
								<?php if ( ! $is_orphan ) : ?>
									<label style="font-size:11px">
										<input type="checkbox" name="also_wc" value="1"> <?php esc_html_e( 'also trash in WooCommerce', 'wc-enterprise-erp' ); ?>
									</label>
								<?php endif; ?>
								<button class="button button-small button-link-delete"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></button>
							<?php else : ?>
								<button class="button button-small" disabled title="<?php esc_attr_e( 'This product has transactions — archive it instead.', 'wc-enterprise-erp' ); ?>"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr><th colspan="4" class="num"><?php esc_html_e( 'Total stock value', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $total_value ) ); ?></th><th colspan="2"></th></tr></tfoot>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}

	/**
	 * Reconciliation report. Shows the diff first; nothing is written until
	 * the form is submitted, and quantities are never touched here.
	 */
	protected function tab_sync( $warehouses ) {
		global $wpdb;

		$warehouse = isset( $_GET['wh'] ) ? (int) $_GET['wh'] : 0;
		if ( ! $warehouse && $warehouses ) {
			$warehouse = (int) $warehouses[0]->id;
		}

		if ( isset( $_GET['synced'] ) ) {
			$this->notice( sprintf(
				/* translators: 1: created count, 2: archived count. */
				__( 'Sync complete — %1$d product(s) added, %2$d orphan(s) archived.', 'wc-enterprise-erp' ),
				isset( $_GET['created'] ) ? (int) $_GET['created'] : 0,
				isset( $_GET['archived'] ) ? (int) $_GET['archived'] : 0
			) );
		}

		$missing = $warehouse ? (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} p
			 LEFT JOIN " . wceerp_table( 'stock' ) . " s
			   ON s.product_id = p.ID AND s.warehouse_id = %d
			 WHERE p.post_type = 'product' AND p.post_status IN ('publish','private','draft')
			   AND s.id IS NULL",
			$warehouse
		) ) : 0;

		$orphans = (int) $wpdb->get_var(
			'SELECT COUNT(*) FROM ' . wceerp_table( 'stock' ) . ' s
			 LEFT JOIN ' . $wpdb->posts . " p ON p.ID = s.product_id
			 WHERE p.ID IS NULL AND s.status <> 'archived'"
		);
		?>
		<p class="description">
			<?php esc_html_e( 'This compares the ERP stock list against your WooCommerce catalogue. It never changes a quantity — new products are added at zero stock, and products deleted from WooCommerce are archived so their history and past valuations stay intact.', 'wc-enterprise-erp' ); ?>
		</p>

		<table class="widefat striped wceerp-table" style="max-width:640px">
			<thead><tr>
				<th><?php esc_html_e( 'Difference found', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Count', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'In WooCommerce but not in the ERP', 'wc-enterprise-erp' ); ?></td>
					<td class="num"><?php echo (int) $missing; ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'In the ERP but deleted from WooCommerce', 'wc-enterprise-erp' ); ?></td>
					<td class="num"><?php echo (int) $orphans; ?></td>
				</tr>
			</tbody>
		</table>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:16px">
			<?php wp_nonce_field( 'wceerp_stock_sync' ); ?>
			<input type="hidden" name="action" value="wceerp_stock_sync">
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
					<td>
						<select name="warehouse_id">
							<?php foreach ( $warehouses as $w ) : ?>
								<option value="<?php echo (int) $w->id; ?>" <?php selected( $warehouse, $w->id ); ?>><?php echo esc_html( $w->name ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'New products are created in this warehouse at zero quantity.', 'wc-enterprise-erp' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Apply', 'wc-enterprise-erp' ); ?></th>
					<td>
						<label><input type="checkbox" name="do_create" value="1" checked> <?php esc_html_e( 'Add missing WooCommerce products to the ERP', 'wc-enterprise-erp' ); ?></label><br>
						<label><input type="checkbox" name="do_archive" value="1" checked> <?php esc_html_e( 'Archive ERP products that no longer exist in WooCommerce', 'wc-enterprise-erp' ); ?></label>
					</td>
				</tr>
			</table>
			<p><button class="button button-primary"><?php esc_html_e( 'Run sync', 'wc-enterprise-erp' ); ?></button></p>
		</form>
		<?php
	}

	protected function tab_adjust( $warehouses ) {
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Stock adjustment', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_stock_adjust">
				<?php wp_nonce_field( 'wceerp_stock_adjust' ); ?>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Product ID', 'wc-enterprise-erp' ); ?></th>
						<td><?php wceerp_product_select( 'product_id', 0, array( 'required' => true ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
						<td><select name="warehouse_id"><?php foreach ( $warehouses as $w ) printf( '<option value="%d">%s</option>', (int) $w->id, esc_html( $w->name ) ); ?></select></td></tr>
					<tr><th><?php esc_html_e( 'Direction', 'wc-enterprise-erp' ); ?></th>
						<td><select name="direction"><option value="in"><?php esc_html_e( 'Stock in (+)', 'wc-enterprise-erp' ); ?></option><option value="out"><?php esc_html_e( 'Stock out (−)', 'wc-enterprise-erp' ); ?></option></select></td></tr>
					<tr><th><?php esc_html_e( 'Quantity', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" step="0.01" min="0.01" name="qty" required class="small-text"></td></tr>
					<tr><th><?php esc_html_e( 'Unit cost (for stock-in)', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" step="0.0001" min="0" name="unit_cost" class="regular-text"></td></tr>
					<tr><th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="note" class="large-text" placeholder="<?php esc_attr_e( 'e.g. broken in transit, counted on 21 Aug', 'wc-enterprise-erp' ); ?>"></td></tr>

					<tr id="wceerp-supplier-row" style="display:none">
						<th><?php esc_html_e( 'Which supplier', 'wc-enterprise-erp' ); ?></th>
						<td>
							<?php
							/* $wpdb is not in scope inside a method unless
							 * asked for. Without this it is null, calling a
							 * method on it is fatal, and the page simply
							 * stops rendering here — taking the reason
							 * selector and the Save button with it. */
							global $wpdb;
							$sup_list = $wpdb->get_results(
								'SELECT id, name FROM ' . wceerp_table( 'suppliers' ) . " WHERE status = 'active' ORDER BY name"
							);
							?>
							<select name="supplier_id" style="max-width:280px">
								<option value="0"><?php esc_html_e( '— choose —', 'wc-enterprise-erp' ); ?></option>
								<?php foreach ( (array) $sup_list as $sup ) : ?>
									<option value="<?php echo (int) $sup->id; ?>"><?php echo esc_html( $sup->name ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">
								<?php esc_html_e( 'The value comes off what you owe them and appears on their ledger, so the return is visible next time you settle up.', 'wc-enterprise-erp' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th><?php esc_html_e( 'Why', 'wc-enterprise-erp' ); ?></th>
						<td>
							<div class="wceerp-choices" style="max-width:640px">
								<?php $first = true; ?>
								<?php foreach ( self::adjust_reasons() as $rk => $rv ) : ?>
									<label class="wceerp-choice<?php echo $first ? ' is-on' : ''; ?>">
										<input type="radio" name="reason" value="<?php echo esc_attr( $rk ); ?>" <?php checked( $first ); ?>>
										<span>
											<b><?php echo esc_html( $rv['label'] ); ?></b>
											<span class="wceerp-choice-desc"><?php echo esc_html( $rv['help'] ); ?></span>
										</span>
									</label>
									<?php $first = false; ?>
								<?php endforeach; ?>
							</div>
							<p class="description" style="margin-top:8px">
								<?php esc_html_e( 'This decides where the value goes in your accounts. Correcting stock you always had is not a cost and must not reduce your profit — that distinction is the difference between a month that looks profitable and one that does not.', 'wc-enterprise-erp' ); ?>
							</p>
							<script>
							(function () {
								var row = document.getElementById( 'wceerp-supplier-row' );
								function sync() {
									var sel = document.querySelector( 'input[name=reason]:checked' );
									if ( row ) { row.style.display = ( sel && 'supplier' === sel.value ) ? '' : 'none'; }
									document.querySelectorAll( '.wceerp-choice input[type=radio]' ).forEach( function ( r ) {
										r.closest( '.wceerp-choice' ).classList.toggle( 'is-on', r.checked );
									} );
								}
								document.querySelectorAll( 'input[name=reason]' ).forEach( function ( r ) {
									r.addEventListener( 'change', sync );
								} );
								sync();
							})();
							</script>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Apply adjustment', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * History of adjustments or transfers.
	 *
	 * Read from stock_moves, which is the only record that cannot disagree
	 * with the stock itself — a separate log would eventually drift from
	 * what actually moved.
	 *
	 * @param string $kind 'adjustment' or 'transfer'.
	 */
	protected function render_movement_report( $kind ) {
		global $wpdb;

		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : gmdate( 'Y-m-01' );
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : gmdate( 'Y-m-d' );
		$wh   = isset( $_GET['wh'] ) ? (int) $_GET['wh'] : 0;
		$prod = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';

		$moves = wceerp_table( 'stock_moves' );
		$whs   = wceerp_table( 'warehouses' );

		$sql    = "SELECT m.*, p.post_title AS product, p.post_type AS wc_type,
		                  pp.post_title AS parent_title, w.name AS warehouse
		           FROM {$moves} m
		           LEFT JOIN {$wpdb->posts} p ON p.ID = m.product_id
		           LEFT JOIN {$wpdb->posts} pp ON pp.ID = p.post_parent
		           LEFT JOIN {$whs} w ON w.id = m.warehouse_id
		           WHERE m.ref_type = %s AND DATE(m.created_at) BETWEEN %s AND %s";
		$params = array( $kind, $from, $to );

		if ( $wh ) {
			$sql     .= ' AND m.warehouse_id = %d';
			$params[] = $wh;
		}
		if ( $prod ) {
			$sql     .= ' AND ( p.post_title LIKE %s OR pp.post_title LIKE %s )';
			$params[] = '%' . $wpdb->esc_like( $prod ) . '%';
			$params[] = '%' . $wpdb->esc_like( $prod ) . '%';
		}
		$sql .= ' ORDER BY m.id DESC LIMIT 500';

		$rows       = (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		$warehouses = (array) $wpdb->get_results( "SELECT id, name FROM {$whs} WHERE status='active' ORDER BY name" );

		$in_qty = 0; $out_qty = 0; $in_val = 0; $out_val = 0;
		foreach ( $rows as $r ) {
			if ( 'in' === $r->direction ) {
				$in_qty += (float) $r->qty;
				$in_val += (float) $r->qty * (float) $r->unit_cost;
			} else {
				$out_qty += (float) $r->qty;
				$out_val += (float) $r->qty * (float) $r->unit_cost;
			}
		}

		$is_transfer = ( 'transfer' === $kind );
		?>
		<div class="wceerp-card">
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-inventory">
				<input type="hidden" name="tab" value="<?php echo esc_attr( $is_transfer ? 'trfhist' : 'adjhist' ); ?>">
				<label><?php esc_html_e( 'From', 'wc-enterprise-erp' ); ?>
					<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"></label>
				<label><?php esc_html_e( 'To', 'wc-enterprise-erp' ); ?>
					<input type="date" name="to" value="<?php echo esc_attr( $to ); ?>"></label>
				<label><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?>
					<select name="wh">
						<option value="0"><?php esc_html_e( 'All', 'wc-enterprise-erp' ); ?></option>
						<?php foreach ( $warehouses as $w ) : ?>
							<option value="<?php echo (int) $w->id; ?>" <?php selected( $wh, (int) $w->id ); ?>><?php echo esc_html( $w->name ); ?></option>
						<?php endforeach; ?>
					</select></label>
				<input type="search" name="q" value="<?php echo esc_attr( $prod ); ?>" placeholder="<?php esc_attr_e( 'Product…', 'wc-enterprise-erp' ); ?>">
				<button class="button button-primary"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			</form>
		</div>

		<div class="wceerp-kpis">
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Movements', 'wc-enterprise-erp' ); ?></span><strong><?php echo count( $rows ); ?></strong></div>
			<?php if ( ! $is_transfer ) : ?>
				<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Added', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo esc_html( number_format( $in_qty, 2 ) ); ?></strong>
					<em><?php echo wp_kses_post( wceerp_money( $in_val ) ); ?></em></div>
				<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Removed', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo esc_html( number_format( $out_qty, 2 ) ); ?></strong>
					<em><?php echo wp_kses_post( wceerp_money( $out_val ) ); ?></em></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Net value change', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $in_val - $out_val ) ); ?></strong></div>
			<?php else : ?>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Quantity moved', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo esc_html( number_format( $out_qty, 2 ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Value moved', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $out_val ) ); ?></strong></div>
			<?php endif; ?>
		</div>

		<p class="description">
			<?php
			echo $is_transfer
				? esc_html__( 'Stock moved between warehouses. A transfer changes nothing in the accounts — the goods are still yours and still worth the same — so this is a control record rather than a financial one. Each transfer appears twice: once leaving, once arriving.', 'wc-enterprise-erp' )
				: esc_html__( 'Every stock adjustment and what it did to your stock value. Adjustments post to the ledger against Miscellaneous, so a large net figure here is worth explaining before it reaches your profit and loss.', 'wc-enterprise-erp' );
			?>
		</p>

		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'When', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
				<th><?php echo $is_transfer ? esc_html__( 'Direction', 'wc-enterprise-erp' ) : esc_html__( 'Change', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Unit cost', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Value', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="8"><?php esc_html_e( 'Nothing in this period.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $r ) : ?>
				<?php
				$name = $r->product;
				if ( 'product_variation' === $r->wc_type && $r->parent_title ) {
					$name = $r->parent_title;
				}
				if ( ! $name ) {
					$name = sprintf( __( '(deleted) #%d', 'wc-enterprise-erp' ), (int) $r->product_id );
				}
				?>
				<tr>
					<td><small><?php echo esc_html( mysql2date( 'j M Y H:i', $r->created_at ) ); ?></small></td>
					<td><?php echo esc_html( $name ); ?> <small>#<?php echo (int) $r->product_id; ?></small></td>
					<td><?php echo esc_html( $r->warehouse ); ?></td>
					<td>
						<?php if ( 'in' === $r->direction ) : ?>
							<span class="wceerp-badge wceerp-badge-ok"><?php echo $is_transfer ? esc_html__( 'received', 'wc-enterprise-erp' ) : esc_html__( 'added', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-badge wceerp-badge-danger"><?php echo $is_transfer ? esc_html__( 'sent', 'wc-enterprise-erp' ) : esc_html__( 'removed', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td class="num"><?php echo esc_html( number_format( (float) $r->qty, 2 ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->unit_cost ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( (float) $r->qty * (float) $r->unit_cost ) ); ?></td>
					<td><small><?php echo esc_html( $r->note ?: '—' ); ?></small></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( count( $rows ) >= 500 ) : ?>
			<p class="description"><?php esc_html_e( 'Showing the most recent 500. Narrow the dates to see more.', 'wc-enterprise-erp' ); ?></p>
		<?php endif; ?>
		<?php
	}

	protected function tab_transfer( $warehouses ) {
		?>
		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Transfer between warehouses', 'wc-enterprise-erp' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_stock_transfer">
				<?php wp_nonce_field( 'wceerp_stock_transfer' ); ?>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th><td><?php wceerp_product_select( 'product_id', 0, array( 'required' => true ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'From warehouse', 'wc-enterprise-erp' ); ?></th>
						<td><select name="from_warehouse"><?php foreach ( $warehouses as $w ) printf( '<option value="%d">%s</option>', (int) $w->id, esc_html( $w->name ) ); ?></select></td></tr>
					<tr><th><?php esc_html_e( 'To warehouse', 'wc-enterprise-erp' ); ?></th>
						<td><select name="to_warehouse"><?php foreach ( $warehouses as $w ) printf( '<option value="%d">%s</option>', (int) $w->id, esc_html( $w->name ) ); ?></select></td></tr>
					<tr><th><?php esc_html_e( 'Quantity', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0.01" name="qty" required></td></tr>
				</table>
				<?php submit_button( __( 'Transfer stock', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function tab_moves() {
		global $wpdb;
		$per_page = 50;
		$total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wceerp_table( 'stock_moves' ) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			'SELECT m.*, w.name AS warehouse, p.post_title AS product
			 FROM ' . wceerp_table( 'stock_moves' ) . ' m
			 LEFT JOIN ' . wceerp_table( 'warehouses' ) . ' w ON w.id = m.warehouse_id
			 LEFT JOIN ' . $wpdb->posts . ' p ON p.ID = m.product_id
			 ORDER BY m.id DESC LIMIT %d OFFSET %d',
			$per_page, wceerp_offset( $per_page )
		) );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Dir', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Unit cost', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Reference', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( (array) $rows as $m ) : ?>
				<tr>
					<td><?php echo esc_html( $m->created_at ); ?></td>
					<td><?php echo esc_html( $m->product ?: '#' . $m->product_id ); ?></td>
					<td><?php echo esc_html( $m->warehouse ); ?></td>
					<td><span class="wceerp-badge <?php echo 'in' === $m->direction ? 'is-in' : 'is-out'; ?>"><?php echo esc_html( strtoupper( $m->direction ) ); ?></span></td>
					<td class="num"><?php echo esc_html( wc_format_decimal( $m->qty, 2 ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $m->unit_cost ) ); ?></td>
					<td><?php echo esc_html( $m->ref_type . ( $m->ref_id ? ' #' . $m->ref_id : '' ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}
}
