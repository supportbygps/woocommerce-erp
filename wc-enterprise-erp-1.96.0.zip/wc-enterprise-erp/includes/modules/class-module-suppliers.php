<?php
/**
 * Module: Supplier Management. Master data with Bangladesh tax identifiers
 * (BIN, TIN, NID) plus a per-supplier ledger view driven by the AP account.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Suppliers extends WCEERP_Module {

	protected $id         = 'suppliers';
	protected $title      = 'Suppliers';
	protected $capability = 'wceerp_manage_suppliers';
	protected $tier       = 'starter';
	protected $order      = 20;

	public function __construct() {
		$this->title = __( 'Suppliers', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_supplier_save', array( $this, 'handle_save' ) );
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_supplier_save' );
		global $wpdb;
		$table = wceerp_table( 'suppliers' );

		$data = array(
			'name'            => sanitize_text_field( wp_unslash( $_POST['name'] ) ),
			'company'         => sanitize_text_field( wp_unslash( $_POST['company'] ?? '' ) ),
			'email'           => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
			'phone'           => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'address'         => sanitize_textarea_field( wp_unslash( $_POST['address'] ?? '' ) ),
			'bin_no'          => sanitize_text_field( wp_unslash( $_POST['bin_no'] ?? '' ) ),
			'tin_no'          => sanitize_text_field( wp_unslash( $_POST['tin_no'] ?? '' ) ),
			'nid_no'          => sanitize_text_field( wp_unslash( $_POST['nid_no'] ?? '' ) ),
			'payment_terms'   => sanitize_text_field( wp_unslash( $_POST['payment_terms'] ?? '' ) ),
			'status'          => 'inactive' === ( $_POST['status'] ?? '' ) ? 'inactive' : 'active',
		);

		$id = (int) ( $_POST['id'] ?? 0 );
		if ( $id ) {
			$wpdb->update( $table, $data, array( 'id' => $id ) );
		} else {
			$data['opening_balance'] = wceerp_dec( $_POST['opening_balance'] ?? 0 );
			$data['created_at']      = current_time( 'mysql' );
			$wpdb->insert( $table, $data );
			$id = $wpdb->insert_id;

			// Opening payable posted so dues start correct.
			if ( $data['opening_balance'] > 0 ) {
				$ap = WCEERP_Accounting::account_by_subtype( 'payable' );
				$eq = WCEERP_Accounting::resolve_account( '3000' );
				if ( $ap && $eq ) {
					WCEERP_Accounting::post(
						array( 'ref_type' => 'supplier_opening', 'ref_id' => $id, 'memo' => 'Opening balance — ' . $data['name'] ),
						array(
							array( 'account' => $eq, 'debit' => $data['opening_balance'] ),
							array( 'account' => $ap->id, 'credit' => $data['opening_balance'], 'party_type' => 'supplier', 'party_id' => $id ),
						)
					);
				}
			}
		}

		wceerp_log( 'suppliers', 'save', $id );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		if ( isset( $_GET['ledger'] ) ) {
			$this->render_ledger( (int) $_GET['ledger'] );
			return;
		}
		global $wpdb;
		$table = wceerp_table( 'suppliers' );
		$edit  = isset( $_GET['edit'] ) ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", (int) $_GET['edit'] ) ) : null;
		$per_page = 50;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$rows     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY name LIMIT %d OFFSET %d", $per_page, wceerp_offset( $per_page ) ) );

		// Payable balances keyed by supplier.
		$dues = array();
		foreach ( WCEERP_Accounting::party_balances( 'supplier', 'payable' ) as $b ) {
			$dues[ (int) $b->party_id ] = -1 * (float) $b->balance; // AP is credit-normal.
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Suppliers', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Supplier saved.', 'wc-enterprise-erp' ) ); ?>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php echo $edit ? esc_html__( 'Edit supplier', 'wc-enterprise-erp' ) : esc_html__( 'Add supplier', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_supplier_save">
						<input type="hidden" name="id" value="<?php echo (int) ( $edit->id ?? 0 ); ?>">
						<?php wp_nonce_field( 'wceerp_supplier_save' ); ?>
						<p><label><?php esc_html_e( 'Contact name *', 'wc-enterprise-erp' ); ?><br><input type="text" name="name" required class="regular-text" value="<?php echo esc_attr( $edit->name ?? '' ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Company', 'wc-enterprise-erp' ); ?><br><input type="text" name="company" class="regular-text" value="<?php echo esc_attr( $edit->company ?? '' ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?><br><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr( $edit->phone ?? '' ); ?>" placeholder="+8801XXXXXXXXX"></label></p>
						<p><label><?php esc_html_e( 'Email', 'wc-enterprise-erp' ); ?><br><input type="email" name="email" class="regular-text" value="<?php echo esc_attr( $edit->email ?? '' ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?><br><textarea name="address" rows="2" class="large-text"><?php echo esc_textarea( $edit->address ?? '' ); ?></textarea></label></p>
						<p>
							<label><?php esc_html_e( 'BIN', 'wc-enterprise-erp' ); ?> <input type="text" name="bin_no" value="<?php echo esc_attr( $edit->bin_no ?? '' ); ?>"></label>
							<label><?php esc_html_e( 'TIN', 'wc-enterprise-erp' ); ?> <input type="text" name="tin_no" value="<?php echo esc_attr( $edit->tin_no ?? '' ); ?>"></label>
							<label><?php esc_html_e( 'NID', 'wc-enterprise-erp' ); ?> <input type="text" name="nid_no" value="<?php echo esc_attr( $edit->nid_no ?? '' ); ?>"></label>
						</p>
						<p><label><?php esc_html_e( 'Payment terms', 'wc-enterprise-erp' ); ?><br><input type="text" name="payment_terms" class="regular-text" value="<?php echo esc_attr( $edit->payment_terms ?? '' ); ?>" placeholder="Net 30"></label></p>
						<?php if ( ! $edit ) : ?>
							<p><label><?php esc_html_e( 'Opening payable balance', 'wc-enterprise-erp' ); ?><br><input type="number" step="0.01" min="0" name="opening_balance" value="0"></label></p>
						<?php endif; ?>
						<p><label><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?>
							<select name="status">
								<option value="active" <?php selected( $edit->status ?? 'active', 'active' ); ?>><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></option>
								<option value="inactive" <?php selected( $edit->status ?? '', 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'wc-enterprise-erp' ); ?></option>
							</select></label></p>
						<?php submit_button( __( 'Save supplier', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'All suppliers', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped">
						<thead><tr>
							<th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'BIN', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Due (payable)', 'wc-enterprise-erp' ); ?></th>
							<th></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $rows as $r ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $r->name ); ?></strong><br><small><?php echo esc_html( $r->company ); ?></small></td>
								<td><?php echo esc_html( $r->phone ); ?></td>
								<td><?php echo esc_html( $r->bin_no ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $dues[ (int) $r->id ] ?? 0 ) ); ?></td>
								<td>
									<a href="<?php echo esc_url( $this->admin_url( array( 'edit' => $r->id ) ) ); ?>"><?php esc_html_e( 'Edit', 'wc-enterprise-erp' ); ?></a> |
									<a href="<?php echo esc_url( $this->admin_url( array( 'ledger' => $r->id ) ) ); ?>"><?php esc_html_e( 'Ledger', 'wc-enterprise-erp' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php wceerp_pagination( $total, $per_page ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	protected function render_ledger( $supplier_id ) {
		global $wpdb;
		$supplier = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'suppliers' ) . ' WHERE id=%d', $supplier_id ) );
		$ap       = WCEERP_Accounting::account_by_subtype( 'payable' );
		$fy       = wceerp_fiscal_year();
		$from     = isset( $_GET['from'] ) ? sanitize_text_field( $_GET['from'] ) : $fy['start'];
		$to       = isset( $_GET['to'] ) ? sanitize_text_field( $_GET['to'] ) : $fy['end'];
		$opening  = $ap ? WCEERP_Accounting::opening_balance( $ap->id, $from, 'supplier', $supplier_id ) : 0;
		$rows     = $ap ? WCEERP_Accounting::ledger( $ap->id, $from, $to, 'supplier', $supplier_id ) : array();
		$running  = $opening;
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php printf( esc_html__( 'Supplier ledger — %s', 'wc-enterprise-erp' ), esc_html( $supplier->name ?? '' ) ); ?></h1>
			<p><a href="<?php echo esc_url( $this->admin_url() ); ?>">&larr; <?php esc_html_e( 'Back to suppliers', 'wc-enterprise-erp' ); ?></a></p>
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-suppliers"><input type="hidden" name="ledger" value="<?php echo (int) $supplier_id; ?>">
				<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"> — <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>">
				<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
			</form>
			<table class="widefat striped wceerp-table">
				<thead><tr><th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Voucher', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Memo', 'wc-enterprise-erp' ); ?></th><th class="num">Dr</th><th class="num">Cr</th><th class="num"><?php esc_html_e( 'Balance', 'wc-enterprise-erp' ); ?></th></tr></thead>
				<tbody>
					<tr><td colspan="5"><em><?php esc_html_e( 'Opening balance', 'wc-enterprise-erp' ); ?></em></td><td class="num"><?php echo wp_kses_post( wceerp_money( -$running ) ); ?></td></tr>
					<?php foreach ( $rows as $r ) : $running += $r->debit - $r->credit; ?>
						<tr>
							<td><?php echo esc_html( $r->journal_date ); ?></td>
							<td><code><?php echo esc_html( $r->doc_no ); ?></code></td>
							<td><?php echo esc_html( $r->memo ?: $r->jmemo ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $r->debit ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $r->credit ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( -$running ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Balance shown as amount owed to the supplier (credit-normal).', 'wc-enterprise-erp' ); ?></p>
		</div>
		<?php
	}
}
