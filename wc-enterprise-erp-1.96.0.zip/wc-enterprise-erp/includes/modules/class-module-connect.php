<?php
/**
 * Module: Connected Store (remote WooCommerce).
 *
 * Lets this ERP tenant pull orders and products from a customer's own,
 * separately-hosted WooCommerce store over its REST API — for the
 * hosted-ERP model where the shop stays on the customer's server but the
 * books live here.
 *
 * How it works
 *   1. The customer generates WooCommerce REST API keys (read access is
 *      enough) in their own WP admin: WooCommerce → Settings → Advanced
 *      → REST API.
 *   2. Those keys + their store URL are saved here.
 *   3. A cron (and a manual "Sync now") pulls orders created since the
 *      last successful sync, and posts each one to this ERP's ledger.
 *
 * Design notes
 *   - Remote orders are NEVER converted into local WooCommerce orders.
 *     They are posted straight to the ledger with ref_type 'remote_order'
 *     and the remote order id, which keeps the books correct without
 *     duplicating shop data.
 *   - Every posting is idempotent: an order already posted (tracked in
 *     the connector log) is skipped, so re-running a sync can't
 *     double-count revenue.
 *   - Failures are recorded and surfaced; a broken connection never
 *     silently stops the books.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Connect extends WCEERP_Module {

	protected $id         = 'connect';
	protected $capability = 'wceerp_manage_settings';
	protected $tier       = 'business';
	protected $order      = 88;

	const CRON = 'wceerp_connect_sync';

	public function __construct() {
		$this->title = __( 'Connected Store', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_init', array( __CLASS__, 'migrate_plaintext_secrets' ) );
		add_action( 'admin_post_wceerp_connect_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_connect_sync', array( $this, 'handle_manual_sync' ) );
		add_action( 'admin_post_wceerp_connect_costs', array( $this, 'handle_import_costs' ) );
		add_action( 'admin_post_wceerp_connect_cost_save', array( $this, 'handle_cost_save' ) );
		add_action( 'admin_post_wceerp_connect_reset', array( $this, 'handle_reset_cursor' ) );
		add_action( 'admin_post_wceerp_connect_mirror', array( $this, 'handle_mirror' ) );
		add_action( 'admin_post_wceerp_connect_push', array( $this, 'handle_push' ) );
		add_action( self::CRON, array( __CLASS__, 'cron_sync' ) );
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 900, 'hourly', self::CRON );
		}
	}

	/* ---------------------------------------------------------------------
	 * Settings accessors.
	 * ------------------------------------------------------------------- */
	/** Secret fields are held encrypted at rest and decrypted on read. */
	const SECRET_KEYS = array( 'ck', 'cs' );

	public static function cfg( $key, $default = '' ) {
		$value = wceerp_get_option( 'connect_' . $key, $default );
		if ( in_array( $key, self::SECRET_KEYS, true ) && class_exists( 'WCEERP_Vault' ) ) {
			return WCEERP_Vault::decrypt( $value );
		}
		return $value;
	}

	/** Raw stored value (still encrypted) — for masking on screen. */
	public static function cfg_raw( $key, $default = '' ) {
		return wceerp_get_option( 'connect_' . $key, $default );
	}

	public static function is_configured() {
		return self::cfg( 'url' ) && self::cfg( 'ck' ) && self::cfg( 'cs' );
	}

	/**
	 * One-time upgrade: encrypt credentials that were stored in plaintext
	 * by an earlier build. Runs quietly; nothing to do once converted.
	 */
	public static function migrate_plaintext_secrets() {
		if ( ! class_exists( 'WCEERP_Vault' ) || ! WCEERP_Vault::available() ) {
			return;
		}
		foreach ( self::SECRET_KEYS as $key ) {
			$stored = wceerp_get_option( 'connect_' . $key, '' );
			if ( '' !== $stored && ! WCEERP_Vault::is_encrypted( $stored ) ) {
				wceerp_update_option( 'connect_' . $key, WCEERP_Vault::encrypt( $stored ) );
			}
		}
	}

	/* ---------------------------------------------------------------------
	 * Remote request helper (WooCommerce REST v3, basic auth over HTTPS).
	 * ------------------------------------------------------------------- */
	protected static function remote( $path, $args = array() ) {
		$base = untrailingslashit( self::cfg( 'url' ) );
		if ( ! $base ) {
			return new WP_Error( 'wceerp_connect', __( 'No store URL configured.', 'wc-enterprise-erp' ) );
		}
		if ( 0 !== strpos( $base, 'https://' ) ) {
			return new WP_Error( 'wceerp_connect', __( 'The store URL must use HTTPS — API keys must never travel over plain HTTP.', 'wc-enterprise-erp' ) );
		}
		$url = add_query_arg( $args, $base . '/wp-json/wc/v3/' . ltrim( $path, '/' ) );

		$response = wp_remote_get( $url, array(
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( self::cfg( 'ck' ) . ':' . self::cfg( 'cs' ) ),
				'Accept'        => 'application/json',
			),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 401 === $code || 403 === $code ) {
			return new WP_Error( 'wceerp_connect', __( 'The store rejected the API keys (check the key has Read access and the site allows REST API).', 'wc-enterprise-erp' ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $body ) && ! empty( $body['message'] ) ? $body['message'] : sprintf( __( 'Store returned HTTP %d.', 'wc-enterprise-erp' ), $code );
			// WooCommerce reports bad query args as "Invalid parameter(s): x"
			// with the detail nested in data.params — surface it so the
			// operator can see what actually failed.
			if ( ! empty( $body['data']['params'] ) && is_array( $body['data']['params'] ) ) {
				$detail = array();
				foreach ( $body['data']['params'] as $param => $why ) {
					$detail[] = $param . ': ' . ( is_string( $why ) ? $why : wp_json_encode( $why ) );
				}
				$msg .= ' — ' . implode( '; ', $detail );
			}
			return new WP_Error( 'wceerp_connect', $msg );
		}
		return is_array( $body ) ? $body : array();
	}

	/** Quick connection test — returns store name or a WP_Error. */
	public static function test_connection() {
		$data = self::remote( 'system_status', array( '_fields' => 'environment' ) );
		if ( is_wp_error( $data ) ) {
			// system_status needs higher perms on some stores; fall back to orders.
			$fallback = self::remote( 'orders', array( 'per_page' => 1 ) );
			if ( is_wp_error( $fallback ) ) {
				return $fallback;
			}
			return __( 'Connected (order access confirmed).', 'wc-enterprise-erp' );
		}
		$name = $data['environment']['site_url'] ?? '';
		return $name ? sprintf( __( 'Connected to %s', 'wc-enterprise-erp' ), $name ) : __( 'Connected.', 'wc-enterprise-erp' );
	}

	/* ---------------------------------------------------------------------
	 * Sync.
	 * ------------------------------------------------------------------- */
	public static function cron_sync() {
		if ( self::is_configured() ) {
			self::sync();
		}
	}

	/**
	 * Pull orders modified since the last sync and post any not yet posted.
	 * Returns array( 'posted' => int, 'skipped' => int, 'error' => string ).
	 */
	public static function sync( $limit_pages = 5 ) {
		global $wpdb;
		$log_table = wceerp_table( 'connect_log' );
		/* WooCommerce REST rejects an ISO string carrying a timezone
		 * offset (e.g. 2026-06-24T00:00:00+00:00) — it wants a bare
		 * 'Y-m-d\TH:i:s'. Normalise whatever is stored, so a value saved
		 * by an older build can't keep breaking the sync. */
		$after_raw = wceerp_get_option( 'connect_last_sync', '' );
		$after_ts  = $after_raw ? strtotime( $after_raw ) : strtotime( '-30 days' );
		if ( ! $after_ts ) {
			$after_ts = strtotime( '-30 days' );
		}
		$after = gmdate( 'Y-m-d\TH:i:s', $after_ts );
		$statuses  = self::cfg( 'statuses', 'processing,completed' );

		$posted  = 0;
		$skipped = 0;
		$page    = 1;

		while ( $page <= $limit_pages ) {
			$orders = self::remote( 'orders', array(
				'after'    => $after,
				'status'   => $statuses,
				'per_page' => 50,
				'page'     => $page,
				'orderby'  => 'date',
				'order'    => 'asc',
			) );

			if ( is_wp_error( $orders ) ) {
				wceerp_update_option( 'connect_last_error', $orders->get_error_message() );
				wceerp_update_option( 'connect_last_error_at', current_time( 'mysql' ) );
				// Track consecutive failures so a quietly-dead connection
				// can be spotted from the network overview.
				$fails = (int) wceerp_get_option( 'connect_fail_streak', 0 ) + 1;
				wceerp_update_option( 'connect_fail_streak', $fails );
				return array( 'posted' => $posted, 'skipped' => $skipped, 'error' => $orders->get_error_message() );
			}
			if ( ! $orders ) {
				break;
			}

			foreach ( $orders as $order ) {
				$remote_id = (int) ( $order['id'] ?? 0 );
				if ( ! $remote_id ) {
					continue;
				}
				// Idempotency: already posted?
				$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $log_table WHERE remote_id = %d", $remote_id ) );
				if ( $exists ) {
					$skipped++;
					continue;
				}
				$result = self::post_remote_order( $order );
				if ( is_wp_error( $result ) ) {
					wceerp_log( 'connect', 'post_failed', $remote_id, $result->get_error_message() );
					continue;
				}
				$wpdb->insert( $log_table, array(
					'remote_id'  => $remote_id,
					'journal_id' => (int) $result,
					'total'      => wceerp_dec( $order['total'] ?? 0 ),
					'order_date' => isset( $order['date_created'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $order['date_created'] ) ) : current_time( 'mysql' ),
					'created_at' => current_time( 'mysql' ),
				) );

				// Keep a shipping-ready copy so Courier & COD can work with
				// remote orders exactly like local ones.
				$bill    = isset( $order['billing'] ) && is_array( $order['billing'] ) ? $order['billing'] : array();
				$ship    = isset( $order['shipping'] ) && is_array( $order['shipping'] ) ? $order['shipping'] : array();
				$addr    = trim( implode( ', ', array_filter( array(
					$ship['address_1'] ?? ( $bill['address_1'] ?? '' ),
					$ship['address_2'] ?? ( $bill['address_2'] ?? '' ),
					$ship['city'] ?? ( $bill['city'] ?? '' ),
					$ship['state'] ?? ( $bill['state'] ?? '' ),
				) ) ) );
				$method  = (string) ( $order['payment_method'] ?? '' );
				$wpdb->replace( wceerp_table( 'connect_orders' ), array(
					'remote_id'        => $remote_id,
					'number'           => sanitize_text_field( (string) ( $order['number'] ?? $remote_id ) ),
					'status'           => sanitize_text_field( (string) ( $order['status'] ?? '' ) ),
					'total'            => wceerp_dec( $order['total'] ?? 0 ),
					'payment_method'   => sanitize_text_field( $method ),
					'is_cod'           => false !== stripos( $method, 'cod' ) ? 1 : 0,
					'customer_name'    => sanitize_text_field( trim( ( $bill['first_name'] ?? '' ) . ' ' . ( $bill['last_name'] ?? '' ) ) ),
					'customer_phone'   => sanitize_text_field( (string) ( $bill['phone'] ?? '' ) ),
					'customer_email'   => sanitize_email( (string) ( $bill['email'] ?? '' ) ),
					'customer_address' => $addr,
					'order_date'       => isset( $order['date_created'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $order['date_created'] ) ) : current_time( 'mysql' ),
					'created_at'       => current_time( 'mysql' ),
				) );
				$posted++;

				if ( ! empty( $order['date_created'] ) ) {
					wceerp_update_option( 'connect_last_sync', gmdate( 'Y-m-d\TH:i:s', strtotime( $order['date_created'] ) ) );
				}
			}

			if ( count( $orders ) < 50 ) {
				break;
			}
			$page++;
		}

		wceerp_update_option( 'connect_last_run', current_time( 'mysql' ) );
		wceerp_update_option( 'connect_last_error', '' );
		wceerp_update_option( 'connect_fail_streak', 0 );
		wceerp_update_option( 'connect_last_success', current_time( 'mysql' ) );
		return array( 'posted' => $posted, 'skipped' => $skipped, 'error' => '' );
	}

	/**
	 * Post one remote order to the ledger.
	 *
	 * Mirrors the local WooCommerce bridge: revenue net of tax, output VAT,
	 * and the money/receivable debit. COGS is posted too when a cost basis
	 * is known for the products involved (see cost_for()); lines without a
	 * known cost simply contribute nothing to COGS rather than guessing.
	 */
	/**
	 * Connection health for operator dashboards.
	 * Returns: ok | stale | failing | unconfigured, plus context.
	 */
	public static function health() {
		if ( ! self::is_configured() ) {
			return array( 'state' => 'unconfigured', 'label' => __( 'Not connected', 'wc-enterprise-erp' ) );
		}
		$fails   = (int) wceerp_get_option( 'connect_fail_streak', 0 );
		$success = wceerp_get_option( 'connect_last_success', '' );
		$age_h   = $success ? ( time() - strtotime( $success ) ) / HOUR_IN_SECONDS : null;

		if ( $fails >= 3 ) {
			return array(
				'state' => 'failing',
				'label' => sprintf( __( 'Failing (%d attempts)', 'wc-enterprise-erp' ), $fails ),
				'error' => wceerp_get_option( 'connect_last_error', '' ),
			);
		}
		if ( null === $age_h || $age_h > 24 ) {
			return array( 'state' => 'stale', 'label' => __( 'No successful sync in 24h', 'wc-enterprise-erp' ) );
		}
		return array( 'state' => 'ok', 'label' => __( 'Healthy', 'wc-enterprise-erp' ) );
	}

	/* ---------------------------------------------------------------------
	 * Cost basis for connected-store products.
	 *
	 * WooCommerce has no native cost-price field, so a remote store's cost
	 * has to come from somewhere explicit. Two supported sources:
	 *   1. A meta key on their products (many cost-of-goods plugins store
	 *      one, e.g. _wc_cog_cost) — set the key in settings and import.
	 *   2. Manual entry / CSV paste in the Cost basis tab.
	 * Anything without a cost simply doesn't contribute to COGS.
	 * ------------------------------------------------------------------- */

	/** Unit cost for a remote product id, or 0 when unknown. */
	public static function cost_for( $remote_product_id ) {
		global $wpdb;
		if ( ! $remote_product_id ) {
			return 0.0;
		}
		$cost = $wpdb->get_var( $wpdb->prepare(
			"SELECT unit_cost FROM " . wceerp_table( 'connect_costs' ) . " WHERE remote_product_id = %d",
			(int) $remote_product_id
		) );
		return $cost ? (float) $cost : 0.0;
	}

	/**
	 * Pull the product catalogue from the connected store and record a cost
	 * for each product, reading the configured cost meta key when present.
	 * Existing manual costs are not overwritten by a blank remote value.
	 */
	public static function import_costs( $limit_pages = 10 ) {
		global $wpdb;
		$table    = wceerp_table( 'connect_costs' );
		$meta_key = self::cfg( 'cost_meta_key', '_wc_cog_cost' );
		$found    = 0;
		$with_cost = 0;
		$page     = 1;

		while ( $page <= $limit_pages ) {
			$products = self::remote( 'products', array( 'per_page' => 100, 'page' => $page, 'status' => 'publish' ) );
			if ( is_wp_error( $products ) ) {
				return $products;
			}
			if ( ! $products ) {
				break;
			}
			foreach ( $products as $p ) {
				$pid = (int) ( $p['id'] ?? 0 );
				if ( ! $pid ) {
					continue;
				}
				$found++;

				// Look for the cost in meta_data.
				$cost = 0.0;
				if ( ! empty( $p['meta_data'] ) && is_array( $p['meta_data'] ) ) {
					foreach ( $p['meta_data'] as $meta ) {
						if ( isset( $meta['key'] ) && $meta['key'] === $meta_key ) {
							$cost = (float) $meta['value'];
							break;
						}
					}
				}

				$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id, unit_cost, source FROM $table WHERE remote_product_id = %d", $pid ) );
				if ( $existing ) {
					// Don't clobber a manually-set cost with an empty remote one.
					if ( $cost > 0 ) {
						$wpdb->update( $table, array(
							'sku'        => sanitize_text_field( $p['sku'] ?? '' ),
							'name'       => sanitize_text_field( $p['name'] ?? '' ),
							'unit_cost'  => $cost,
							'source'     => 'remote',
							'updated_at' => current_time( 'mysql' ),
						), array( 'id' => $existing->id ) );
						$with_cost++;
					}
				} else {
					$wpdb->insert( $table, array(
						'remote_product_id' => $pid,
						'sku'               => sanitize_text_field( $p['sku'] ?? '' ),
						'name'              => sanitize_text_field( $p['name'] ?? '' ),
						'unit_cost'         => $cost,
						'source'            => $cost > 0 ? 'remote' : 'manual',
						'updated_at'        => current_time( 'mysql' ),
					) );
					if ( $cost > 0 ) {
						$with_cost++;
					}
				}
			}
			if ( count( $products ) < 100 ) {
				break;
			}
			$page++;
		}
		return array( 'found' => $found, 'with_cost' => $with_cost );
	}

	/* ---------------------------------------------------------------------
	 * Product mirror.
	 *
	 * Creates a local WooCommerce product for each remote product, linked
	 * by _wceerp_remote_id meta. Mirrored products make Inventory, POS,
	 * stock valuation and the rest of the ERP work normally — they are the
	 * ERP's own copy, not a second storefront (they're kept out of the
	 * catalogue via 'private' status so they can't be sold from this site).
	 * ------------------------------------------------------------------- */

	/** Local product id for a remote product id, or 0. */
	public static function local_product_for( $remote_id ) {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wceerp_remote_id' AND meta_value = %s LIMIT 1",
			(string) (int) $remote_id
		) );
		return (int) $id;
	}

	/**
	 * Pull the remote catalogue and mirror it locally.
	 * Updates name/sku/price on every run; never deletes.
	 */
	public static function mirror_products( $limit_pages = 20 ) {
		$created = 0;
		$updated = 0;
		$page    = 1;

		while ( $page <= $limit_pages ) {
			$products = self::remote( 'products', array( 'per_page' => 100, 'page' => $page, 'status' => 'publish' ) );
			if ( is_wp_error( $products ) ) {
				return $products;
			}
			if ( ! $products ) {
				break;
			}

			foreach ( $products as $p ) {
				$rid = (int) ( $p['id'] ?? 0 );
				if ( ! $rid ) {
					continue;
				}
				$local_id = self::local_product_for( $rid );
				$name     = sanitize_text_field( $p['name'] ?? ( 'Remote #' . $rid ) );
				$sku      = sanitize_text_field( $p['sku'] ?? '' );
				$price    = wceerp_dec( $p['price'] ?? 0 );
				$stock    = isset( $p['stock_quantity'] ) && null !== $p['stock_quantity'] ? (float) $p['stock_quantity'] : null;

				if ( $local_id ) {
					$product = wc_get_product( $local_id );
					if ( ! $product ) {
						continue;
					}
					$updated++;
				} else {
					$product = new WC_Product_Simple();
					$created++;
				}

				$product->set_name( $name );
				if ( $sku && ! wc_get_product_id_by_sku( $sku ) ) {
					$product->set_sku( $sku );
				}
				if ( $price > 0 ) {
					$product->set_regular_price( (string) $price );
				}
				// Keep mirrors out of this site's shop front.
				$product->set_status( 'private' );
				$product->set_catalog_visibility( 'hidden' );
				$local_id = $product->save();

				update_post_meta( $local_id, '_wceerp_remote_id', (string) $rid );
				update_post_meta( $local_id, '_wceerp_remote_synced', current_time( 'mysql' ) );
				if ( null !== $stock ) {
					update_post_meta( $local_id, '_wceerp_remote_stock', $stock );
				}

				// Seed ERP stock to match the remote quantity on first mirror.
				if ( null !== $stock && class_exists( 'WCEERP_Module_Inventory' ) ) {
					self::seed_stock( $local_id, $stock );
				}
			}

			if ( count( $products ) < 100 ) {
				break;
			}
			$page++;
		}

		wceerp_update_option( 'connect_products_synced', current_time( 'mysql' ) );
		return array( 'created' => $created, 'updated' => $updated );
	}

	/**
	 * Bring ERP stock in line with a mirrored quantity, once.
	 * Only seeds when the ERP has no stock row yet — after that the ERP's
	 * own movements are authoritative and are not silently overwritten.
	 */
	protected static function seed_stock( $product_id, $qty ) {
		global $wpdb;
		$table = wceerp_table( 'stock' );
		$wh    = (int) $wpdb->get_var( "SELECT id FROM " . wceerp_table( 'warehouses' ) . " ORDER BY is_default DESC, id ASC LIMIT 1" );
		if ( ! $wh ) {
			return;
		}
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE product_id = %d AND warehouse_id = %d", $product_id, $wh ) );
		if ( $exists ) {
			return;
		}
		if ( (float) $qty > 0 ) {
			WCEERP_Module_Inventory::move_stock( $product_id, $wh, (float) $qty, 'in', 'connect_seed', 0, null, null, __( 'Opening stock from connected store', 'wc-enterprise-erp' ) );
		}
	}

	/**
	 * Push this ERP's stock quantity for one product back to the remote
	 * store. Deliberately manual — an automatic push would race against
	 * live sales on their site and could oversell.
	 */
	public static function push_stock( $local_product_id ) {
		global $wpdb;
		$remote_id = get_post_meta( $local_product_id, '_wceerp_remote_id', true );
		if ( ! $remote_id ) {
			return new WP_Error( 'wceerp_connect', __( 'This product is not linked to the connected store.', 'wc-enterprise-erp' ) );
		}
		$wh  = (int) $wpdb->get_var( "SELECT id FROM " . wceerp_table( 'warehouses' ) . " ORDER BY is_default DESC, id ASC LIMIT 1" );
		$qty = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(qty),0) FROM " . wceerp_table( 'stock' ) . " WHERE product_id = %d" . ( $wh ? ' AND warehouse_id = %d' : '' ),
			$wh ? array( $local_product_id, $wh ) : array( $local_product_id )
		) );

		$res = self::remote_write( 'products/' . (int) $remote_id, array(
			'manage_stock'   => true,
			'stock_quantity' => (int) round( $qty ),
		) );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		update_post_meta( $local_product_id, '_wceerp_remote_pushed', current_time( 'mysql' ) );
		wceerp_log( 'connect', 'stock_push', $local_product_id, $qty );
		return (int) round( $qty );
	}

	/** PUT/POST helper — write operations need a key with Write permission. */
	protected static function remote_write( $path, $body, $method = 'PUT' ) {
		$base = untrailingslashit( self::cfg( 'url' ) );
		if ( ! $base || 0 !== strpos( $base, 'https://' ) ) {
			return new WP_Error( 'wceerp_connect', __( 'Store URL must be HTTPS.', 'wc-enterprise-erp' ) );
		}
		$response = wp_remote_request( $base . '/wp-json/wc/v3/' . ltrim( $path, '/' ), array(
			'method'  => $method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( self::cfg( 'ck' ) . ':' . self::cfg( 'cs' ) ),
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 401 === $code || 403 === $code ) {
			return new WP_Error( 'wceerp_connect', __( 'Write refused — the API key needs Read/Write permission on their store.', 'wc-enterprise-erp' ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $data ) && ! empty( $data['message'] ) ? $data['message'] : sprintf( __( 'Store returned HTTP %d.', 'wc-enterprise-erp' ), $code );
			return new WP_Error( 'wceerp_connect', $msg );
		}
		return is_array( $data ) ? $data : array();
	}

	protected static function post_remote_order( $order ) {
		$total = wceerp_dec( $order['total'] ?? 0 );
		$tax   = wceerp_dec( $order['total_tax'] ?? 0 );
		if ( $total <= 0 ) {
			return new WP_Error( 'wceerp_connect', 'Zero-total order skipped.' );
		}
		$net = round( $total - $tax, 2 );

		$sales = WCEERP_Accounting::account_by_subtype( 'sales' );
		$cash  = WCEERP_Accounting::account_by_subtype( 'cash' );
		$ar    = WCEERP_Accounting::account_by_subtype( 'receivable' );
		if ( ! $sales || ! $cash || ! $ar ) {
			return new WP_Error( 'wceerp_connect', 'Chart of accounts is missing core accounts.' );
		}

		$method  = strtolower( (string) ( $order['payment_method'] ?? '' ) );
		$is_cod  = false !== stripos( $method, 'cod' );
		$paid    = ! empty( $order['date_paid'] ) && ! $is_cod;
		$money   = $paid ? WCEERP_WC_Bridge::map_gateway_account( $method, $cash ) : $ar->id;

		$lines = array(
			array( 'account' => $money, 'debit' => $total, 'memo' => 'Remote order #' . $order['id'] ),
			array( 'account' => $sales->id, 'credit' => $net, 'memo' => 'Sales — remote #' . $order['id'] ),
		);
		if ( $tax > 0 ) {
			$vat = WCEERP_Accounting::resolve_account( '2100' );
			if ( $vat ) {
				$lines[] = array( 'account' => $vat, 'credit' => $tax, 'memo' => 'Output VAT — remote #' . $order['id'] );
			} else {
				// No VAT account: keep the journal balanced by folding tax into sales.
				$lines[1]['credit'] = $total;
			}
		}

		/* COGS — only for line items whose cost basis we actually know.
		 * Dr COGS / Cr Inventory, mirroring a normal sale. Products with no
		 * recorded cost contribute zero rather than a guessed figure, so the
		 * number is always understated-but-true rather than invented. */
		$cogs_total = 0.0;
		if ( ! empty( $order['line_items'] ) && is_array( $order['line_items'] ) ) {
			foreach ( $order['line_items'] as $item ) {
				$pid  = (int) ( $item['product_id'] ?? 0 );
				$vid  = (int) ( $item['variation_id'] ?? 0 );
				$qty  = (float) ( $item['quantity'] ?? 0 );
				$cost = self::cost_for( $vid ?: $pid );
				if ( $cost > 0 && $qty > 0 ) {
					$cogs_total += $cost * $qty;
				}
			}
		}
		if ( $cogs_total > 0.004 ) {
			$cogs_acc = WCEERP_Accounting::account_by_subtype( 'cogs' );
			$inv_acc  = WCEERP_Accounting::account_by_subtype( 'inventory' );
			if ( $cogs_acc && $inv_acc ) {
				$cogs_total = round( $cogs_total, 2 );
				$lines[] = array( 'account' => $cogs_acc->id, 'debit' => $cogs_total, 'memo' => 'COGS — remote #' . $order['id'] );
				$lines[] = array( 'account' => $inv_acc->id, 'credit' => $cogs_total, 'memo' => 'Inventory — remote #' . $order['id'] );
			}
		}

		$journal = WCEERP_Accounting::post(
			array(
				'journal_date' => isset( $order['date_created'] ) ? gmdate( 'Y-m-d', strtotime( $order['date_created'] ) ) : current_time( 'Y-m-d' ),
				'ref_type'     => 'remote_order',
				'ref_id'       => (int) $order['id'],
				'memo'         => 'Connected store order #' . $order['id'],
			),
			$lines
		);

		// Move stock for any mirrored products in this order, so Inventory
		// reflects what the connected store actually sold.
		if ( ! is_wp_error( $journal ) && ! empty( $order['line_items'] ) && is_array( $order['line_items'] ) && class_exists( 'WCEERP_Module_Inventory' ) ) {
			global $wpdb;
			$wh = (int) $wpdb->get_var( "SELECT id FROM " . wceerp_table( 'warehouses' ) . " ORDER BY is_default DESC, id ASC LIMIT 1" );
			if ( $wh ) {
				foreach ( $order['line_items'] as $item ) {
					$rid = (int) ( $item['variation_id'] ?? 0 ) ?: (int) ( $item['product_id'] ?? 0 );
					$qty = (float) ( $item['quantity'] ?? 0 );
					if ( ! $rid || $qty <= 0 ) {
						continue;
					}
					$local = self::local_product_for( $rid );
					if ( $local ) {
						WCEERP_Module_Inventory::move_stock(
							$local,
							$wh,
							$qty,
							'out',
							'remote_order',
							(int) $order['id'],
							null,
							null,
							'Sold via connected store'
						);
					}
				}
			}
		}

		return $journal;
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */
	public function handle_save() {
		$this->verify_nonce( 'wceerp_connect_save' );
		wceerp_update_option( 'connect_url', esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) ) );
		$ck_in = sanitize_text_field( wp_unslash( $_POST['ck'] ?? '' ) );
		if ( '' !== $ck_in ) {
			wceerp_update_option( 'connect_ck', WCEERP_Vault::encrypt( $ck_in ) );
		}
		if ( ! empty( $_POST['cs'] ) ) {
			wceerp_update_option( 'connect_cs', WCEERP_Vault::encrypt( sanitize_text_field( wp_unslash( $_POST['cs'] ) ) ) );
		}
		wceerp_update_option( 'connect_statuses', sanitize_text_field( wp_unslash( $_POST['statuses'] ?? 'processing,completed' ) ) );
		wceerp_update_option( 'connect_cost_meta_key', sanitize_text_field( wp_unslash( $_POST['cost_meta_key'] ?? '_wc_cog_cost' ) ) );
		wp_safe_redirect( $this->admin_url( array( 'saved' => 1 ) ) );
		exit;
	}

	/**
	 * Reset the sync cursor so the next run re-scans from 30 days back.
	 * Safe: already-imported orders are skipped by the idempotency check,
	 * so this can never double-post revenue.
	 */
	public function handle_mirror() {
		$this->verify_nonce( 'wceerp_connect_mirror' );
		$res = self::mirror_products();
		if ( is_wp_error( $res ) ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'products', 'err' => rawurlencode( $res->get_error_message() ) ) ) );
			exit;
		}
		wp_safe_redirect( $this->admin_url( array(
			'tab'     => 'products',
			'created' => (int) $res['created'],
			'updated' => (int) $res['updated'],
		) ) );
		exit;
	}

	public function handle_push() {
		$this->verify_nonce( 'wceerp_connect_push' );
		$ids = isset( $_POST['push'] ) && is_array( $_POST['push'] ) ? array_map( 'intval', $_POST['push'] ) : array();
		$ok = 0;
		$fail = '';
		foreach ( $ids as $pid ) {
			$r = self::push_stock( $pid );
			if ( is_wp_error( $r ) ) {
				$fail = $r->get_error_message();
			} else {
				$ok++;
			}
		}
		wp_safe_redirect( $this->admin_url( array(
			'tab'    => 'products',
			'pushed' => $ok,
			'err'    => $fail ? rawurlencode( $fail ) : '',
		) ) );
		exit;
	}

	public function handle_reset_cursor() {
		$this->verify_nonce( 'wceerp_connect_reset' );
		wceerp_update_option( 'connect_last_sync', '' );
		wceerp_update_option( 'connect_last_error', '' );
		wp_safe_redirect( $this->admin_url( array( 'reset' => 1 ) ) );
		exit;
	}

	public function handle_import_costs() {
		$this->verify_nonce( 'wceerp_connect_costs' );
		$res = self::import_costs();
		if ( is_wp_error( $res ) ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'costs', 'err' => rawurlencode( $res->get_error_message() ) ) ) );
			exit;
		}
		wp_safe_redirect( $this->admin_url( array(
			'tab'       => 'costs',
			'found'     => (int) $res['found'],
			'with_cost' => (int) $res['with_cost'],
		) ) );
		exit;
	}

	public function handle_cost_save() {
		$this->verify_nonce( 'wceerp_connect_cost_save' );
		global $wpdb;
		$table = wceerp_table( 'connect_costs' );
		$costs = isset( $_POST['cost'] ) && is_array( $_POST['cost'] ) ? $_POST['cost'] : array();
		$saved = 0;
		foreach ( $costs as $id => $value ) {
			$id    = (int) $id;
			$value = wceerp_dec( $value );
			if ( $id ) {
				$wpdb->update( $table, array(
					'unit_cost'  => $value,
					'source'     => 'manual',
					'updated_at' => current_time( 'mysql' ),
				), array( 'id' => $id ) );
				$saved++;
			}
		}
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'costs', 'saved_costs' => $saved ) ) );
		exit;
	}

	public function handle_manual_sync() {
		$this->verify_nonce( 'wceerp_connect_sync' );
		$res = self::sync();
		wp_safe_redirect( $this->admin_url( array(
			'posted'  => (int) $res['posted'],
			'skipped' => (int) $res['skipped'],
			'err'     => $res['error'] ? rawurlencode( $res['error'] ) : '',
		) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */
	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'connection';
		echo '<div class="wrap wceerp-wrap">';
		echo '<h1>' . esc_html__( 'Connected Store', 'wc-enterprise-erp' ) . '</h1>';
		$tabs = array(
			'connection' => __( 'Connection', 'wc-enterprise-erp' ),
			'products'   => __( 'Products & stock', 'wc-enterprise-erp' ),
			'costs'      => __( 'Cost basis (COGS)', 'wc-enterprise-erp' ),
		);
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $key => $label ) {
			printf(
				'<a href="%s" class="nav-tab %s">%s</a>',
				esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
				$tab === $key ? 'nav-tab-active' : '',
				esc_html( $label )
			);
		}
		echo '</h2>';
		if ( 'costs' === $tab ) {
			$this->render_costs();
		} elseif ( 'products' === $tab ) {
			$this->render_products();
		} else {
			$this->render_connection();
		}
		echo '</div>';
	}

	/**
	 * Cost basis screen — the missing half of profit for connected stores.
	 */
	protected function render_costs() {
		global $wpdb;
		$table = wceerp_table( 'connect_costs' );
		$rows  = $wpdb->get_results( "SELECT * FROM $table ORDER BY (unit_cost = 0) DESC, name ASC LIMIT 300" );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$known = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE unit_cost > 0" );
		?>
		<?php if ( isset( $_GET['found'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>
				<?php printf( esc_html__( 'Imported %1$d products, %2$d had a cost value.', 'wc-enterprise-erp' ), (int) $_GET['found'], (int) ( $_GET['with_cost'] ?? 0 ) ); ?>
			</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['saved_costs'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php printf( esc_html__( '%d costs saved.', 'wc-enterprise-erp' ), (int) $_GET['saved_costs'] ); ?></p></div>
		<?php endif; ?>
		<?php if ( ! empty( $_GET['err'] ) ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( wp_unslash( $_GET['err'] ) ); ?></p></div>
		<?php endif; ?>

		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Why this matters', 'wc-enterprise-erp' ); ?></h2>
			<p class="description" style="max-width:760px">
				<?php esc_html_e( 'WooCommerce has no built-in cost price, so a connected store cannot tell us what its products cost. Without a cost basis, imported orders post revenue but no COGS — and the Profit analysis report would overstate profit. Set costs here and COGS is posted with every future imported order.', 'wc-enterprise-erp' ); ?>
			</p>
			<p>
				<strong><?php printf( esc_html__( '%1$d of %2$d products have a cost.', 'wc-enterprise-erp' ), $known, $total ); ?></strong>
				<?php if ( $total && $known < $total ) : ?>
					<span style="color:#b98a2f"><?php esc_html_e( 'Orders containing the rest will post no COGS for those lines.', 'wc-enterprise-erp' ); ?></span>
				<?php endif; ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="wceerp_connect_costs">
				<?php wp_nonce_field( 'wceerp_connect_costs' ); ?>
				<?php submit_button( __( 'Import products & costs from store', 'wc-enterprise-erp' ), 'secondary', 'submit', false ); ?>
				<span class="description"><?php printf( esc_html__( 'Reads the meta key "%s" on their products.', 'wc-enterprise-erp' ), esc_html( self::cfg( 'cost_meta_key', '_wc_cog_cost' ) ) ); ?></span>
			</form>
		</div>

		<?php if ( $rows ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="margin-top:16px">
				<input type="hidden" name="action" value="wceerp_connect_cost_save">
				<?php wp_nonce_field( 'wceerp_connect_cost_save' ); ?>
				<h2><?php esc_html_e( 'Unit costs', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Products without a cost are listed first. Enter the purchase cost per unit.', 'wc-enterprise-erp' ); ?></p>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'SKU', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Source', 'wc-enterprise-erp' ); ?></th>
						<th style="width:140px"><?php esc_html_e( 'Unit cost', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $rows as $r ) : ?>
						<tr>
							<td><?php echo esc_html( $r->name ?: '#' . $r->remote_product_id ); ?></td>
							<td><code><?php echo esc_html( $r->sku ); ?></code></td>
							<td><?php echo 'remote' === $r->source ? esc_html__( 'from store', 'wc-enterprise-erp' ) : esc_html__( 'manual', 'wc-enterprise-erp' ); ?></td>
							<td><input type="number" step="0.01" min="0" name="cost[<?php echo (int) $r->id; ?>]" value="<?php echo esc_attr( $r->unit_cost ); ?>" style="width:120px"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php submit_button( __( 'Save costs', 'wc-enterprise-erp' ) ); ?>
			</form>
		<?php endif; ?>
		<?php
	}

	/**
	 * Products & stock screen — mirror the remote catalogue and, when the
	 * operator explicitly chooses to, push ERP stock back to their store.
	 */
	protected function render_products() {
		global $wpdb;
		$stock_t = wceerp_table( 'stock' );
		$rows = $wpdb->get_results(
			"SELECT p.ID AS local_id, p.post_title AS name, pm.meta_value AS remote_id,
					COALESCE(SUM(s.qty),0) AS erp_qty,
					(SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_wceerp_remote_stock' LIMIT 1) AS remote_qty,
					(SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_wceerp_remote_pushed' LIMIT 1) AS pushed_at
			 FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_wceerp_remote_id'
			 LEFT JOIN $stock_t s ON s.product_id = p.ID
			 WHERE p.post_type = 'product'
			 GROUP BY p.ID
			 ORDER BY p.post_title ASC
			 LIMIT 300"
		);
		$synced = wceerp_get_option( 'connect_products_synced', '' );
		?>
		<?php if ( isset( $_GET['created'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>
				<?php printf( esc_html__( 'Mirror complete: %1$d new products, %2$d updated.', 'wc-enterprise-erp' ), (int) $_GET['created'], (int) ( $_GET['updated'] ?? 0 ) ); ?>
			</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['pushed'] ) && ! $_GET['err'] ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php printf( esc_html__( 'Stock pushed for %d product(s).', 'wc-enterprise-erp' ), (int) $_GET['pushed'] ); ?></p></div>
		<?php endif; ?>
		<?php if ( ! empty( $_GET['err'] ) ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( wp_unslash( $_GET['err'] ) ); ?></p></div>
		<?php endif; ?>

		<div class="wceerp-card">
			<h2><?php esc_html_e( 'Mirror the catalogue', 'wc-enterprise-erp' ); ?></h2>
			<p class="description" style="max-width:760px">
				<?php esc_html_e( 'Creates a local copy of each remote product so Inventory, stock valuation and POS work normally. Mirrors are kept private and hidden, so they never appear on this site\'s shop front. Opening stock is seeded once from their quantity; after that the ERP\'s own stock movements are authoritative.', 'wc-enterprise-erp' ); ?>
			</p>
			<?php if ( $synced ) : ?>
				<p><strong><?php esc_html_e( 'Last mirrored:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $synced ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_connect_mirror">
				<?php wp_nonce_field( 'wceerp_connect_mirror' ); ?>
				<?php submit_button( __( 'Mirror products now', 'wc-enterprise-erp' ), 'secondary', 'submit', false ); ?>
			</form>
		</div>

		<?php if ( $rows ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wceerp-card" style="margin-top:16px"
				onsubmit="return confirm('<?php echo esc_js( __( 'Push ERP stock to the customer\'s live store? This overwrites their stock quantity for the selected products.', 'wc-enterprise-erp' ) ); ?>');">
				<input type="hidden" name="action" value="wceerp_connect_push">
				<?php wp_nonce_field( 'wceerp_connect_push' ); ?>
				<h2><?php esc_html_e( 'Mirrored products', 'wc-enterprise-erp' ); ?></h2>
				<p class="description" style="max-width:760px">
					<strong><?php esc_html_e( 'Pushing is manual on purpose.', 'wc-enterprise-erp' ); ?></strong>
					<?php esc_html_e( 'An automatic push would race against live sales on their site and could oversell. Tick only the products you intend to overwrite. Requires an API key with Read/Write permission.', 'wc-enterprise-erp' ); ?>
				</p>
				<table class="widefat striped">
					<thead><tr>
						<th style="width:30px"></th>
						<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'ERP stock', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Their stock (at mirror)', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Last pushed', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $rows as $r ) : ?>
						<tr>
							<td><input type="checkbox" name="push[]" value="<?php echo (int) $r->local_id; ?>"></td>
							<td><?php echo esc_html( $r->name ); ?> <small style="color:#888">#<?php echo esc_html( $r->remote_id ); ?></small></td>
							<td class="num"><strong><?php echo esc_html( rtrim( rtrim( number_format( (float) $r->erp_qty, 2 ), '0' ), '.' ) ); ?></strong></td>
							<td class="num"><?php echo null !== $r->remote_qty ? esc_html( (float) $r->remote_qty ) : '—'; ?></td>
							<td><?php echo $r->pushed_at ? esc_html( $r->pushed_at ) : '<span style="color:#bbb">—</span>'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php submit_button( __( 'Push selected stock to their store', 'wc-enterprise-erp' ), 'delete' ); ?>
			</form>
		<?php endif; ?>
		<?php
	}

	protected function render_connection() {
		global $wpdb;
		$configured = self::is_configured();
		$last_run   = wceerp_get_option( 'connect_last_run', '' );
		$last_err   = wceerp_get_option( 'connect_last_error', '' );
		$log_table  = wceerp_table( 'connect_log' );
		$recent     = $wpdb->get_results( "SELECT * FROM $log_table ORDER BY id DESC LIMIT 20" );
		$count      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $log_table" );
		?>
			<?php if ( isset( $_GET['posted'] ) && empty( $_GET['err'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>
					<?php printf( esc_html__( 'Sync finished: %1$d posted, %2$d already recorded.', 'wc-enterprise-erp' ), (int) $_GET['posted'], (int) ( $_GET['skipped'] ?? 0 ) ); ?>
				</p></div>
			<?php endif; ?>
			<?php if ( ! empty( $_GET['err'] ) ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( wp_unslash( $_GET['err'] ) ); ?></p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['reset'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Sync position reset. Run "Sync now" to re-scan.', 'wc-enterprise-erp' ); ?></p></div>
			<?php endif; ?>
			<?php if ( $last_err ) : ?>
				<div class="notice notice-warning"><p><strong><?php esc_html_e( 'Last sync error:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $last_err ); ?></p></div>
			<?php endif; ?>

			<div class="wceerp-card" style="max-width:720px">
				<h2><?php esc_html_e( 'Customer store connection', 'wc-enterprise-erp' ); ?></h2>
				<?php
				$vault_notice = class_exists( 'WCEERP_Vault' ) ? WCEERP_Vault::config_notice() : '';
				if ( $vault_notice ) :
					?>
					<div class="notice notice-warning inline" style="margin:8px 0"><p><strong><?php esc_html_e( 'Credential security:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $vault_notice ); ?></p></div>
				<?php elseif ( class_exists( 'WCEERP_Vault' ) && WCEERP_Vault::has_dedicated_key() ) : ?>
					<p style="color:#2f8a4c;font-size:13px">🔒 <?php esc_html_e( 'Credentials are encrypted at rest with a dedicated vault key.', 'wc-enterprise-erp' ); ?></p>
				<?php endif; ?>
				<p class="description">
					<?php esc_html_e( 'Ask the customer to create REST API keys on their own store: WooCommerce → Settings → Advanced → REST API → Add key, with Read permission. Paste the URL and keys here.', 'wc-enterprise-erp' ); ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_connect_save">
					<?php wp_nonce_field( 'wceerp_connect_save' ); ?>
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Store URL', 'wc-enterprise-erp' ); ?></th>
							<td><input type="url" name="url" class="regular-text" required placeholder="https://customer-store.com" value="<?php echo esc_attr( self::cfg( 'url' ) ); ?>">
								<p class="description"><?php esc_html_e( 'Must be HTTPS.', 'wc-enterprise-erp' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Consumer key', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="ck" class="regular-text" value="" autocomplete="off" placeholder="<?php echo self::cfg( 'ck' ) ? esc_attr( WCEERP_Vault::mask( self::cfg( 'ck' ) ) ) . '  ' . esc_attr__( '(leave blank to keep)', 'wc-enterprise-erp' ) : 'ck_…'; ?>"></td></tr>
						<tr><th><?php esc_html_e( 'Consumer secret', 'wc-enterprise-erp' ); ?></th>
							<td><input type="password" name="cs" class="regular-text" autocomplete="new-password" placeholder="<?php echo self::cfg( 'cs' ) ? '••••••••  (leave blank to keep)' : 'cs_…'; ?>"></td></tr>
						<tr><th><?php esc_html_e( 'Cost meta key', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="cost_meta_key" class="regular-text" value="<?php echo esc_attr( self::cfg( 'cost_meta_key', '_wc_cog_cost' ) ); ?>">
								<p class="description"><?php esc_html_e( 'Product meta key on their store holding the cost price (used by the Cost basis tab). Common: _wc_cog_cost', 'wc-enterprise-erp' ); ?></p></td></tr>
						<tr><th><?php esc_html_e( 'Order statuses to import', 'wc-enterprise-erp' ); ?></th>
							<td><input type="text" name="statuses" class="regular-text" value="<?php echo esc_attr( self::cfg( 'statuses', 'processing,completed' ) ); ?>">
								<p class="description"><?php esc_html_e( 'Comma separated. Default: processing,completed', 'wc-enterprise-erp' ); ?></p></td></tr>
					</tbody></table>
					<?php submit_button( __( 'Save connection', 'wc-enterprise-erp' ) ); ?>
				</form>

				<?php if ( $configured ) : ?>
					<hr>
					<p>
						<strong><?php esc_html_e( 'Status:', 'wc-enterprise-erp' ); ?></strong>
						<?php
						$test = self::test_connection();
						if ( is_wp_error( $test ) ) {
							echo '<span style="color:#c8302e">' . esc_html( $test->get_error_message() ) . '</span>';
						} else {
							echo '<span style="color:#2f8a4c">' . esc_html( $test ) . '</span>';
						}
						?>
					</p>
					<p>
						<?php if ( $last_run ) : ?>
							<?php printf( esc_html__( 'Last sync: %s', 'wc-enterprise-erp' ), esc_html( $last_run ) ); ?> ·
						<?php endif; ?>
						<?php printf( esc_html__( '%d orders imported so far', 'wc-enterprise-erp' ), $count ); ?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
						<input type="hidden" name="action" value="wceerp_connect_sync">
						<?php wp_nonce_field( 'wceerp_connect_sync' ); ?>
						<?php submit_button( __( 'Sync now', 'wc-enterprise-erp' ), 'secondary', 'submit', false ); ?>
						<span class="description"><?php esc_html_e( 'Runs automatically every hour.', 'wc-enterprise-erp' ); ?></span>
					</form>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;margin-left:8px" onsubmit="return confirm('<?php echo esc_js( __( 'Re-scan from 30 days back? Orders already imported are skipped, so nothing is double-counted.', 'wc-enterprise-erp' ) ); ?>');">
						<input type="hidden" name="action" value="wceerp_connect_reset">
						<?php wp_nonce_field( 'wceerp_connect_reset' ); ?>
						<?php submit_button( __( 'Reset sync position', 'wc-enterprise-erp' ), 'link', 'submit', false ); ?>
					</form>
				<?php endif; ?>
			</div>

			<?php if ( $recent ) : ?>
				<div class="wceerp-card" style="margin-top:16px">
					<h2><?php esc_html_e( 'Recently imported orders', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped">
						<thead><tr>
							<th><?php esc_html_e( 'Remote order', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Order date', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Journal', 'wc-enterprise-erp' ); ?></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $recent as $r ) : ?>
							<tr>
								<td>#<?php echo (int) $r->remote_id; ?></td>
								<td><?php echo esc_html( mysql2date( 'j M Y', $r->order_date ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $r->total ) ); ?></td>
								<td>#<?php echo (int) $r->journal_id; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		<?php
	}
}
