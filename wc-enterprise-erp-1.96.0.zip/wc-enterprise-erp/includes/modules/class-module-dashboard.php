<?php
/**
 * Module: Dashboard — the ERP landing screen.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Dashboard extends WCEERP_Module {

	protected $id         = 'dashboard';
	protected $title      = 'Dashboard';
	protected $capability = 'wceerp_view_dashboard';
	protected $tier       = 'starter';
	protected $order      = 5;
	protected $has_menu   = false; // Rendered by the top-level ERP menu itself.

	public function __construct() {
		$this->title = __( 'Dashboard', 'wc-enterprise-erp' );
	}

	public function init() {}

	public function render_page() {
		global $wpdb;

		$fy   = wceerp_fiscal_year();
		$from = sanitize_text_field( $_GET['from'] ?? $fy['start'] );
		$to   = sanitize_text_field( $_GET['to'] ?? $fy['end'] );

		$types = WCEERP_Accounting::type_balances( $from, $to );

		$sum = function ( $type ) use ( $types ) {
			$total = 0;
			foreach ( isset( $types[ $type ] ) ? $types[ $type ] : array() as $row ) {
				$total += $row['amount'];
			}
			return $total;
		};

		$income   = $sum( 'income' );
		$expense  = $sum( 'expense' );
		$profit   = $income - $expense;

		// Money account balances (all time, from posted journal lines).
		$jl       = wceerp_table( 'journal_lines' );
		$j        = wceerp_table( 'journals' );
		$acc      = wceerp_table( 'accounts' );
		/* The posted test has to be in WHERE. In a LEFT JOIN's ON clause it
		 * does not exclude anything: the line survives with NULL journal
		 * columns and its debit and credit are summed regardless, so voided
		 * entries were being counted into cash and bank balances.
		 *
		 * A LEFT JOIN from accounts is still wanted here, so that a money
		 * account with no movement shows as zero rather than vanishing --
		 * hence the subquery rather than an INNER JOIN. */
		$money    = $wpdb->get_results(
			"SELECT a.name, a.subtype, COALESCE(SUM(l.debit - l.credit),0) AS balance
			 FROM $acc a
			 LEFT JOIN (
			     SELECT ln.account_id, ln.debit, ln.credit
			     FROM $jl ln
			     INNER JOIN $j jn ON jn.id = ln.journal_id
			     WHERE jn.status = 'posted'
			 ) l ON l.account_id = a.id
			 WHERE a.subtype IN ('cash','bank','mobile_banking')
			 GROUP BY a.id ORDER BY a.code"
		);

		// Dues.
		$cust_due = 0;
		foreach ( WCEERP_Accounting::party_balances( 'customer', 'receivable' ) as $r ) {
			$cust_due += max( 0, (float) $r->balance );
		}
		$supp_due = 0;
		foreach ( WCEERP_Accounting::party_balances( 'supplier', 'payable' ) as $r ) {
			$supp_due += max( 0, -(float) $r->balance );
		}

		// Stock value + low stock.
		$stock       = wceerp_table( 'stock' );
		$stock_value = (float) $wpdb->get_var( "SELECT COALESCE(SUM(qty * avg_cost),0) FROM $stock" );
		$threshold   = (float) wceerp_get_option( 'low_stock_threshold', 5 );
		$low_stock   = $wpdb->get_results( $wpdb->prepare(
			"SELECT product_id, SUM(qty) AS qty FROM $stock GROUP BY product_id HAVING qty <= %f ORDER BY qty ASC LIMIT 10",
			$threshold
		) );

		// Recent journals.
		$journals = $wpdb->get_results( "SELECT * FROM $j WHERE status = 'posted' ORDER BY id DESC LIMIT 8" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo esc_html( wceerp_get_option( 'company_name', __( 'Enterprise ERP', 'wc-enterprise-erp' ) ) ); ?> — <?php esc_html_e( 'Dashboard', 'wc-enterprise-erp' ); ?></h1>
			<p class="description">
				<?php
				/* translators: 1: start date 2: end date */
				printf( esc_html__( 'Fiscal year %1$s to %2$s', 'wc-enterprise-erp' ), esc_html( $from ), esc_html( $to ) );
				?>
			</p>

			<?php
			/* The four figures the owner actually looks for, given colour
			 * and weight so the screen is glanced at rather than read.
			 * Same palette as the staff app, so moving between phone and
			 * desk feels like one product. */
			$margin   = $income > 0 ? ( $profit / $income ) * 100 : 0;
			$cod_held = class_exists( 'WCEERP_Module_Courier' ) ? (float) WCEERP_Module_Courier::cod_outstanding_total() : 0;
			?>
			<div class="wceerp-kpis is-hero">
				<div class="wceerp-kpi hero sales">
					<span class="ic dashicons dashicons-chart-line"></span>
					<span><?php esc_html_e( 'Sales / income', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $income ) ); ?></strong>
					<em><?php esc_html_e( 'this period', 'wc-enterprise-erp' ); ?></em>
				</div>

				<div class="wceerp-kpi hero orders">
					<span class="ic dashicons dashicons-tickets-alt"></span>
					<span><?php esc_html_e( 'Expenses', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $expense ) ); ?></strong>
					<em><?php esc_html_e( 'including cost of goods', 'wc-enterprise-erp' ); ?></em>
				</div>

				<div class="wceerp-kpi hero <?php echo $profit >= 0 ? 'profit' : 'loss'; ?>">
					<span class="ic dashicons dashicons-awards"></span>
					<span><?php echo $profit >= 0 ? esc_html__( 'Net profit', 'wc-enterprise-erp' ) : esc_html__( 'Net loss', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( abs( $profit ) ) ); ?></strong>
					<em><?php printf( esc_html__( 'Margin %s%%', 'wc-enterprise-erp' ), esc_html( number_format( $margin, 1 ) ) ); ?></em>
				</div>

				<div class="wceerp-kpi hero cod">
					<span class="ic dashicons dashicons-cart"></span>
					<span><?php esc_html_e( 'COD with couriers', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $cod_held ) ); ?></strong>
					<em><?php esc_html_e( 'not yet in your bank', 'wc-enterprise-erp' ); ?></em>
				</div>
			</div>

			<?php
			// ---- Corporate metrics band -------------------------------
			// Figures a business owner is asked for in a board meeting:
			// what came in, what it cost, what is owed both ways, and how
			// much of it is actually cash. All read from the ledger.
			global $wpdb;
			$today      = current_time( 'Y-m-d' );
			$month_from = gmdate( 'Y-m-01' );

			$today_rows = WCEERP_Accounting::trial_balance( $today, $today );
			$today_sales = 0.0;
			foreach ( (array) $today_rows as $r ) {
				if ( 'income' === $r->type ) {
					$today_sales += (float) $r->credit - (float) $r->debit;
				}
			}

			$orders_month = 0;
			if ( function_exists( 'wc_get_orders' ) ) {
				$orders_month = count( wc_get_orders( array(
					'limit'        => -1,
					'return'       => 'ids',
					'status'       => array( 'processing', 'completed' ),
					'date_created' => '>=' . $month_from,
				) ) );
			}
			$aov     = $orders_month > 0 ? $income / $orders_month : 0;
			$margin  = $income > 0 ? ( $profit / $income ) * 100 : 0;
			$net_pos = $cust_due - $supp_due;

			$cod_held = 0.0;
			$cons_t   = wceerp_table( 'consignments' );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $cons_t ) ) === $cons_t ) {
				$cod_held = (float) $wpdb->get_var( "SELECT COALESCE(SUM(cod_amount - collected_amount),0) FROM $cons_t WHERE status IN ('booked','in_transit','delivered')" );
			}
			?>
			<div class="wceerp-metrics">
				<div class="m">
					<span class="k"><?php esc_html_e( "Today's sales", 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $today_sales ) ); ?></strong>
				</div>
				<div class="m">
					<span class="k"><?php esc_html_e( 'Orders this month', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo (int) $orders_month; ?></strong>
				</div>
				<div class="m">
					<span class="k"><?php esc_html_e( 'Average order value', 'wc-enterprise-erp' ); ?></span>
					<strong><?php echo wp_kses_post( wceerp_money( $aov ) ); ?></strong>
				</div>
				<div class="m">
					<span class="k"><?php esc_html_e( 'Gross margin', 'wc-enterprise-erp' ); ?></span>
					<strong style="color:<?php echo $margin >= 0 ? '#2f8a4c' : '#c8302e'; ?>"><?php echo esc_html( number_format( $margin, 1 ) ); ?>%</strong>
				</div>
				<div class="m">
					<span class="k"><?php esc_html_e( 'Working capital position', 'wc-enterprise-erp' ); ?></span>
					<strong style="color:<?php echo $net_pos >= 0 ? '#2f8a4c' : '#c8302e'; ?>"><?php echo wp_kses_post( wceerp_money( $net_pos ) ); ?></strong>
					<small><?php esc_html_e( 'receivables less payables', 'wc-enterprise-erp' ); ?></small>
				</div>
				<div class="m">
					<span class="k"><?php esc_html_e( 'COD with couriers', 'wc-enterprise-erp' ); ?></span>
					<strong style="color:<?php echo $cod_held > 0.004 ? '#b98a2f' : '#8a8f98'; ?>"><?php echo wp_kses_post( wceerp_money( $cod_held ) ); ?></strong>
					<small><?php esc_html_e( 'not yet in your bank', 'wc-enterprise-erp' ); ?></small>
				</div>
			</div>

			<?php
			/* Portal card. Without a visible link the portal was invisible —
			 * an operator had no way to reach it, or to install the app. */
			if ( class_exists( 'WCEERP_Portal' ) ) :
				$portal_on  = WCEERP_Portal::is_enabled();
				$portal_url = WCEERP_Portal::url();
				?>
				<div class="wceerp-portal-card <?php echo $portal_on ? 'is-on' : 'is-off'; ?>">
					<div class="pc-ic">📱</div>
					<div class="pc-tx">
						<strong><?php esc_html_e( 'Staff app', 'wc-enterprise-erp' ); ?></strong>
						<?php if ( $portal_on ) : ?>
							<span>
								<?php esc_html_e( 'Open on a phone and tap Install to add it to the home screen.', 'wc-enterprise-erp' ); ?>
								<code><?php echo esc_html( $portal_url ); ?></code>
							</span>
						<?php else : ?>
							<span><?php esc_html_e( 'A phone-friendly app for your staff, with PIN sign-in. Currently switched off.', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</div>
					<div class="pc-go">
						<?php if ( $portal_on ) : ?>
							<a class="button button-primary" href="<?php echo esc_url( $portal_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open app', 'wc-enterprise-erp' ); ?></a>
						<?php else : ?>
							<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=wceerp-settings' ) ); ?>"><?php esc_html_e( 'Turn on', 'wc-enterprise-erp' ); ?></a>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="wceerp-quick">
				<?php
				$quick = array();
				if ( class_exists( 'WCEERP_Module_POS' ) ) {
					$quick[] = array( home_url( '/wceerp-pos' ), '🧾', __( 'New sale / POS', 'wc-enterprise-erp' ), __( 'Open the terminal', 'wc-enterprise-erp' ) );
				}
				$quick[] = array( admin_url( 'admin.php?page=wceerp-purchases' ), '📦', __( 'Receive purchase', 'wc-enterprise-erp' ), __( 'Stock in + supplier due', 'wc-enterprise-erp' ) );
				$quick[] = array( admin_url( 'admin.php?page=wceerp-expenses&tab=add' ), '💸', __( 'Record expense', 'wc-enterprise-erp' ), __( 'Rent, utilities, transport…', 'wc-enterprise-erp' ) );
				$quick[] = array( admin_url( 'admin.php?page=wceerp-dues' ), '💰', __( 'Record payment', 'wc-enterprise-erp' ), __( 'Customer / supplier', 'wc-enterprise-erp' ) );
				foreach ( $quick as $q ) :
					?>
					<a class="wceerp-quick-card" href="<?php echo esc_url( $q[0] ); ?>">
						<span class="ic"><?php echo esc_html( $q[1] ); ?></span>
						<span class="tx"><strong><?php echo esc_html( $q[2] ); ?></strong><small><?php echo esc_html( $q[3] ); ?></small></span>
					</a>
				<?php endforeach; ?>
			</div>

			<div class="wceerp-kpis">
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Cash + bank + wallets', 'wc-enterprise-erp' ); ?></span><strong>
					<?php
					$money_total = 0;
					foreach ( $money as $m ) {
						$money_total += (float) $m->balance;
					}
					echo wp_kses_post( wceerp_money( $money_total ) );
					?>
				</strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Customer due', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $cust_due ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Supplier due', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $supp_due ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Stock value', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $stock_value ) ); ?></strong></div>
			</div>

			<?php
			// Needs-attention strip: only shown when there is something to say.
			$alerts = array();
			if ( $low_stock ) {
				$alerts[] = array( 'warn', sprintf( _n( '%d product is running low', '%d products are running low', count( $low_stock ), 'wc-enterprise-erp' ), count( $low_stock ) ), admin_url( 'admin.php?page=wceerp-inventory' ) );
			}
			if ( class_exists( 'WCEERP_Module_Courier' ) ) {
				$cons_t = wceerp_table( 'consignments' );
				$held   = (float) $wpdb->get_var( "SELECT COALESCE(SUM(cod_amount - collected_amount),0) FROM $cons_t WHERE status IN ('booked','in_transit','delivered')" );
				if ( $held > 0.004 ) {
					$alerts[] = array( 'info', sprintf( __( '%s COD still held by couriers', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $held ) ) ), admin_url( 'admin.php?page=wceerp-courier&tab=orders' ) );
				}
			}
			if ( $cust_due > 0.004 ) {
				$alerts[] = array( 'info', sprintf( __( '%s owed by customers', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $cust_due ) ) ), admin_url( 'admin.php?page=wceerp-dues' ) );
			}
			?>
			<?php if ( $alerts ) : ?>
				<div class="wceerp-alerts">
					<?php foreach ( $alerts as $a ) : ?>
						<a class="wceerp-alert is-<?php echo esc_attr( $a[0] ); ?>" href="<?php echo esc_url( $a[2] ); ?>">
							<span><?php echo 'warn' === $a[0] ? '⚠️' : '💡'; ?></span>
							<span><?php echo esc_html( $a[1] ); ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Cash, bank & mobile banking', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped wceerp-table">
						<thead><tr><th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Balance', 'wc-enterprise-erp' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( (array) $money as $m ) : ?>
							<tr>
								<td><?php echo esc_html( $m->name ); ?> <span class="wceerp-badge is-<?php echo esc_attr( $m->subtype ); ?>"><?php echo esc_html( str_replace( '_', ' ', $m->subtype ) ); ?></span></td>
								<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $m->balance ) ); ?></strong></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Low stock', 'wc-enterprise-erp' ); ?></h2>
					<?php if ( ! $low_stock ) : ?>
						<p><?php esc_html_e( 'All products are above the low-stock threshold. 🎉', 'wc-enterprise-erp' ); ?></p>
					<?php else : ?>
					<table class="widefat striped wceerp-table">
						<thead><tr><th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Qty (all warehouses)', 'wc-enterprise-erp' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $low_stock as $row ) : ?>
							<tr>
								<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->product_id . '&action=edit' ) ); ?>"><?php echo esc_html( get_the_title( $row->product_id ) ?: '#' . $row->product_id ); ?></a></td>
								<td class="num"><span class="wceerp-badge is-out"><?php echo esc_html( wceerp_lakh_format( $row->qty, 0 ) ); ?></span></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php endif; ?>
				</div>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Recent journal entries', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Doc no.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Memo', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $journals ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No journal entries yet — receive a purchase or complete a WooCommerce order to see accounting flow in.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $journals as $entry ) : ?>
						<tr>
							<td><code><?php echo esc_html( $entry->doc_no ); ?></code></td>
							<td><?php echo esc_html( $entry->journal_date ); ?></td>
							<td><span class="wceerp-badge is-<?php echo esc_attr( $entry->ref_type ); ?>"><?php echo esc_html( $entry->ref_type ); ?></span></td>
							<td><?php echo esc_html( $entry->memo ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>

		<?php $this->render_feature_highlights(); ?>
		<?php
	}

	/**
	 * Feature showcase: everything in the buyer's package with a ✓, and
	 * what the next tier unlocks with a lock — the ERP sells its own
	 * upgrades honestly, from inside the dashboard.
	 */
	protected function render_feature_highlights() {
		$catalog = array(
			array( 'inventory', __( 'Multi-warehouse Inventory', 'wc-enterprise-erp' ), __( 'Live WooCommerce stock sync, average costing, transfers, opening stock import.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'accounting', __( 'Double-entry Accounting', 'wc-enterprise-erp' ), __( 'Real journals behind every sale, purchase and payment — trial balance always balances.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'purchases', __( 'Purchases & Suppliers', 'wc-enterprise-erp' ), __( 'POs, goods receipt, supplier dues and payments.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'courier', __( 'Courier & COD (BD)', 'wc-enterprise-erp' ), __( 'Steadfast & Pathao booking, tracking, COD receivable and payout reconciliation.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'tax', __( 'VAT / Mushak', 'wc-enterprise-erp' ), __( 'VAT-inclusive pricing, output/input VAT accounts, Mushak-style summaries.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'dues', __( 'Dues & Payments', 'wc-enterprise-erp' ), __( 'Customer, dealer and supplier ledgers with one-click payment posting.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'crm', __( 'CRM & Pipeline', 'wc-enterprise-erp' ), __( 'Lead board, WhatsApp links, follow-up reminders, conversion reports.', 'wc-enterprise-erp' ), 'business' ),
			array( 'service', __( 'Service, AMC & Tickets', 'wc-enterprise-erp' ), __( 'Recurring contract invoicing as real orders; support tickets with time logs.', 'wc-enterprise-erp' ), 'business' ),
			array( 'dealers', __( 'Dealer / B2B Portal', 'wc-enterprise-erp' ), __( 'Dealer prices on the storefront, credit limits, self-serve statements.', 'wc-enterprise-erp' ), 'business' ),
			array( 'procurement', __( 'RFQ & Purchase Approvals', 'wc-enterprise-erp' ), __( 'Quote comparison, award-to-PO, two-level approval thresholds, supplier ratings.', 'wc-enterprise-erp' ), 'business' ),
			array( 'analytics', __( 'Analytics', 'wc-enterprise-erp' ), __( '12-month profit and cash-flow charts, movers, supplier spend.', 'wc-enterprise-erp' ), 'business' ),
			array( 'banking', __( 'Bank Reconciliation', 'wc-enterprise-erp' ), __( 'Statement import and book-vs-bank matching.', 'wc-enterprise-erp' ), 'business' ),
			array( 'pos', __( 'Offline POS + Exchange', 'wc-enterprise-erp' ), __( 'Sells through internet outages; returns, exchanges, shifts, X/Z reports, 80mm & A4 printing.', 'wc-enterprise-erp' ), 'starter' ),
			array( 'hr', __( 'HR & Payroll', 'wc-enterprise-erp' ), __( 'Attendance-aware payroll paying every employee via their own bKash/Nagad/bank channel.', 'wc-enterprise-erp' ), 'enterprise' ),
			array( 'ai', __( 'Business Assistant', 'wc-enterprise-erp' ), __( 'Stock-out forecasts, cash runway, supplier price gaps — plus optional AI Q&A on your books.', 'wc-enterprise-erp' ), 'enterprise' ),
			array( 'api', __( 'Mobile App REST API', 'wc-enterprise-erp' ), __( 'Secure endpoints for a companion app: dashboard, stock, dues, payments, push devices.', 'wc-enterprise-erp' ), 'enterprise' ),
			array( 'branches', __( 'Multi-branch', 'wc-enterprise-erp' ), __( 'Branch-tagged books and warehouses with branch comparison.', 'wc-enterprise-erp' ), 'enterprise' ),
			array( 'whitelabel', __( 'White Label + Multi-company', 'wc-enterprise-erp' ), __( 'Your brand on everything; unlimited isolated companies via Multisite.', 'wc-enterprise-erp' ), 'enterprise' ),
		);
		$next_tier = array( 'starter' => __( 'Business package', 'wc-enterprise-erp' ), 'business' => __( 'Business package', 'wc-enterprise-erp' ), 'enterprise' => __( 'Enterprise package', 'wc-enterprise-erp' ) );
		?>
		<div class="wceerp-card">
			<h2><?php echo esc_html( apply_filters( 'wceerp_brand', 'WooCommerce ERP' ) ); ?> — <?php esc_html_e( 'your package at a glance', 'wc-enterprise-erp' ); ?></h2>
			<?php if ( class_exists( 'WCEERP_Limits' ) && WCEERP_Limits::active() ) : ?>
				<div class="wceerp-usage">
					<?php foreach ( array( 'users', 'products', 'orders_month' ) as $resource ) :
						$limit = WCEERP_Limits::limit( $resource );
						$used  = WCEERP_Limits::usage( $resource );
						$label = WCEERP_Limits::LIMIT_LABELS[ $resource ];
						$pct   = $limit > 0 ? min( 100, round( 100 * $used / $limit ) ) : 0;
						$near  = $limit > 0 && $pct >= 80;
						?>
						<div class="wceerp-usage-item">
							<span><?php echo esc_html( $label ); ?></span>
							<strong><?php echo (int) $used; ?><?php echo $limit > 0 ? ' / ' . (int) $limit : ' <small>· ' . esc_html__( 'unlimited', 'wc-enterprise-erp' ) . '</small>'; ?></strong>
							<?php if ( $limit > 0 ) : ?>
								<div class="bar"><div style="width:<?php echo (int) $pct; ?>%;background:<?php echo $near ? '#c8302e' : '#2f8a4c'; ?>"></div></div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="wceerp-features">
				<?php foreach ( $catalog as $feature ) :
					list( $slug, $title, $description, $tier ) = $feature;
					$unlocked = WCEERP_License::tier_allows( $tier );
					?>
					<div class="wceerp-feature <?php echo $unlocked ? 'is-on' : 'is-locked'; ?>">
						<span class="st"><?php echo $unlocked ? '✓' : '🔒'; ?></span>
						<b><?php echo esc_html( $title ); ?></b>
						<small><?php echo esc_html( $description ); ?></small>
						<?php if ( ! $unlocked ) : ?>
							<em><?php printf( esc_html__( 'Unlocks with the %s', 'wc-enterprise-erp' ), esc_html( $next_tier[ $tier ] ) ); ?></em>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
