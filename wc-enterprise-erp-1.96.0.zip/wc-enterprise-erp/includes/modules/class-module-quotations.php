<?php
/**
 * Module: Quotations — price quotes that convert into WooCommerce orders.
 *
 * Flow: draft → sent → accepted → converted (a real WooCommerce order is
 * created with the quoted lines and prices). Rejected/expired close it.
 * Quotes never touch stock or the books — only the converted order does,
 * through the normal WooCommerce bridge.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Quotations extends WCEERP_Module {

	protected $id         = 'quotations';
	protected $title      = 'Quotations';
	protected $capability = 'wceerp_manage_quotations';
	protected $tier       = 'starter';
	protected $order      = 27;

	public function __construct() {
		$this->title = __( 'Quotations', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_quotation_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_quotation_status', array( $this, 'handle_status' ) );
		add_action( 'admin_post_wceerp_quotation_convert', array( $this, 'handle_convert' ) );
		add_action( 'admin_post_wceerp_quotation_pdf', array( $this, 'handle_pdf' ) );
	}

	protected function get_quotation( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'quotations' ) . ' WHERE id=%d', $id ) );
	}

	protected function get_items( $id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'quotation_items' ) . ' WHERE quotation_id=%d ORDER BY id', $id ) );
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	public function handle_save() {
		$this->verify_nonce( 'wceerp_quotation_save' );
		global $wpdb;

		$products = array_map( 'intval', (array) ( $_POST['item_product'] ?? array() ) );
		$descs    = array_map( 'sanitize_text_field', array_map( 'wp_unslash', (array) ( $_POST['item_desc'] ?? array() ) ) );
		$qtys     = array_map( 'wceerp_dec', (array) ( $_POST['item_qty'] ?? array() ) );
		$prices   = array_map( 'wceerp_dec', (array) ( $_POST['item_price'] ?? array() ) );
		$taxes    = array_map( 'wceerp_dec', (array) ( $_POST['item_tax'] ?? array() ) );

		$subtotal = 0;
		$tax      = 0;
		$items    = array();
		foreach ( $qtys as $i => $qty ) {
			$product_id = $products[ $i ] ?? 0;
			$desc       = $descs[ $i ] ?? '';
			if ( $qty <= 0 || ( ! $product_id && ! $desc ) ) {
				continue;
			}
			if ( ! $desc && $product_id ) {
				$desc = get_the_title( $product_id );
			}
			$line      = $qty * ( $prices[ $i ] ?? 0 );
			$line_tax  = $line * ( ( $taxes[ $i ] ?? 0 ) / 100 );
			$subtotal += $line;
			$tax      += $line_tax;
			$items[]   = array(
				'product_id' => $product_id ? $product_id : null,
				'description' => $desc,
				'qty'        => $qty,
				'unit_price' => $prices[ $i ] ?? 0,
				'tax_rate'   => $taxes[ $i ] ?? 0,
				'line_total' => $line + $line_tax,
			);
		}

		$name = sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) );
		if ( ! $name || ! $items ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'new', 'error' => 'incomplete' ) ) );
			exit;
		}

		$discount = wceerp_dec( $_POST['discount'] ?? 0 );

		$wpdb->insert( wceerp_table( 'quotations' ), array(
			'doc_no'           => wceerp_next_doc_number( 'qt' ),
			'customer_user_id' => (int) ( $_POST['customer_user_id'] ?? 0 ) ?: null,
			'customer_name'    => $name,
			'phone'            => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'email'            => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
			'address'          => sanitize_textarea_field( wp_unslash( $_POST['address'] ?? '' ) ),
			'status'           => 'draft',
			'subtotal'         => $subtotal,
			'tax_total'        => $tax,
			'discount'         => $discount,
			'grand_total'      => $subtotal + $tax - $discount,
			'valid_until'      => ! empty( $_POST['valid_until'] ) ? sanitize_text_field( $_POST['valid_until'] ) : null,
			'note'             => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_by'       => get_current_user_id(),
			'created_at'       => current_time( 'mysql' ),
		) );
		$quotation_id = (int) $wpdb->insert_id;

		foreach ( $items as $item ) {
			$item['quotation_id'] = $quotation_id;
			$wpdb->insert( wceerp_table( 'quotation_items' ), $item );
		}

		wceerp_log( 'quotations', 'create', $quotation_id );
		wp_safe_redirect( $this->admin_url( array( 'view' => $quotation_id, 'updated' => 1 ) ) );
		exit;
	}

	public function handle_status() {
		$this->verify_nonce( 'wceerp_quotation_status' );
		global $wpdb;

		$id      = (int) ( $_POST['quotation_id'] ?? 0 );
		$status  = sanitize_key( $_POST['new_status'] ?? '' );
		$allowed = array( 'draft', 'sent', 'accepted', 'rejected', 'expired' );

		if ( $id && in_array( $status, $allowed, true ) ) {
			$wpdb->update( wceerp_table( 'quotations' ), array( 'status' => $status ), array( 'id' => $id ) );
			wceerp_log( 'quotations', 'status', $id, $status );
		}
		wp_safe_redirect( $this->admin_url( array( 'view' => $id, 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Convert an accepted quotation into a real WooCommerce order with the
	 * quoted lines and prices. Stock and books flow through the normal
	 * WooCommerce bridge when the order is processed.
	 */
	public function handle_convert() {
		$this->verify_nonce( 'wceerp_quotation_convert' );
		global $wpdb;

		$id        = (int) ( $_POST['quotation_id'] ?? 0 );
		$quotation = $this->get_quotation( $id );
		if ( ! $quotation || 'converted' === $quotation->status ) {
			wp_safe_redirect( $this->admin_url() );
			exit;
		}

		$order = wc_create_order( array(
			'customer_id' => (int) $quotation->customer_user_id,
			'created_via' => 'wceerp_quotation',
		) );
		if ( is_wp_error( $order ) ) {
			wp_die( esc_html( $order->get_error_message() ) );
		}

		foreach ( $this->get_items( $id ) as $item ) {
			$net = (float) $item->qty * (float) $item->unit_price;
			$vat = $net * ( (float) $item->tax_rate / 100 );

			if ( $item->product_id && ( $product = wc_get_product( $item->product_id ) ) ) {
				$order_item_id = $order->add_product( $product, (float) $item->qty, array(
					'subtotal' => $net,
					'total'    => $net,
				) );
			} else {
				$line = new WC_Order_Item_Product();
				$line->set_name( $item->description );
				$line->set_quantity( (float) $item->qty );
				$line->set_subtotal( $net );
				$line->set_total( $net );
				$order->add_item( $line );
				$order_item_id = $line->get_id();
			}

			// Carry quoted VAT as a line-level total tax if WooCommerce taxes are not configured to recalc.
			if ( $vat > 0 && $order_item_id ) {
				$order_item = $order->get_item( $order_item_id );
				if ( $order_item ) {
					$order_item->set_taxes( array( 'total' => array( $vat ), 'subtotal' => array( $vat ) ) );
					$order_item->save();
				}
			}
		}

		if ( (float) $quotation->discount > 0 ) {
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( __( 'Quotation discount', 'wc-enterprise-erp' ) );
			$fee->set_total( -1 * (float) $quotation->discount );
			$order->add_item( $fee );
		}

		$order->set_billing_first_name( $quotation->customer_name );
		if ( $quotation->phone ) {
			$order->set_billing_phone( $quotation->phone );
		}
		if ( $quotation->email ) {
			$order->set_billing_email( $quotation->email );
		}
		if ( $quotation->address ) {
			$order->set_billing_address_1( wp_strip_all_tags( $quotation->address ) );
		}

		$order->update_meta_data( '_wceerp_quotation_id', $id );
		$order->update_meta_data( '_wceerp_quotation_no', $quotation->doc_no );
		$order->calculate_totals( false );
		$order->set_status( 'pending', sprintf( __( 'Created from quotation %s.', 'wc-enterprise-erp' ), $quotation->doc_no ) );
		$order->save();

		$wpdb->update( wceerp_table( 'quotations' ), array(
			'status'   => 'converted',
			'order_id' => $order->get_id(),
		), array( 'id' => $id ) );

		wceerp_log( 'quotations', 'convert', $id, 'order #' . $order->get_id() );
		wp_safe_redirect( admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' ) );
		exit;
	}

	/**
	 * Stream a quotation PDF via the built-in PDF writer.
	 */
	public function handle_pdf() {
		if ( ! wp_verify_nonce( sanitize_key( $_GET['_wpnonce'] ?? '' ), 'wceerp_quotation_pdf' ) || ! wceerp_user_can( $this->capability ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}

		$quotation = $this->get_quotation( (int) ( $_GET['quotation_id'] ?? 0 ) );
		if ( ! $quotation ) {
			wp_die( esc_html__( 'Quotation not found.', 'wc-enterprise-erp' ) );
		}
		$items = $this->get_items( $quotation->id );

		$pdf   = new WCEERP_PDF();
		$pdf->add_page();
		$left  = 40;
		$right = 555;
		$y     = 50;

		$inv = WCEERP_Invoice_Settings::get();

		$pdf->set_font( 16, true )->text( $left, $y, $inv['company_name'] );
		$pdf->set_font( 13, true )->text_right( $right, $y, __( 'QUOTATION', 'wc-enterprise-erp' ) );
		$y += 14;
		$pdf->set_font( 9 );
		if ( $inv['address'] ) {
			foreach ( array_slice( preg_split( '/\r\n|\n|\r/', $inv['address'] ), 0, 3 ) as $addr_line ) {
				$pdf->text( $left, $y, mb_substr( $addr_line, 0, 70 ) );
				$y += 11;
			}
		}
		$contact = trim( $inv['phone'] . ( $inv['phone'] && $inv['email'] ? '  ·  ' : '' ) . $inv['email'] );
		if ( $contact ) {
			$pdf->text( $left, $y, $contact );
			$y += 11;
		}
		if ( $inv['bin'] ) {
			$pdf->text( $left, $y, sprintf( __( 'BIN: %s', 'wc-enterprise-erp' ), $inv['bin'] ) );
		}
		$meta_y = 64;
		$pdf->text_right( $right, $meta_y, sprintf( __( 'No: %s', 'wc-enterprise-erp' ), $quotation->doc_no ) );
		$meta_y += 12;
		$pdf->text_right( $right, $meta_y, sprintf( __( 'Date: %s', 'wc-enterprise-erp' ), mysql2date( 'j M Y', $quotation->created_at ) ) );
		if ( $quotation->valid_until ) {
			$meta_y += 12;
			$pdf->text_right( $right, $meta_y, sprintf( __( 'Valid until: %s', 'wc-enterprise-erp' ), $quotation->valid_until ) );
		}
		$y = max( $y, $meta_y ) + 14;
		$pdf->line( $left, $y, $right, $y, 1.2 );
		$y += 18;

		$pdf->set_font( 10, true )->text( $left, $y, __( 'Quoted to', 'wc-enterprise-erp' ) );
		$y += 13;
		$pdf->set_font( 9 )->text( $left, $y, $quotation->customer_name );
		$y += 12;
		if ( $quotation->phone || $quotation->email ) {
			$pdf->text( $left, $y, trim( $quotation->phone . '  ' . $quotation->email ) );
			$y += 12;
		}
		if ( $quotation->address ) {
			$pdf->text( $left, $y, mb_substr( preg_replace( '/\s+/', ' ', $quotation->address ), 0, 90 ) );
			$y += 12;
		}
		$y += 8;

		$pdf->set_font( 9, true );
		$pdf->text( $left, $y, __( 'SL', 'wc-enterprise-erp' ) );
		$pdf->text( 70, $y, __( 'Description', 'wc-enterprise-erp' ) );
		$pdf->text_right( 370, $y, __( 'Qty', 'wc-enterprise-erp' ) );
		$pdf->text_right( 445, $y, __( 'Unit price', 'wc-enterprise-erp' ) );
		$pdf->text_right( 500, $y, __( 'VAT %', 'wc-enterprise-erp' ) );
		$pdf->text_right( $right, $y, __( 'Total', 'wc-enterprise-erp' ) );
		$y += 5;
		$pdf->line( $left, $y, $right, $y );
		$y += 13;
		$pdf->set_font( 9 );

		$sl = 0;
		foreach ( (array) $items as $item ) {
			$sl++;
			$pdf->text( $left, $y, (string) $sl );
			$pdf->text( 70, $y, mb_substr( $item->description, 0, 48 ) );
			$pdf->text_right( 370, $y, rtrim( rtrim( number_format( (float) $item->qty, 2, '.', ',' ), '0' ), '.' ) );
			$pdf->text_right( 445, $y, number_format( (float) $item->unit_price, 2, '.', ',' ) );
			$pdf->text_right( 500, $y, rtrim( rtrim( number_format( (float) $item->tax_rate, 2, '.', ',' ), '0' ), '.' ) );
			$pdf->text_right( $right, $y, number_format( (float) $item->line_total, 2, '.', ',' ) );
			$y += 13;
			if ( $y > 700 ) {
				$pdf->add_page();
				$y = 50;
			}
		}
		$y += 3;
		$pdf->line( $left, $y, $right, $y );
		$y += 15;

		$totals = array(
			__( 'Subtotal', 'wc-enterprise-erp' )    => (float) $quotation->subtotal,
			__( 'VAT', 'wc-enterprise-erp' )         => (float) $quotation->tax_total,
			__( 'Discount', 'wc-enterprise-erp' )    => -1 * (float) $quotation->discount,
			__( 'Grand total', 'wc-enterprise-erp' ) => (float) $quotation->grand_total,
		);
		$i = 0;
		foreach ( $totals as $label => $amount ) {
			$i++;
			if ( 3 === $i && 0.0 === $amount ) {
				continue;
			}
			$pdf->set_font( 9, 4 === $i );
			$pdf->text_right( 500, $y, $label );
			$pdf->text_right( $right, $y, 'Tk ' . number_format( $amount, 2, '.', ',' ) );
			$y += 13;
		}

		if ( $quotation->note ) {
			$y += 10;
			$pdf->set_font( 9, true )->text( $left, $y, __( 'Notes', 'wc-enterprise-erp' ) );
			$y += 12;
			$pdf->set_font( 9 )->text( $left, $y, mb_substr( preg_replace( '/\s+/', ' ', $quotation->note ), 0, 110 ) );
			$y += 4;
		}

		if ( ! empty( $inv['terms'] ) ) {
			$y += 14;
			$pdf->set_font( 8, true )->text( $left, $y, __( 'Terms & Conditions', 'wc-enterprise-erp' ) );
			$y += 11;
			$pdf->set_font( 8 );
			foreach ( array_slice( preg_split( '/\r\n|\n|\r/', $inv['terms'] ), 0, 4 ) as $term_line ) {
				$pdf->text( $left, $y, mb_substr( $term_line, 0, 110 ) );
				$y += 10;
			}
		}

		if ( 'yes' === $inv['signature'] ) {
			$sign_y = 760;
			$pdf->line( $left, $sign_y, $left + 150, $sign_y );
			$pdf->line( $right - 150, $sign_y, $right, $sign_y );
			$pdf->set_font( 8 );
			$pdf->text_center( $left + 75, $sign_y + 11, __( 'Customer signature', 'wc-enterprise-erp' ) );
			$pdf->text_center( $right - 75, $sign_y + 11, __( 'Authorised signature', 'wc-enterprise-erp' ) );
		}

		$footer_text = $inv['footer'] ?: __( 'Prices are valid until the date shown above. This quotation is not a tax invoice.', 'wc-enterprise-erp' );
		$pdf->set_font( 7 )->text_center( ( $left + $right ) / 2, 810, $footer_text );

		$pdf->stream( $quotation->doc_no . '.pdf' );
	}

	/* ---------------------------------------------------------------------
	 * Screens.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		if ( isset( $_GET['view'] ) ) {
			$this->render_view( (int) $_GET['view'] );
			return;
		}
		$tab = sanitize_key( $_GET['tab'] ?? 'list' );
		?>
		<div class="wrap wceerp-wrap">
			<h1>
				<?php esc_html_e( 'Quotations', 'wc-enterprise-erp' ); ?>
				<a href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'new' ) ) ); ?>" class="page-title-action"><?php esc_html_e( 'New quotation', 'wc-enterprise-erp' ); ?></a>
			</h1>
			<?php if ( isset( $_GET['error'] ) ) { $this->notice( __( 'Please add a customer name and at least one line.', 'wc-enterprise-erp' ), 'error' ); } ?>
			<?php 'new' === $tab ? $this->render_form() : $this->render_list(); ?>
		</div>
		<?php
	}

	protected function render_list() {
		global $wpdb;
		$table    = wceerp_table( 'quotations' );
		$status   = sanitize_key( $_GET['status'] ?? '' );
		$where    = $status ? $wpdb->prepare( 'WHERE status = %s', $status ) : '';
		$per_page = 25;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table $where" );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d",
			$per_page, wceerp_offset( $per_page )
		) );
		$statuses = array( '', 'draft', 'sent', 'accepted', 'rejected', 'expired', 'converted' );
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-quotations">
			<select name="status">
				<?php foreach ( $statuses as $s ) : ?>
					<option value="<?php echo esc_attr( $s ); ?>" <?php selected( $status, $s ); ?>><?php echo esc_html( $s ? ucfirst( $s ) : __( 'All statuses', 'wc-enterprise-erp' ) ); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="button"><?php esc_html_e( 'Filter', 'wc-enterprise-erp' ); ?></button>
		</form>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Quote no.', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Valid until', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No quotations yet.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( (array) $rows as $r ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( $this->admin_url( array( 'view' => $r->id ) ) ); ?>"><code><?php echo esc_html( $r->doc_no ); ?></code></a></td>
					<td><?php echo esc_html( mysql2date( 'j M Y', $r->created_at ) ); ?></td>
					<td><?php echo esc_html( $r->customer_name ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->grand_total ) ); ?></td>
					<td><?php echo esc_html( $r->valid_until ?: '—' ); ?></td>
					<td><span class="wceerp-badge is-<?php echo esc_attr( $r->status ); ?>"><?php echo esc_html( ucfirst( $r->status ) ); ?></span></td>
					<td><?php echo $r->order_id ? '<a href="' . esc_url( admin_url( 'post.php?post=' . (int) $r->order_id . '&action=edit' ) ) . '">#' . (int) $r->order_id . '</a>' : '—'; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}

	protected function render_form() {
		$vat = esc_attr( wceerp_get_option( 'default_vat_rate', '15' ) );
		?>
		<div class="wceerp-card">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_quotation_save">
				<?php wp_nonce_field( 'wceerp_quotation_save' ); ?>

				<h3><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></h3>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Existing customer', 'wc-enterprise-erp' ); ?></th>
						<td>
							<select class="wc-customer-search" id="wceerp-q-customer" data-placeholder="<?php esc_attr_e( 'Search existing customer…', 'wc-enterprise-erp' ); ?>" data-allow_clear="true" style="width:60%;min-width:240px"></select>
							<p class="description"><?php esc_html_e( 'Pick one to auto-fill the fields below, or just type a new customer\'s details directly.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="customer_name" id="wceerp-q-name" class="regular-text" required></td></tr>
					<tr><th><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="phone" id="wceerp-q-phone" class="regular-text"></td></tr>
					<tr><th><?php esc_html_e( 'Email', 'wc-enterprise-erp' ); ?></th>
						<td><input type="email" name="email" id="wceerp-q-email" class="regular-text"></td></tr>
					<tr><th><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?></th>
						<td><textarea name="address" id="wceerp-q-address" rows="2" class="large-text"></textarea></td></tr>
					<input type="hidden" name="customer_user_id" id="wceerp-q-userid" value="0">
					<tr><th><?php esc_html_e( 'Valid until', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="valid_until" value="<?php echo esc_attr( gmdate( 'Y-m-d', strtotime( '+14 days' ) ) ); ?>"></td></tr>
				</tbody></table>
				<script>
				jQuery(function ($) {
					$('#wceerp-q-customer').on('change', function () {
						var id = $(this).val();
						if (!id) { $('#wceerp-q-userid').val(0); return; }
						$('#wceerp-q-userid').val(id);
						$.post(ajaxurl, { action: 'wceerp_customer_lookup', id: id, _wpnonce: '<?php echo esc_js( wp_create_nonce( 'wceerp_customer_lookup' ) ); ?>' }, function (r) {
							if (r && r.success) {
								if (!$('#wceerp-q-name').val()) { $('#wceerp-q-name').val(r.data.name); }
								if (!$('#wceerp-q-phone').val()) { $('#wceerp-q-phone').val(r.data.phone); }
								if (!$('#wceerp-q-email').val()) { $('#wceerp-q-email').val(r.data.email); }
								if (!$('#wceerp-q-address').val()) { $('#wceerp-q-address').val(r.data.address); }
							}
						});
					});
				});
				</script>

				<h3><?php esc_html_e( 'Lines', 'wc-enterprise-erp' ); ?></h3>
				<table class="widefat wceerp-items wceerp-table">
					<thead><tr>
						<th style="width:28%"><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th style="width:24%"><?php esc_html_e( 'Description (optional override)', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Unit price', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'VAT %', 'wc-enterprise-erp' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
						<tr>
							<td><?php wceerp_product_select( 'item_product[]' ); ?></td>
							<td><input type="text" name="item_desc[]" placeholder="<?php esc_attr_e( 'Custom line / service…', 'wc-enterprise-erp' ); ?>"></td>
							<td><input type="number" name="item_qty[]" step="0.01" min="0"></td>
							<td><input type="number" name="item_price[]" step="0.01" min="0"></td>
							<td><input type="number" name="item_tax[]" step="0.01" min="0" value="<?php echo $vat; ?>"></td>
							<td></td>
						</tr>
					</tbody>
				</table>
				<p><button type="button" class="button" id="wceerp-add-row"><?php esc_html_e( '+ Add line', 'wc-enterprise-erp' ); ?></button></p>

				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Discount', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" step="0.01" min="0" name="discount" value="0"></td></tr>
					<tr><th><?php esc_html_e( 'Notes / terms', 'wc-enterprise-erp' ); ?></th>
						<td><textarea name="note" rows="2" class="large-text" placeholder="<?php esc_attr_e( 'Delivery time, payment terms, warranty…', 'wc-enterprise-erp' ); ?>"></textarea></td></tr>
				</tbody></table>

				<?php submit_button( __( 'Create quotation', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_view( $id ) {
		$q = $this->get_quotation( $id );
		if ( ! $q ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Quotation not found.', 'wc-enterprise-erp' ) . '</p></div>';
			return;
		}
		$items   = $this->get_items( $id );
		$pdf_url = wp_nonce_url( admin_url( 'admin-post.php?action=wceerp_quotation_pdf&quotation_id=' . $id ), 'wceerp_quotation_pdf' );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo esc_html( $q->doc_no ); ?> <span class="wceerp-badge is-<?php echo esc_attr( $q->status ); ?>"><?php echo esc_html( ucfirst( $q->status ) ); ?></span></h1>
			<?php if ( isset( $_GET['updated'] ) ) { $this->notice( __( 'Quotation updated.', 'wc-enterprise-erp' ) ); } ?>
			<p>
				<a href="<?php echo esc_url( $this->admin_url() ); ?>">&larr; <?php esc_html_e( 'All quotations', 'wc-enterprise-erp' ); ?></a> ·
				<a href="<?php echo esc_url( WCEERP_Document::url( 'quotation', $id ) ); ?>" target="_blank"><strong><?php esc_html_e( 'Print / save as PDF', 'wc-enterprise-erp' ); ?></strong></a> ·
				<a href="<?php echo esc_url( $pdf_url ); ?>" target="_blank"><?php esc_html_e( 'Plain PDF', 'wc-enterprise-erp' ); ?></a> ·
				<a href="#" onclick="window.print();return false;"><?php esc_html_e( 'Print', 'wc-enterprise-erp' ); ?></a>
			</p>

			<div class="wceerp-card wceerp-report">
				<p>
					<strong><?php esc_html_e( 'Customer:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $q->customer_name ); ?>
					<?php if ( $q->phone ) : ?> · <?php echo esc_html( $q->phone ); ?><?php endif; ?>
					<?php if ( $q->email ) : ?> · <?php echo esc_html( $q->email ); ?><?php endif; ?><br>
					<strong><?php esc_html_e( 'Date:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( mysql2date( 'j M Y', $q->created_at ) ); ?>
					<?php if ( $q->valid_until ) : ?> · <strong><?php esc_html_e( 'Valid until:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $q->valid_until ); ?><?php endif; ?>
				</p>

				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Description', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Unit price', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'VAT %', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Line total', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( (array) $items as $item ) : ?>
						<tr>
							<td><?php echo esc_html( $item->description ); ?></td>
							<td class="num"><?php echo esc_html( wceerp_lakh_format( $item->qty, 0 ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $item->unit_price ) ); ?></td>
							<td class="num"><?php echo esc_html( $item->tax_rate ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $item->line_total ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot>
						<tr><th colspan="4" class="num"><?php esc_html_e( 'Subtotal', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $q->subtotal ) ); ?></th></tr>
						<tr><th colspan="4" class="num"><?php esc_html_e( 'VAT', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $q->tax_total ) ); ?></th></tr>
						<?php if ( (float) $q->discount > 0 ) : ?>
						<tr><th colspan="4" class="num"><?php esc_html_e( 'Discount', 'wc-enterprise-erp' ); ?></th><th class="num">−<?php echo wp_kses_post( wceerp_money( $q->discount ) ); ?></th></tr>
						<?php endif; ?>
						<tr class="wceerp-grand"><th colspan="4" class="num"><?php esc_html_e( 'Grand total', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $q->grand_total ) ); ?></th></tr>
					</tfoot>
				</table>

				<?php if ( $q->note ) : ?>
					<p><strong><?php esc_html_e( 'Notes:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $q->note ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( 'converted' !== $q->status ) : ?>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Actions', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
					<input type="hidden" name="action" value="wceerp_quotation_status">
					<input type="hidden" name="quotation_id" value="<?php echo (int) $q->id; ?>">
					<?php wp_nonce_field( 'wceerp_quotation_status' ); ?>
					<?php if ( 'draft' === $q->status ) : ?>
						<button class="button" name="new_status" value="sent"><?php esc_html_e( 'Mark as sent', 'wc-enterprise-erp' ); ?></button>
					<?php endif; ?>
					<?php if ( in_array( $q->status, array( 'draft', 'sent' ), true ) ) : ?>
						<button class="button" name="new_status" value="accepted"><?php esc_html_e( 'Mark accepted', 'wc-enterprise-erp' ); ?></button>
						<button class="button" name="new_status" value="rejected"><?php esc_html_e( 'Mark rejected', 'wc-enterprise-erp' ); ?></button>
						<button class="button" name="new_status" value="expired"><?php esc_html_e( 'Mark expired', 'wc-enterprise-erp' ); ?></button>
					<?php endif; ?>
				</form>

				<?php if ( in_array( $q->status, array( 'sent', 'accepted' ), true ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;margin-left:8px">
					<input type="hidden" name="action" value="wceerp_quotation_convert">
					<input type="hidden" name="quotation_id" value="<?php echo (int) $q->id; ?>">
					<?php wp_nonce_field( 'wceerp_quotation_convert' ); ?>
					<button class="button button-primary"><?php esc_html_e( 'Convert to WooCommerce order', 'wc-enterprise-erp' ); ?></button>
				</form>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
