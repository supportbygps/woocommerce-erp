<?php
/**
 * Module: Mobile App REST API.
 *
 * Namespace `wceerp/v1`, designed for Flutter / React Native clients.
 *
 * Authentication — no custom token scheme to get wrong:
 *   WordPress Application Passwords (core since WP 5.6) over HTTPS.
 *   The app sends  Authorization: Basic base64(username:app-password)
 *   and every route additionally checks an ERP capability, so a
 *   store-keeper login cannot read the P&L.
 *
 * Push notifications — honest wiring, no fake FCM:
 *   POST /devices stores the device token per user; every ERP
 *   notification fires `do_action( 'wceerp_push', $user_ids, $title,
 *   $body, $url, $tokens )`. Hook your FCM/OneSignal sender there
 *   (server key stays in your integration, not in this plugin).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_API extends WCEERP_Module {

	protected $id         = 'api';
	protected $title      = 'Mobile API';
	protected $capability = 'wceerp_use_api';
	protected $tier       = 'business';
	protected $order      = 80;

	const NS = 'wceerp/v1';

	public function __construct() {
		$this->title = __( 'Mobile API', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_api_key_create', array( $this, 'handle_key_create' ) );
		add_action( 'admin_post_wceerp_api_key_revoke', array( $this, 'handle_key_revoke' ) );
		add_action( 'wp_ajax_wceerp_pair_code', array( $this, 'ajax_pair_code' ) );
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_action( 'wceerp_notification_added', array( __CLASS__, 'relay_push' ), 10, 2 );
	}

	/* ---------------------------------------------------------------------
	 * Auth helpers.
	 * ------------------------------------------------------------------- */

	protected function guard( $capability ) {
		return function () use ( $capability ) {
			// A locked licence closes the API too — otherwise the mobile
			// app would remain a working entry point into a locked ERP.
			if ( class_exists( 'WCEERP_License' ) && WCEERP_License::is_locked() ) {
				return new WP_Error( 'wceerp_licence', WCEERP_License::lock_reason(), array( 'status' => 402 ) );
			}
			if ( ! is_user_logged_in() ) {
				return new WP_Error( 'wceerp_auth', __( 'Authenticate with a WordPress application password.', 'wc-enterprise-erp' ), array( 'status' => 401 ) );
			}
			if ( ! wceerp_user_can( 'wceerp_use_api' ) || ( $capability && ! wceerp_user_can( $capability ) ) ) {
				return new WP_Error( 'wceerp_forbidden', __( 'Your account lacks the required ERP permission.', 'wc-enterprise-erp' ), array( 'status' => 403 ) );
			}
			return true;
		};
	}

	/* ---------------------------------------------------------------------
	 * Pairing.
	 *
	 * A phone should never be asked to type a site address and a licence
	 * key. People mistype both, and an onboarding step that fails silently
	 * is where a customer gives up. Instead the ERP shows a short code, the
	 * phone sends it back, and what returns is a token tied to that user
	 * and that device — revocable from the ERP without touching anything
	 * else.
	 *
	 * The code is deliberately weak on its own: six digits is guessable
	 * given time, so it lives for five minutes, works once, and the
	 * endpoint refuses after a handful of wrong attempts from one address.
	 * ------------------------------------------------------------------- */

	const PAIR_TTL      = 300;  // five minutes: long enough to walk to a phone
	const PAIR_ATTEMPTS = 8;    // per IP per hour

	protected static function pair_key( $code ) {
		return 'wceerp_pair_' . hash( 'sha256', $code );
	}

	/** Issue a code for the user looking at the screen. */
	public static function create_pair_code() {
		// Digits only — this gets read aloud and typed with thumbs.
		$code = str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );

		set_transient(
			self::pair_key( $code ),
			array(
				'user'    => get_current_user_id(),
				'created' => time(),
			),
			self::PAIR_TTL
		);

		return $code;
	}

	/**
	 * Exchange a code for a device token.
	 *
	 * Returns everything the app needs to stop asking questions: the token,
	 * who it belongs to, what they may do, and how to label the site.
	 */
	public function route_device_pair( WP_REST_Request $request ) {
		global $wpdb;

		$ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
		$bucket  = 'wceerp_pair_try_' . hash( 'sha256', $ip );
		$tries   = (int) get_transient( $bucket );

		if ( $tries >= self::PAIR_ATTEMPTS ) {
			return new WP_Error(
				'wceerp_pair_throttled',
				__( 'Too many attempts. Wait an hour and try again.', 'wc-enterprise-erp' ),
				array( 'status' => 429 )
			);
		}

		$code = preg_replace( '/\D/', '', (string) $request->get_param( 'code' ) );
		$name = sanitize_text_field( (string) $request->get_param( 'device' ) );

		$pair = $code ? get_transient( self::pair_key( $code ) ) : false;
		if ( ! $pair || empty( $pair['user'] ) ) {
			// Count only failures, so a working phone is never throttled.
			set_transient( $bucket, $tries + 1, HOUR_IN_SECONDS );
			return new WP_Error(
				'wceerp_pair_invalid',
				__( 'That code is wrong or has expired. Generate a new one in the ERP.', 'wc-enterprise-erp' ),
				array( 'status' => 403 )
			);
		}

		// One use only — burn it before issuing anything.
		delete_transient( self::pair_key( $code ) );

		$user = get_userdata( (int) $pair['user'] );
		if ( ! $user ) {
			return new WP_Error( 'wceerp_pair_invalid', __( 'That account no longer exists.', 'wc-enterprise-erp' ), array( 'status' => 403 ) );
		}

		/* The token is stored hashed, exactly like an API key, so a copy of
		 * the database does not hand anyone a working device. */
		$key_id = 'dev_' . wp_generate_password( 12, false, false );
		$secret = wp_generate_password( 40, false, false );

		$wpdb->insert( wceerp_table( 'api_keys' ), array(
			'key_id'      => $key_id,
			'secret_hash' => hash( 'sha256', $secret ),
			'label'       => $name ? $name : __( 'Mobile device', 'wc-enterprise-erp' ),
			/* Real scope names, or the token is refused on every scoped
			 * route. A paired phone gets what the app actually does — the
			 * user's own permissions still apply on top, so this cannot
			 * hand anyone more than their account already allows. */
			'scopes'      => implode( ',', array(
				'pos:read',
				'pos:write',
				'orders:read',
				'orders:write',
				'inventory:read',
				'inventory:write',
				'courier:read',
				'courier:write',
				'accounting:read',
			) ),
			'status'      => 'active',
			'acts_as'     => (int) $user->ID,
			'created_by'  => (int) $user->ID,
			'created_at'  => current_time( 'mysql' ),
		) );

		wceerp_log( 'api', 'device_paired', (int) $wpdb->insert_id, $name . ' · ' . $user->user_login );

		return rest_ensure_response( array(
			/* Dot, not colon — this is the format the existing Bearer
			 * authentication parses, and a token in any other shape would
			 * simply never authenticate. */
			'token'    => $key_id . '.' . $secret,
			'site'     => get_bloginfo( 'name' ),
			'api'      => rest_url( self::NS ),
			'user'     => array(
				'id'   => (int) $user->ID,
				'name' => $user->display_name,
			),
			'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'BDT',
		) );
	}

	/* ---------------------------------------------------------------------
	 * Routes.
	 * ------------------------------------------------------------------- */

	/** A fresh code, on demand. */
	public function ajax_pair_code() {
		if ( ! wceerp_user_can( 'wceerp_use_api' ) ) {
			wp_send_json_error( array(), 403 );
		}
		check_ajax_referer( 'wceerp_pair_code', 'nonce' );

		$code = self::create_pair_code();

		/* Everything the phone needs, so a scan asks nothing further. The
		 * code is short-lived and single-use, which is what makes putting
		 * it in a QR acceptable at all. */
		$payload = wp_json_encode( array(
			'v'    => 1,
			'site' => home_url(),
			'api'  => rest_url( self::NS ),
			'code' => $code,
			'name' => get_bloginfo( 'name' ),
		) );

		wp_send_json_success( array(
			'code'    => $code,
			'payload' => $payload,
			'expires' => self::PAIR_TTL,
		) );
	}

	public function register_routes() {
		$r = function ( $route, $methods, $callback, $capability = '' ) {
			register_rest_route( self::NS, $route, array(
				'methods'             => $methods,
				'callback'            => array( $this, $callback ),
				'permission_callback' => $this->guard( $capability ),
			) );
		};

		$r( '/me', 'GET', 'route_me' );
		$r( '/dashboard', 'GET', 'route_dashboard', 'wceerp_view_reports' );
		$r( '/products', 'GET', 'route_products', 'wceerp_manage_inventory' );
		$r( '/stock', 'GET', 'route_stock', 'wceerp_manage_inventory' );
		$r( '/orders', 'GET', 'route_orders' );
		$r( '/orders/(?P<id>\d+)', 'GET', 'route_order' );
		$r( '/customers', 'GET', 'route_customers' );
		$r( '/dues/(?P<type>customer|supplier|dealer)', 'GET', 'route_dues', 'wceerp_manage_accounting' );
		$r( '/payments', 'POST', 'route_payment_create', 'wceerp_manage_accounting' );
		$r( '/accounts', 'GET', 'route_accounts', 'wceerp_manage_accounting' );
		$r( '/reports/trial-balance', 'GET', 'route_trial_balance', 'wceerp_view_reports' );
		$r( '/reports/pnl', 'GET', 'route_pnl', 'wceerp_view_reports' );
		$r( '/consignments', 'GET', 'route_consignments', 'wceerp_manage_courier' );
		$r( '/notifications', 'GET', 'route_notifications' );
		$r( '/devices', 'POST', 'route_device_register' );

		/* The jobs a phone is actually for. Everything else stays on the
		 * web: nobody runs payroll from a phone, and building thirty-seven
		 * modules twice is how this would collapse under its own weight. */
		$r( '/couriers', 'GET', 'route_couriers', 'wceerp_manage_courier' );
		$r( '/consignments', 'POST', 'route_consignment_create', 'wceerp_manage_courier' );
		$r( '/consignments/(?P<id>\d+)/sync', 'POST', 'route_consignment_sync', 'wceerp_manage_courier' );
		$r( '/pos/sale', 'POST', 'route_pos_sale', 'wceerp_use_pos' );
		$r( '/stock/adjust', 'POST', 'route_stock_adjust', 'wceerp_manage_inventory' );

		/* Pairing is the one route that cannot require authentication —
		 * the whole point is that the phone has no credentials yet. The
		 * code itself is the credential: six digits, one use, five minutes,
		 * and rate limited so it cannot be guessed. */
		register_rest_route( self::NS, '/devices/pair', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'route_device_pair' ),
			'permission_callback' => '__return_true',
		) );
	}

	/* ---------------------------------------------------------------------
	 * Route callbacks.
	 * ------------------------------------------------------------------- */

	public function route_me() {
		$user = wp_get_current_user();
		$caps = array();
		foreach ( array_keys( WCEERP_Capabilities::all_caps() ) as $cap ) {
			if ( wceerp_user_can( $cap ) ) {
				$caps[] = $cap;
			}
		}
		return array(
			'id'           => $user->ID,
			'display_name' => $user->display_name,
			'email'        => $user->user_email,
			'capabilities' => $caps,
			'currency'     => '৳',
			'fiscal_year'  => wceerp_fiscal_year(),
		);
	}

	public function route_dashboard() {
		global $wpdb;
		$month = gmdate( 'Y-m-01' );
		$jl    = wceerp_table( 'journal_lines' );
		$j     = wceerp_table( 'journals' );
		$acc   = wceerp_table( 'accounts' );

		$pnl = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.type, SUM(l.debit) d, SUM(l.credit) c
			 FROM $jl l
			 INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 INNER JOIN $acc a ON a.id=l.account_id
			 WHERE jr.journal_date >= %s AND a.type IN ('income','expense')
			 GROUP BY a.type", $month
		) );
		$income = $expense = 0.0;
		foreach ( (array) $pnl as $row ) {
			if ( 'income' === $row->type ) {
				$income = (float) $row->c - (float) $row->d;
			} else {
				$expense = (float) $row->d - (float) $row->c;
			}
		}
		$stock_value = (float) $wpdb->get_var( 'SELECT COALESCE(SUM(qty*avg_cost),0) FROM ' . wceerp_table( 'stock' ) );
		$cod_hold    = 0.0;
		$acc_1110    = WCEERP_Accounting::resolve_account( '1110' );
		if ( $acc_1110 ) {
			$cod_hold = (float) $wpdb->get_var( $wpdb->prepare(
				"SELECT COALESCE(SUM(l.debit-l.credit),0) FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted' WHERE l.account_id=%d", $acc_1110
			) );
		}
		return array(
			'month_income'    => round( $income, 2 ),
			'month_expense'   => round( $expense, 2 ),
			'month_profit'    => round( $income - $expense, 2 ),
			'inventory_value' => round( $stock_value, 2 ),
			'cod_with_courier' => round( $cod_hold, 2 ),
		);
	}

	public function route_products( WP_REST_Request $request ) {
		$page   = max( 1, (int) $request->get_param( 'page' ) );
		$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$query  = new WC_Product_Query( array(
			'limit'   => 50,
			'page'    => $page,
			'status'  => 'publish',
			's'       => $search,
			'orderby' => 'title',
			'order'   => 'ASC',
		) );
		$out = array();
		foreach ( $query->get_products() as $product ) {
			$out[] = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'sku'   => $product->get_sku(),
				'price' => (float) $product->get_price(),
				'type'  => $product->get_type(),
			);
		}
		return array( 'page' => $page, 'products' => $out );
	}

	public function route_stock( WP_REST_Request $request ) {
		global $wpdb;
		$warehouse = (int) $request->get_param( 'warehouse_id' );
		$where     = $warehouse ? $wpdb->prepare( 'WHERE s.warehouse_id=%d', $warehouse ) : '';
		$rows      = $wpdb->get_results(
			"SELECT s.product_id, s.warehouse_id, s.qty, s.avg_cost, w.code AS warehouse_code
			 FROM " . wceerp_table( 'stock' ) . ' s
			 INNER JOIN ' . wceerp_table( 'warehouses' ) . " w ON w.id=s.warehouse_id
			 $where ORDER BY s.product_id LIMIT 2000"
		);
		return array( 'stock' => $rows );
	}

	public function route_orders( WP_REST_Request $request ) {
		$page   = max( 1, (int) $request->get_param( 'page' ) );
		$status = sanitize_key( (string) $request->get_param( 'status' ) );
		$orders = wc_get_orders( array(
			'limit'  => 25,
			'page'   => $page,
			'status' => $status ? array( $status ) : array_keys( wc_get_order_statuses() ),
		) );
		$out = array();
		foreach ( $orders as $order ) {
			$out[] = $this->order_summary( $order );
		}
		return array( 'page' => $page, 'orders' => $out );
	}

	public function route_order( WP_REST_Request $request ) {
		$order = wc_get_order( (int) $request['id'] );
		if ( ! $order ) {
			return new WP_Error( 'wceerp_not_found', __( 'Order not found.', 'wc-enterprise-erp' ), array( 'status' => 404 ) );
		}
		$data          = $this->order_summary( $order );
		$data['items'] = array();
		foreach ( $order->get_items() as $item ) {
			$data['items'][] = array(
				'product_id' => $item->get_product_id(),
				'name'       => $item->get_name(),
				'qty'        => (float) $item->get_quantity(),
				'total'      => (float) $item->get_total(),
			);
		}
		return $data;
	}

	protected function order_summary( $order ) {
		return array(
			'id'       => $order->get_id(),
			'number'   => $order->get_order_number(),
			'status'   => $order->get_status(),
			'total'    => (float) $order->get_total(),
			'currency' => $order->get_currency(),
			'customer' => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'phone'    => $order->get_billing_phone(),
			'gateway'  => $order->get_payment_method(),
			'date'     => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i' ) : '',
		);
	}

	public function route_customers( WP_REST_Request $request ) {
		$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$query  = new WP_User_Query( array(
			'role__in' => array( 'customer', 'subscriber' ),
			'number'   => 30,
			'search'   => $search ? '*' . $search . '*' : '',
		) );
		$out = array();
		foreach ( $query->get_results() as $user ) {
			$out[] = array( 'id' => $user->ID, 'name' => $user->display_name, 'email' => $user->user_email );
		}
		return array( 'customers' => $out );
	}

	public function route_dues( WP_REST_Request $request ) {
		$type     = $request['type'];
		$subtype  = 'supplier' === $type ? 'payable' : 'receivable';
		$balances = WCEERP_Accounting::party_balances( $type, $subtype );
		return array( 'type' => $type, 'balances' => $balances );
	}

	/**
	 * Idempotency, for anything that moves money or stock.
	 *
	 * A phone on a patchy connection retries. Without a key to recognise
	 * the retry by, a sale sent twice is two sales in the ledger and two
	 * lots of stock gone — and nobody notices until the month is wrong.
	 * The client sends a key it generated; the same key returns the same
	 * answer instead of doing the work again.
	 */
	protected function replay( WP_REST_Request $request ) {
		$key = sanitize_text_field( (string) $request->get_header( 'x-idempotency-key' ) );
		if ( '' === $key ) {
			$key = sanitize_text_field( (string) $request->get_param( 'idempotency_key' ) );
		}
		if ( '' === $key ) {
			return array( null, '' );
		}
		$slot = 'wceerp_idem_' . hash( 'sha256', $key );
		$seen = get_transient( $slot );
		return array( $seen ? $seen : null, $slot );
	}

	protected function remember( $slot, $payload ) {
		if ( $slot ) {
			// A day is longer than any retry, and short enough not to grow.
			set_transient( $slot, $payload, DAY_IN_SECONDS );
		}
		return rest_ensure_response( $payload );
	}

	/** Which couriers this shop has configured. */
	public function route_couriers( WP_REST_Request $request ) {
		$out = array();
		foreach ( WCEERP_Module_Courier::drivers() as $slug => $d ) {
			$out[] = array(
				'slug'  => $slug,
				'label' => $d['label'],
				'api'   => ! empty( $d['api'] ),
			);
		}
		return rest_ensure_response( $out );
	}

	/**
	 * Book a parcel from an order.
	 *
	 * The heavy lifting stays in the courier module — this only validates
	 * and delegates, so the API and the admin screen can never drift into
	 * booking parcels by different rules.
	 */
	public function route_consignment_create( WP_REST_Request $request ) {
		global $wpdb;

		list( $seen, $slot ) = $this->replay( $request );
		if ( $seen ) {
			return rest_ensure_response( $seen );
		}

		$order_id = (int) $request->get_param( 'order_id' );
		$courier  = sanitize_key( (string) $request->get_param( 'courier' ) );
		$book_now = (bool) $request->get_param( 'book' );

		if ( ! $order_id || ! $courier ) {
			return new WP_Error( 'wceerp_bad_request', __( 'order_id and courier are required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}
		if ( ! isset( WCEERP_Module_Courier::drivers()[ $courier ] ) ) {
			return new WP_Error( 'wceerp_bad_request', __( 'Unknown courier.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( ! $order ) {
			return new WP_Error( 'wceerp_not_found', __( 'That order does not exist.', 'wc-enterprise-erp' ), array( 'status' => 404 ) );
		}

		$table = wceerp_table( 'consignments' );

		/* Already booked is not an error worth failing on — the phone may
		 * simply not have heard the first answer. Hand back what exists. */
		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d", $order_id ) );
		if ( $existing ) {
			return $this->remember( $slot, array(
				'id'       => (int) $existing->id,
				'doc_no'   => $existing->doc_no,
				'courier'  => $existing->courier,
				'tracking' => $existing->tracking_code,
				'status'   => $existing->status,
				'existing' => true,
			) );
		}

		$cod = (float) $order->get_total();
		if ( class_exists( 'WCEERP_Order_Payments' ) ) {
			$cod = (float) WCEERP_Order_Payments::cod_outstanding( $order_id );
		}

		$doc = wceerp_next_doc_number( 'cn' );
		$wpdb->insert( $table, array(
			'doc_no'            => $doc,
			'order_id'          => $order_id,
			'courier'           => $courier,
			'recipient_name'    => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'recipient_phone'   => $order->get_billing_phone(),
			'recipient_address' => wp_strip_all_tags( $order->get_formatted_billing_address() ),
			'cod_amount'        => $cod,
			'collected_amount'  => 0,
			'status'            => 'pending',
			'created_by'        => get_current_user_id(),
			'created_at'        => current_time( 'mysql' ),
		) );
		$id = (int) $wpdb->insert_id;

		$booked = null;
		if ( $book_now ) {
			$c      = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			$booked = WCEERP_Module_Courier::api_book( $c );

			if ( is_wp_error( $booked ) ) {
				/* The consignment stays — it is a real record, and deleting
				 * it would lose the reference the shop can quote when the
				 * courier is asked why the booking failed. */
				return new WP_Error(
					'wceerp_courier',
					$booked->get_error_message(),
					array( 'status' => 502, 'consignment_id' => $id, 'doc_no' => $doc )
				);
			}

			$wpdb->update( $table, array(
				'remote_id'     => $booked['remote_id'] ?? '',
				'tracking_code' => $booked['tracking_code'] ?? '',
				'status'        => 'booked',
			), array( 'id' => $id ) );
		}

		wceerp_log( 'courier', 'api_consignment_created', $id, $courier . ' order #' . $order_id );

		return $this->remember( $slot, array(
			'id'       => $id,
			'doc_no'   => $doc,
			'courier'  => $courier,
			'tracking' => $booked['tracking_code'] ?? '',
			'status'   => $book_now ? 'booked' : 'pending',
			'cod'      => round( $cod, 2 ),
		) );
	}

	/** Ask the courier where one parcel has got to. */
	public function route_consignment_sync( WP_REST_Request $request ) {
		global $wpdb;

		$id = (int) $request['id'];
		$c  = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'consignments' ) . ' WHERE id = %d',
			$id
		) );
		if ( ! $c ) {
			return new WP_Error( 'wceerp_not_found', __( 'No such consignment.', 'wc-enterprise-erp' ), array( 'status' => 404 ) );
		}

		$status = WCEERP_Module_Courier::api_track( $c );
		if ( is_wp_error( $status ) ) {
			return new WP_Error( 'wceerp_courier', $status->get_error_message(), array( 'status' => 502 ) );
		}
		WCEERP_Module_Courier::apply_status( $c, $status );

		$fresh = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'consignments' ) . ' WHERE id = %d',
			$id
		) );

		return rest_ensure_response( array(
			'id'        => $id,
			'status'    => $fresh->status,
			'collected' => (float) $fresh->collected_amount,
			'reported'  => (float) $fresh->remote_collected,
		) );
	}

	/** A counter sale. */
	public function route_pos_sale( WP_REST_Request $request ) {
		list( $seen, $slot ) = $this->replay( $request );
		if ( $seen ) {
			return rest_ensure_response( $seen );
		}

		$items = (array) $request->get_param( 'items' );
		if ( ! $items ) {
			return new WP_Error( 'wceerp_bad_request', __( 'At least one item is required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		$result = WCEERP_POS_Service::create_sale( array(
			'items'            => $items,
			'customer_id'      => (int) $request->get_param( 'customer_id' ),
			'customer_name'    => sanitize_text_field( (string) $request->get_param( 'customer_name' ) ),
			'customer_phone'   => sanitize_text_field( (string) $request->get_param( 'customer_phone' ) ),
			'customer_address' => sanitize_textarea_field( (string) $request->get_param( 'customer_address' ) ),
			'shipping'         => wceerp_dec( $request->get_param( 'shipping' ) ),
			'shipping_label'   => sanitize_text_field( (string) $request->get_param( 'shipping_label' ) ),
			'discount'         => wceerp_dec( $request->get_param( 'discount' ) ),
			'paid'             => wceerp_dec( $request->get_param( 'paid' ) ),
			'method'           => sanitize_key( (string) ( $request->get_param( 'method' ) ?: 'cash' ) ),
			'note'             => sanitize_text_field( (string) $request->get_param( 'note' ) ),
		) );

		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'wceerp_pos', $result->get_error_message(), array( 'status' => 400 ) );
		}

		return $this->remember( $slot, is_array( $result ) ? $result : array( 'ok' => true ) );
	}

	/**
	 * Adjust stock, with a reason.
	 *
	 * The reason is required rather than optional, because it decides which
	 * account the value lands in — and an adjustment posted to the wrong
	 * one is how a profitable month turns into a reported loss.
	 */
	public function route_stock_adjust( WP_REST_Request $request ) {
		list( $seen, $slot ) = $this->replay( $request );
		if ( $seen ) {
			return rest_ensure_response( $seen );
		}

		$product   = (int) $request->get_param( 'product_id' );
		$warehouse = (int) $request->get_param( 'warehouse_id' );
		$qty       = wceerp_dec( $request->get_param( 'qty' ) );
		$direction = 'out' === sanitize_key( (string) $request->get_param( 'direction' ) ) ? 'out' : 'in';
		$reason    = sanitize_key( (string) $request->get_param( 'reason' ) );
		$note      = sanitize_text_field( (string) $request->get_param( 'note' ) );

		$reasons = WCEERP_Module_Inventory::adjust_reasons();
		if ( ! $product || ! $warehouse || $qty <= 0 ) {
			return new WP_Error( 'wceerp_bad_request', __( 'product_id, warehouse_id and a positive qty are required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}
		if ( ! isset( $reasons[ $reason ] ) ) {
			return new WP_Error(
				'wceerp_bad_request',
				sprintf(
					/* translators: %s: list of reasons. */
					__( 'A reason is required, one of: %s', 'wc-enterprise-erp' ),
					implode( ', ', array_keys( $reasons ) )
				),
				array( 'status' => 400 )
			);
		}

		$label = $reasons[ $reason ]['label'];
		$value = WCEERP_Module_Inventory::move_stock(
			$product,
			$warehouse,
			$qty,
			$direction,
			'adjustment',
			0,
			null,
			null,
			$note ? $label . ' — ' . $note : $label
		);

		wceerp_log( 'inventory', 'api_adjust', $product, $direction . ' ' . $qty . ' · ' . $reason );

		return $this->remember( $slot, array(
			'product_id' => $product,
			'direction'  => $direction,
			'qty'        => $qty,
			'value'      => round( (float) $value, 2 ),
			'reason'     => $reason,
		) );
	}

	public function route_payment_create( WP_REST_Request $request ) {
		$party_type = sanitize_key( (string) $request->get_param( 'party_type' ) );
		$party_id   = (int) $request->get_param( 'party_id' );
		$amount     = wceerp_dec( $request->get_param( 'amount' ) );
		$account    = sanitize_text_field( (string) $request->get_param( 'account' ) ); // code or id.
		if ( ! in_array( $party_type, array( 'customer', 'supplier', 'dealer' ), true ) || ! $party_id || $amount <= 0 || ! $account ) {
			return new WP_Error( 'wceerp_bad_request', __( 'party_type, party_id, amount and account are required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}
		$account_id = WCEERP_Accounting::resolve_account( $account );
		if ( ! $account_id ) {
			return new WP_Error( 'wceerp_bad_request', __( 'Unknown money account.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}
		$result = WCEERP_Accounting::record_payment( array(
			'direction'  => 'supplier' === $party_type ? 'out' : 'in',
			'party_type' => $party_type,
			'party_id'   => $party_id,
			'account_id' => (int) $account_id,
			'amount'     => $amount,
			'method'     => sanitize_key( (string) ( $request->get_param( 'method' ) ?: 'cash' ) ),
			'note'       => sanitize_text_field( (string) $request->get_param( 'note' ) ),
			'ref_type'   => 'api',
		) );
		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 422 ) );
			return $result;
		}
		wceerp_log( 'api', 'payment', (int) $result, $party_type . ' #' . $party_id );
		return array( 'payment_id' => (int) $result, 'ok' => true );
	}

	public function route_accounts() {
		return array( 'accounts' => WCEERP_Accounting::accounts() );
	}

	public function route_trial_balance( WP_REST_Request $request ) {
		$fy   = wceerp_fiscal_year();
		$from = sanitize_text_field( (string) ( $request->get_param( 'from' ) ?: $fy['start'] ) );
		$to   = sanitize_text_field( (string) ( $request->get_param( 'to' ) ?: current_time( 'Y-m-d' ) ) );
		return array( 'from' => $from, 'to' => $to, 'rows' => WCEERP_Accounting::trial_balance( $from, $to ) );
	}

	public function route_pnl( WP_REST_Request $request ) {
		$fy   = wceerp_fiscal_year();
		$from = sanitize_text_field( (string) ( $request->get_param( 'from' ) ?: $fy['start'] ) );
		$to   = sanitize_text_field( (string) ( $request->get_param( 'to' ) ?: current_time( 'Y-m-d' ) ) );
		$rows = WCEERP_Accounting::trial_balance( $from, $to );
		$income = $expense = 0.0;
		$lines  = array();
		foreach ( (array) $rows as $row ) {
			if ( ! in_array( $row->type, array( 'income', 'expense' ), true ) ) {
				continue;
			}
			$net = 'income' === $row->type ? (float) $row->credit - (float) $row->debit : (float) $row->debit - (float) $row->credit;
			if ( abs( $net ) < 0.005 ) {
				continue;
			}
			$lines[] = array( 'code' => $row->code, 'name' => $row->name, 'type' => $row->type, 'amount' => round( $net, 2 ) );
			if ( 'income' === $row->type ) {
				$income += $net;
			} else {
				$expense += $net;
			}
		}
		return array( 'from' => $from, 'to' => $to, 'lines' => $lines, 'income' => round( $income, 2 ), 'expense' => round( $expense, 2 ), 'profit' => round( $income - $expense, 2 ) );
	}

	public function route_consignments( WP_REST_Request $request ) {
		global $wpdb;
		$status = sanitize_key( (string) $request->get_param( 'status' ) );
		$where  = $status ? $wpdb->prepare( 'WHERE status=%s', $status ) : '';
		return array( 'consignments' => $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'consignments' ) . " $where ORDER BY id DESC LIMIT 100" ) );
	}

	public function route_notifications() {
		global $wpdb;
		return array( 'notifications' => $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'notifications' ) . ' WHERE user_id IN (0,%d) ORDER BY id DESC LIMIT 50', get_current_user_id()
		) ) );
	}

	/* ---------------------------------------------------------------------
	 * Push wiring.
	 * ------------------------------------------------------------------- */

	public function route_device_register( WP_REST_Request $request ) {
		$token    = sanitize_text_field( (string) $request->get_param( 'token' ) );
		$platform = sanitize_key( (string) $request->get_param( 'platform' ) );
		if ( ! $token ) {
			return new WP_Error( 'wceerp_bad_request', __( 'token is required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}
		$tokens = (array) get_user_meta( get_current_user_id(), '_wceerp_push_tokens', true );
		$tokens[ $token ] = array( 'platform' => $platform ?: 'unknown', 'seen' => current_time( 'mysql' ) );
		$tokens = array_slice( $tokens, -10, 10, true ); // keep last 10 devices.
		update_user_meta( get_current_user_id(), '_wceerp_push_tokens', $tokens );
		return array( 'ok' => true, 'devices' => count( $tokens ) );
	}

	/** Fired by the Notifications module; hands tokens to any push sender. */
	public static function relay_push( $notification_id, $type ) {
		global $wpdb;
		$note = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'notifications' ) . ' WHERE id=%d', (int) $notification_id
		) );
		if ( ! $note ) {
			return;
		}

		/* user_id 0 = broadcast to every user that registered a device. */
		if ( (int) $note->user_id ) {
			$user_ids = array( (int) $note->user_id );
		} else {
			$user_ids = get_users( array(
				'meta_key' => '_wceerp_push_tokens', // phpcs:ignore
				'fields'   => 'ID',
				'number'   => 200,
			) );
		}
		$tokens = array();
		foreach ( $user_ids as $uid ) {
			foreach ( (array) get_user_meta( (int) $uid, '_wceerp_push_tokens', true ) as $token => $meta ) {
				$tokens[] = $token;
			}
		}
		/**
		 * Deliver with your own FCM / OneSignal integration:
		 * add_action( 'wceerp_push', fn( $user_ids, $title, $body, $url, $tokens ) => …, 10, 5 );
		 */
		do_action( 'wceerp_push', $user_ids, $note->title, $note->message, $note->link, $tokens );
	}

	/* ---------------------------------------------------------------------
	 * Docs screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		$base = esc_url( rest_url( self::NS ) );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Mobile / REST API', 'wc-enterprise-erp' ) ) ); ?></h1>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Connecting an app', 'wc-enterprise-erp' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Users → Profile → Application Passwords → create one (e.g. "Android app").', 'wc-enterprise-erp' ); ?></li>
					<li><?php esc_html_e( 'The app sends it as HTTP Basic auth over HTTPS:', 'wc-enterprise-erp' ); ?>
						<pre style="background:#f6f7f7;padding:10px;border-radius:6px;font-size:12px">Authorization: Basic base64( "username:xxxx xxxx xxxx xxxx" )</pre></li>
					<li><?php esc_html_e( 'Every route also checks the user\'s ERP permissions — the roles matrix applies to the API exactly as it does in wp-admin.', 'wc-enterprise-erp' ); ?></li>
				</ol>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Endpoints', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr><th><?php esc_html_e( 'Route', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Method', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Requires', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
						<?php
						$rows = array(
							array( '/me', 'GET', '—' ),
							array( '/dashboard', 'GET', 'view reports' ),
							array( '/products?search=&page=', 'GET', 'inventory' ),
							array( '/stock?warehouse_id=', 'GET', 'inventory' ),
							array( '/orders?status=&page= · /orders/{id}', 'GET', '—' ),
							array( '/customers?search=', 'GET', '—' ),
							array( '/dues/{customer|supplier|dealer}', 'GET', 'accounting' ),
							array( '/payments  {party_type, party_id, amount, account, note}', 'POST', 'accounting' ),
							array( '/accounts · /reports/trial-balance · /reports/pnl', 'GET', 'accounting / reports' ),
							array( '/consignments?status=', 'GET', 'courier' ),
							array( '/notifications', 'GET', '—' ),
							array( '/devices  {token, platform}', 'POST', '—' ),
							array( '/pos/catalog · /pos/sale · /pos/shift', 'GET/POST', 'POS terminal' ),
						);
						foreach ( $rows as $row ) {
							printf( '<tr><td><code>%s%s</code></td><td>%s</td><td>%s</td></tr>', $base, esc_html( $row[0] ), esc_html( $row[1] ), esc_html( $row[2] ) );
						}
						?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Push notifications: the app registers its FCM token at /devices; hook the wceerp_push action to deliver via your FCM/OneSignal account (server keys stay outside the plugin).', 'wc-enterprise-erp' ); ?></p>
			</div>
			<hr>
			<?php $this->render_keys(); ?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Integration keys.
	 * ------------------------------------------------------------------- */

	public function handle_key_create() {
		$this->verify_nonce( 'wceerp_api_key_create' );

		$result = WCEERP_API_Auth::create( array(
			'label'      => wp_unslash( $_POST['label'] ?? '' ),
			'scopes'     => (array) ( $_POST['scopes'] ?? array() ),
			'rate_limit' => (int) ( $_POST['rate_limit'] ?? 120 ),
			'expires_on' => sanitize_text_field( wp_unslash( $_POST['expires_on'] ?? '' ) ),
		) );

		if ( is_wp_error( $result ) ) {
			set_transient( 'wceerp_api_err_' . get_current_user_id(), $result->get_error_message(), 60 );
			wp_safe_redirect( $this->admin_url( array( 'failed' => 1 ) ) );
			exit;
		}

		/* Shown once, then gone. Storing it would defeat hashing the secret. */
		set_transient( 'wceerp_api_new_' . get_current_user_id(), $result['token'], 300 );
		wp_safe_redirect( $this->admin_url( array( 'created' => 1 ) ) );
		exit;
	}

	public function handle_key_revoke() {
		$this->verify_nonce( 'wceerp_api_key_revoke' );
		WCEERP_API_Auth::revoke( (int) ( $_POST['id'] ?? 0 ) );
		wp_safe_redirect( $this->admin_url( array( 'revoked' => 1 ) ) );
		exit;
	}

	protected function render_keys() {
		$scopes = WCEERP_API_Auth::scopes();
		$keys   = WCEERP_API_Auth::all();
		$fresh  = get_transient( 'wceerp_api_new_' . get_current_user_id() );
		if ( $fresh ) {
			delete_transient( 'wceerp_api_new_' . get_current_user_id() );
		}
		if ( ! empty( $_GET['failed'] ) ) {
			$err = get_transient( 'wceerp_api_err_' . get_current_user_id() );
			delete_transient( 'wceerp_api_err_' . get_current_user_id() );
			$this->notice( $err ? $err : __( 'Could not create the key.', 'wc-enterprise-erp' ), 'error' );
		}
		if ( ! empty( $_GET['revoked'] ) ) {
			$this->notice( __( 'Key revoked. It stops working immediately.', 'wc-enterprise-erp' ) );
		}
		?>
		<?php /* Pairing sits above integration keys because it is what most
		         people came for: getting the app on a phone. */ ?>
		<div class="wceerp-card" style="max-width:640px;margin-bottom:20px">
			<h2><span class="dashicons dashicons-smartphone"></span><?php esc_html_e( 'Connect a phone', 'wc-enterprise-erp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Open the app, choose "Connect a store", and scan this — or type the six digits. Nobody has to enter a web address or a licence key on a phone, which is where connecting usually goes wrong.', 'wc-enterprise-erp' ); ?>
			</p>

			<div id="wceerp-pair-box" style="display:none;text-align:center;padding:16px 0">
				<div id="wceerp-pair-qr" style="display:inline-block;background:#fff;padding:10px;border:1px solid #E3E0E8;border-radius:10px"></div>
				<div style="font:700 32px/1.2 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.16em;margin-top:14px" id="wceerp-pair-code"></div>
				<p class="description" id="wceerp-pair-expiry" style="margin-top:6px"></p>
			</div>

			<p>
				<button type="button" class="button button-primary" id="wceerp-pair-go"><?php esc_html_e( 'Show pairing code', 'wc-enterprise-erp' ); ?></button>
				<span class="description" style="margin-left:8px"><?php esc_html_e( 'Valid for five minutes, and works once.', 'wc-enterprise-erp' ); ?></span>
			</p>

			<p class="description">
				<?php esc_html_e( 'The phone is granted your own permissions — never more. Revoke it any time from the list below; the device stops working immediately without affecting anyone else.', 'wc-enterprise-erp' ); ?>
			</p>
		</div>

		<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
		<script>
		(function () {
			var btn = document.getElementById( 'wceerp-pair-go' );
			if ( ! btn ) { return; }
			var box = document.getElementById( 'wceerp-pair-box' );
			var qr  = document.getElementById( 'wceerp-pair-qr' );
			var out = document.getElementById( 'wceerp-pair-code' );
			var exp = document.getElementById( 'wceerp-pair-expiry' );
			var timer;

			btn.addEventListener( 'click', function () {
				btn.disabled = true;
				var body = new FormData();
				body.append( 'action', 'wceerp_pair_code' );
				body.append( 'nonce', <?php echo wp_json_encode( wp_create_nonce( 'wceerp_pair_code' ) ); ?> );

				fetch( <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, {
					method: 'POST', body: body, credentials: 'same-origin'
				} )
					.then( function ( r ) { return r.json(); } )
					.then( function ( j ) {
						btn.disabled = false;
						if ( ! j || ! j.success ) { throw new Error( 'failed' ); }

						out.textContent = j.data.code.replace( /(\d{3})(\d{3})/, '$1 $2' );
						box.style.display = '';
						qr.innerHTML = '';

						/* The QR is a convenience, not the mechanism — if the
						   library does not load, the digits still work. */
						if ( window.QRCode ) {
							var c = document.createElement( 'canvas' );
							qr.appendChild( c );
							QRCode.toCanvas( c, j.data.payload, { width: 190, margin: 1 } );
						} else {
							qr.textContent = <?php echo wp_json_encode( __( 'Type the code instead.', 'wc-enterprise-erp' ) ); ?>;
						}

						var left = j.data.expires;
						clearInterval( timer );
						timer = setInterval( function () {
							left--;
							if ( left <= 0 ) {
								clearInterval( timer );
								box.style.display = 'none';
								exp.textContent = '';
								return;
							}
							var m = Math.floor( left / 60 ), s = left % 60;
							exp.textContent = <?php echo wp_json_encode( __( 'Expires in', 'wc-enterprise-erp' ) ); ?>
								+ ' ' + m + ':' + ( s < 10 ? '0' : '' ) + s;
						}, 1000 );
					} )
					.catch( function () {
						btn.disabled = false;
						out.textContent = '';
						exp.textContent = <?php echo wp_json_encode( __( 'Could not get a code. Reload and try again.', 'wc-enterprise-erp' ) ); ?>;
						box.style.display = '';
					} );
			} );
		})();
		</script>

		<h2><?php esc_html_e( 'Integration keys', 'wc-enterprise-erp' ); ?></h2>
		<p class="description" style="max-width:720px">
			<?php esc_html_e( 'For third parties integrating with this shop. Unlike a WordPress application password, each key is limited to the scopes you choose, can be revoked on its own, is rate limited, and every call is attributed to it.', 'wc-enterprise-erp' ); ?>
			<br><code><?php echo esc_html( rest_url( 'wceerp/public/v1' ) ); ?></code>
		</p>

		<?php if ( $fresh ) : ?>
			<div class="notice notice-success">
				<p><strong><?php esc_html_e( 'Copy this key now — it is not shown again.', 'wc-enterprise-erp' ); ?></strong></p>
				<p><code style="user-select:all;word-break:break-all;font-size:13px"><?php echo esc_html( $fresh ); ?></code></p>
				<p class="description"><?php esc_html_e( 'Send it as: Authorization: Bearer <that value>', 'wc-enterprise-erp' ); ?></p>
			</div>
		<?php endif; ?>

		<div class="wceerp-card" style="max-width:640px">
			<h3><?php esc_html_e( 'Issue a key', 'wc-enterprise-erp' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'wceerp_api_key_create' ); ?>
				<input type="hidden" name="action" value="wceerp_api_key_create">
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Label', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="label" class="regular-text" required
							placeholder="<?php esc_attr_e( 'e.g. Shopfront kiosk vendor', 'wc-enterprise-erp' ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Scopes', 'wc-enterprise-erp' ); ?></th>
						<td>
							<?php foreach ( $scopes as $sk => $sl ) : ?>
								<label style="display:block;margin-bottom:3px">
									<input type="checkbox" name="scopes[]" value="<?php echo esc_attr( $sk ); ?>">
									<code><?php echo esc_html( $sk ); ?></code> — <?php echo esc_html( $sl ); ?>
								</label>
							<?php endforeach; ?>
							<p class="description"><?php esc_html_e( 'Grant only what the integration needs. Read scopes cannot write.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Rate limit', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" name="rate_limit" value="120" min="10" max="6000" style="width:100px">
						<?php esc_html_e( 'requests per minute', 'wc-enterprise-erp' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Expires', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="expires_on">
						<p class="description"><?php esc_html_e( 'Optional. A key with an end date is safer than one that lives forever.', 'wc-enterprise-erp' ); ?></p></td></tr>
				</tbody></table>
				<?php submit_button( __( 'Create key', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>

		<table class="widefat striped wceerp-table" style="margin-top:18px">
			<thead><tr>
				<th><?php esc_html_e( 'Label', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Key ID', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Scopes', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Calls', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Last used', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $keys ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No integration keys yet.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $keys as $k ) : ?>
				<tr>
					<td><?php echo esc_html( $k->label ); ?></td>
					<td><code><?php echo esc_html( $k->key_id ); ?></code></td>
					<td><small><?php echo esc_html( str_replace( ',', ', ', (string) $k->scopes ) ); ?></small></td>
					<td class="num"><?php echo (int) $k->request_count; ?></td>
					<td><small><?php echo esc_html( $k->last_used_at ?: '—' ); ?><?php echo $k->last_ip ? '<br>' . esc_html( $k->last_ip ) : ''; ?></small></td>
					<td>
						<?php if ( 'active' === $k->status && ( ! $k->expires_on || $k->expires_on >= current_time( 'Y-m-d' ) ) ) : ?>
							<span class="wceerp-badge wceerp-badge-ok"><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></span>
						<?php elseif ( 'revoked' === $k->status ) : ?>
							<span class="wceerp-badge"><?php esc_html_e( 'Revoked', 'wc-enterprise-erp' ); ?></span>
						<?php else : ?>
							<span class="wceerp-badge"><?php esc_html_e( 'Expired', 'wc-enterprise-erp' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( 'active' === $k->status ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
								onsubmit="return confirm('<?php echo esc_js( __( 'Revoke this key? Any integration using it stops working immediately.', 'wc-enterprise-erp' ) ); ?>');">
								<?php wp_nonce_field( 'wceerp_api_key_revoke' ); ?>
								<input type="hidden" name="action" value="wceerp_api_key_revoke">
								<input type="hidden" name="id" value="<?php echo (int) $k->id; ?>">
								<button class="button button-small button-link-delete"><?php esc_html_e( 'Revoke', 'wc-enterprise-erp' ); ?></button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

}
