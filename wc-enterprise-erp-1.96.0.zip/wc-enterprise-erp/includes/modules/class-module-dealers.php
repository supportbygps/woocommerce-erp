<?php
/**
 * Module: Dealers & Wholesale.
 *
 * A dealer is a WordPress user with a dealer record. Being one changes
 * three things, all automatic:
 *
 *  1. Pricing  — their wholesale discount % applies storewide on the
 *                front end (filterable per product).
 *  2. Credit   — on-account orders are blocked at checkout once
 *                open due + new order would exceed their credit limit.
 *  3. Books    — unpaid orders post to Accounts Receivable under
 *                party "dealer", so dues, statements and payments run
 *                through the same double-entry ledger as everything else.
 *
 * Dealers see their own live statement under My Account → Dealer
 * statement on the shop front end.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Dealers extends WCEERP_Module {

	protected $id         = 'dealers';
	protected $title      = 'Dealers';
	protected $capability = 'wceerp_manage_dealers';
	protected $tier       = 'business';
	protected $order      = 32;

	public function __construct() {
		$this->title = __( 'Dealers & Wholesale', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_dealer_save', array( $this, 'handle_save' ) );
		add_action( 'wp_ajax_wceerp_dealer_users', array( $this, 'ajax_user_search' ) );
		add_action( 'admin_post_wceerp_dealer_status', array( $this, 'handle_status' ) );

		/* Wholesale pricing on the storefront. */
		add_filter( 'woocommerce_product_get_price', array( $this, 'wholesale_price' ), 20, 2 );
		add_filter( 'woocommerce_product_variation_get_price', array( $this, 'wholesale_price' ), 20, 2 );

		/* Per-product dealer / wholesale price fields. */
		add_action( 'woocommerce_product_options_pricing', array( $this, 'product_price_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_prices' ) );

		/* Credit limit gate at checkout. */
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'enforce_credit_limit' ), 10, 2 );

		/* Front-end statement: My Account → Dealer statement. */
		add_action( 'init', array( $this, 'register_endpoint' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'account_menu' ) );
		add_action( 'woocommerce_account_dealer-statement_endpoint', array( $this, 'render_front_statement' ) );
	}

	/* ---------------------------------------------------------------------
	 * Lookups.
	 * ------------------------------------------------------------------- */

	public static function by_user( $user_id ) {
		global $wpdb;
		static $cache = array();
		if ( ! array_key_exists( $user_id, $cache ) ) {
			$cache[ $user_id ] = $wpdb->get_row( $wpdb->prepare(
				'SELECT * FROM ' . wceerp_table( 'dealers' ) . " WHERE user_id=%d AND status='active'", $user_id
			) );
		}
		return $cache[ $user_id ];
	}

	/** Open due (Dr − Cr) on AR for one dealer, from the ledger. */
	public static function open_due( $dealer_id ) {
		global $wpdb;
		$ar = WCEERP_Accounting::account_by_subtype( 'receivable' );
		if ( ! $ar ) {
			return 0.0;
		}
		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );
		return (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(l.debit - l.credit),0)
			 FROM $jl l INNER JOIN $j jr ON jr.id=l.journal_id AND jr.status='posted'
			 WHERE l.account_id=%d AND l.party_type='dealer' AND l.party_id=%d",
			$ar->id, $dealer_id
		) );
	}

	/* ---------------------------------------------------------------------
	 * Storefront behaviour.
	 * ------------------------------------------------------------------- */

	/* ---------------------------------------------------------------------
	 * Tiered pricing.
	 *
	 * Resolution order, highest priority first:
	 *   1. A per-product price for the buyer's tier (erp product_prices).
	 *   2. The buyer's group discount % off the retail price.
	 *   3. Retail price, unchanged.
	 * ------------------------------------------------------------------- */

	/** Selling tiers. Retail is the implicit default and has no record. */
	public static function tiers() {
		return apply_filters( 'wceerp_price_tiers', array(
			'dealer'    => __( 'Dealer', 'wc-enterprise-erp' ),
			'wholesale' => __( 'Wholesale', 'wc-enterprise-erp' ),
		) );
	}

	/** The tier a user buys at, or '' for ordinary retail customers. */
	public static function tier_for_user( $user_id ) {
		$dealer = self::by_user( (int) $user_id );
		if ( ! $dealer || 'active' !== $dealer->status ) {
			return '';
		}
		$tier = isset( $dealer->group_type ) ? (string) $dealer->group_type : 'dealer';
		return array_key_exists( $tier, self::tiers() ) ? $tier : 'dealer';
	}

	/** A per-product tier price, or null when none is set. */
	public static function product_tier_price( $product_id, $tier ) {
		global $wpdb;
		if ( ! $product_id || ! $tier ) {
			return null;
		}
		$val = $wpdb->get_var( $wpdb->prepare(
			'SELECT price FROM ' . wceerp_table( 'product_prices' ) . ' WHERE product_id = %d AND tier = %s',
			(int) $product_id, $tier
		) );
		return ( null === $val ) ? null : (float) $val;
	}

	/** Store (or clear, when $price is null) a per-product tier price. */
	public static function set_product_tier_price( $product_id, $tier, $price ) {
		global $wpdb;
		$table = wceerp_table( 'product_prices' );
		if ( null === $price || '' === $price ) {
			$wpdb->delete( $table, array( 'product_id' => (int) $product_id, 'tier' => $tier ) );
			return;
		}
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$table} (product_id, tier, price, updated_at) VALUES (%d, %s, %f, %s)
			 ON DUPLICATE KEY UPDATE price = VALUES(price), updated_at = VALUES(updated_at)",
			(int) $product_id, $tier, (float) $price, current_time( 'mysql' )
		) );
	}

	/**
	 * Resolve the price a given tier pays for a product.
	 *
	 * @param int    $product_id Product.
	 * @param string $tier       '', 'dealer' or 'wholesale'.
	 * @param float  $base       Retail price to fall back to.
	 * @param object $dealer     Optional dealer row, to avoid a re-query.
	 * @return float
	 */
	public static function price_for( $product_id, $tier, $base, $dealer = null ) {
		$base = (float) $base;
		if ( ! $tier ) {
			return $base;
		}
		$fixed = self::product_tier_price( $product_id, $tier );
		if ( null !== $fixed && $fixed > 0 ) {
			return round( (float) apply_filters( 'wceerp_tier_price', $fixed, $product_id, $tier, $base ), 2 );
		}
		$pct = $dealer ? (float) $dealer->discount_pct : 0;
		if ( $pct <= 0 ) {
			return $base;
		}
		$pct = (float) apply_filters( 'wceerp_dealer_discount_pct', $pct, $dealer, $product_id );
		return round( $base * ( 1 - $pct / 100 ), 2 );
	}

	/** Average cost of a product, used to warn about below-cost pricing. */
	public static function avg_cost( $product_id ) {
		global $wpdb;
		return (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT AVG(avg_cost) FROM ' . wceerp_table( 'stock' ) . ' WHERE product_id = %d AND avg_cost > 0',
			(int) $product_id
		) );
	}

	public function wholesale_price( $price, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $price;
		}
		if ( ! is_user_logged_in() || '' === $price ) {
			return $price;
		}
		$dealer = self::by_user( get_current_user_id() );
		if ( ! $dealer || 'active' !== $dealer->status ) {
			return $price;
		}
		$tier = self::tier_for_user( get_current_user_id() );
		if ( ! $tier ) {
			return $price;
		}
		$pid = $product ? $product->get_id() : 0;
		return self::price_for( $pid, $tier, (float) $price, $dealer );
	}

	/* ---------------------------------------------------------------------
	 * Per-product price fields on the WooCommerce product editor.
	 * ------------------------------------------------------------------- */

	public function product_price_fields() {
		global $post;
		$pid = $post ? (int) $post->ID : 0;
		echo '<div class="options_group">';
		foreach ( self::tiers() as $tier => $label ) {
			$val = self::product_tier_price( $pid, $tier );
			woocommerce_wp_text_input( array(
				'id'          => '_wceerp_price_' . $tier,
				'value'       => ( null === $val ) ? '' : wc_format_localized_price( $val ),
				'label'       => sprintf(
					/* translators: 1: tier name, 2: currency symbol. */
					__( '%1$s price (%2$s)', 'wc-enterprise-erp' ),
					$label, get_woocommerce_currency_symbol()
				),
				'data_type'   => 'price',
				'desc_tip'    => true,
				'description' => __( 'Leave blank to fall back to this buyer group\'s discount percentage.', 'wc-enterprise-erp' ),
			) );
		}
		echo '</div>';
	}

	public function save_product_prices( $post_id ) {
		if ( ! current_user_can( 'edit_product', $post_id ) ) {
			return;
		}
		foreach ( array_keys( self::tiers() ) as $tier ) {
			$key = '_wceerp_price_' . $tier;
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] );
			if ( '' === trim( (string) $raw ) ) {
				self::set_product_tier_price( $post_id, $tier, null );
				continue;
			}
			self::set_product_tier_price( $post_id, $tier, wc_format_decimal( $raw ) );
		}
	}

	/**
	 * On-account gateways (default: COD used as "on account", BACS) are
	 * blocked when open due + this order would breach the credit limit.
	 */
	public function enforce_credit_limit( $data, $errors ) {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$dealer = self::by_user( get_current_user_id() );
		if ( ! $dealer || (float) $dealer->credit_limit <= 0 ) {
			return;
		}
		$gateways   = (array) apply_filters( 'wceerp_dealer_credit_gateways', array( 'cod', 'bacs' ) );
		$is_account = false;
		foreach ( $gateways as $needle ) {
			if ( false !== stripos( (string) ( $data['payment_method'] ?? '' ), $needle ) ) {
				$is_account = true;
				break;
			}
		}
		if ( ! $is_account || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$due   = self::open_due( (int) $dealer->id );
		$total = (float) WC()->cart->get_total( 'edit' );
		if ( $due + $total > (float) $dealer->credit_limit + 0.004 ) {
			$errors->add( 'wceerp_credit_limit', sprintf(
				/* translators: 1: open due 2: credit limit */
				__( 'Your on-account balance (%1$s due) plus this order would exceed your credit limit of %2$s. Please clear part of your due or pay online.', 'wc-enterprise-erp' ),
				wp_strip_all_tags( wceerp_money( $due ) ),
				wp_strip_all_tags( wceerp_money( $dealer->credit_limit ) )
			) );
		}
	}

	public function register_endpoint() {
		add_rewrite_endpoint( 'dealer-statement', EP_ROOT | EP_PAGES );
	}

	public function account_menu( $items ) {
		if ( is_user_logged_in() && self::by_user( get_current_user_id() ) ) {
			$items['dealer-statement'] = __( 'Dealer statement', 'wc-enterprise-erp' );
		}
		return $items;
	}

	public function render_front_statement() {
		$dealer = self::by_user( get_current_user_id() );
		if ( ! $dealer ) {
			echo '<p>' . esc_html__( 'No dealer account is linked to this login.', 'wc-enterprise-erp' ) . '</p>';
			return;
		}
		$ar  = WCEERP_Accounting::account_by_subtype( 'receivable' );
		$due = self::open_due( (int) $dealer->id );
		echo '<h3>' . esc_html( $dealer->company ?: $dealer->name ) . '</h3>';
		echo '<p><strong>' . esc_html__( 'Current due:', 'wc-enterprise-erp' ) . '</strong> ' . wp_kses_post( wceerp_money( $due ) );
		echo ' &nbsp;·&nbsp; <strong>' . esc_html__( 'Credit limit:', 'wc-enterprise-erp' ) . '</strong> ' . wp_kses_post( wceerp_money( $dealer->credit_limit ) ) . '</p>';

		if ( $ar ) {
			$lines = WCEERP_Accounting::ledger( $ar->id, gmdate( 'Y-m-d', strtotime( '-6 months' ) ), current_time( 'Y-m-d' ), 'dealer', (int) $dealer->id );
			echo '<table class="shop_table"><thead><tr><th>' . esc_html__( 'Date', 'wc-enterprise-erp' ) . '</th><th>' . esc_html__( 'Detail', 'wc-enterprise-erp' ) . '</th><th style="text-align:right">' . esc_html__( 'Purchase', 'wc-enterprise-erp' ) . '</th><th style="text-align:right">' . esc_html__( 'Payment', 'wc-enterprise-erp' ) . '</th></tr></thead><tbody>';
			if ( ! $lines ) {
				echo '<tr><td colspan="4">' . esc_html__( 'No transactions in the last 6 months.', 'wc-enterprise-erp' ) . '</td></tr>';
			}
			foreach ( (array) $lines as $line ) {
				echo '<tr><td>' . esc_html( $line->journal_date ) . '</td><td>' . esc_html( $line->memo ?: $line->jmemo ) . '</td>'
					. '<td style="text-align:right">' . ( (float) $line->debit ? wp_kses_post( wceerp_money( $line->debit ) ) : '—' ) . '</td>'
					. '<td style="text-align:right">' . ( (float) $line->credit ? wp_kses_post( wceerp_money( $line->credit ) ) : '—' ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
	}

	/* ---------------------------------------------------------------------
	 * Admin handlers.
	 * ------------------------------------------------------------------- */

	public function handle_save() {
		$this->verify_nonce( 'wceerp_dealer_save' );
		global $wpdb;

		$mode  = sanitize_key( $_POST['user_mode'] ?? 'new' );
		$name  = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$phone = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );

		if ( ! $name ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => 'name' ) ) );
			exit;
		}

		if ( 'existing' === $mode ) {
			$user_id = (int) ( $_POST['user_id'] ?? 0 );
			if ( ! $user_id || ! get_userdata( $user_id ) ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'user' ) ) );
				exit;
			}
		} else {
			/* Create the WordPress account inline. Requiring the admin to
			 * go and make one by hand, then paste a numeric ID back, was
			 * the single clumsiest step in this module. */
			if ( ! $email || ! is_email( $email ) ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'email' ) ) );
				exit;
			}
			if ( ! current_user_can( 'create_users' ) ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'cap' ) ) );
				exit;
			}
			if ( email_exists( $email ) ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'email_taken' ) ) );
				exit;
			}

			$login = sanitize_user( (string) $_POST['username'] ?? '', true );
			if ( ! $login ) {
				$login = sanitize_user( current( explode( '@', $email ) ), true );
			}
			$base = $login;
			$i    = 1;
			while ( username_exists( $login ) ) {
				$login = $base . ++$i;
			}

			$pass    = wp_generate_password( 14, true );
			$user_id = wp_insert_user( array(
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => $pass,
				'display_name' => $name,
				'first_name'   => $name,
				'role'         => apply_filters( 'wceerp_dealer_role', 'customer' ),
			) );
			if ( is_wp_error( $user_id ) ) {
				wp_safe_redirect( $this->admin_url( array( 'error' => 'create' ) ) );
				exit;
			}

			if ( $phone ) {
				update_user_meta( $user_id, 'billing_phone', $phone );
			}
			update_user_meta( $user_id, 'billing_email', $email );
			update_user_meta( $user_id, 'billing_first_name', $name );

			if ( ! empty( $_POST['notify'] ) ) {
				wp_new_user_notification( $user_id, null, 'user' );
			}
		}

		$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . wceerp_table( 'dealers' ) . ' WHERE user_id=%d', $user_id ) );
		if ( $exists ) {
			wp_safe_redirect( $this->admin_url( array( 'error' => 'duplicate' ) ) );
			exit;
		}

		$wpdb->insert( wceerp_table( 'dealers' ), array(
			'user_id'      => $user_id,
			'name'         => $name,
			'company'      => sanitize_text_field( wp_unslash( $_POST['company'] ?? '' ) ),
			'phone'        => $phone,
			'territory'    => sanitize_text_field( wp_unslash( $_POST['territory'] ?? '' ) ),
			'group_type'   => array_key_exists( sanitize_key( $_POST['group_type'] ?? '' ), self::tiers() ) ? sanitize_key( $_POST['group_type'] ) : 'dealer',
			'discount_pct' => min( 90, max( 0, wceerp_dec( $_POST['discount_pct'] ?? 0 ) ) ),
			'credit_limit' => max( 0, wceerp_dec( $_POST['credit_limit'] ?? 0 ) ),
			'status'       => 'active',
			'note'         => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'   => current_time( 'mysql' ),
		) );
		wceerp_log( 'dealers', 'create', (int) $wpdb->insert_id, 'user ' . $user_id );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/** Search users for the dealer picker. */
	public function ajax_user_search() {
		if ( ! current_user_can( 'list_users' ) ) {
			wp_send_json_error( array(), 403 );
		}
		check_ajax_referer( 'wceerp_dealer_users', 'nonce' );
		$q = sanitize_text_field( wp_unslash( $_GET['q'] ?? '' ) );
		if ( mb_strlen( $q ) < 2 ) {
			wp_send_json_success( array() );
		}
		$users = get_users( array(
			'search'         => '*' . $q . '*',
			'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
			'number'         => 20,
			'fields'         => array( 'ID', 'display_name', 'user_email' ),
		) );
		$out = array();
		foreach ( $users as $u ) {
			$out[] = array(
				'id'    => (int) $u->ID,
				'text'  => $u->display_name . ' (' . $u->user_email . ')',
			);
		}
		wp_send_json_success( $out );
	}

	public function handle_status() {
		$this->verify_nonce( 'wceerp_dealer_status' );
		global $wpdb;
		$id = (int) ( $_POST['dealer_id'] ?? 0 );
		$to = 'suspend' === ( $_POST['do'] ?? '' ) ? 'suspended' : 'active';
		if ( $id ) {
			$wpdb->update( wceerp_table( 'dealers' ), array( 'status' => $to ), array( 'id' => $id ) );
			wceerp_log( 'dealers', 'status', $id, $to );
		}
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Admin screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		global $wpdb;
		$table     = wceerp_table( 'dealers' );
		$statement = (int) ( $_GET['statement'] ?? 0 );
		if ( $statement ) {
			$this->render_statement( $statement );
			return;
		}

		if ( ! empty( $_GET['updated'] ) ) {
			$this->notice( __( 'Saved.', 'wc-enterprise-erp' ) );
		}
		if ( ! empty( $_GET['error'] ) ) {
			$messages = array(
				'user'        => __( 'Pick a valid WordPress user for the dealer login.', 'wc-enterprise-erp' ),
				'duplicate'   => __( 'That user already has a dealer account.', 'wc-enterprise-erp' ),
				'name'        => __( 'Enter the dealer name.', 'wc-enterprise-erp' ),
				'email'       => __( 'Enter a valid email address for the new dealer login.', 'wc-enterprise-erp' ),
				'email_taken' => __( 'A WordPress user with that email already exists — switch to "Link an existing user" instead.', 'wc-enterprise-erp' ),
				'cap'         => __( 'Your role cannot create users. Ask an administrator, or link an existing user.', 'wc-enterprise-erp' ),
				'create'      => __( 'The WordPress account could not be created.', 'wc-enterprise-erp' ),
			);
			$this->notice( $messages[ sanitize_key( $_GET['error'] ) ] ?? __( 'Could not save.', 'wc-enterprise-erp' ), 'error' );
		}

		$per_page = 25;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$dealers  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY status, name LIMIT %d OFFSET %d", $per_page, wceerp_offset( $per_page ) ) );

		$total_due = 0;
		$dues      = array();
		foreach ( (array) $dealers as $dealer ) {
			$dues[ $dealer->id ] = self::open_due( (int) $dealer->id );
			$total_due          += $dues[ $dealer->id ];
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Dealers & Wholesale', 'wc-enterprise-erp' ) ) ); ?></h1>

			<div class="wceerp-kpis">
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Dealers', 'wc-enterprise-erp' ); ?></span><strong><?php echo (int) $total; ?></strong></div>
				<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Total dealer due (this page)', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $total_due ) ); ?></strong></div>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Register a dealer', 'wc-enterprise-erp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'The login account is created for you. Tier pricing and the credit limit start working on the storefront as soon as the dealer is saved.', 'wc-enterprise-erp' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_dealer_save">
						<?php wp_nonce_field( 'wceerp_dealer_save' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Login account', 'wc-enterprise-erp' ); ?></th>
								<td>
									<label style="margin-right:14px">
										<input type="radio" name="user_mode" value="new" checked class="wceerp-umode">
										<?php esc_html_e( 'Create a new account', 'wc-enterprise-erp' ); ?>
									</label>
									<label>
										<input type="radio" name="user_mode" value="existing" class="wceerp-umode">
										<?php esc_html_e( 'Link an existing user', 'wc-enterprise-erp' ); ?>
									</label>
								</td></tr>

							<tr class="wceerp-u-new"><th><?php esc_html_e( 'Email', 'wc-enterprise-erp' ); ?> <span style="color:#b32d2e">*</span></th>
								<td><input type="email" name="email" class="regular-text">
								<p class="description"><?php esc_html_e( 'Becomes the dealer login. A username and secure password are generated automatically.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr class="wceerp-u-new"><th><?php esc_html_e( 'Username', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="username" class="regular-text" autocomplete="off">
								<p class="description"><?php esc_html_e( 'Optional — taken from the email address when left blank.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr class="wceerp-u-new"><th><?php esc_html_e( 'Send login details', 'wc-enterprise-erp' ); ?></th>
								<td><label><input type="checkbox" name="notify" value="1" checked>
								<?php esc_html_e( 'Email the dealer a link to set their password', 'wc-enterprise-erp' ); ?></label></td></tr>

							<tr class="wceerp-u-existing" style="display:none"><th><?php esc_html_e( 'Existing user', 'wc-enterprise-erp' ); ?></th>
								<td>
									<input type="text" id="wceerp-user-q" class="regular-text" autocomplete="off"
										placeholder="<?php esc_attr_e( 'Search name or email…', 'wc-enterprise-erp' ); ?>">
									<input type="hidden" name="user_id" id="wceerp-user-id" value="">
									<div id="wceerp-user-res" style="max-height:170px;overflow:auto;margin-top:6px"></div>
									<p class="description" id="wceerp-user-sel"></p>
								</td></tr>
							<tr><th><?php esc_html_e( 'Dealer name', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="name" class="regular-text" required></td></tr>
							<tr><th><?php esc_html_e( 'Company', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="company" class="regular-text"></td></tr>
							<tr><th><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="phone"></td></tr>
							<tr><th><?php esc_html_e( 'Territory', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="territory" placeholder="<?php esc_attr_e( 'e.g. Sylhet division', 'wc-enterprise-erp' ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Buyer group', 'wc-enterprise-erp' ); ?></th>
								<td>
									<select name="group_type">
										<?php foreach ( self::tiers() as $tk => $tl ) : ?>
											<option value="<?php echo esc_attr( $tk ); ?>"><?php echo esc_html( $tl ); ?></option>
										<?php endforeach; ?>
									</select>
									<p class="description"><?php esc_html_e( 'Determines which per-product price this buyer gets. A product with no price set for the group falls back to the discount % below.', 'wc-enterprise-erp' ); ?></p>
								</td></tr>
							<tr><th><?php esc_html_e( 'Group discount %', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0" max="90" name="discount_pct" value="0">
								<p class="description"><?php esc_html_e( 'Fallback only — used when a product has no fixed price for this group.', 'wc-enterprise-erp' ); ?></p></td></tr>
							<tr><th><?php esc_html_e( 'Credit limit', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0" name="credit_limit" value="0">
								<p class="description"><?php esc_html_e( '0 = no on-account credit control.', 'wc-enterprise-erp' ); ?></p></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Register dealer', 'wc-enterprise-erp' ) ); ?>
						<script>
						(function () {
							var nonce = <?php echo wp_json_encode( wp_create_nonce( 'wceerp_dealer_users' ) ); ?>;
							var ajax  = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
							function show(mode) {
								document.querySelectorAll('.wceerp-u-new').forEach(function (el) { el.style.display = mode === 'new' ? '' : 'none'; });
								document.querySelectorAll('.wceerp-u-existing').forEach(function (el) { el.style.display = mode === 'existing' ? '' : 'none'; });
							}
							document.querySelectorAll('.wceerp-umode').forEach(function (r) {
								r.addEventListener('change', function () { show(r.value); });
							});
							var q = document.getElementById('wceerp-user-q');
							var t = null;
							if (q) {
								q.addEventListener('input', function () {
									clearTimeout(t);
									var term = q.value.trim();
									var box = document.getElementById('wceerp-user-res');
									if (term.length < 2) { box.innerHTML = ''; return; }
									t = setTimeout(function () {
										fetch(ajax + '?action=wceerp_dealer_users&nonce=' + encodeURIComponent(nonce) + '&q=' + encodeURIComponent(term), { credentials: 'same-origin' })
											.then(function (r) { return r.json(); })
											.then(function (j) {
												var rows = (j && j.data) || [];
												box.innerHTML = '';
												if (!rows.length) { box.innerHTML = '<p class="description">No matches.</p>'; return; }
												rows.forEach(function (u) {
													var d = document.createElement('div');
													d.style.cssText = 'padding:6px 8px;border-bottom:1px dashed #eee;cursor:pointer';
													d.textContent = u.text;
													d.addEventListener('click', function () {
														document.getElementById('wceerp-user-id').value = u.id;
														document.getElementById('wceerp-user-sel').textContent = 'Selected: ' + u.text;
														box.innerHTML = '';
														q.value = '';
													});
													box.appendChild(d);
												});
											});
									}, 250);
								});
							}
						})();
						</script>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Dealer list', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped wceerp-table">
						<thead><tr>
							<th><?php esc_html_e( 'Dealer', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Disc %', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Due', 'wc-enterprise-erp' ); ?></th>
							<th class="num"><?php esc_html_e( 'Limit', 'wc-enterprise-erp' ); ?></th>
							<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
							<th></th>
						</tr></thead>
						<tbody>
						<?php if ( ! $dealers ) : ?>
							<tr><td colspan="6"><?php esc_html_e( 'No dealers yet.', 'wc-enterprise-erp' ); ?></td></tr>
						<?php endif; ?>
						<?php foreach ( (array) $dealers as $dealer ) :
							$due  = $dues[ $dealer->id ];
							$over = (float) $dealer->credit_limit > 0 && $due > (float) $dealer->credit_limit;
							?>
							<tr>
								<td><strong><?php echo esc_html( $dealer->name ); ?></strong><?php echo $dealer->company ? '<br><small>' . esc_html( $dealer->company ) . '</small>' : ''; ?></td>
								<td class="num">
									<?php
									$tiers = self::tiers();
									$gt    = isset( $dealer->group_type ) ? $dealer->group_type : 'dealer';
									echo esc_html( isset( $tiers[ $gt ] ) ? $tiers[ $gt ] : $gt );
									?>
									<br><small><?php echo esc_html( wceerp_dec( $dealer->discount_pct ) ); ?>%</small>
								</td>
								<td class="num" <?php echo $over ? 'style="color:#b32d2e;font-weight:600"' : ''; ?>><?php echo wp_kses_post( wceerp_money( $due ) ); ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $dealer->credit_limit ) ); ?></td>
								<td><span class="wceerp-badge is-<?php echo esc_attr( $dealer->status ); ?>"><?php echo esc_html( $dealer->status ); ?></span></td>
								<td style="white-space:nowrap">
									<a class="button button-small" href="<?php echo esc_url( $this->admin_url( array( 'statement' => $dealer->id ) ) ); ?>"><?php esc_html_e( 'Statement', 'wc-enterprise-erp' ); ?></a>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<input type="hidden" name="action" value="wceerp_dealer_status">
										<input type="hidden" name="dealer_id" value="<?php echo (int) $dealer->id; ?>">
										<?php wp_nonce_field( 'wceerp_dealer_status' ); ?>
										<?php if ( 'active' === $dealer->status ) : ?>
											<button class="button button-small" name="do" value="suspend"><?php esc_html_e( 'Suspend', 'wc-enterprise-erp' ); ?></button>
										<?php else : ?>
											<button class="button button-small" name="do" value="activate"><?php esc_html_e( 'Activate', 'wc-enterprise-erp' ); ?></button>
										<?php endif; ?>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php wceerp_pagination( $total, $per_page ); ?>
					<p class="description"><?php esc_html_e( 'Receive dealer payments from ERP → Dues (party type: dealer) — the due here updates instantly.', 'wc-enterprise-erp' ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}

	protected function render_statement( $dealer_id ) {
		global $wpdb;
		$dealer = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'dealers' ) . ' WHERE id=%d', $dealer_id ) );
		if ( ! $dealer ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Dealer not found.', 'wc-enterprise-erp' ) . '</p></div>';
			return;
		}
		$ar   = WCEERP_Accounting::account_by_subtype( 'receivable' );
		$from = sanitize_text_field( $_GET['from'] ?? gmdate( 'Y-m-d', strtotime( '-6 months' ) ) );
		$to   = sanitize_text_field( $_GET['to'] ?? current_time( 'Y-m-d' ) );

		$opening = $ar ? WCEERP_Accounting::opening_balance( $ar->id, $from, 'dealer', (int) $dealer->id ) : 0;
		$lines   = $ar ? WCEERP_Accounting::ledger( $ar->id, $from, $to, 'dealer', (int) $dealer->id ) : array();
		$running = $opening;
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php printf( esc_html__( 'Dealer statement — %s', 'wc-enterprise-erp' ), esc_html( $dealer->company ?: $dealer->name ) ); ?></h1>
			<form method="get" class="wceerp-filter">
				<input type="hidden" name="page" value="wceerp-dealers">
				<input type="hidden" name="statement" value="<?php echo (int) $dealer_id; ?>">
				<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>">
				<input type="date" name="to" value="<?php echo esc_attr( $to ); ?>">
				<button class="button"><?php esc_html_e( 'Apply', 'wc-enterprise-erp' ); ?></button>
				<a class="button" href="<?php echo esc_url( $this->admin_url() ); ?>"><?php esc_html_e( '← Back', 'wc-enterprise-erp' ); ?></a>
				<button class="button" type="button" onclick="window.print()"><?php esc_html_e( 'Print', 'wc-enterprise-erp' ); ?></button>
			</form>

			<div class="wceerp-card wceerp-print-area">
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Doc', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Detail', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Purchase (Dr)', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Payment (Cr)', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Balance', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
						<tr><td colspan="5"><em><?php esc_html_e( 'Opening balance', 'wc-enterprise-erp' ); ?></em></td>
							<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $opening ) ); ?></strong></td></tr>
						<?php foreach ( (array) $lines as $line ) :
							$running += (float) $line->debit - (float) $line->credit;
							?>
							<tr>
								<td><?php echo esc_html( $line->journal_date ); ?></td>
								<td><code><?php echo esc_html( $line->doc_no ); ?></code></td>
								<td><?php echo esc_html( $line->memo ?: $line->jmemo ); ?></td>
								<td class="num"><?php echo (float) $line->debit ? wp_kses_post( wceerp_money( $line->debit ) ) : '—'; ?></td>
								<td class="num"><?php echo (float) $line->credit ? wp_kses_post( wceerp_money( $line->credit ) ) : '—'; ?></td>
								<td class="num"><?php echo wp_kses_post( wceerp_money( $running ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
					<tfoot><tr>
						<th colspan="5"><?php esc_html_e( 'Closing due', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php echo wp_kses_post( wceerp_money( $running ) ); ?></th>
					</tr></tfoot>
				</table>
			</div>
		</div>
		<?php
	}
}
