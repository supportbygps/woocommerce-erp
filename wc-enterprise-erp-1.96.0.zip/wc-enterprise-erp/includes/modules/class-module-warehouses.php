<?php
/**
 * Module: Warehouses (multi-warehouse master data).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Warehouses extends WCEERP_Module {

	protected $id         = 'warehouses';
	protected $title      = 'Warehouses';
	protected $capability = 'wceerp_manage_warehouses';
	protected $tier       = 'starter';
	protected $order      = 15;

	public function __construct() {
		$this->title = __( 'Warehouses', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_warehouse_save', array( $this, 'handle_save' ) );
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_warehouse_save' );
		global $wpdb;
		$table = wceerp_table( 'warehouses' );

		$data = array(
			'name'    => sanitize_text_field( wp_unslash( $_POST['name'] ) ),
			'code'    => strtoupper( sanitize_key( $_POST['code'] ) ),
			'address' => sanitize_textarea_field( wp_unslash( $_POST['address'] ?? '' ) ),
			'phone'   => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'status'  => 'inactive' === ( $_POST['status'] ?? '' ) ? 'inactive' : 'active',
		);

		$id = (int) ( $_POST['id'] ?? 0 );
		if ( $id ) {
			$wpdb->update( $table, $data, array( 'id' => $id ) );
		} else {
			$data['created_at'] = current_time( 'mysql' );
			$wpdb->insert( $table, $data );
			$id = $wpdb->insert_id;
		}

		if ( ! empty( $_POST['is_default'] ) ) {
			$wpdb->query( "UPDATE $table SET is_default = 0" );
			$wpdb->update( $table, array( 'is_default' => 1 ), array( 'id' => $id ) );
		}

		wceerp_log( 'warehouses', 'save', $id );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		global $wpdb;
		$table = wceerp_table( 'warehouses' );
		$edit  = isset( $_GET['edit'] ) ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", (int) $_GET['edit'] ) ) : null;
		$rows  = $wpdb->get_results( "SELECT * FROM $table ORDER BY is_default DESC, name" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Warehouses', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Warehouse saved.', 'wc-enterprise-erp' ) ); ?>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php echo $edit ? esc_html__( 'Edit warehouse', 'wc-enterprise-erp' ) : esc_html__( 'Add warehouse', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_warehouse_save">
						<input type="hidden" name="id" value="<?php echo (int) ( $edit->id ?? 0 ); ?>">
						<?php wp_nonce_field( 'wceerp_warehouse_save' ); ?>
						<p><label><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?><br><input type="text" name="name" required class="regular-text" value="<?php echo esc_attr( $edit->name ?? '' ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?><br><input type="text" name="code" required class="regular-text" value="<?php echo esc_attr( $edit->code ?? '' ); ?>" placeholder="DHK-01"></label></p>
						<p><label><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?><br><textarea name="address" class="large-text" rows="2"><?php echo esc_textarea( $edit->address ?? '' ); ?></textarea></label></p>
						<p><label><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?><br><input type="text" name="phone" class="regular-text" value="<?php echo esc_attr( $edit->phone ?? '' ); ?>"></label></p>
						<p><label><input type="checkbox" name="is_default" value="1" <?php checked( ! empty( $edit->is_default ) ); ?>> <?php esc_html_e( 'Default warehouse (used for online sales)', 'wc-enterprise-erp' ); ?></label></p>
						<p><label><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?>
							<select name="status">
								<option value="active" <?php selected( $edit->status ?? 'active', 'active' ); ?>><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></option>
								<option value="inactive" <?php selected( $edit->status ?? '', 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'wc-enterprise-erp' ); ?></option>
							</select></label></p>
						<?php submit_button( __( 'Save warehouse', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'All warehouses', 'wc-enterprise-erp' ); ?></h2>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th><th></th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $r ) : ?>
							<tr>
								<td><?php echo esc_html( $r->name ); ?> <?php echo $r->is_default ? '<span class="wceerp-badge is-in">' . esc_html__( 'Default', 'wc-enterprise-erp' ) . '</span>' : ''; ?></td>
								<td><code><?php echo esc_html( $r->code ); ?></code></td>
								<td><?php echo esc_html( $r->status ); ?></td>
								<td><a href="<?php echo esc_url( $this->admin_url( array( 'edit' => $r->id ) ) ); ?>"><?php esc_html_e( 'Edit', 'wc-enterprise-erp' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php
	}
}
