<?php
/**
 * Module: Reseller Management & Sales Commission.
 *
 * Orders placed by (or attributed to) a reseller earn commission
 * automatically when the sale posts. Approving accrues:
 *   Dr Sales Commission Expense / Cr Commission Payable (per reseller).
 * Paying out settles Commission Payable through record_payment().
 *
 * Attribution: order meta `_wceerp_reseller_id`, a `?ref={id}` cookie,
 * or the buying user being linked to a reseller record.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Resellers extends WCEERP_Module {

	protected $id         = 'resellers';
	protected $title      = 'Resellers';
	protected $capability = 'wceerp_manage_resellers';
	protected $tier       = 'business';
	protected $order      = 40;

	public function __construct() {
		$this->title = __( 'Resellers', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_reseller_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_commission_action', array( $this, 'handle_commission' ) );

		// Referral cookie → order attribution.
		add_action( 'init', array( __CLASS__, 'capture_ref' ) );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'attach_ref_to_order' ) );
	}

	public static function capture_ref() {
		if ( isset( $_GET['ref'] ) && is_numeric( $_GET['ref'] ) && ! headers_sent() ) {
			setcookie( 'wceerp_ref', (string) (int) $_GET['ref'], time() + 30 * DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
		}
	}

	public static function attach_ref_to_order( $order ) {
		if ( ! empty( $_COOKIE['wceerp_ref'] ) ) {
			$order->update_meta_data( '_wceerp_reseller_id', (int) $_COOKIE['wceerp_ref'] );
		}
	}

	/**
	 * Called by the WooCommerce bridge after every sale posting.
	 */
	public static function maybe_create_commission( $order ) {
		global $wpdb;
		$table = wceerp_table( 'resellers' );

		$reseller_id = (int) $order->get_meta( '_wceerp_reseller_id' );
		if ( ! $reseller_id && $order->get_customer_id() ) {
			$reseller_id = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM $table WHERE user_id = %d AND status='active'", $order->get_customer_id()
			) );
		}
		if ( ! $reseller_id ) {
			return;
		}

		$reseller = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d AND status='active'", $reseller_id ) );
		if ( ! $reseller ) {
			return;
		}

		$net    = (float) $order->get_total() - (float) $order->get_total_tax();
		$amount = 'flat' === $reseller->commission_type
			? (float) $reseller->commission_rate
			: $net * ( (float) $reseller->commission_rate / 100 );
		$amount = round( (float) apply_filters( 'wceerp_commission_amount', $amount, $reseller, $order ), 2 );

		if ( $amount <= 0 ) {
			return;
		}

		$wpdb->query( $wpdb->prepare(
			'INSERT IGNORE INTO ' . wceerp_table( 'commissions' ) . '
			 (reseller_id, order_id, order_total, amount, status, created_at)
			 VALUES (%d, %d, %f, %f, %s, %s)',
			$reseller_id, $order->get_id(), $net, $amount, 'pending', current_time( 'mysql' )
		) );

		if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'commission',
				__( 'New commission pending', 'wc-enterprise-erp' ),
				sprintf( __( '%1$s earned %2$s on order #%3$d.', 'wc-enterprise-erp' ), $reseller->name, wp_strip_all_tags( wceerp_money( $amount ) ), $order->get_id() ),
				admin_url( 'admin.php?page=wceerp-resellers&tab=commissions' )
			);
		}
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_reseller_save' );
		global $wpdb;
		$table = wceerp_table( 'resellers' );

		$data = array(
			'user_id'         => (int) ( $_POST['user_id'] ?? 0 ) ?: null,
			'name'            => sanitize_text_field( wp_unslash( $_POST['name'] ) ),
			'phone'           => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
			'email'           => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
			'area'            => sanitize_text_field( wp_unslash( $_POST['area'] ?? '' ) ),
			'commission_type' => 'flat' === ( $_POST['commission_type'] ?? '' ) ? 'flat' : 'percent',
			'commission_rate' => wceerp_dec( $_POST['commission_rate'] ?? 0 ),
			'status'          => 'inactive' === ( $_POST['status'] ?? '' ) ? 'inactive' : 'active',
		);

		$id = (int) ( $_POST['id'] ?? 0 );
		if ( $id ) {
			$wpdb->update( $table, $data, array( 'id' => $id ) );
		} else {
			$data['created_at'] = current_time( 'mysql' );
			$wpdb->insert( $table, $data );
			$id = $wpdb->insert_id;
		}

		wceerp_log( 'resellers', 'save', $id );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function handle_commission() {
		$this->verify_nonce( 'wceerp_commission_action' );
		global $wpdb;
		$table = wceerp_table( 'commissions' );
		$id    = (int) $_POST['commission_id'];
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
		$do    = sanitize_key( $_POST['do'] );

		if ( $row && 'approve' === $do && 'pending' === $row->status ) {
			$expense = WCEERP_Accounting::resolve_account( '5400' );
			$payable = WCEERP_Accounting::resolve_account( '2200' );
			WCEERP_Accounting::post(
				array( 'ref_type' => 'commission', 'ref_id' => $id, 'memo' => 'Commission accrual — order #' . $row->order_id ),
				array(
					array( 'account' => $expense, 'debit' => (float) $row->amount ),
					array( 'account' => $payable, 'credit' => (float) $row->amount, 'party_type' => 'reseller', 'party_id' => (int) $row->reseller_id ),
				)
			);
			$wpdb->update( $table, array( 'status' => 'approved' ), array( 'id' => $id ) );
		}

		if ( $row && 'pay' === $do && 'approved' === $row->status ) {
			$cash = WCEERP_Accounting::account_by_subtype( 'cash' );
			WCEERP_Accounting::record_payment( array(
				'direction'  => 'out',
				'party_type' => 'reseller',
				'party_id'   => (int) $row->reseller_id,
				'account_id' => $cash->id,
				'amount'     => (float) $row->amount,
				'contra'     => WCEERP_Accounting::resolve_account( '2200' ),
				'note'       => 'Commission payout — order #' . $row->order_id,
			) );
			$wpdb->update( $table, array( 'status' => 'paid', 'paid_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
		}

		if ( $row && 'cancel' === $do && 'pending' === $row->status ) {
			$wpdb->update( $table, array( 'status' => 'cancelled' ), array( 'id' => $id ) );
		}

		wp_safe_redirect( $this->admin_url( array( 'tab' => 'commissions', 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'resellers';
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Resellers & Commission', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); ?>
			<nav class="nav-tab-wrapper">
				<?php
				foreach ( array( 'resellers' => __( 'Resellers', 'wc-enterprise-erp' ), 'commissions' => __( 'Commissions', 'wc-enterprise-erp' ) ) as $key => $label ) {
					printf( '<a class="nav-tab %s" href="%s">%s</a>', $tab === $key ? 'nav-tab-active' : '', esc_url( $this->admin_url( array( 'tab' => $key ) ) ), esc_html( $label ) );
				}
				?>
			</nav>
			<?php 'commissions' === $tab ? $this->tab_commissions() : $this->tab_resellers(); ?>
		</div>
		<?php
	}

	protected function tab_resellers() {
		global $wpdb;
		$table = wceerp_table( 'resellers' );
		$edit  = isset( $_GET['edit'] ) ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", (int) $_GET['edit'] ) ) : null;
		$rows  = $wpdb->get_results( "SELECT * FROM $table ORDER BY name" );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php echo $edit ? esc_html__( 'Edit reseller', 'wc-enterprise-erp' ) : esc_html__( 'Add reseller', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_reseller_save">
					<input type="hidden" name="id" value="<?php echo (int) ( $edit->id ?? 0 ); ?>">
					<?php wp_nonce_field( 'wceerp_reseller_save' ); ?>
					<p><label><?php esc_html_e( 'Name *', 'wc-enterprise-erp' ); ?><br><input type="text" name="name" required class="regular-text" value="<?php echo esc_attr( $edit->name ?? '' ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Linked WP user ID (optional)', 'wc-enterprise-erp' ); ?><br><input type="number" name="user_id" value="<?php echo (int) ( $edit->user_id ?? 0 ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Phone', 'wc-enterprise-erp' ); ?><br><input type="text" name="phone" value="<?php echo esc_attr( $edit->phone ?? '' ); ?>"></label>
					   <label><?php esc_html_e( 'Email', 'wc-enterprise-erp' ); ?><br><input type="email" name="email" value="<?php echo esc_attr( $edit->email ?? '' ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Area / territory', 'wc-enterprise-erp' ); ?><br><input type="text" name="area" class="regular-text" value="<?php echo esc_attr( $edit->area ?? '' ); ?>" placeholder="Dhaka, Chattogram…"></label></p>
					<p>
						<label><?php esc_html_e( 'Commission', 'wc-enterprise-erp' ); ?>
							<select name="commission_type">
								<option value="percent" <?php selected( $edit->commission_type ?? 'percent', 'percent' ); ?>><?php esc_html_e( '% of net sale', 'wc-enterprise-erp' ); ?></option>
								<option value="flat" <?php selected( $edit->commission_type ?? '', 'flat' ); ?>><?php esc_html_e( 'Flat per order', 'wc-enterprise-erp' ); ?></option>
							</select>
						</label>
						<input type="number" step="0.01" min="0" name="commission_rate" value="<?php echo esc_attr( $edit->commission_rate ?? '5' ); ?>">
					</p>
					<p><label><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?>
						<select name="status">
							<option value="active" <?php selected( $edit->status ?? 'active', 'active' ); ?>><?php esc_html_e( 'Active', 'wc-enterprise-erp' ); ?></option>
							<option value="inactive" <?php selected( $edit->status ?? '', 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'wc-enterprise-erp' ); ?></option>
						</select></label></p>
					<?php submit_button( __( 'Save reseller', 'wc-enterprise-erp' ) ); ?>
				</form>
				<p class="description"><?php esc_html_e( 'Referral link for a reseller: your-store.com/?ref={reseller ID}', 'wc-enterprise-erp' ); ?></p>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'All resellers', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th>#</th><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Area', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Commission', 'wc-enterprise-erp' ); ?></th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $rows as $r ) : ?>
						<tr>
							<td><?php echo (int) $r->id; ?></td>
							<td><?php echo esc_html( $r->name ); ?></td>
							<td><?php echo esc_html( $r->area ); ?></td>
							<td><?php echo esc_html( 'flat' === $r->commission_type ? wp_strip_all_tags( wceerp_money( $r->commission_rate ) ) . '/order' : $r->commission_rate . '%' ); ?></td>
							<td><a href="<?php echo esc_url( $this->admin_url( array( 'edit' => $r->id ) ) ); ?>"><?php esc_html_e( 'Edit', 'wc-enterprise-erp' ); ?></a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	protected function tab_commissions() {
		global $wpdb;
		$per_page = 25;
		$total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wceerp_table( 'commissions' ) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			'SELECT c.*, r.name AS reseller FROM ' . wceerp_table( 'commissions' ) . ' c
			 LEFT JOIN ' . wceerp_table( 'resellers' ) . ' r ON r.id = c.reseller_id
			 ORDER BY c.id DESC LIMIT %d OFFSET %d', $per_page, wceerp_offset( $per_page )
		) );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Reseller', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Net sale', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Commission', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( (array) $rows as $c ) : ?>
				<tr>
					<td><?php echo esc_html( $c->reseller ); ?></td>
					<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . $c->order_id . '&action=edit' ) ); ?>">#<?php echo (int) $c->order_id; ?></a></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $c->order_total ) ); ?></td>
					<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $c->amount ) ); ?></strong></td>
					<td><span class="wceerp-badge is-<?php echo esc_attr( $c->status ); ?>"><?php echo esc_html( ucfirst( $c->status ) ); ?></span></td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
							<input type="hidden" name="action" value="wceerp_commission_action">
							<input type="hidden" name="commission_id" value="<?php echo (int) $c->id; ?>">
							<?php wp_nonce_field( 'wceerp_commission_action' ); ?>
							<?php if ( 'pending' === $c->status ) : ?>
								<button class="button button-small" name="do" value="approve"><?php esc_html_e( 'Approve', 'wc-enterprise-erp' ); ?></button>
								<button class="button button-small" name="do" value="cancel"><?php esc_html_e( 'Cancel', 'wc-enterprise-erp' ); ?></button>
							<?php elseif ( 'approved' === $c->status ) : ?>
								<button class="button button-small button-primary" name="do" value="pay"><?php esc_html_e( 'Pay out', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}
}
