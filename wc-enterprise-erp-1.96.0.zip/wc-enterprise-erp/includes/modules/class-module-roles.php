<?php
/**
 * Module: Roles & Permissions — a capability matrix over the
 * ERP capabilities defined in WCEERP_Capabilities.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Roles extends WCEERP_Module {

	protected $id         = 'roles';
	protected $title      = 'Roles & Permissions';
	protected $capability = 'wceerp_manage_settings';
	protected $tier       = 'business';
	protected $order      = 80;

	public function __construct() {
		$this->title = __( 'Roles & Permissions', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_roles_save', array( $this, 'handle_save' ) );
	}

	/**
	 * Roles shown in the matrix — everything except subscriber/customer-ish roles
	 * would be noise, so we show admin, shop manager and the ERP roles plus
	 * any custom role that already holds an ERP capability.
	 */
	protected function editable_roles() {
		$all  = wp_roles()->roles;
		$keep = array( 'administrator', 'shop_manager', 'editor', 'wceerp_accountant', 'wceerp_store_keeper', 'wceerp_purchase_officer', 'wceerp_reseller' );

		foreach ( $all as $slug => $role ) {
			foreach ( array_keys( (array) $role['capabilities'] ) as $cap ) {
				if ( 0 === strpos( $cap, 'wceerp_' ) && ! in_array( $slug, $keep, true ) ) {
					$keep[] = $slug;
				}
			}
		}

		$out = array();
		foreach ( $keep as $slug ) {
			if ( isset( $all[ $slug ] ) ) {
				$out[ $slug ] = $all[ $slug ]['name'];
			}
		}
		return $out;
	}

	public function handle_save() {
		$this->verify_nonce( 'wceerp_roles_save' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Only administrators can change permissions.', 'wc-enterprise-erp' ) );
		}

		$caps    = array_keys( WCEERP_Capabilities::all_caps() );
		$roles   = $this->editable_roles();
		$checked = isset( $_POST['grant'] ) ? (array) $_POST['grant'] : array();

		foreach ( $roles as $slug => $name ) {
			if ( 'administrator' === $slug ) {
				continue; // Admin always keeps everything.
			}
			$role = get_role( $slug );
			if ( ! $role ) {
				continue;
			}
			foreach ( $caps as $cap ) {
				if ( ! empty( $checked[ $slug ][ $cap ] ) ) {
					$role->add_cap( $cap );
				} else {
					$role->remove_cap( $cap );
				}
			}
		}

		wceerp_log( 'roles', 'matrix_save' );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	public function render_page() {
		$caps  = WCEERP_Capabilities::all_caps();
		$roles = $this->editable_roles();

		if ( ! empty( $_GET['updated'] ) ) {
			$this->notice( __( 'Permissions saved.', 'wc-enterprise-erp' ) );
		}
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Roles & Permissions', 'wc-enterprise-erp' ) ) ); ?></h1>
			<p class="description"><?php esc_html_e( 'Tick a box to grant that ERP capability to the role. Administrators always hold every capability. The plugin ships four ready-made roles: Accountant, Store Keeper, Purchase Officer and Reseller.', 'wc-enterprise-erp' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_roles_save">
				<?php wp_nonce_field( 'wceerp_roles_save' ); ?>

				<div class="wceerp-card" style="overflow-x:auto">
					<table class="widefat striped wceerp-table wceerp-matrix">
						<thead><tr>
							<th><?php esc_html_e( 'Capability', 'wc-enterprise-erp' ); ?></th>
							<?php foreach ( $roles as $slug => $name ) : ?>
								<th><?php echo esc_html( translate_user_role( $name ) ); ?></th>
							<?php endforeach; ?>
						</tr></thead>
						<tbody>
						<?php foreach ( $caps as $cap => $label ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $label ); ?></strong><br><code><?php echo esc_html( $cap ); ?></code></td>
								<?php foreach ( $roles as $slug => $name ) :
									$role = get_role( $slug );
									$has  = $role && $role->has_cap( $cap );
									$lock = 'administrator' === $slug;
									?>
									<td style="text-align:center">
										<input type="checkbox"
											name="grant[<?php echo esc_attr( $slug ); ?>][<?php echo esc_attr( $cap ); ?>]"
											value="1" <?php checked( $has || $lock ); ?> <?php disabled( $lock ); ?>>
									</td>
								<?php endforeach; ?>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<p><button class="button button-primary"><?php esc_html_e( 'Save permissions', 'wc-enterprise-erp' ); ?></button></p>
			</form>
		</div>
		<?php
	}
}
