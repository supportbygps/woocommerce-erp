<?php
/**
 * Module: Fixed Assets.
 *
 * Accounts:
 *   1500 Fixed Assets (at cost)      — Dr on purchase, Cr on disposal
 *   1510 Accumulated Depreciation    — Cr monthly, Dr on disposal (contra)
 *   5700 Depreciation Expense        — Dr monthly
 *   4100 Other Income / 5900 Misc    — gain / loss on disposal
 *
 * Straight-line depreciation runs on a monthly cron (and can be run
 * manually). Each asset+month is posted at most once (unique key), so
 * re-running is always safe.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Assets extends WCEERP_Module {

	protected $id         = 'assets';
	protected $title      = 'Fixed Assets';
	protected $capability = 'wceerp_manage_assets';
	protected $tier       = 'business';
	protected $order      = 45;

	public function __construct() {
		$this->title = __( 'Fixed Assets', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_asset_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_asset_depreciate', array( $this, 'handle_depreciate' ) );
		add_action( 'admin_post_wceerp_asset_dispose', array( $this, 'handle_dispose' ) );

		add_action( 'wceerp_asset_depreciation', array( __CLASS__, 'run_depreciation' ) );
		if ( ! wp_next_scheduled( 'wceerp_asset_depreciation' ) ) {
			wp_schedule_event( strtotime( 'tomorrow 02:00' ), 'daily', 'wceerp_asset_depreciation' );
		}
	}

	protected function money_accounts() {
		global $wpdb;
		return $wpdb->get_results(
			'SELECT id, code, name FROM ' . wceerp_table( 'accounts' ) . " WHERE subtype IN ('cash','bank','mobile_banking','payable') AND status='active' ORDER BY code"
		);
	}

	/* ---------------------------------------------------------------------
	 * Handlers.
	 * ------------------------------------------------------------------- */

	/**
	 * Register + book the purchase: Dr 1500 / Cr cash|bank|AP.
	 */
	public function handle_save() {
		$this->verify_nonce( 'wceerp_asset_save' );
		global $wpdb;

		$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$cost = wceerp_dec( $_POST['purchase_cost'] ?? 0 );
		$life = max( 1, (int) ( $_POST['useful_life_months'] ?? 60 ) );
		$fund = (int) ( $_POST['fund_account_id'] ?? 0 );

		if ( ! $name || $cost <= 0 || ! $fund ) {
			wp_die( esc_html__( 'An asset needs a name, a cost and a funding account.', 'wc-enterprise-erp' ) );
		}

		$doc_no = wceerp_next_doc_number( 'fa' );
		$wpdb->insert( wceerp_table( 'assets' ), array(
			'doc_no'             => $doc_no,
			'name'               => $name,
			'category'           => sanitize_text_field( wp_unslash( $_POST['category'] ?? '' ) ),
			'purchase_date'      => sanitize_text_field( $_POST['purchase_date'] ?? current_time( 'Y-m-d' ) ),
			'purchase_cost'      => $cost,
			'salvage_value'      => min( $cost, wceerp_dec( $_POST['salvage_value'] ?? 0 ) ),
			'useful_life_months' => $life,
			'status'             => 'active',
			'note'               => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_at'         => current_time( 'mysql' ),
		) );
		$asset_id = (int) $wpdb->insert_id;

		WCEERP_Accounting::post(
			array(
				'journal_date' => sanitize_text_field( $_POST['purchase_date'] ?? current_time( 'Y-m-d' ) ),
				'ref_type'     => 'asset',
				'ref_id'       => $asset_id,
				'memo'         => sprintf( 'Asset purchase — %s (%s)', $name, $doc_no ),
			),
			array(
				array( 'account' => '1500', 'debit' => $cost, 'memo' => $doc_no . ' ' . $name ),
				array( 'account' => $fund, 'credit' => $cost, 'memo' => 'Funding — ' . $doc_no ),
			)
		);

		wceerp_log( 'assets', 'create', $asset_id, $doc_no );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Post straight-line depreciation for every active asset for the given
	 * month (defaults to last month on cron, current month on the button).
	 * Idempotent per asset+period.
	 */
	public static function run_depreciation( $period = '' ) {
		global $wpdb;
		$assets_t = wceerp_table( 'assets' );
		$dep_t    = wceerp_table( 'asset_depreciation' );

		if ( ! $period ) {
			$period = gmdate( 'Y-m', strtotime( 'first day of last month' ) );
		}
		$period = preg_match( '/^\d{4}-\d{2}$/', $period ) ? $period : gmdate( 'Y-m' );

		$assets = $wpdb->get_results( "SELECT * FROM $assets_t WHERE status = 'active'" );
		$posted = 0;

		foreach ( (array) $assets as $asset ) {
			// Not before the purchase month.
			if ( $period < substr( $asset->purchase_date, 0, 7 ) ) {
				continue;
			}
			// Already posted for this period?
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $dep_t WHERE asset_id=%d AND period=%s", $asset->id, $period ) );
			if ( $exists ) {
				continue;
			}

			$depreciable = (float) $asset->purchase_cost - (float) $asset->salvage_value;
			$monthly     = $depreciable / max( 1, (int) $asset->useful_life_months );
			$remaining   = $depreciable - (float) $asset->accum_depreciation;
			$amount      = round( min( $monthly, max( 0, $remaining ) ), 2 );

			if ( $amount <= 0.004 ) {
				$wpdb->update( $assets_t, array( 'status' => 'fully_depreciated' ), array( 'id' => $asset->id ) );
				continue;
			}

			$journal = WCEERP_Accounting::post(
				array(
					'journal_date' => $period . '-28',
					'ref_type'     => 'asset_depreciation',
					'ref_id'       => (int) $asset->id,
					'memo'         => sprintf( 'Depreciation %s — %s', $period, $asset->name ),
				),
				array(
					array( 'account' => '5700', 'debit' => $amount ),
					array( 'account' => '1510', 'credit' => $amount ),
				)
			);
			if ( is_wp_error( $journal ) ) {
				continue;
			}

			$wpdb->insert( $dep_t, array(
				'asset_id'   => (int) $asset->id,
				'period'     => $period,
				'amount'     => $amount,
				'journal_id' => (int) $journal,
				'created_at' => current_time( 'mysql' ),
			) );

			$new_accum = (float) $asset->accum_depreciation + $amount;
			$wpdb->update( $assets_t, array(
				'accum_depreciation' => $new_accum,
				'status'             => ( $new_accum + 0.004 >= $depreciable ) ? 'fully_depreciated' : 'active',
			), array( 'id' => $asset->id ) );
			$posted++;
		}

		wceerp_log( 'assets', 'depreciation_run', 0, "$period: $posted assets" );
		return $posted;
	}

	public function handle_depreciate() {
		$this->verify_nonce( 'wceerp_asset_depreciate' );
		$period = sanitize_text_field( $_POST['period'] ?? gmdate( 'Y-m' ) );
		$posted = self::run_depreciation( $period );
		wp_safe_redirect( $this->admin_url( array( 'depreciated' => (int) $posted, 'period' => $period ) ) );
		exit;
	}

	/**
	 * Disposal: Dr money (sale) + Dr 1510 (accum) / Cr 1500 (cost),
	 * difference to 4100 gain or 5900 loss.
	 */
	public function handle_dispose() {
		$this->verify_nonce( 'wceerp_asset_dispose' );
		global $wpdb;

		$id    = (int) ( $_POST['asset_id'] ?? 0 );
		$asset = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'assets' ) . ' WHERE id=%d', $id ) );
		if ( ! $asset || 'disposed' === $asset->status ) {
			wp_safe_redirect( $this->admin_url() );
			exit;
		}

		$sale    = wceerp_dec( $_POST['disposal_amount'] ?? 0 );
		$account = (int) ( $_POST['account_id'] ?? 0 );
		$date    = sanitize_text_field( $_POST['disposal_date'] ?? current_time( 'Y-m-d' ) );

		$cost       = (float) $asset->purchase_cost;
		$accum      = (float) $asset->accum_depreciation;
		$book_value = $cost - $accum;
		$diff       = $sale - $book_value; // + gain / − loss.

		$lines = array();
		if ( $sale > 0.004 && $account ) {
			$lines[] = array( 'account' => $account, 'debit' => $sale, 'memo' => 'Sale proceeds — ' . $asset->doc_no );
		}
		if ( $accum > 0.004 ) {
			$lines[] = array( 'account' => '1510', 'debit' => $accum, 'memo' => 'Accum. depreciation written off' );
		}
		$lines[] = array( 'account' => '1500', 'credit' => $cost, 'memo' => 'Asset cost removed — ' . $asset->doc_no );
		if ( $diff > 0.004 ) {
			$lines[] = array( 'account' => '4100', 'credit' => $diff, 'memo' => 'Gain on disposal' );
		} elseif ( $diff < -0.004 ) {
			$lines[] = array( 'account' => '5900', 'debit' => -$diff, 'memo' => 'Loss on disposal' );
		}

		$journal = WCEERP_Accounting::post( array(
			'journal_date' => $date,
			'ref_type'     => 'asset_disposal',
			'ref_id'       => $id,
			'memo'         => sprintf( 'Disposal — %s (%s)', $asset->name, $asset->doc_no ),
		), $lines );

		if ( is_wp_error( $journal ) ) {
			wp_die( esc_html( $journal->get_error_message() ) );
		}

		$wpdb->update( wceerp_table( 'assets' ), array(
			'status'          => 'disposed',
			'disposal_date'   => $date,
			'disposal_amount' => $sale,
		), array( 'id' => $id ) );

		wceerp_log( 'assets', 'dispose', $id, $asset->doc_no );
		wp_safe_redirect( $this->admin_url( array( 'updated' => 1 ) ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Screen.
	 * ------------------------------------------------------------------- */

	public function render_page() {
		global $wpdb;
		$table = wceerp_table( 'assets' );

		if ( ! empty( $_GET['updated'] ) ) {
			$this->notice( __( 'Saved.', 'wc-enterprise-erp' ) );
		}
		if ( isset( $_GET['depreciated'] ) ) {
			$this->notice( sprintf(
				__( 'Depreciation posted for %1$d asset(s) — period %2$s.', 'wc-enterprise-erp' ),
				(int) $_GET['depreciated'], sanitize_text_field( $_GET['period'] ?? '' )
			) );
		}

		$per_page = 25;
		$total    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		$rows     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY status='disposed', id DESC LIMIT %d OFFSET %d", $per_page, wceerp_offset( $per_page ) ) );
		$totals   = $wpdb->get_row( "SELECT COALESCE(SUM(purchase_cost),0) AS cost, COALESCE(SUM(accum_depreciation),0) AS accum FROM $table WHERE status <> 'disposed'" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Fixed Assets', 'wc-enterprise-erp' ) ) ); ?></h1>

			<div class="wceerp-kpis">
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Assets at cost', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $totals->cost ) ); ?></strong></div>
				<div class="wceerp-kpi"><span><?php esc_html_e( 'Accumulated depreciation', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $totals->accum ) ); ?></strong></div>
				<div class="wceerp-kpi is-good"><span><?php esc_html_e( 'Net book value', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( (float) $totals->cost - (float) $totals->accum ) ); ?></strong></div>
			</div>

			<div class="wceerp-columns">
				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Register an asset', 'wc-enterprise-erp' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_asset_save">
						<?php wp_nonce_field( 'wceerp_asset_save' ); ?>
						<table class="form-table"><tbody>
							<tr><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="name" class="regular-text" required placeholder="<?php esc_attr_e( 'e.g. Delivery van, Sewing machine', 'wc-enterprise-erp' ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Category', 'wc-enterprise-erp' ); ?></th>
								<td><input type="text" name="category" placeholder="<?php esc_attr_e( 'Vehicle / Machinery / Furniture', 'wc-enterprise-erp' ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Purchase date', 'wc-enterprise-erp' ); ?></th>
								<td><input type="date" name="purchase_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></td></tr>
							<tr><th><?php esc_html_e( 'Cost', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0.01" name="purchase_cost" required></td></tr>
							<tr><th><?php esc_html_e( 'Salvage value', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" step="0.01" min="0" name="salvage_value" value="0"></td></tr>
							<tr><th><?php esc_html_e( 'Useful life (months)', 'wc-enterprise-erp' ); ?></th>
								<td><input type="number" name="useful_life_months" min="1" value="60"></td></tr>
							<tr><th><?php esc_html_e( 'Paid from', 'wc-enterprise-erp' ); ?></th>
								<td><select name="fund_account_id" required>
									<?php foreach ( $this->money_accounts() as $a ) : ?>
										<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code . ' — ' . $a->name ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Choose Accounts Payable if bought on credit.', 'wc-enterprise-erp' ); ?></p></td></tr>
						</tbody></table>
						<?php submit_button( __( 'Register & post purchase', 'wc-enterprise-erp' ) ); ?>
					</form>
				</div>

				<div class="wceerp-card">
					<h2><?php esc_html_e( 'Run depreciation', 'wc-enterprise-erp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Straight-line: (cost − salvage) ÷ life months, posted Dr 5700 / Cr 1510. The daily scheduler posts last month automatically; each asset-month is only ever posted once, so this button is always safe.', 'wc-enterprise-erp' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wceerp_asset_depreciate">
						<?php wp_nonce_field( 'wceerp_asset_depreciate' ); ?>
						<p>
							<input type="month" name="period" value="<?php echo esc_attr( gmdate( 'Y-m', strtotime( 'first day of last month' ) ) ); ?>">
							<button class="button button-primary"><?php esc_html_e( 'Post depreciation for this month', 'wc-enterprise-erp' ); ?></button>
						</p>
					</form>
				</div>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Asset register', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped wceerp-table">
					<thead><tr>
						<th><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Asset', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Purchased', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Cost', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Accum. dep.', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Book value', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Dispose', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="8"><?php esc_html_e( 'No assets yet.', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( (array) $rows as $asset ) :
						$book = (float) $asset->purchase_cost - (float) $asset->accum_depreciation;
						?>
						<tr>
							<td><code><?php echo esc_html( $asset->doc_no ); ?></code></td>
							<td><strong><?php echo esc_html( $asset->name ); ?></strong><br><small><?php echo esc_html( $asset->category ); ?></small></td>
							<td><?php echo esc_html( $asset->purchase_date ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $asset->purchase_cost ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $asset->accum_depreciation ) ); ?></td>
							<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $book ) ); ?></strong></td>
							<td><span class="wceerp-badge is-<?php echo esc_attr( $asset->status ); ?>"><?php echo esc_html( str_replace( '_', ' ', $asset->status ) ); ?></span></td>
							<td>
								<?php if ( 'disposed' !== $asset->status ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;flex-wrap:wrap;align-items:center">
									<input type="hidden" name="action" value="wceerp_asset_dispose">
									<input type="hidden" name="asset_id" value="<?php echo (int) $asset->id; ?>">
									<input type="hidden" name="disposal_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>">
									<?php wp_nonce_field( 'wceerp_asset_dispose' ); ?>
									<input type="number" step="0.01" min="0" name="disposal_amount" placeholder="<?php esc_attr_e( 'Sale ৳', 'wc-enterprise-erp' ); ?>" style="width:90px">
									<select name="account_id">
										<?php foreach ( $this->money_accounts() as $a ) : ?>
											<option value="<?php echo (int) $a->id; ?>"><?php echo esc_html( $a->code ); ?></option>
										<?php endforeach; ?>
									</select>
									<button class="button button-small wceerp-confirm" data-confirm="<?php esc_attr_e( 'Dispose this asset and post the gain/loss?', 'wc-enterprise-erp' ); ?>"><?php esc_html_e( 'Dispose', 'wc-enterprise-erp' ); ?></button>
								</form>
								<?php else : ?>
									<small><?php echo esc_html( $asset->disposal_date ); ?></small>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php wceerp_pagination( $total, $per_page ); ?>
			</div>
		</div>
		<?php
	}
}
