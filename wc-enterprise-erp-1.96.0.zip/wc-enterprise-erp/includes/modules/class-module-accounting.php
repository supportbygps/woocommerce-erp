<?php
/**
 * Module: Accounting — Chart of Accounts, Journal entry & list,
 * General Ledger, Cash Book, Bank Book (incl. bKash/Nagad/Rocket books).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Accounting extends WCEERP_Module {

	protected $id         = 'accounting';
	protected $title      = 'Accounting';
	protected $capability = 'wceerp_manage_accounting';
	protected $tier       = 'business';
	protected $order      = 30;

	public function __construct() {
		$this->title = __( 'Accounting', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_account_save', array( $this, 'handle_account_save' ) );
		add_action( 'admin_post_wceerp_journal_save', array( $this, 'handle_journal_save' ) );
		add_action( 'admin_post_wceerp_journal_void', array( $this, 'handle_journal_void' ) );
	}

	/**
	 * Void a journal from the ledger screen.
	 *
	 * The function this calls has always existed — payout reversal and
	 * expense deletion both use it — but nothing let a shop reach it
	 * directly for an ordinary mis-posting. The only route was a correcting
	 * entry stacked on top, which balances the books but leaves the wrong
	 * line sitting there uncorrected for ever.
	 *
	 * Gated on the same capability as everything else in Accounting —
	 * whoever can post a journal can undo one, and nobody with lesser
	 * access gets a route to erase history from the reports.
	 */
	public function handle_journal_void() {
		$this->verify_nonce( 'wceerp_journal_void' );
		if ( ! wceerp_user_can( $this->capability ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}

		$id     = (int) ( $_POST['journal_id'] ?? 0 );
		$reason = sanitize_text_field( wp_unslash( $_POST['reason'] ?? '' ) );

		/* Wherever the ledger was showing, land back on the same tab and
		 * account — losing that context on every void would be a small
		 * but real annoyance repeated every time this is used. */
		$args = array( 'tab' => 'ledger' );
		foreach ( array( 'account', 'from', 'to' ) as $k ) {
			if ( ! empty( $_POST[ 'back_' . $k ] ) ) {
				$args[ $k ] = sanitize_text_field( wp_unslash( $_POST[ 'back_' . $k ] ) );
			}
		}

		$result = WCEERP_Accounting::void( $id, $reason );

		/* This module reads 'updated' and 'error' on render — the same
		 * keys every other handler here already uses — so matching them
		 * is what makes the message actually appear. */
		if ( is_wp_error( $result ) ) {
			$args['error'] = rawurlencode( $result->get_error_message() );
		} else {
			$args['updated'] = 1;
		}

		wp_safe_redirect( $this->admin_url( $args ) );
		exit;
	}

	public function handle_account_save() {
		$this->verify_nonce( 'wceerp_account_save' );
		global $wpdb;
		$wpdb->insert( wceerp_table( 'accounts' ), array(
			'code'    => sanitize_text_field( $_POST['code'] ),
			'name'    => sanitize_text_field( wp_unslash( $_POST['name'] ) ),
			'type'    => in_array( $_POST['type'], array( 'asset', 'liability', 'equity', 'income', 'expense' ), true ) ? $_POST['type'] : 'expense',
			'subtype' => sanitize_key( $_POST['subtype'] ?? '' ) ?: null,
		) );
		wp_safe_redirect( $this->admin_url( array( 'tab' => 'accounts', 'updated' => 1 ) ) );
		exit;
	}

	public function handle_journal_save() {
		$this->verify_nonce( 'wceerp_journal_save' );

		$accounts = array_map( 'intval', (array) $_POST['line_account'] );
		$debits   = array_map( 'wceerp_dec', (array) $_POST['line_debit'] );
		$credits  = array_map( 'wceerp_dec', (array) $_POST['line_credit'] );
		$memos    = array_map( 'sanitize_text_field', (array) $_POST['line_memo'] );

		$lines = array();
		foreach ( $accounts as $i => $acc ) {
			if ( $acc && ( $debits[ $i ] > 0 || $credits[ $i ] > 0 ) ) {
				$lines[] = array( 'account' => $acc, 'debit' => $debits[ $i ], 'credit' => $credits[ $i ], 'memo' => $memos[ $i ] );
			}
		}

		$result = WCEERP_Accounting::post( array(
			'journal_date' => sanitize_text_field( $_POST['journal_date'] ),
			'ref_type'     => 'manual',
			'memo'         => sanitize_text_field( wp_unslash( $_POST['memo'] ?? '' ) ),
		), $lines );

		$args = is_wp_error( $result )
			? array( 'tab' => 'journal', 'error' => rawurlencode( $result->get_error_message() ) )
			: array( 'tab' => 'journal', 'updated' => 1 );
		wp_safe_redirect( $this->admin_url( $args ) );
		exit;
	}

	/* ------------------------------------------------------------------ */

	public function render_page() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'journal';
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Accounting', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Saved.', 'wc-enterprise-erp' ) ); ?>
			<?php if ( isset( $_GET['error'] ) ) $this->notice( sanitize_text_field( rawurldecode( $_GET['error'] ) ), 'error' ); ?>

			<nav class="nav-tab-wrapper">
				<?php
				foreach ( array(
					'journal'  => __( 'Journal', 'wc-enterprise-erp' ),
					'ledger'   => __( 'General ledger', 'wc-enterprise-erp' ),
					'cashbook' => __( 'Cash book', 'wc-enterprise-erp' ),
					'bankbook' => __( 'Bank book', 'wc-enterprise-erp' ),
					'accounts' => __( 'Chart of accounts', 'wc-enterprise-erp' ),
				) as $key => $label ) {
					printf(
						'<a class="nav-tab %s" href="%s">%s</a>',
						$tab === $key ? 'nav-tab-active' : '',
						esc_url( $this->admin_url( array( 'tab' => $key ) ) ),
						esc_html( $label )
					);
				}
				?>
			</nav>

			<?php
			if ( 'journal' === $tab )  $this->tab_journal();
			if ( 'ledger' === $tab )   $this->tab_ledger();
			if ( 'cashbook' === $tab ) $this->tab_money_book( 'cash', __( 'Cash book', 'wc-enterprise-erp' ) );
			if ( 'bankbook' === $tab ) $this->tab_money_book( 'bank', __( 'Bank book', 'wc-enterprise-erp' ) );
			if ( 'accounts' === $tab ) $this->tab_accounts();
			?>
		</div>
		<?php
	}

	protected function tab_journal() {
		global $wpdb;
		$accounts = WCEERP_Accounting::accounts();
		$per_page = 25;
		$total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wceerp_table( 'journals' ) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			'SELECT j.*, SUM(l.debit) AS total FROM ' . wceerp_table( 'journals' ) . ' j
			 LEFT JOIN ' . wceerp_table( 'journal_lines' ) . ' l ON l.journal_id = j.id
			 GROUP BY j.id ORDER BY j.id DESC LIMIT %d OFFSET %d', $per_page, wceerp_offset( $per_page )
		) );
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'New journal voucher', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_journal_save">
					<?php wp_nonce_field( 'wceerp_journal_save' ); ?>
					<p><label><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?> <input type="date" name="journal_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></label>
					<label><?php esc_html_e( 'Memo', 'wc-enterprise-erp' ); ?> <input type="text" name="memo" class="regular-text"></label></p>
					<table class="widefat wceerp-items" id="wceerp-jv-lines">
						<thead><tr><th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th><th>Dr</th><th>Cr</th><th><?php esc_html_e( 'Line memo', 'wc-enterprise-erp' ); ?></th><th></th></tr></thead>
						<tbody>
							<?php for ( $i = 0; $i < 2; $i++ ) : ?>
							<tr>
								<td><select name="line_account[]">
									<option value=""><?php esc_html_e( '— account —', 'wc-enterprise-erp' ); ?></option>
									<?php foreach ( $accounts as $a ) printf( '<option value="%d">%s — %s</option>', (int) $a->id, esc_html( $a->code ), esc_html( $a->name ) ); ?>
								</select></td>
								<td><input type="number" name="line_debit[]" step="0.01" min="0" value="0"></td>
								<td><input type="number" name="line_credit[]" step="0.01" min="0" value="0"></td>
								<td><input type="text" name="line_memo[]"></td>
								<td></td>
							</tr>
							<?php endfor; ?>
						</tbody>
					</table>
					<p><button type="button" class="button" id="wceerp-add-row"><?php esc_html_e( '+ Add line', 'wc-enterprise-erp' ); ?></button></p>
					<?php submit_button( __( 'Post journal', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>

			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Recent journals', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Voucher', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Source', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Memo', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( (array) $rows as $j ) : ?>
						<tr>
							<td><code><?php echo esc_html( $j->doc_no ); ?></code></td>
							<td><?php echo esc_html( $j->journal_date ); ?></td>
							<td><?php echo esc_html( $j->ref_type . ( $j->ref_id ? ' #' . $j->ref_id : '' ) ); ?></td>
							<td><?php echo esc_html( $j->memo ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $j->total ) ); ?></td>
							<td><?php echo esc_html( $j->status ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php wceerp_pagination( $total, $per_page ); ?>
			</div>
		</div>
		<?php
	}

	protected function tab_ledger() {
		$accounts = WCEERP_Accounting::accounts();
		$fy       = wceerp_fiscal_year();
		$acc_id   = isset( $_GET['account'] ) ? (int) $_GET['account'] : ( $accounts ? (int) $accounts[0]->id : 0 );
		$from     = isset( $_GET['from'] ) ? sanitize_text_field( $_GET['from'] ) : $fy['start'];
		$to       = isset( $_GET['to'] ) ? sanitize_text_field( $_GET['to'] ) : $fy['end'];
		?>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-accounting"><input type="hidden" name="tab" value="ledger">
			<select name="account">
				<?php foreach ( $accounts as $a ) printf( '<option value="%d" %s>%s — %s</option>', (int) $a->id, selected( $acc_id, $a->id, false ), esc_html( $a->code ), esc_html( $a->name ) ); ?>
			</select>
			<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"> — <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>">
			<button class="button"><?php esc_html_e( 'View ledger', 'wc-enterprise-erp' ); ?></button>
		</form>
		<?php
		$this->ledger_table( $acc_id, $from, $to );
	}

	/**
	 * Cash book / bank book = ledgers of the money accounts of a subtype,
	 * including mobile banking channels for Bangladesh in the bank book.
	 */
	protected function tab_money_book( $kind, $title ) {
		global $wpdb;
		$table = wceerp_table( 'accounts' );
		$fy    = wceerp_fiscal_year();
		$from  = isset( $_GET['from'] ) ? sanitize_text_field( $_GET['from'] ) : $fy['start'];
		$to    = isset( $_GET['to'] ) ? sanitize_text_field( $_GET['to'] ) : $fy['end'];

		$subtypes = 'cash' === $kind ? array( 'cash' ) : array( 'bank', 'mobile_banking' );
		$in       = "'" . implode( "','", array_map( 'esc_sql', $subtypes ) ) . "'";
		$accounts = $wpdb->get_results( "SELECT * FROM $table WHERE subtype IN ($in) AND status='active' ORDER BY code" );

		$acc_id = isset( $_GET['account'] ) ? (int) $_GET['account'] : ( $accounts ? (int) $accounts[0]->id : 0 );
		?>
		<h2><?php echo esc_html( $title ); ?></h2>
		<form method="get" class="wceerp-filter">
			<input type="hidden" name="page" value="wceerp-accounting"><input type="hidden" name="tab" value="<?php echo esc_attr( 'cash' === $kind ? 'cashbook' : 'bankbook' ); ?>">
			<select name="account">
				<?php foreach ( $accounts as $a ) printf( '<option value="%d" %s>%s — %s</option>', (int) $a->id, selected( $acc_id, $a->id, false ), esc_html( $a->code ), esc_html( $a->name ) ); ?>
			</select>
			<input type="date" name="from" value="<?php echo esc_attr( $from ); ?>"> — <input type="date" name="to" value="<?php echo esc_attr( $to ); ?>">
			<button class="button"><?php esc_html_e( 'View book', 'wc-enterprise-erp' ); ?></button>
		</form>
		<?php
		$this->ledger_table( $acc_id, $from, $to, true );
	}

	protected function ledger_table( $acc_id, $from, $to, $money_book = false ) {
		if ( ! $acc_id ) {
			return;
		}
		$opening = WCEERP_Accounting::opening_balance( $acc_id, $from );
		$rows    = WCEERP_Accounting::ledger( $acc_id, $from, $to );
		$running = $opening;
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Voucher', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Particulars', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Source', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php echo $money_book ? esc_html__( 'Receipt (Dr)', 'wc-enterprise-erp' ) : 'Dr'; ?></th>
				<th class="num"><?php echo $money_book ? esc_html__( 'Payment (Cr)', 'wc-enterprise-erp' ) : 'Cr'; ?></th>
				<th class="num"><?php esc_html_e( 'Balance', 'wc-enterprise-erp' ); ?></th>
				<th></th>
			</tr></thead>
			<tbody>
				<tr><td colspan="5"><em><?php esc_html_e( 'Opening balance', 'wc-enterprise-erp' ); ?></em></td><td class="num"><?php echo wp_kses_post( wceerp_money( $running ) ); ?></td></tr>
				<?php foreach ( $rows as $r ) : $running += $r->debit - $r->credit; ?>
					<tr>
						<td><?php echo esc_html( $r->journal_date ); ?></td>
						<td><code><?php echo esc_html( $r->doc_no ); ?></code></td>
						<td><?php echo esc_html( $r->memo ?: $r->jmemo ); ?></td>
						<td>
							<?php
							/* What created this entry. Without it a figure in
							 * an account like Miscellaneous is impossible to
							 * explain — which is exactly when someone needs
							 * to explain it. */
							$sources = array(
								'wc_order'         => __( 'Online order', 'wc-enterprise-erp' ),
								'pos'              => __( 'POS sale', 'wc-enterprise-erp' ),
								'pos_shift'        => __( 'POS shift close', 'wc-enterprise-erp' ),
								'pos_refund'       => __( 'POS refund', 'wc-enterprise-erp' ),
								'expense'          => __( 'Expense', 'wc-enterprise-erp' ),
								'purchase'         => __( 'Purchase', 'wc-enterprise-erp' ),
								'stock_adjustment' => __( 'Stock adjustment', 'wc-enterprise-erp' ),
								'courier_payout'   => __( 'Courier payout', 'wc-enterprise-erp' ),
								'opening'          => __( 'Opening balance', 'wc-enterprise-erp' ),
								'asset_disposal'   => __( 'Asset disposal', 'wc-enterprise-erp' ),
								'payment'          => __( 'Payment received', 'wc-enterprise-erp' ),
								'manual'           => __( 'Manual journal', 'wc-enterprise-erp' ),
							);
							$label = $sources[ $r->ref_type ] ?? ( $r->ref_type ?: __( 'unknown', 'wc-enterprise-erp' ) );
							echo '<span class="wceerp-badge">' . esc_html( $label ) . '</span>';
							if ( $r->ref_id ) {
								echo ' <small>#' . (int) $r->ref_id . '</small>';
							}
							?>
						</td>
						<td class="num"><?php echo $r->debit > 0 ? wp_kses_post( wceerp_money( $r->debit ) ) : '—'; ?></td>
						<td class="num"><?php echo $r->credit > 0 ? wp_kses_post( wceerp_money( $r->credit ) ) : '—'; ?></td>
						<td class="num"><?php echo wp_kses_post( wceerp_money( $running ) ); ?></td>
						<td>
							<?php if ( wceerp_user_can( $this->capability ) && ! empty( $r->journal_id ) ) : ?>
								<button type="button" class="button-link wceerp-void-link"
									data-id="<?php echo (int) $r->journal_id; ?>"
									data-doc="<?php echo esc_attr( $r->doc_no ); ?>"
									style="color:#C0392B;font-size:12px"><?php esc_html_e( 'Void', 'wc-enterprise-erp' ); ?></button>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<?php
			/* Requiring a reason in the dialog rather than in the form field
			 * itself: a native browser confirm cannot collect text, and a
			 * void with no reason is a mystery the day this ledger is next
			 * opened — the one thing worth insisting on before it goes. */
			?>
			<script>
			(function () {
				document.querySelectorAll( '.wceerp-void-link' ).forEach( function ( btn ) {
					btn.addEventListener( 'click', function () {
						var reason = prompt(
							<?php echo wp_json_encode( __( 'Why is this journal being voided? This is kept with the void, and is the only thing that will explain it later.', 'wc-enterprise-erp' ) ); ?>
							+ ' (' + btn.dataset.doc + ')'
						);
						if ( reason === null ) { return; }
						reason = reason.trim();
						if ( ! reason ) {
							alert( <?php echo wp_json_encode( __( 'A reason is required.', 'wc-enterprise-erp' ) ); ?> );
							return;
						}
						if ( ! confirm( <?php echo wp_json_encode( __( 'Void this journal? It stays in the audit trail and comes out of every report immediately. This cannot be undone from here.', 'wc-enterprise-erp' ) ); ?> ) ) {
							return;
						}

						var f = document.createElement( 'form' );
						f.method = 'post';
						f.action = <?php echo wp_json_encode( admin_url( 'admin-post.php' ) ); ?>;
						[
							[ 'action', 'wceerp_journal_void' ],
							[ '_wpnonce', <?php echo wp_json_encode( wp_create_nonce( 'wceerp_journal_void' ) ); ?> ],
							[ 'journal_id', btn.dataset.id ],
							[ 'reason', reason ],
							[ 'back_account', <?php echo wp_json_encode( (string) $acc_id ); ?> ],
							[ 'back_from', <?php echo wp_json_encode( (string) $from ); ?> ],
							[ 'back_to', <?php echo wp_json_encode( (string) $to ); ?> ]
						].forEach( function ( pair ) {
							var i = document.createElement( 'input' );
							i.type = 'hidden'; i.name = pair[0]; i.value = pair[1];
							f.appendChild( i );
						} );
						document.body.appendChild( f );
						f.submit();
					} );
				} );
			})();
			</script>
			<tfoot><tr><th colspan="7" class="num"><?php esc_html_e( 'Closing balance', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $running ) ); ?></th></tr></tfoot>
		</table>
		<?php
	}

	protected function tab_accounts() {
		$accounts = WCEERP_Accounting::accounts();
		?>
		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Add account', 'wc-enterprise-erp' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_account_save">
					<?php wp_nonce_field( 'wceerp_account_save' ); ?>
					<p><label><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?><br><input type="text" name="code" required placeholder="5150"></label></p>
					<p><label><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?><br><input type="text" name="name" required class="regular-text"></label></p>
					<p><label><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?><br>
						<select name="type">
							<?php foreach ( array( 'asset', 'liability', 'equity', 'income', 'expense' ) as $t ) printf( '<option value="%s">%s</option>', esc_attr( $t ), esc_html( ucfirst( $t ) ) ); ?>
						</select></label></p>
					<p><label><?php esc_html_e( 'Subtype (optional)', 'wc-enterprise-erp' ); ?><br><input type="text" name="subtype" placeholder="bank, cash, mobile_banking…"></label></p>
					<?php submit_button( __( 'Add account', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
			<div class="wceerp-card">
				<h2><?php esc_html_e( 'Chart of accounts', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Code', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Name', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Type', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Subtype', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $accounts as $a ) : ?>
						<tr><td><code><?php echo esc_html( $a->code ); ?></code></td><td><?php echo esc_html( $a->name ); ?></td><td><?php echo esc_html( ucfirst( $a->type ) ); ?></td><td><?php echo esc_html( $a->subtype ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
}
