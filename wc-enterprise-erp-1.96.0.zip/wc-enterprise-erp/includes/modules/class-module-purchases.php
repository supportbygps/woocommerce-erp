<?php
/**
 * Module: Purchase Management.
 *
 * Flow: create PO (draft/ordered) → receive → stock in at cost, batch
 * created (if batch number given), journal posted:
 *   Dr Inventory (net) + Dr VAT Input (rebateable) / Cr Accounts Payable.
 * Payments against the PO settle supplier due through the Dues module.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Purchases extends WCEERP_Module {

	protected $id         = 'purchases';
	protected $title      = 'Purchases';
	protected $capability = 'wceerp_manage_purchases';
	protected $tier       = 'starter';
	protected $order      = 25;

	public function __construct() {
		$this->title = __( 'Purchases', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_purchase_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wceerp_purchase_receive', array( $this, 'handle_receive' ) );
	}

	/* ------------------------------------------------------------------ */

	public function handle_save() {
		$this->verify_nonce( 'wceerp_purchase_save' );
		global $wpdb;

		$supplier  = (int) $_POST['supplier_id'];
		$warehouse = (int) $_POST['warehouse_id'];
		$date      = sanitize_text_field( $_POST['purchase_date'] );
		$products  = array_map( 'intval', (array) ( $_POST['item_product'] ?? array() ) );
		$qtys      = array_map( 'wceerp_dec', (array) ( $_POST['item_qty'] ?? array() ) );
		$costs     = array_map( 'wceerp_dec', (array) ( $_POST['item_cost'] ?? array() ) );
		$taxes     = array_map( 'wceerp_dec', (array) ( $_POST['item_tax'] ?? array() ) );
		$batches   = array_map( 'sanitize_text_field', (array) ( $_POST['item_batch'] ?? array() ) );
		$expiries  = array_map( 'sanitize_text_field', (array) ( $_POST['item_exp'] ?? array() ) );

		$subtotal = 0;
		$tax      = 0;
		$items    = array();
		foreach ( $products as $i => $pid ) {
			if ( ! $pid || $qtys[ $i ] <= 0 ) {
				continue;
			}
			$line      = $qtys[ $i ] * $costs[ $i ];
			$line_tax  = $line * ( $taxes[ $i ] / 100 );
			$subtotal += $line;
			$tax      += $line_tax;
			$items[]   = array(
				'product_id' => $pid,
				'qty'        => $qtys[ $i ],
				'unit_cost'  => $costs[ $i ],
				'tax_rate'   => $taxes[ $i ],
				'line_total' => $line + $line_tax,
				'batch_no'   => $batches[ $i ] ?? '',
				'exp_date'   => ! empty( $expiries[ $i ] ) ? $expiries[ $i ] : null,
			);
		}

		if ( ! $supplier || ! $warehouse || ! $items ) {
			wp_safe_redirect( $this->admin_url( array( 'tab' => 'new', 'error' => 'incomplete' ) ) );
			exit;
		}

		$discount = wceerp_dec( $_POST['discount'] ?? 0 );
		$shipping = wceerp_dec( $_POST['shipping'] ?? 0 );

		$wpdb->insert( wceerp_table( 'purchases' ), array(
			'doc_no'        => wceerp_next_doc_number( 'po' ),
			'supplier_id'   => $supplier,
			'warehouse_id'  => $warehouse,
			'status'        => 'ordered',
			'subtotal'      => $subtotal,
			'tax_total'     => $tax,
			'discount'      => $discount,
			'shipping'      => $shipping,
			'grand_total'   => $subtotal + $tax + $shipping - $discount,
			'purchase_date' => $date,
			'note'          => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'created_by'    => get_current_user_id(),
			'created_at'    => current_time( 'mysql' ),
		) );
		$purchase_id = (int) $wpdb->insert_id;

		foreach ( $items as $item ) {
			$item['purchase_id'] = $purchase_id;
			$wpdb->insert( wceerp_table( 'purchase_items' ), $item );
		}

		if ( class_exists( 'WCEERP_Module_Procurement' ) ) {
			WCEERP_Module_Procurement::after_po_created( $purchase_id );
		}

		wceerp_log( 'purchases', 'create', $purchase_id );
		wp_safe_redirect( $this->admin_url( array( 'view' => $purchase_id, 'updated' => 1 ) ) );
		exit;
	}

	/**
	 * Receive a PO fully or partially. Per-line "receive now" quantities
	 * come from the detail screen; each receipt stocks in at cost and posts
	 * a journal for the received portion only. Shipping and discount are
	 * allocated proportionally to the received value, so multiple partial
	 * receipts sum exactly to the PO grand total.
	 */
	public function handle_receive() {
		$this->verify_nonce( 'wceerp_purchase_receive' );
		global $wpdb;

		$id       = (int) $_POST['purchase_id'];
		$purchase = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'purchases' ) . ' WHERE id=%d', $id ) );
		if ( ! $purchase || in_array( $purchase->status, array( 'received', 'cancelled' ), true ) ) {
			wp_safe_redirect( $this->admin_url() );
			exit;
		}

		/* Approval gate: a PO above the configured thresholds cannot be
		 * received until every approval level has signed off. */
		if ( isset( $purchase->approval_status ) && in_array( $purchase->approval_status, array( 'pending', 'rejected' ), true ) ) {
			wp_safe_redirect( $this->admin_url( array( 'view' => $id, 'error' => 'approval' ) ) );
			exit;
		}

		$items    = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'purchase_items' ) . ' WHERE purchase_id=%d', $id ) );
		$requested = isset( $_POST['receive_qty'] ) ? (array) $_POST['receive_qty'] : array();

		$received_net = 0; // value of goods received this time (ex VAT).
		$received_vat = 0;
		$any          = false;

		foreach ( $items as $item ) {
			$remaining = (float) $item->qty - (float) $item->received_qty;
			if ( $remaining <= 0 ) {
				continue;
			}

			// Default (button without per-line inputs) = receive everything remaining.
			$now = array_key_exists( $item->id, $requested ) ? wceerp_dec( $requested[ $item->id ] ) : $remaining;
			$now = min( $remaining, max( 0, $now ) );
			if ( $now <= 0 ) {
				continue;
			}
			$any = true;

			$batch_id = null;
			if ( $item->batch_no ) {
				$wpdb->insert( wceerp_table( 'batches' ), array(
					'product_id'   => $item->product_id,
					'warehouse_id' => $purchase->warehouse_id,
					'batch_no'     => $item->batch_no,
					'exp_date'     => $item->exp_date,
					'qty'          => $now,
					'unit_cost'    => $item->unit_cost,
					'created_at'   => current_time( 'mysql' ),
				) );
				$batch_id = $wpdb->insert_id;
			}

			WCEERP_Module_Inventory::move_stock(
				$item->product_id, $purchase->warehouse_id, $now,
				'in', 'purchase', $id, (float) $item->unit_cost, $batch_id
			);

			$wpdb->update(
				wceerp_table( 'purchase_items' ),
				array( 'received_qty' => (float) $item->received_qty + $now ),
				array( 'id' => $item->id )
			);

			$line_net      = $now * (float) $item->unit_cost;
			$received_net += $line_net;
			$received_vat += $line_net * ( (float) $item->tax_rate / 100 );
		}

		if ( ! $any ) {
			wp_safe_redirect( $this->admin_url( array( 'view' => $id, 'error' => 'nothing' ) ) );
			exit;
		}

		/* Allocate shipping/discount proportionally to the received fraction. */
		$fraction  = (float) $purchase->subtotal > 0 ? $received_net / (float) $purchase->subtotal : 1;
		$extras    = ( (float) $purchase->shipping - (float) $purchase->discount ) * $fraction;
		$net_total = round( $received_net + $extras, 2 );
		$vat_total = round( $received_vat, 2 );

		/* Journal: Dr Inventory (net) + Dr VAT input / Cr AP for this receipt. */
		$inv       = WCEERP_Accounting::account_by_subtype( 'inventory' );
		$vat_input = WCEERP_Accounting::resolve_account( '1300' );
		$ap        = WCEERP_Accounting::account_by_subtype( 'payable' );

		$lines = array(
			array( 'account' => $inv->id, 'debit' => $net_total, 'memo' => 'Goods received — ' . $purchase->doc_no ),
		);
		if ( $vat_total > 0 && $vat_input ) {
			$lines[] = array( 'account' => $vat_input, 'debit' => $vat_total, 'memo' => 'VAT input — ' . $purchase->doc_no );
		}
		$lines[] = array(
			'account'    => $ap->id,
			'credit'     => $net_total + $vat_total,
			'party_type' => 'supplier',
			'party_id'   => (int) $purchase->supplier_id,
			'memo'       => 'Payable — ' . $purchase->doc_no,
		);

		WCEERP_Accounting::post( array(
			'journal_date' => current_time( 'Y-m-d' ),
			'ref_type'     => 'purchase',
			'ref_id'       => $id,
			'memo'         => 'Goods receipt ' . $purchase->doc_no,
		), $lines );

		/* Status: received when every line is complete, otherwise partial. */
		$outstanding = (float) $wpdb->get_var( $wpdb->prepare(
			'SELECT COALESCE(SUM(qty - received_qty),0) FROM ' . wceerp_table( 'purchase_items' ) . ' WHERE purchase_id=%d', $id
		) );
		$status = $outstanding <= 0.0001 ? 'received' : 'partial';
		$wpdb->update( wceerp_table( 'purchases' ), array( 'status' => $status ), array( 'id' => $id ) );
		wceerp_log( 'purchases', 'receive', $id, $status );

		if ( class_exists( 'WCEERP_Module_Notifications' ) ) {
			WCEERP_Module_Notifications::add(
				'purchase_received',
				sprintf(
					/* translators: 1: PO number 2: status */
					__( 'Purchase %1$s %2$s', 'wc-enterprise-erp' ),
					$purchase->doc_no,
					'received' === $status ? __( 'fully received', 'wc-enterprise-erp' ) : __( 'partially received', 'wc-enterprise-erp' )
				),
				sprintf( __( 'Stock added. Supplier due increased by %s.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $net_total + $vat_total ) ) ),
				$this->admin_url( array( 'view' => $id ) )
			);
		}

		wp_safe_redirect( $this->admin_url( array( 'view' => $id, 'updated' => 1 ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */

	public function render_page() {
		if ( isset( $_GET['view'] ) ) {
			$this->render_view( (int) $_GET['view'] );
			return;
		}
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'list';
		?>
		<div class="wrap wceerp-wrap">
			<h1>
				<?php esc_html_e( 'Purchases', 'wc-enterprise-erp' ); ?>
				<a href="<?php echo esc_url( $this->admin_url( array( 'tab' => 'new' ) ) ); ?>" class="page-title-action"><?php esc_html_e( 'New purchase', 'wc-enterprise-erp' ); ?></a>
			</h1>
			<?php if ( isset( $_GET['error'] ) ) $this->notice( __( 'Please choose a supplier, warehouse and at least one item.', 'wc-enterprise-erp' ), 'error' ); ?>
			<?php 'new' === $tab ? $this->render_form() : $this->render_list(); ?>
		</div>
		<?php
	}

	protected function render_list() {
		global $wpdb;
		$per_page = 25;
		$total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wceerp_table( 'purchases' ) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			'SELECT p.*, s.name AS supplier, w.name AS warehouse
			 FROM ' . wceerp_table( 'purchases' ) . ' p
			 LEFT JOIN ' . wceerp_table( 'suppliers' ) . ' s ON s.id = p.supplier_id
			 LEFT JOIN ' . wceerp_table( 'warehouses' ) . ' w ON w.id = p.warehouse_id
			 ORDER BY p.id DESC LIMIT %d OFFSET %d',
			$per_page, wceerp_offset( $per_page )
		) );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'PO no.', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Warehouse', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Status', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( (array) $rows as $r ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( $this->admin_url( array( 'view' => $r->id ) ) ); ?>"><code><?php echo esc_html( $r->doc_no ); ?></code></a></td>
					<td><?php echo esc_html( $r->purchase_date ); ?></td>
					<td><?php echo esc_html( $r->supplier ); ?></td>
					<td><?php echo esc_html( $r->warehouse ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $r->grand_total ) ); ?></td>
					<td><span class="wceerp-badge is-<?php echo esc_attr( $r->status ); ?>"><?php echo esc_html( ucfirst( $r->status ) ); ?></span></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}

	protected function render_form() {
		global $wpdb;
		$suppliers  = $wpdb->get_results( 'SELECT id, name, company FROM ' . wceerp_table( 'suppliers' ) . " WHERE status='active' ORDER BY name" );
		$warehouses = $wpdb->get_results( 'SELECT id, name FROM ' . wceerp_table( 'warehouses' ) . " WHERE status='active' ORDER BY name" );
		$vat        = esc_attr( wceerp_get_option( 'default_vat_rate', '15' ) );
		?>
		<div class="wceerp-card">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wceerp_purchase_save">
				<?php wp_nonce_field( 'wceerp_purchase_save' ); ?>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Supplier', 'wc-enterprise-erp' ); ?></th>
						<td><select name="supplier_id" required>
							<option value=""><?php esc_html_e( '— choose —', 'wc-enterprise-erp' ); ?></option>
							<?php foreach ( $suppliers as $s ) printf( '<option value="%d">%s</option>', (int) $s->id, esc_html( $s->name . ( $s->company ? " ({$s->company})" : '' ) ) ); ?>
						</select></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Receive into warehouse', 'wc-enterprise-erp' ); ?></th>
						<td><select name="warehouse_id"><?php foreach ( $warehouses as $w ) printf( '<option value="%d">%s</option>', (int) $w->id, esc_html( $w->name ) ); ?></select></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Purchase date', 'wc-enterprise-erp' ); ?></th>
						<td><input type="date" name="purchase_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>" required></td>
					</tr>
				</table>

				<h3><?php esc_html_e( 'Items', 'wc-enterprise-erp' ); ?></h3>
				<table class="widefat wceerp-items" id="wceerp-po-items">
					<thead><tr>
						<th style="width:32%"><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Unit cost', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'VAT %', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Batch no.', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Expiry', 'wc-enterprise-erp' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
						<tr>
							<td><?php wceerp_product_select( 'item_product[]' ); ?></td>
							<td><input type="number" name="item_qty[]" step="0.01" min="0"></td>
							<td><input type="number" name="item_cost[]" step="0.0001" min="0"></td>
							<td><input type="number" name="item_tax[]" step="0.01" min="0" value="<?php echo $vat; ?>"></td>
							<td><input type="text" name="item_batch[]" placeholder="<?php esc_attr_e( 'optional', 'wc-enterprise-erp' ); ?>"></td>
							<td><input type="date" name="item_exp[]"></td>
							<td></td>
						</tr>
					</tbody>
				</table>
				<p><button type="button" class="button" id="wceerp-add-row"><?php esc_html_e( '+ Add item', 'wc-enterprise-erp' ); ?></button></p>

				<table class="form-table">
					<tr><th><?php esc_html_e( 'Discount', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0" name="discount" value="0"></td></tr>
					<tr><th><?php esc_html_e( 'Shipping / carrying cost', 'wc-enterprise-erp' ); ?></th><td><input type="number" step="0.01" min="0" name="shipping" value="0"></td></tr>
					<tr><th><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?></th><td><textarea name="note" class="large-text" rows="2"></textarea></td></tr>
				</table>
				<?php submit_button( __( 'Create purchase order', 'wc-enterprise-erp' ) ); ?>
			</form>
		</div>
		<?php
	}

	protected function render_view( $id ) {
		global $wpdb;
		$p = $wpdb->get_row( $wpdb->prepare(
			'SELECT p.*, s.name AS supplier, w.name AS warehouse FROM ' . wceerp_table( 'purchases' ) . ' p
			 LEFT JOIN ' . wceerp_table( 'suppliers' ) . ' s ON s.id=p.supplier_id
			 LEFT JOIN ' . wceerp_table( 'warehouses' ) . ' w ON w.id=p.warehouse_id
			 WHERE p.id=%d', $id
		) );
		if ( ! $p ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Purchase not found.', 'wc-enterprise-erp' ) . '</p></div>';
			return;
		}
		$items = $wpdb->get_results( $wpdb->prepare(
			'SELECT i.*, po.post_title AS product FROM ' . wceerp_table( 'purchase_items' ) . ' i
			 LEFT JOIN ' . $wpdb->posts . ' po ON po.ID = i.product_id WHERE i.purchase_id=%d', $id
		) );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo esc_html( $p->doc_no ); ?> <span class="wceerp-badge is-<?php echo esc_attr( $p->status ); ?>"><?php echo esc_html( ucfirst( $p->status ) ); ?></span></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Purchase updated.', 'wc-enterprise-erp' ) ); ?>
			<p><a href="<?php echo esc_url( $this->admin_url() ); ?>">&larr; <?php esc_html_e( 'All purchases', 'wc-enterprise-erp' ); ?></a></p>

			<div class="wceerp-card">
				<p>
					<strong><?php esc_html_e( 'Supplier:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $p->supplier ); ?> ·
					<strong><?php esc_html_e( 'Warehouse:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $p->warehouse ); ?> ·
					<strong><?php esc_html_e( 'Date:', 'wc-enterprise-erp' ); ?></strong> <?php echo esc_html( $p->purchase_date ); ?>
				</p>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Received', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Cost', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'VAT %', 'wc-enterprise-erp' ); ?></th><th><?php esc_html_e( 'Batch', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Line total', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $items as $i ) : ?>
						<tr>
							<td><?php echo esc_html( $i->product ?: '#' . $i->product_id ); ?></td>
							<td class="num"><?php echo esc_html( wc_format_decimal( $i->qty, 2 ) ); ?></td>
							<td class="num"><?php echo esc_html( wc_format_decimal( $i->received_qty, 2 ) ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $i->unit_cost ) ); ?></td>
							<td class="num"><?php echo esc_html( $i->tax_rate ); ?></td>
							<td><?php echo esc_html( $i->batch_no ); ?></td>
							<td class="num"><?php echo wp_kses_post( wceerp_money( $i->line_total ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot>
						<tr><th colspan="6" class="num"><?php esc_html_e( 'Subtotal', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $p->subtotal ) ); ?></th></tr>
						<tr><th colspan="6" class="num"><?php esc_html_e( 'VAT', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $p->tax_total ) ); ?></th></tr>
						<tr><th colspan="6" class="num"><?php esc_html_e( 'Shipping − Discount', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $p->shipping - $p->discount ) ); ?></th></tr>
						<tr><th colspan="6" class="num"><?php esc_html_e( 'Grand total', 'wc-enterprise-erp' ); ?></th><th class="num"><strong><?php echo wp_kses_post( wceerp_money( $p->grand_total ) ); ?></strong></th></tr>
					</tfoot>
				</table>

				<?php if ( ! in_array( $p->status, array( 'received', 'cancelled' ), true ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
						<input type="hidden" name="action" value="wceerp_purchase_receive">
						<input type="hidden" name="purchase_id" value="<?php echo (int) $p->id; ?>">
						<?php wp_nonce_field( 'wceerp_purchase_receive' ); ?>

						<h3><?php esc_html_e( 'Receive goods', 'wc-enterprise-erp' ); ?></h3>
						<p class="description"><?php esc_html_e( 'Adjust the quantities to receive a partial delivery — the rest stays outstanding and can be received later. Each receipt stocks in and posts to the books for the received portion only.', 'wc-enterprise-erp' ); ?></p>
						<table class="widefat striped wceerp-table" style="max-width:640px">
							<thead><tr>
								<th><?php esc_html_e( 'Product', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Outstanding', 'wc-enterprise-erp' ); ?></th>
								<th class="num"><?php esc_html_e( 'Receive now', 'wc-enterprise-erp' ); ?></th>
							</tr></thead>
							<tbody>
							<?php foreach ( $items as $i ) :
								$remaining = (float) $i->qty - (float) $i->received_qty;
								if ( $remaining <= 0 ) {
									continue;
								}
								?>
								<tr>
									<td><?php echo esc_html( $i->product ?: '#' . $i->product_id ); ?></td>
									<td class="num"><?php echo esc_html( wc_format_decimal( $remaining, 2 ) ); ?></td>
									<td class="num"><input type="number" name="receive_qty[<?php echo (int) $i->id; ?>]" step="0.01" min="0" max="<?php echo esc_attr( $remaining ); ?>" value="<?php echo esc_attr( $remaining ); ?>" style="width:110px"></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
						<?php submit_button( __( 'Receive (stock in + post to books)', 'wc-enterprise-erp' ), 'primary', 'submit', false ); ?>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
