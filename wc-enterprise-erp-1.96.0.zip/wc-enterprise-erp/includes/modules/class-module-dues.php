<?php
/**
 * Module: Dues — Customer Due (receivable) and Supplier Due (payable),
 * with a payment form that supports cash, bank, cheque, bKash, Nagad,
 * Rocket and card. Payments post straight to the ledger.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Module_Dues extends WCEERP_Module {

	protected $id         = 'dues';
	protected $title      = 'Dues & Payments';
	protected $capability = 'wceerp_manage_payments';
	protected $tier       = 'starter';
	protected $order      = 35;

	public function __construct() {
		$this->title = __( 'Dues & Payments', 'wc-enterprise-erp' );
	}

	public function init() {
		add_action( 'admin_post_wceerp_payment_save', array( $this, 'handle_payment' ) );
	}

	public static function methods() {
		return apply_filters( 'wceerp_payment_methods', array(
			'cash'   => __( 'Cash', 'wc-enterprise-erp' ),
			'bank'   => __( 'Bank transfer', 'wc-enterprise-erp' ),
			'cheque' => __( 'Cheque', 'wc-enterprise-erp' ),
			'bkash'  => __( 'bKash', 'wc-enterprise-erp' ),
			'nagad'  => __( 'Nagad', 'wc-enterprise-erp' ),
			'rocket' => __( 'Rocket', 'wc-enterprise-erp' ),
			'card'   => __( 'Card', 'wc-enterprise-erp' ),
		) );
	}

	public function handle_payment() {
		$this->verify_nonce( 'wceerp_payment_save' );

		$party_type = sanitize_key( $_POST['party_type'] );
		$party_id   = (int) $_POST['party_id'];
		$amount     = wceerp_dec( $_POST['amount'] );
		$direction  = 'out' === $_POST['direction'] ? 'out' : 'in';

		/* Refuse to take more than is owed.
		 *
		 * Per-order payments have always checked this; payments taken
		 * against a party never did, so this form would credit a receivable
		 * with nothing outstanding and drive the balance negative. That is
		 * how a customer ends up "owing" minus several lakh: not a display
		 * fault, but money credited against a debt that was not there.
		 *
		 * The check is a ceiling, not an exact match — a part payment is
		 * perfectly normal and still allowed. */
		$subtype = ( 'supplier' === $party_type ) ? 'payable' : 'receivable';
		$account = WCEERP_Accounting::account_by_subtype( $subtype );

		if ( $account && $amount > 0 ) {
			$balance = 0.0;
			foreach ( (array) WCEERP_Accounting::party_balances( $party_type, $subtype ) as $b ) {
				if ( (int) $b->party_id === $party_id ) {
					$balance = (float) $b->balance;
					break;
				}
			}

			// Receivables are debit-normal, payables credit-normal.
			$owed = ( 'supplier' === $party_type ) ? -1 * $balance : $balance;

			if ( $owed <= 0.004 ) {
				wp_safe_redirect( $this->admin_url( array(
					'tab'   => $party_type,
					'error' => rawurlencode(
						$owed < -0.004
							? sprintf(
								/* translators: %s: credit amount. */
								__( 'Nothing is owed — this account is already in credit by %s. Taking another payment would make that worse. Find the entries behind the credit in Accounting and void the wrong ones.', 'wc-enterprise-erp' ),
								wp_strip_all_tags( wceerp_money( abs( $owed ) ) )
							)
							: __( 'Nothing is outstanding for that account, so there is no payment to take.', 'wc-enterprise-erp' )
					),
				) ) );
				exit;
			}

			if ( $amount > $owed + 0.004 ) {
				wp_safe_redirect( $this->admin_url( array(
					'tab'   => $party_type,
					'error' => rawurlencode( sprintf(
						/* translators: 1: attempted, 2: outstanding. */
						__( 'That is more than is owed. You entered %1$s against an outstanding balance of %2$s.', 'wc-enterprise-erp' ),
						wp_strip_all_tags( wceerp_money( $amount ) ),
						wp_strip_all_tags( wceerp_money( $owed ) )
					) ),
				) ) );
				exit;
			}
		}

		$result = WCEERP_Accounting::record_payment( array(
			'payment_date' => sanitize_text_field( $_POST['payment_date'] ),
			'direction'    => $direction,
			'party_type'   => $party_type,
			'party_id'     => $party_id,
			'account_id'   => (int) $_POST['account_id'],
			'method'       => sanitize_key( $_POST['method'] ),
			'amount'       => $amount,
			'txn_no'       => sanitize_text_field( wp_unslash( $_POST['txn_no'] ?? '' ) ),
			'note'         => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
		) );

		$args = is_wp_error( $result )
			? array( 'error' => rawurlencode( $result->get_error_message() ) )
			: array( 'updated' => 1 );
		wp_safe_redirect( $this->admin_url( $args ) );
		exit;
	}

	public function render_page() {
		global $wpdb;
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'customer';

		// Money accounts for the payment form.
		$money = $wpdb->get_results( 'SELECT * FROM ' . wceerp_table( 'accounts' ) . " WHERE subtype IN ('cash','bank','mobile_banking') AND status='active' ORDER BY code" );
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php echo wp_kses_post( $this->heading( __( 'Dues & Payments', 'wc-enterprise-erp' ) ) ); ?></h1>
			<?php if ( isset( $_GET['updated'] ) ) $this->notice( __( 'Payment recorded and posted to the books.', 'wc-enterprise-erp' ) ); ?>
			<?php if ( isset( $_GET['error'] ) ) $this->notice( sanitize_text_field( rawurldecode( $_GET['error'] ) ), 'error' ); ?>

			<nav class="nav-tab-wrapper">
				<?php
				foreach ( array(
					'customer' => __( 'Customer due', 'wc-enterprise-erp' ),
					'dealer'   => __( 'Dealer due', 'wc-enterprise-erp' ),
					'supplier' => __( 'Supplier due', 'wc-enterprise-erp' ),
					'orders'   => __( 'Unpaid orders', 'wc-enterprise-erp' ),
					'payments' => __( 'Payment history', 'wc-enterprise-erp' ),
				) as $key => $label ) {
					printf( '<a class="nav-tab %s" href="%s">%s</a>', $tab === $key ? 'nav-tab-active' : '', esc_url( $this->admin_url( array( 'tab' => $key ) ) ), esc_html( $label ) );
				}
				?>
			</nav>

			<?php
			if ( 'customer' === $tab ) $this->tab_party( 'customer', $money );
			if ( 'dealer' === $tab ) $this->tab_party( 'dealer', $money );
			if ( 'supplier' === $tab ) $this->tab_party( 'supplier', $money );
			if ( 'orders' === $tab ) $this->tab_orders( $money );
			if ( 'payments' === $tab ) $this->tab_history();
			?>
		</div>
		<?php
	}

	/**
	 * Resolve a party id into a usable contact record.
	 *
	 * Dues are only actionable if you can see who owes and how to reach
	 * them, so this returns a name, phone and email rather than an id.
	 */
	protected function party_info( $party_type, $party_id ) {
		global $wpdb;
		$party_id = (int) $party_id;
		$out = array( 'name' => '#' . $party_id, 'phone' => '', 'email' => '' );

		if ( 'dealer' === $party_type ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'dealers' ) . ' WHERE id=%d', $party_id ) );
			if ( $row ) {
				$out['name']  = $row->name;
				$out['phone'] = $row->phone ?? '';
				$out['email'] = $row->email ?? '';
			}
		} elseif ( 'supplier' === $party_type ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . wceerp_table( 'suppliers' ) . ' WHERE id=%d', $party_id ) );
			if ( $row ) {
				$out['name']  = $row->name;
				$out['phone'] = $row->phone ?? '';
				$out['email'] = $row->email ?? '';
			}
		} else {
			$user = get_userdata( $party_id );
			if ( $user ) {
				$out['name']  = $user->display_name;
				$out['email'] = $user->user_email;
				$out['phone'] = (string) get_user_meta( $party_id, 'billing_phone', true );
			} else {
				$out['name'] = __( 'Walk-in customer', 'wc-enterprise-erp' ) . ' #' . $party_id;
			}
		}
		return $out;
	}

	/**
	 * How old is this party's oldest unpaid entry?
	 *
	 * Ageing is what turns a due list into a chase list — a balance that
	 * is four months old needs a different conversation from one raised
	 * last week.
	 */
	protected function oldest_entry_days( $party_type, $party_id, $account_subtype ) {
		global $wpdb;
		$acc = WCEERP_Accounting::account_by_subtype( $account_subtype );
		if ( ! $acc ) {
			return 0;
		}
		$jl   = wceerp_table( 'journal_lines' );
		$j    = wceerp_table( 'journals' );
		$date = $wpdb->get_var( $wpdb->prepare(
			"SELECT MIN(j.journal_date) FROM $jl l
			 INNER JOIN $j j ON j.id = l.journal_id AND j.status = 'posted'
			 WHERE l.account_id = %d AND l.party_type = %s AND l.party_id = %d",
			$acc->id, $party_type, (int) $party_id
		) );
		return $date ? (int) floor( ( time() - strtotime( $date ) ) / DAY_IN_SECONDS ) : 0;
	}

	/**
	 * Break the guest bucket apart.
	 *
	 * WooCommerce gives every guest the user id 0, so the ledger honestly
	 * records a hundred different walk-in customers under one party — and
	 * the dues list shows a single row called "Walk-in customer #0" with an
	 * unusable total. Nobody can chase that.
	 *
	 * The entries themselves know better: each carries the order it came
	 * from, and the order carries a name and a phone. Grouping by phone
	 * turns one meaningless row back into the people who actually owe you.
	 *
	 * Derived at display time rather than stored, because the alternative —
	 * inventing a customer record per guest — fills the user table with
	 * accounts nobody asked for and can never be undone.
	 *
	 * @return array Rows keyed by phone, each { name, phone, due, days, orders }
	 */
	protected function guest_breakdown( $account_id, $party_type ) {
		global $wpdb;

		if ( 'customer' !== $party_type || ! $account_id ) {
			return array();
		}

		$jl = wceerp_table( 'journal_lines' );
		$j  = wceerp_table( 'journals' );

		$lines = (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT j.ref_id AS order_id, j.journal_date,
			        SUM( l.debit - l.credit ) AS balance
			 FROM {$jl} l
			 INNER JOIN {$j} j ON j.id = l.journal_id
			 WHERE j.status = 'posted'
			   AND l.account_id = %d
			   AND l.party_type = 'customer'
			   AND l.party_id = 0
			   AND j.ref_id > 0
			 GROUP BY j.ref_id
			 HAVING ABS( balance ) > 0.005
			 ORDER BY j.journal_date ASC",
			$account_id
		) );

		if ( ! $lines || ! function_exists( 'wc_get_order' ) ) {
			return array();
		}

		$people = array();
		foreach ( $lines as $l ) {
			$order = wc_get_order( (int) $l->order_id );
			if ( ! $order ) {
				continue;
			}

			$phone = preg_replace( '/\D/', '', (string) $order->get_billing_phone() );
			$name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );

			/* No phone means no way to tell one walk-in from another, so
			 * those stay together rather than pretending to be distinct. */
			$key = $phone ? $phone : 'unknown';

			if ( ! isset( $people[ $key ] ) ) {
				$people[ $key ] = array(
					'name'   => $name ? $name : __( 'Walk-in customer', 'wc-enterprise-erp' ),
					'phone'  => $phone,
					'due'    => 0.0,
					'days'   => 0,
					'orders' => array(),
				);
			}

			$people[ $key ]['due']     += (float) $l->balance;
			$people[ $key ]['orders'][] = (int) $l->order_id;

			// Oldest entry sets the age, which is what makes ageing useful.
			$days = (int) floor( ( time() - strtotime( $l->journal_date ) ) / DAY_IN_SECONDS );
			if ( $days > $people[ $key ]['days'] ) {
				$people[ $key ]['days'] = $days;
			}

			if ( $name && __( 'Walk-in customer', 'wc-enterprise-erp' ) === $people[ $key ]['name'] ) {
				$people[ $key ]['name'] = $name;
			}
		}

		return $people;
	}

	protected function tab_party( $party_type, $money ) {
		global $wpdb;
		$is_customer = in_array( $party_type, array( 'customer', 'dealer' ), true ); // dealers sit on AR too.
		$subtype     = $is_customer ? 'receivable' : 'payable';
		$balances    = WCEERP_Accounting::party_balances( $party_type, $subtype );

		// Build rows with contact + ageing, then sort by size of debt.
		$rows  = array();
		$total = 0;
		$aged  = array( 'current' => 0, '30' => 0, '60' => 0, '90' => 0 );

		/* A party in credit is not a debtor.
		 *
		 * A negative balance means more has been paid in than was ever
		 * charged. Adding it to "owed to you" makes the headline
		 * meaningless, and a large enough credit turns the total negative —
		 * which is exactly what was showing. Counted separately, because a
		 * debt and a credit need opposite actions. */
		$credits      = array();
		$credit_total = 0;

		foreach ( (array) $balances as $b ) {
			$due = $is_customer ? (float) $b->balance : -1 * (float) $b->balance;
			if ( abs( $due ) < 0.005 ) {
				continue; // settled
			}

			if ( $due < 0 ) {
				$info          = $this->party_info( $party_type, $b->party_id );
				$credits[]     = array( 'id' => (int) $b->party_id, 'due' => $due ) + $info;
				$credit_total += $due;
				continue;
			}

			/* Party 0 is not one customer, it is every guest. Expand it. */
			if ( 0 === (int) $b->party_id && 'customer' === $party_type ) {
				$acc    = WCEERP_Accounting::account_by_subtype( $subtype );
				$people = $acc ? $this->guest_breakdown( $acc->id, $party_type ) : array();

				if ( $people ) {
					foreach ( $people as $person ) {
						if ( $person['due'] < 0.005 ) {
							continue;
						}
						$pd = $person['days'];
						if ( $pd <= 30 )      { $aged['current'] += $person['due']; $bucket = 'current'; }
						elseif ( $pd <= 60 )  { $aged['30'] += $person['due']; $bucket = '30'; }
						elseif ( $pd <= 90 )  { $aged['60'] += $person['due']; $bucket = '60'; }
						else                  { $aged['90'] += $person['due']; $bucket = '90'; }

						$rows[] = array(
							'id'     => 0,
							'due'    => $person['due'],
							'days'   => $pd,
							'bucket' => $bucket,
							'name'   => $person['name'],
							'phone'  => $person['phone'],
							'email'  => '',
							'orders' => $person['orders'],
						);
						$total += $person['due'];
					}
					continue;
				}
			}
			$days = $this->oldest_entry_days( $party_type, $b->party_id, $subtype );
			$info = $this->party_info( $party_type, $b->party_id );

			if ( $days <= 30 )      { $aged['current'] += $due; $bucket = 'current'; }
			elseif ( $days <= 60 )  { $aged['30'] += $due; $bucket = '30'; }
			elseif ( $days <= 90 )  { $aged['60'] += $due; $bucket = '60'; }
			else                    { $aged['90'] += $due; $bucket = '90'; }

			$rows[]  = array( 'id' => (int) $b->party_id, 'due' => $due, 'days' => $days, 'bucket' => $bucket, 'orders' => array() ) + $info;
			$total  += $due;
		}
		usort( $rows, function ( $a, $b ) {
			return $b['due'] <=> $a['due'];
		} );

		$labels = array(
			'customer' => array( __( 'Customers who owe you', 'wc-enterprise-erp' ), __( 'Receive customer payment', 'wc-enterprise-erp' ) ),
			'dealer'   => array( __( 'Dealers who owe you', 'wc-enterprise-erp' ), __( 'Receive dealer payment', 'wc-enterprise-erp' ) ),
			'supplier' => array( __( 'Suppliers you owe', 'wc-enterprise-erp' ), __( 'Pay supplier', 'wc-enterprise-erp' ) ),
		);
		?>
		<?php if ( $credits ) : ?>
			<div class="notice notice-warning" style="margin:0 0 14px">
				<p><strong><?php
					printf(
						/* translators: 1: count, 2: amount. */
						esc_html__( '%1$d account(s) are in credit by %2$s — left out of the figures below.', 'wc-enterprise-erp' ),
						count( $credits ),
						wp_kses_post( wceerp_money( abs( $credit_total ) ) )
					);
				?></strong></p>
				<p class="description">
					<?php esc_html_e( 'More has been paid in than was ever charged. Usually a payment recorded twice, a cash POS sale that also had a payment recorded against it, or money received against a sale that never posted. Worth finding: a credit here is money your books think you owe back.', 'wc-enterprise-erp' ); ?>
				</p>
				<ul style="margin:6px 0 8px 18px;list-style:disc">
					<?php foreach ( array_slice( $credits, 0, 20 ) as $cr ) : ?>
						<li>
							<?php echo esc_html( ! empty( $cr['name'] ) ? $cr['name'] : sprintf( __( 'Guest / walk-in #%d', 'wc-enterprise-erp' ), $cr['id'] ) ); ?>
							— <?php echo wp_kses_post( wceerp_money( abs( $cr['due'] ) ) ); ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<div class="wceerp-kpis" style="margin-bottom:14px">
			<div class="wceerp-kpi <?php echo $is_customer ? '' : 'is-bad'; ?>">
				<span><?php echo $is_customer ? esc_html__( 'Total owed to you', 'wc-enterprise-erp' ) : esc_html__( 'Total you owe', 'wc-enterprise-erp' ); ?></span>
				<strong><?php echo wp_kses_post( wceerp_money( $total ) ); ?></strong>
			</div>
			<div class="wceerp-kpi"><span><?php esc_html_e( 'Up to 30 days', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $aged['current'] ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( '31–60 days', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $aged['30'] ) ); ?></strong></div>
			<div class="wceerp-kpi"><span><?php esc_html_e( '61–90 days', 'wc-enterprise-erp' ); ?></span><strong style="color:#b98a2f"><?php echo wp_kses_post( wceerp_money( $aged['60'] ) ); ?></strong></div>
			<div class="wceerp-kpi is-bad"><span><?php esc_html_e( 'Over 90 days', 'wc-enterprise-erp' ); ?></span><strong><?php echo wp_kses_post( wceerp_money( $aged['90'] ) ); ?></strong></div>
		</div>

		<div class="wceerp-columns">
			<div class="wceerp-card">
				<h2><?php echo esc_html( $labels[ $party_type ][0] ); ?></h2>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'Party', 'wc-enterprise-erp' ); ?></th>
						<th><?php esc_html_e( 'Age', 'wc-enterprise-erp' ); ?></th>
						<th class="num"><?php esc_html_e( 'Balance', 'wc-enterprise-erp' ); ?></th>
						<th></th>
					</tr></thead>
					<tbody>
					<?php if ( ! $rows ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'Nothing outstanding. 🎉', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $rows as $r ) :
						$colour = 'current' === $r['bucket'] ? '#8a8f98' : ( '90' === $r['bucket'] ? '#c8302e' : '#b98a2f' );
						$wa     = $r['phone'] ? 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $r['phone'] ) . '?text=' . rawurlencode(
							sprintf(
								/* translators: 1: name 2: amount */
								__( 'Hello %1$s, this is a reminder about your outstanding balance of %2$s.', 'wc-enterprise-erp' ),
								$r['name'],
								wp_strip_all_tags( wceerp_money( $r['due'] ) )
							)
						) : '';
						?>
						<tr>
							<td>
								<strong><?php echo esc_html( $r['name'] ); ?></strong>
								<?php if ( $r['phone'] || $r['email'] ) : ?>
									<br><small style="color:#888"><?php echo esc_html( trim( $r['phone'] . ( $r['phone'] && $r['email'] ? ' · ' : '' ) . $r['email'] ) ); ?></small>
								<?php endif; ?>

								<?php
								/* A guest has no account to take payment against,
								 * so the orders are the way in: open one and record
								 * the payment there. Without this the row names a
								 * debt nobody can act on. */
								if ( ! empty( $r['orders'] ) ) :
									?>
									<br><small>
										<?php esc_html_e( 'Orders:', 'wc-enterprise-erp' ); ?>
										<?php foreach ( array_slice( $r['orders'], 0, 6 ) as $oid ) : ?>
											<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $oid . '&action=edit' ) ); ?>">#<?php echo (int) $oid; ?></a>
										<?php endforeach; ?>
										<?php if ( count( $r['orders'] ) > 6 ) : ?>
											<?php printf( esc_html__( '+%d more', 'wc-enterprise-erp' ), count( $r['orders'] ) - 6 ); ?>
										<?php endif; ?>
									</small>
								<?php endif; ?>
							</td>
							<td style="color:<?php echo esc_attr( $colour ); ?>;font-weight:600">
								<?php echo esc_html( sprintf( _n( '%d day', '%d days', $r['days'], 'wc-enterprise-erp' ), $r['days'] ) ); ?>
							</td>
							<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $r['due'] ) ); ?></strong></td>
							<td>
								<?php if ( $wa && $is_customer ) : ?>
									<a class="button button-small" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener">💬</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot><tr><th><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th><th></th><th class="num"><?php echo wp_kses_post( wceerp_money( $total ) ); ?></th><th></th></tr></tfoot>
				</table>
				<?php if ( $aged['90'] > 0.004 && $is_customer ) : ?>
					<p class="description" style="color:#c8302e">
						<?php echo wp_kses_post( sprintf( __( '<strong>%s</strong> has been outstanding for more than 90 days. Debt this old is much harder to collect — chase it first.', 'wc-enterprise-erp' ), wp_strip_all_tags( wceerp_money( $aged['90'] ) ) ) ); ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="wceerp-card">
				<h2><?php echo $is_customer ? esc_html__( 'Customers with dues', 'wc-enterprise-erp' ) : esc_html__( 'Suppliers with dues', 'wc-enterprise-erp' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Party', 'wc-enterprise-erp' ); ?></th><th class="num"><?php esc_html_e( 'Due amount', 'wc-enterprise-erp' ); ?></th></tr></thead>
					<tbody>
					<?php if ( ! $balances ) : ?>
						<tr><td colspan="2"><?php esc_html_e( 'No outstanding dues. 🎉', 'wc-enterprise-erp' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $balances as $b ) :
						$due = $is_customer ? (float) $b->balance : -1 * (float) $b->balance;
						$total += $due;
						if ( 'dealer' === $party_type ) {
							$name = $wpdb->get_var( $wpdb->prepare( 'SELECT name FROM ' . wceerp_table( 'dealers' ) . ' WHERE id=%d', (int) $b->party_id ) ) ?: '#' . (int) $b->party_id;
						} elseif ( $is_customer ) {
							$user = get_userdata( (int) $b->party_id );
							$name = $user ? $user->display_name . ' (' . $user->user_email . ')' : __( 'Guest / walk-in', 'wc-enterprise-erp' ) . ' #' . (int) $b->party_id;
						} else {
							$name = $wpdb->get_var( $wpdb->prepare( 'SELECT name FROM ' . wceerp_table( 'suppliers' ) . ' WHERE id=%d', (int) $b->party_id ) ) ?: '#' . (int) $b->party_id;
						}
						?>
						<tr>
							<td><?php echo esc_html( $name ); ?></td>
							<td class="num"><strong><?php echo wp_kses_post( wceerp_money( $due ) ); ?></strong></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot><tr><th><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th><th class="num"><?php echo wp_kses_post( wceerp_money( $total ) ); ?></th></tr></tfoot>
				</table>
			</div>

			<div class="wceerp-card">
				<h2><?php echo esc_html( $labels[ $party_type ][1] ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_payment_save">
					<input type="hidden" name="party_type" value="<?php echo esc_attr( $party_type ); ?>">
					<input type="hidden" name="direction" value="<?php echo $is_customer ? 'in' : 'out'; ?>">
					<?php wp_nonce_field( 'wceerp_payment_save' ); ?>
					<p><label><?php esc_html_e( 'Who', 'wc-enterprise-erp' ); ?><br>
						<?php if ( $rows ) : ?>
							<select name="party_id" required style="max-width:100%">
								<option value=""><?php esc_html_e( '— select —', 'wc-enterprise-erp' ); ?></option>
								<?php foreach ( $rows as $r ) : ?>
									<option value="<?php echo (int) $r['id']; ?>">
										<?php echo esc_html( $r['name'] . ' — ' . wp_strip_all_tags( wceerp_money( $r['due'] ) ) ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<input type="number" name="party_id" min="0" required placeholder="<?php esc_attr_e( 'ID', 'wc-enterprise-erp' ); ?>">
						<?php endif; ?>
					</label>
					<span class="description"><?php esc_html_e( 'Only parties with an outstanding balance are listed.', 'wc-enterprise-erp' ); ?></span></p>
					<p><label><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?><br><input type="date" name="payment_date" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?><br><input type="number" name="amount" step="0.01" min="0.01" required></label></p>
					<p><label><?php esc_html_e( 'Money account', 'wc-enterprise-erp' ); ?><br>
						<select name="account_id"><?php foreach ( $money as $a ) printf( '<option value="%d">%s — %s</option>', (int) $a->id, esc_html( $a->code ), esc_html( $a->name ) ); ?></select></label></p>
					<p><label><?php esc_html_e( 'Method', 'wc-enterprise-erp' ); ?><br>
						<select name="method"><?php foreach ( self::methods() as $key => $label ) printf( '<option value="%s">%s</option>', esc_attr( $key ), esc_html( $label ) ); ?></select></label></p>
					<p><label><?php esc_html_e( 'Transaction / cheque no.', 'wc-enterprise-erp' ); ?><br><input type="text" name="txn_no" class="regular-text" placeholder="TrxID 8N7A5..."></label></p>
					<p><label><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?><br><input type="text" name="note" class="regular-text"></label></p>
					<?php submit_button( $is_customer ? __( 'Receive payment', 'wc-enterprise-erp' ) : __( 'Make payment', 'wc-enterprise-erp' ) ); ?>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Orders with money still outstanding.
	 *
	 * The party tabs answer "who owes me"; this answers "which orders",
	 * which is what someone chasing a payment actually needs. Balances come
	 * from WCEERP_Order_Payments so advances, courier COD and part payments
	 * are all accounted for, rather than assuming an unpaid order is unpaid
	 * in full.
	 */
	protected function tab_orders( $money ) {
		if ( ! class_exists( 'WCEERP_Order_Payments' ) || ! function_exists( 'wc_get_orders' ) ) {
			echo '<p>' . esc_html__( 'WooCommerce is not available.', 'wc-enterprise-erp' ) . '</p>';
			return;
		}

		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$args   = array(
			'limit'   => 200,
			'orderby' => 'date',
			'order'   => 'DESC',
			'status'  => array( 'processing', 'completed', 'on-hold' ),
			'return'  => 'objects',
		);
		$golive = function_exists( 'wceerp_start_date' ) ? wceerp_start_date() : '';
		if ( $golive ) {
			$args['date_created'] = '>=' . $golive;
		}
		if ( $search ) {
			$args['s'] = $search;
		}

		$rows  = array();
		$total = 0.0;

		foreach ( (array) wc_get_orders( $args ) as $order ) {
			$pic = WCEERP_Order_Payments::picture( $order );
			if ( $pic['due'] <= 0.005 ) {
				continue;
			}
			$rows[] = array( 'order' => $order, 'pic' => $pic );
			$total += $pic['due'];
		}
		?>
		<div class="wceerp-kpis" style="margin-bottom:14px">
			<div class="wceerp-kpi is-bad">
				<span><?php esc_html_e( 'Outstanding on orders', 'wc-enterprise-erp' ); ?></span>
				<strong><?php echo wp_kses_post( wceerp_money( $total ) ); ?></strong>
			</div>
			<div class="wceerp-kpi">
				<span><?php esc_html_e( 'Orders affected', 'wc-enterprise-erp' ); ?></span>
				<strong><?php echo count( $rows ); ?></strong>
			</div>
		</div>

		<form method="get" style="margin-bottom:12px">
			<input type="hidden" name="page" value="wceerp-dues">
			<input type="hidden" name="tab" value="orders">
			<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Order number, name or phone…', 'wc-enterprise-erp' ); ?>">
			<button class="button"><?php esc_html_e( 'Search', 'wc-enterprise-erp' ); ?></button>
		</form>

		<p class="description" style="max-width:760px">
			<?php esc_html_e( 'Money still owed after advances received and anything a courier is holding. Recording a payment here posts it to the books and updates the customer\'s balance immediately.', 'wc-enterprise-erp' ); ?>
		</p>

		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Order', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Customer', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Age', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Received', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'With courier', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Due', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Record payment', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="8"><?php esc_html_e( 'Nothing outstanding — every order is settled.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $rows as $row ) : ?>
				<?php
				$order   = $row['order'];
				$pic     = $row['pic'];
				$created = $order->get_date_created();
				$days    = $created ? (int) floor( ( time() - $created->getTimestamp() ) / DAY_IN_SECONDS ) : 0;
				$name    = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
				?>
				<tr>
					<td>
						<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo (int) $order->get_id(); ?></a>
						<br><small><?php echo esc_html( $created ? $created->date( 'j M Y' ) : '' ); ?></small>
					</td>
					<td>
						<?php echo esc_html( $name ?: __( 'Guest', 'wc-enterprise-erp' ) ); ?>
						<?php if ( $order->get_billing_phone() ) : ?>
							<br><small><a href="tel:<?php echo esc_attr( $order->get_billing_phone() ); ?>"><?php echo esc_html( $order->get_billing_phone() ); ?></a></small>
						<?php endif; ?>
					</td>
					<td>
						<?php
						$colour = $days > 60 ? '#b32d2e' : ( $days > 30 ? '#996800' : '#646970' );
						printf( '<span style="color:%s">%s</span>', esc_attr( $colour ), esc_html( sprintf( _n( '%d day', '%d days', $days, 'wc-enterprise-erp' ), $days ) ) );
						?>
					</td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $pic['total'] ) ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( (float) $pic['paid'] + (float) $pic['cod_collected'] ) ); ?></td>
					<td class="num"><?php echo (float) $pic['cod_pending'] > 0.005 ? wp_kses_post( wceerp_money( $pic['cod_pending'] ) ) : '<span style="color:#bbb">—</span>'; ?></td>
					<td class="num"><strong style="color:#b32d2e"><?php echo wp_kses_post( wceerp_money( $pic['due'] ) ); ?></strong></td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:4px;flex-wrap:wrap">
							<?php wp_nonce_field( 'wceerp_record_payment' ); ?>
							<input type="hidden" name="action" value="wceerp_record_payment">
							<input type="hidden" name="order_id" value="<?php echo (int) $order->get_id(); ?>">
							<input type="number" step="0.01" min="0.01" max="<?php echo esc_attr( $pic['due'] ); ?>"
								name="amount" value="<?php echo esc_attr( $pic['due'] ); ?>" style="width:88px" required>
							<select name="method" style="max-width:96px">
								<?php foreach ( WCEERP_Order_Payments::methods() as $mk => $m ) : ?>
									<option value="<?php echo esc_attr( $mk ); ?>"><?php echo esc_html( $m['label'] ); ?></option>
								<?php endforeach; ?>
							</select>
							<input type="hidden" name="paid_on" value="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>">
							<input type="hidden" name="redirect_to" value="<?php echo esc_url( admin_url( 'admin.php?page=wceerp-dues&tab=orders' ) ); ?>">
							<button class="button button-small button-primary"><?php esc_html_e( 'Receive', 'wc-enterprise-erp' ); ?></button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	protected function tab_history() {
		global $wpdb;
		$per_page = 25;
		$total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . wceerp_table( 'payments' ) );
		$rows     = $wpdb->get_results( $wpdb->prepare(
			'SELECT p.*, a.name AS account FROM ' . wceerp_table( 'payments' ) . ' p
			 LEFT JOIN ' . wceerp_table( 'accounts' ) . ' a ON a.id = p.account_id
			 ORDER BY p.id DESC LIMIT %d OFFSET %d', $per_page, wceerp_offset( $per_page )
		) );
		?>
		<table class="widefat striped wceerp-table">
			<thead><tr>
				<th><?php esc_html_e( 'Voucher', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Date', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Dir', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Party', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Account', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Method', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Txn no.', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( (array) $rows as $p ) : ?>
				<tr>
					<td><code><?php echo esc_html( $p->doc_no ); ?></code></td>
					<td><?php echo esc_html( $p->payment_date ); ?></td>
					<td><span class="wceerp-badge <?php echo 'in' === $p->direction ? 'is-in' : 'is-out'; ?>"><?php echo esc_html( strtoupper( $p->direction ) ); ?></span></td>
					<td><?php echo esc_html( $p->party_type . ' #' . $p->party_id ); ?></td>
					<td><?php echo esc_html( $p->account ); ?></td>
					<td><?php echo esc_html( self::methods()[ $p->method ] ?? $p->method ); ?></td>
					<td><?php echo esc_html( $p->txn_no ); ?></td>
					<td class="num"><?php echo wp_kses_post( wceerp_money( $p->amount ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php wceerp_pagination( $total, $per_page ); ?>
		<?php
	}
}
