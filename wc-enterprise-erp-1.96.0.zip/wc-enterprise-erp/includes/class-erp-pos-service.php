<?php
/**
 * POS service layer.
 *
 * The sale logic used to live inside a REST callback, reading WP_REST_Request
 * directly. That made it impossible to reuse: an admin handler or a public API
 * route would have had to fabricate a request object to call it.
 *
 * This is the pattern the rest of the ERP should follow — a plain function
 * that takes an array and returns data or a WP_Error, with no knowledge of
 * HTTP. Both the internal terminal and the public API are thin adapters over
 * it, so they cannot drift apart in behaviour.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_POS_Service {

	/**
	 * Create a POS sale.
	 *
	 * Idempotent on `uuid`: replaying the same uuid returns the original
	 * order rather than creating a second one. This is what makes the
	 * endpoint safe for an integrator to retry after a timeout.
	 *
	 * @param array $args uuid, items[], discount, received, pay_method,
	 *                    customer_id, customer_name, customer_phone, tier,
	 *                    shift_uuid, sold_at, exchange_ref, exchange_order_id
	 * @return array|WP_Error
	 */
	public static function create_sale( array $args ) {
		global $wpdb;
		$sales = wceerp_table( 'pos_sales' );

		$uuid = substr( sanitize_text_field( (string) ( $args['uuid'] ?? '' ) ), 0, 40 );
		if ( ! $uuid ) {
			return new WP_Error( 'wceerp_bad_request', __( 'uuid is required — it is what makes a retry safe.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$sales} WHERE uuid = %s", $uuid ) );
		if ( $existing ) {
			return array(
				'ok'        => true,
				'order_id'  => (int) $existing->order_id,
				'total'     => (float) $existing->total,
				'duplicate' => true,
			);
		}

		$items = (array) ( $args['items'] ?? array() );
		if ( ! $items ) {
			return new WP_Error( 'wceerp_bad_request', __( 'items is required.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		$method  = sanitize_key( (string) ( $args['pay_method'] ?? 'cash' ) ) ?: 'cash';
		$phone   = sanitize_text_field( (string) ( $args['customer_phone'] ?? '' ) );
		$name    = sanitize_text_field( (string) ( $args['customer_name'] ?? '' ) );
		$sold_at = sanitize_text_field( (string) ( $args['sold_at'] ?? '' ) );

		$order = wc_create_order( array( 'created_via' => 'wceerp_pos' ) );
		if ( is_wp_error( $order ) ) {
			return $order;
		}

		$total   = 0;
		$counted = 0;
		foreach ( $items as $item ) {
			$product = wc_get_product( (int) ( $item['id'] ?? 0 ) );
			$qty     = max( 0.01, (float) ( $item['qty'] ?? 1 ) );
			$price   = wceerp_dec( $item['price'] ?? 0 ); // VAT-inclusive shelf price.
			if ( ! $product ) {
				continue;
			}
			$line = round( $price * $qty, 2 );
			$order->add_product( $product, $qty, array( 'subtotal' => $line, 'total' => $line ) );
			$total += $line;
			$counted++;
		}

		/* Every product id was unknown. Completing this would post a
		 * zero-value sale and quietly move no stock, so refuse instead. */
		if ( ! $counted ) {
			$order->delete( true );
			return new WP_Error( 'wceerp_bad_request', __( 'None of the supplied product ids exist.', 'wc-enterprise-erp' ), array( 'status' => 400 ) );
		}

		/* Delivery charged to the customer.
		 *
		 * A shipping line rather than a fee, because that is what it is —
		 * and WooCommerce reports, invoices and the courier screen all read
		 * shipping. Added before the discount is worked out, so a discount
		 * can reduce the delivery as well as the goods; at a counter that is
		 * usually what is meant when someone knocks money off the total.
		 *
		 * This is money coming in, not the courier's charge going out. The
		 * two are unrelated and often differ: charge a flat 60 and pay Bahok
		 * 135, and the difference is a real cost you are absorbing. */
		$shipping = max( 0, wceerp_dec( $args['shipping'] ?? 0 ) );
		if ( $shipping > 0.004 ) {
			$ship = new WC_Order_Item_Shipping();
			$ship->set_method_title( sanitize_text_field( (string) ( $args['shipping_label'] ?? '' ) ) ?: __( 'Delivery', 'wc-enterprise-erp' ) );
			$ship->set_total( $shipping );
			$order->add_item( $ship );
			$total += $shipping;
		}

		$discount = min( $total, wceerp_dec( $args['discount'] ?? 0 ) );
		if ( $discount > 0.004 ) {
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( __( 'POS discount', 'wc-enterprise-erp' ) );
			$fee->set_total( -$discount );
			$order->add_item( $fee );
			$total -= $discount;
		}

		$customer_id = (int) ( $args['customer_id'] ?? 0 );
		if ( $customer_id && get_userdata( $customer_id ) ) {
			$order->set_customer_id( $customer_id );
			if ( ! $name ) {
				$name = get_userdata( $customer_id )->display_name;
			}
		}
		/* The address was captured at the counter and then dropped here, so
		 * a POS sale that later needed delivering had no address to book a
		 * parcel against — the one thing you would need it for. */
		$address = trim( (string) ( $args['customer_address'] ?? '' ) );

		if ( $name || $phone || $address ) {
			$order->set_billing_first_name( $name ?: __( 'Walk-in', 'wc-enterprise-erp' ) );
			$order->set_billing_phone( $phone );

			if ( $address ) {
				/* WooCommerce keeps address lines separate. A counter gives
				 * you one blob of text, so the first line goes to address_1
				 * and the rest to address_2 rather than being truncated. */
				$parts = preg_split( '/\r\n|\r|\n|,\s*/', $address, 2 );
				$order->set_billing_address_1( trim( $parts[0] ) );
				if ( ! empty( $parts[1] ) ) {
					$order->set_billing_address_2( trim( $parts[1] ) );
				}
				// Shipping mirrors billing: at a counter they are the same.
				$order->set_shipping_first_name( $name ?: __( 'Walk-in', 'wc-enterprise-erp' ) );
				$order->set_shipping_address_1( trim( $parts[0] ) );
				if ( ! empty( $parts[1] ) ) {
					$order->set_shipping_address_2( trim( $parts[1] ) );
				}
			}
		}

		$order->set_payment_method( 'pos_' . $method ); // pos_bkash → a/c 1020 in the bridge.
		$order->set_payment_method_title( 'POS — ' . strtoupper( $method ) );
		$order->update_meta_data( '_wceerp_pos_uuid', $uuid );

		$shift = substr( sanitize_text_field( (string) ( $args['shift_uuid'] ?? '' ) ), 0, 40 );
		$order->update_meta_data( '_wceerp_pos_shift', $shift );

		$has_received = array_key_exists( 'received', $args ) && null !== $args['received'];
		$received     = wceerp_dec( $args['received'] ?? 0 );
		$due          = $has_received ? max( 0, round( $total - $received, 2 ) ) : 0;

		/* An unpaid balance has to belong to someone, or it lands in
		 * Accounts Receivable with no party and can never be chased. */
		if ( $due > 0.004 && ! $order->get_customer_id() ) {
			$order->delete( true );
			return new WP_Error(
				'wceerp_bad_request',
				__( 'A sale with a balance due must be linked to a customer.', 'wc-enterprise-erp' ),
				array( 'status' => 400 )
			);
		}

		$order->update_meta_data( '_wceerp_pos_received', $has_received ? $received : $total );
		$order->update_meta_data( '_wceerp_pos_due', $due );

		$tier = sanitize_key( (string) ( $args['tier'] ?? '' ) );
		if ( $tier && class_exists( 'WCEERP_Module_Dealers' ) && array_key_exists( $tier, WCEERP_Module_Dealers::tiers() ) ) {
			$order->update_meta_data( '_wceerp_price_tier', $tier );
		}
		if ( $sold_at ) {
			$order->add_order_note( 'Sold offline at ' . $sold_at );
		}

		$exchange_ref = substr( sanitize_text_field( (string) ( $args['exchange_ref'] ?? '' ) ), 0, 40 );
		if ( $exchange_ref ) {
			$order->update_meta_data( '_wceerp_pos_exchange', $exchange_ref );
			$order->add_order_note( sprintf(
				'POS exchange %s — replaces returned goods from order #%d',
				$exchange_ref,
				(int) ( $args['exchange_order_id'] ?? 0 )
			) );
		}

		$order->set_total( $total );

		if ( $due > 0.004 ) {
			$order->add_order_note( sprintf(
				'POS: received %s of %s — %s due',
				wp_strip_all_tags( wceerp_money( $received ) ),
				wp_strip_all_tags( wceerp_money( $total ) ),
				wp_strip_all_tags( wceerp_money( $due ) )
			) );
			$order->save();
			$order->update_status( 'processing', __( 'WCEERP POS sale (partial payment)', 'wc-enterprise-erp' ) );
		} else {
			$order->save();
			$order->payment_complete();
			$order->update_status( 'completed', __( 'WCEERP POS sale', 'wc-enterprise-erp' ) );
		}

		$wpdb->insert( $sales, array(
			'uuid'       => $uuid,
			'shift_uuid' => $shift,
			'order_id'   => $order->get_id(),
			'user_id'    => get_current_user_id(),
			'total'      => $total,
			'pay_method' => $method,
			'sold_at'    => $sold_at ?: current_time( 'mysql' ),
			'created_at' => current_time( 'mysql' ),
		) );

		wceerp_log( 'pos', 'sale', $order->get_id(), $uuid . ( ! empty( $args['_via_api'] ) ? ' [api]' : '' ) );

		return array(
			'ok'       => true,
			'order_id' => $order->get_id(),
			'total'    => round( $total, 2 ),
			'due'      => $due,
		);
	}

	/** Catalogue page, shared by the terminal and the public API. */
	public static function catalogue( $page = 1, $per_page = 200 ) {
		$query = new WC_Product_Query( array(
			'limit'  => max( 1, min( 500, (int) $per_page ) ),
			'page'   => max( 1, (int) $page ),
			'status' => 'publish',
			'return' => 'objects',
		) );

		$out      = array();
		$has_tier = class_exists( 'WCEERP_Module_Dealers' );

		foreach ( $query->get_products() as $product ) {
			$row = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'sku'   => (string) $product->get_sku(),
				'price' => (float) wc_get_price_including_tax( $product ),
			);
			if ( $has_tier ) {
				$tiers = array();
				foreach ( array_keys( WCEERP_Module_Dealers::tiers() ) as $tier ) {
					$fixed = WCEERP_Module_Dealers::product_tier_price( $product->get_id(), $tier );
					if ( null !== $fixed && $fixed > 0 ) {
						$tiers[ $tier ] = (float) $fixed;
					}
				}
				if ( $tiers ) {
					$row['tiers'] = $tiers;
				}
			}
			$out[] = $row;
		}
		return $out;
	}
}
