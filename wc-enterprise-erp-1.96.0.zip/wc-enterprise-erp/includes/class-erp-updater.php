<?php
/**
 * Plugin updates from your own server.
 *
 * A commercial plugin is not in the WordPress.org directory, so WordPress has
 * nowhere to look for new versions. This fills that gap: it asks the licence
 * server what the current release is and, if it is newer, hands WordPress a
 * package URL so the update appears on the client's Plugins screen exactly
 * like any other.
 *
 * Server contract — POST {license_endpoint}/update
 *
 *   request  { product, version, key, site, php, wp }
 *   response {
 *     version       "1.43.0"
 *     package       "https://.../download?token=…"   (authorised, expiring)
 *     tested        "6.8"
 *     requires      "6.0"
 *     requires_php  "7.4"
 *     changelog     "<p>…</p>"
 *     last_updated  "2026-07-27"
 *     notice        "optional message shown on the plugins screen"
 *   }
 *
 * Two deliberate safety properties:
 *
 *   1. The server decides who is told about a release. Returning the new
 *      version to a subset of licences gives you a staged rollout, which
 *      matters enormously for software that posts to people's books.
 *   2. No licence, no package. The download URL must be authorised server
 *      side, or the paid plugin is simply a public download.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Updater {

	const CACHE   = 'wceerp_update_info';
	const CACHE_H = 12; // hours

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ), 10, 2 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_meta' ), 10, 2 );
		add_action( 'admin_post_wceerp_check_update', array( __CLASS__, 'handle_manual_check' ) );
	}

	protected static function basename() {
		return plugin_basename( WCEERP_FILE );
	}

	protected static function slug() {
		return dirname( self::basename() );
	}

	/**
	 * Ask the licence server what the current release is.
	 *
	 * @param bool $force Skip the cache.
	 * @return array|WP_Error
	 */
	public static function remote_info( $force = false ) {
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		if ( ! class_exists( 'WCEERP_License' ) ) {
			return new WP_Error( 'wceerp_update', 'Licence client unavailable.' );
		}

		$endpoint = WCEERP_License::endpoint();
		if ( ! $endpoint ) {
			return new WP_Error( 'wceerp_update', 'No licence endpoint configured.' );
		}

		$state = (array) get_option( WCEERP_License::OPTION, array() );

		$res = wp_remote_post( $endpoint . '/update', array(
			'timeout' => 15,
			'headers' => array( 'Accept' => 'application/json', 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( array(
				'product' => WCEERP_License::PRODUCT,
				'version' => WCEERP_VERSION,
				'key'     => (string) ( $state['key'] ?? '' ),
				'site'    => home_url(),
				'php'     => PHP_VERSION,
				'wp'      => get_bloginfo( 'version' ),
			) ),
		) );

		if ( is_wp_error( $res ) ) {
			/* Cache the failure briefly. A server outage must not mean every
			 * admin page load stalls for 15 seconds on every client site. */
			set_site_transient( self::CACHE, array( 'error' => 1 ), HOUR_IN_SECONDS );
			return $res;
		}

		$code = wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( $code < 200 || $code >= 300 || ! is_array( $data ) || empty( $data['version'] ) ) {
			set_site_transient( self::CACHE, array( 'error' => 1 ), HOUR_IN_SECONDS );
			return new WP_Error( 'wceerp_update', 'No update information returned.' );
		}

		set_site_transient( self::CACHE, $data, self::CACHE_H * HOUR_IN_SECONDS );
		return $data;
	}

	/** Add our update to the list WordPress is about to store. */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$info = self::remote_info();
		if ( is_wp_error( $info ) || ! empty( $info['error'] ) || empty( $info['version'] ) ) {
			return $transient;
		}

		$file = self::basename();

		if ( version_compare( $info['version'], WCEERP_VERSION, '>' ) ) {
			/* Without a package URL the update is announced but cannot be
			 * installed — which is what an unlicensed site should see. */
			$item = (object) array(
				'id'            => self::slug(),
				'slug'          => self::slug(),
				'plugin'        => $file,
				'new_version'   => $info['version'],
				'url'           => $info['homepage'] ?? 'https://getproservices.net',
				'package'       => (string) ( $info['package'] ?? '' ),
				'tested'        => (string) ( $info['tested'] ?? '' ),
				'requires_php'  => (string) ( $info['requires_php'] ?? '' ),
				'icons'         => (array) ( $info['icons'] ?? array() ),
			);
			$transient->response[ $file ] = $item;
			unset( $transient->no_update[ $file ] );
		} else {
			$transient->no_update[ $file ] = (object) array(
				'id'          => self::slug(),
				'slug'        => self::slug(),
				'plugin'      => $file,
				'new_version' => WCEERP_VERSION,
				'url'         => 'https://getproservices.net',
				'package'     => '',
			);
		}

		return $transient;
	}

	/** Populate the "View details" panel. */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::slug() !== $args->slug ) {
			return $result;
		}

		$info = self::remote_info();
		if ( is_wp_error( $info ) || empty( $info['version'] ) ) {
			return $result;
		}

		return (object) array(
			'name'          => 'WooCommerce ERP',
			'slug'          => self::slug(),
			'version'       => $info['version'],
			'author'        => '<a href="https://getproservices.net">Get Pro Services</a>',
			'homepage'      => $info['homepage'] ?? 'https://getproservices.net',
			'requires'      => (string) ( $info['requires'] ?? '' ),
			'tested'        => (string) ( $info['tested'] ?? '' ),
			'requires_php'  => (string) ( $info['requires_php'] ?? '' ),
			'last_updated'  => (string) ( $info['last_updated'] ?? '' ),
			'download_link' => (string) ( $info['package'] ?? '' ),
			'sections'      => array(
				'description' => (string) ( $info['description'] ?? __( 'Enterprise ERP for WooCommerce — accounting, inventory, POS, couriers and payments.', 'wc-enterprise-erp' ) ),
				'changelog'   => (string) ( $info['changelog'] ?? '' ),
			),
		);
	}

	/** Drop the cache after any plugin update so the state is never stale. */
	public static function flush( $upgrader, $options ) {
		if ( isset( $options['action'], $options['type'] ) && 'update' === $options['action'] && 'plugin' === $options['type'] ) {
			delete_site_transient( self::CACHE );
		}
	}

	public static function row_meta( $links, $file ) {
		if ( self::basename() !== $file ) {
			return $links;
		}
		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wceerp_check_update' ), 'wceerp_check_update' ) ),
			esc_html__( 'Check for updates', 'wc-enterprise-erp' )
		);
		return $links;
	}

	public static function handle_manual_check() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_check_update' );

		delete_site_transient( self::CACHE );
		delete_site_transient( 'update_plugins' );
		self::remote_info( true );

		wp_safe_redirect( admin_url( 'plugins.php' ) );
		exit;
	}
}
