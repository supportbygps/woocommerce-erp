<?php
/**
 * Security layer.
 *
 * The ERP holds a business's entire financial record — ledger, payroll,
 * customer contact details, courier COD balances. A WordPress site is a
 * broad attack surface, so this class adds the controls that protect ERP
 * data specifically, on top of the per-module nonce and capability checks
 * that already guard every write.
 *
 * What it does, and why each piece exists:
 *
 *   1. SENSITIVE-ACCESS AUDIT. Records who opened accounting, payroll,
 *      dues and reports. Most breaches are discovered late; without a
 *      record of who looked at what, they are not discovered at all.
 *
 *   2. IDLE TIMEOUT. An ERP left open on a shop counter is an unlocked
 *      filing cabinet. After a period of inactivity the PIN is required
 *      again — data is never destroyed, only re-locked.
 *
 *   3. SECURITY HEADERS on ERP screens. Stops the ERP being framed by
 *      another site (clickjacking), limits referrer leakage of URLs that
 *      contain record ids, and blocks MIME sniffing.
 *
 *   4. EXPORT GUARD. Bulk export is how data actually leaves a business.
 *      Large exports are rate-limited and always recorded.
 *
 *   5. FAILED-LOGIN AWARENESS. Repeated failures against a site running
 *      the ERP are surfaced to the operator rather than buried in a log
 *      nobody reads.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Security {

	/** Screens whose access is worth recording. */
	const SENSITIVE = array( 'accounting', 'reports', 'hr', 'dues', 'payroll', 'staff', 'connect' );

	/** Re-lock the ERP after this long with no activity. */
	const IDLE_TIMEOUT = 1800; // 30 minutes

	public static function boot() {
		add_action( 'current_screen', array( __CLASS__, 'guard_erp_screen' ), 1 );
		// 'template_redirect' rather than 'send_headers': the latter fires
		// before $wp_query exists, so calling get_query_var() there is a
		// fatal error on every front-end request.
		add_action( 'template_redirect', array( __CLASS__, 'security_headers' ), 1 );
		add_action( 'admin_init', array( __CLASS__, 'security_headers' ) );
		add_action( 'wp_login_failed', array( __CLASS__, 'note_failed_login' ) );
		add_action( 'admin_notices', array( __CLASS__, 'security_notices' ) );
		add_filter( 'wceerp_can_export', array( __CLASS__, 'guard_export' ), 10, 2 );
	}

	/* ---------------------------------------------------------------------
	 * Idle timeout + access audit.
	 * ------------------------------------------------------------------- */

	public static function guard_erp_screen() {
		if ( ! is_admin() || wp_doing_ajax() || ! is_user_logged_in() ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( 0 !== strpos( $page, 'wceerp' ) ) {
			return;
		}

		$user_id = get_current_user_id();
		$key     = 'wceerp_last_seen_' . $user_id;
		$last    = (int) get_transient( $key );

		// Idle too long → drop the PIN unlock so it must be re-entered.
		if ( $last && ( time() - $last ) > self::IDLE_TIMEOUT && class_exists( 'WCEERP_Pin' ) ) {
			WCEERP_Pin::set_unlocked( false );
		}
		set_transient( $key, time(), 2 * HOUR_IN_SECONDS );

		// Record access to money and people screens.
		$module = str_replace( 'wceerp-', '', $page );
		if ( in_array( $module, self::SENSITIVE, true ) ) {
			self::record_access( $module );
		}
	}

	/**
	 * Log a view of a sensitive screen, at most once per session per
	 * screen — enough to answer "who looked at payroll", without filling
	 * the audit table with every page refresh.
	 */
	protected static function record_access( $module ) {
		$user_id = get_current_user_id();
		$once    = 'wceerp_acc_' . $user_id . '_' . $module;
		if ( get_transient( $once ) ) {
			return;
		}
		set_transient( $once, 1, HOUR_IN_SECONDS );
		if ( function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'security', 'viewed_' . $module, $user_id, self::client_ip() );
		}
	}

	/** Client IP, stored hashed — enough to correlate, not to track. */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return $ip ? substr( md5( $ip . wp_salt() ), 0, 12 ) : '';
	}

	/* ---------------------------------------------------------------------
	 * Headers.
	 * ------------------------------------------------------------------- */

	public static function security_headers() {
		if ( headers_sent() ) {
			return;
		}
		$is_erp = ( isset( $_GET['page'] ) && 0 === strpos( sanitize_key( $_GET['page'] ), 'wceerp' ) );

		// Query vars only exist once the main query has run. Guard on the
		// global rather than assuming, so this is safe on any hook.
		if ( ! $is_erp && isset( $GLOBALS['wp_query'] ) && $GLOBALS['wp_query'] instanceof WP_Query ) {
			$is_erp = (bool) get_query_var( 'wceerp_portal' ) || (bool) get_query_var( 'wceerp_pos' );
		}
		if ( ! $is_erp ) {
			return;
		}
		// Stop the ERP being embedded in someone else's page.
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		// URLs here carry record ids; do not leak them to third parties.
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: geolocation=(), microphone=(), camera=(self)' );
	}

	/* ---------------------------------------------------------------------
	 * Export guard.
	 * ------------------------------------------------------------------- */

	/**
	 * Bulk export is the realistic route for data to leave a business —
	 * a departing employee taking the customer list, for instance. Large
	 * exports are throttled and always recorded.
	 */
	public static function guard_export( $allowed, $row_count = 0 ) {
		if ( ! $allowed ) {
			return $allowed;
		}
		$user_id = get_current_user_id();
		$key     = 'wceerp_export_' . $user_id;
		$today   = (int) get_transient( $key );

		if ( $today > 20 ) {
			return new WP_Error(
				'wceerp_export_limit',
				__( 'You have run a lot of exports today. This is paused for a while as a safety measure — contact an administrator if you need to continue.', 'wc-enterprise-erp' )
			);
		}
		set_transient( $key, $today + 1, DAY_IN_SECONDS );
		if ( function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'security', 'export', $user_id, (int) $row_count . ' rows · ' . self::client_ip() );
		}
		return true;
	}

	/* ---------------------------------------------------------------------
	 * Failed logins.
	 * ------------------------------------------------------------------- */

	public static function note_failed_login( $username ) {
		$key   = 'wceerp_failed_logins';
		$count = (int) get_transient( $key ) + 1;
		set_transient( $key, $count, HOUR_IN_SECONDS );
		if ( 10 === $count && function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'security', 'failed_login_burst', 0, sanitize_user( $username ) );
		}
	}

	/* ---------------------------------------------------------------------
	 * Operator notices.
	 * ------------------------------------------------------------------- */

	public static function security_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( 0 !== strpos( $page, 'wceerp' ) ) {
			return;
		}

		$warnings = array();

		// Default PIN still in use.
		if ( class_exists( 'WCEERP_Pin' ) && WCEERP_Pin::is_default_pin() && ! WCEERP_Pin::is_enforced() ) {
			$warnings[] = __( 'The ERP PIN is still the default 1234.', 'wc-enterprise-erp' );
		}
		// Portal open without 2FA.
		if ( class_exists( 'WCEERP_Portal' ) && WCEERP_Portal::is_enabled()
			&& 'yes' !== wceerp_get_option( 'portal_2fa_required', 'no' ) ) {
			$warnings[] = __( 'The staff portal is on but two-factor is not required.', 'wc-enterprise-erp' );
		}
		// Connected-store credentials without a dedicated vault key.
		if ( class_exists( 'WCEERP_Vault' ) && class_exists( 'WCEERP_Module_Connect' )
			&& WCEERP_Module_Connect::is_configured() && ! WCEERP_Vault::has_dedicated_key() ) {
			$warnings[] = __( 'Connected-store credentials are encrypted with WordPress salts rather than a dedicated key.', 'wc-enterprise-erp' );
		}
		// Site not on HTTPS — everything else is moot without it.
		if ( ! is_ssl() && 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			$warnings[] = __( 'This site is not using HTTPS. Passwords and PINs travel in the clear.', 'wc-enterprise-erp' );
		}

		if ( ! $warnings ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'ERP security:', 'wc-enterprise-erp' ) . '</strong></p><ul style="margin:4px 0 8px 20px;list-style:disc">';
		foreach ( $warnings as $w ) {
			echo '<li>' . esc_html( $w ) . '</li>';
		}
		echo '</ul></div>';
	}
}
