<?php
/**
 * ERP data reset.
 *
 * For starting the books again after a false start — the usual case being a
 * shop that began selling through the ERP before recording opening stock, so
 * COGS posted at zero and the profit figures are meaningless.
 *
 * What it deliberately never touches:
 *   - WooCommerce orders, order items and customers
 *   - Products and their prices
 *   - The chart of accounts, warehouses, suppliers, dealers, staff
 *   - Settings, API keys and the audit trail
 *
 * It clears ERP *transactions* only. The shop's commercial record is left
 * exactly as it was, so nothing a customer or the tax office might ask for
 * is destroyed.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Reset {

	/**
	 * Groups of tables, each safe to clear independently.
	 *
	 * Order matters on execution: children before parents.
	 */
	public static function groups() {
		return array(
			'ledger' => array(
				'label'  => __( 'Ledger — journals and all postings', 'wc-enterprise-erp' ),
				'note'   => __( 'Every journal entry. The chart of accounts itself is kept.', 'wc-enterprise-erp' ),
				'tables' => array( 'journal_lines', 'journals' ),
			),
			'stock' => array(
				'label'  => __( 'Stock — balances, movements, batches and serials', 'wc-enterprise-erp' ),
				'note'   => __( 'Products are kept; their quantities and average costs are cleared so you can enter opening stock properly.', 'wc-enterprise-erp' ),
				'tables' => array( 'stock_moves', 'stock', 'batches', 'serials', 'productions' ),
			),
			'sales' => array(
				'label'  => __( 'ERP sales records — POS sales, shifts and refunds', 'wc-enterprise-erp' ),
				'note'   => __( 'The WooCommerce orders these created are NOT deleted.', 'wc-enterprise-erp' ),
				'tables' => array( 'pos_refunds', 'pos_sales', 'pos_shifts' ),
			),
			'courier' => array(
				'label'  => __( 'Courier — consignments and COD payouts', 'wc-enterprise-erp' ),
				'note'   => __( 'Parcels already with a courier will need re-entering.', 'wc-enterprise-erp' ),
				'tables' => array( 'consignments', 'courier_payouts' ),
			),
			'payments' => array(
				'label'  => __( 'Payments recorded against orders', 'wc-enterprise-erp' ),
				'note'   => __( 'Advances and part payments logged in the ERP.', 'wc-enterprise-erp' ),
				'tables' => array( 'order_payments' ),
			),
			'assets' => array(
				'label'  => __( 'Fixed assets and depreciation', 'wc-enterprise-erp' ),
				'note'   => __( 'Asset records and their depreciation schedules. These post journals, so leaving them behind an emptied ledger leaves them unbacked.', 'wc-enterprise-erp' ),
				'tables' => array( 'asset_depreciation', 'assets' ),
			),
			'hr' => array(
				'label'  => __( 'Payroll, commissions and salary advances', 'wc-enterprise-erp' ),
				'note'   => __( 'Employee records, attendance and leave are kept — only the money postings go.', 'wc-enterprise-erp' ),
				'tables' => array( 'payroll_items', 'payroll_runs', 'commissions', 'salary_advances' ),
			),
			'banking' => array(
				'label'  => __( 'Bank reconciliation lines', 'wc-enterprise-erp' ),
				'note'   => __( 'Imported statement lines matched against journals that would no longer exist.', 'wc-enterprise-erp' ),
				'tables' => array( 'bank_statement_lines' ),
			),
			'connect' => array(
				'label'  => __( 'Connected stores and reseller orders', 'wc-enterprise-erp' ),
				'note'   => __( 'Orders pulled in from connected shops and reseller records.', 'wc-enterprise-erp' ),
				'tables' => array( 'connect_costs', 'connect_orders', 'connect_log', 'resellers' ),
			),
			'purchases' => array(
				'label'  => __( 'Purchases and expenses', 'wc-enterprise-erp' ),
				'note'   => __( 'Supplier records themselves are kept.', 'wc-enterprise-erp' ),
				'tables' => array( 'purchase_items', 'purchase_approvals', 'purchases', 'expenses' ),
			),
		);
	}

	/** Row counts per group, so nothing is deleted unseen. */
	public static function preview() {
		global $wpdb;
		$out = array();
		foreach ( self::groups() as $key => $group ) {
			$total = 0;
			$per   = array();
			foreach ( $group['tables'] as $t ) {
				$name = wceerp_table( $t );
				if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) !== $name ) {
					continue;
				}
				$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name}" );
				$per[ $t ] = $n;
				$total    += $n;
			}
			$out[ $key ] = array( 'total' => $total, 'tables' => $per );
		}
		return $out;
	}

	/**
	 * Clear the selected groups.
	 *
	 * @param array $keys       Group keys.
	 * @param bool  $clear_meta Also clear the "already posted" markers on
	 *                          WooCommerce orders, so they could post again.
	 * @param bool  $reset_seq  Restart document numbering.
	 * @return array Summary of rows removed.
	 */
	public static function run( array $keys, $clear_meta = true, $reset_seq = false ) {
		global $wpdb;

		$groups  = self::groups();
		$removed = array();

		foreach ( $keys as $key ) {
			if ( ! isset( $groups[ $key ] ) ) {
				continue;
			}
			foreach ( $groups[ $key ]['tables'] as $t ) {
				$name = wceerp_table( $t );
				if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) !== $name ) {
					continue;
				}
				$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name}" );
				// TRUNCATE also resets AUTO_INCREMENT, which is what we want
				// for a clean restart of document references.
				$wpdb->query( "TRUNCATE TABLE {$name}" );
				$removed[ $t ] = $n;
			}
		}

		if ( $clear_meta ) {
			self::clear_order_markers();
		}
		if ( $reset_seq ) {
			self::clear_sequences();
		}

		// Opening COD is a posted journal; if the ledger went, so did it.
		if ( in_array( 'ledger', $keys, true ) ) {
			foreach ( array( 'cod_opening_total', 'cod_opening_journal', 'cod_opening_date', 'cod_opening_breakdown' ) as $opt ) {
				wceerp_update_option( $opt, '' );
			}
		}

		wceerp_log( 'settings', 'data_reset', 0, implode( ',', $keys ) . ' — ' . array_sum( $removed ) . ' rows' );

		return $removed;
	}

	/**
	 * Remove the ERP's markers from WooCommerce orders.
	 *
	 * Without this, every past order still counts as "already posted" and
	 * could never be recorded again. Handles both classic post meta and the
	 * HPOS orders-meta table.
	 */
	protected static function clear_order_markers() {
		global $wpdb;

		$keys = array(
			'_wceerp_posted',
			'_wceerp_reversed',
			'_wceerp_skipped_pre_golive',
			'_wceerp_cod_expected',
		);

		foreach ( $keys as $k ) {
			if ( function_exists( 'delete_post_meta_by_key' ) ) {
				delete_post_meta_by_key( $k );
			}
		}

		$hpos = $wpdb->prefix . 'wc_orders_meta';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hpos ) ) === $hpos ) {
			$in = "'" . implode( "','", array_map( 'esc_sql', $keys ) ) . "'";
			$wpdb->query( "DELETE FROM {$hpos} WHERE meta_key IN ({$in})" );
		}
	}

	/** Restart document numbering (invoices, consignments, purchases…). */
	protected static function clear_sequences() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'wceerp_seq_%'" );
	}
}
