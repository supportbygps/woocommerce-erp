<?php
/**
 * Encrypted credential vault.
 *
 * Connected-store API keys are the crown jewels of this SaaS: one key
 * can read every customer record on a tenant's live shop and, with write
 * scope, change their stock. Storing them as plain options means a
 * database dump, a stray backup, or a compromised tenant admin hands an
 * attacker working credentials to somebody else's business.
 *
 * This vault encrypts secrets at rest with AES-256-GCM. The encryption
 * key is derived from a constant in wp-config.php (WCEERP_VAULT_KEY),
 * which lives outside the database — so a stolen dump is not enough to
 * decrypt anything.
 *
 * Setup (once, on the SaaS server):
 *
 *   define( 'WCEERP_VAULT_KEY', '<64 random hex chars>' );
 *
 * Generate one with:  wp eval "echo bin2hex(random_bytes(32));"
 *
 * Without the constant the vault falls back to WordPress's own salts so
 * nothing breaks, but it says so loudly in the admin — because salts are
 * also in wp-config, yet are more likely to be rotated or shared.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Vault {

	const CIPHER = 'aes-256-gcm';
	const PREFIX = 'wceerp_v1:';

	/** True when a dedicated vault key is configured. */
	public static function has_dedicated_key() {
		return defined( 'WCEERP_VAULT_KEY' ) && strlen( (string) WCEERP_VAULT_KEY ) >= 32;
	}

	/** True when the platform can encrypt at all. */
	public static function available() {
		return function_exists( 'openssl_encrypt' ) && in_array( self::CIPHER, (array) openssl_get_cipher_methods(), true );
	}

	/**
	 * 32-byte key. Prefers the dedicated constant; falls back to WordPress
	 * salts so an un-configured install still encrypts rather than storing
	 * plaintext.
	 */
	protected static function key() {
		if ( self::has_dedicated_key() ) {
			$raw = (string) WCEERP_VAULT_KEY;
			// Accept hex or raw; normalise to 32 bytes.
			if ( ctype_xdigit( $raw ) && 64 === strlen( $raw ) ) {
				return hex2bin( $raw );
			}
			return hash( 'sha256', $raw, true );
		}
		$fallback = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' );
		return hash( 'sha256', 'wceerp-vault|' . $fallback, true );
	}

	/**
	 * Encrypt a secret for storage. Returns a self-describing string:
	 *   wceerp_v1:<base64(iv|tag|ciphertext)>
	 * Returns the plaintext unchanged if encryption isn't available, so
	 * the caller never loses data on a misconfigured host.
	 */
	public static function encrypt( $plaintext ) {
		$plaintext = (string) $plaintext;
		if ( '' === $plaintext || ! self::available() ) {
			return $plaintext;
		}
		$iv  = random_bytes( 12 ); // 96-bit nonce, the GCM standard.
		$tag = '';
		$ct  = openssl_encrypt( $plaintext, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16 );
		if ( false === $ct ) {
			return $plaintext;
		}
		return self::PREFIX . base64_encode( $iv . $tag . $ct );
	}

	/** Decrypt a stored value. Values without the prefix are returned as-is. */
	public static function decrypt( $stored ) {
		$stored = (string) $stored;
		if ( '' === $stored || 0 !== strpos( $stored, self::PREFIX ) ) {
			return $stored; // legacy plaintext or empty
		}
		if ( ! self::available() ) {
			return '';
		}
		$blob = base64_decode( substr( $stored, strlen( self::PREFIX ) ), true );
		if ( false === $blob || strlen( $blob ) < 29 ) {
			return '';
		}
		$iv  = substr( $blob, 0, 12 );
		$tag = substr( $blob, 12, 16 );
		$ct  = substr( $blob, 28 );
		$out = openssl_decrypt( $ct, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv, $tag );
		return false === $out ? '' : $out;
	}

	/** Is this stored value already encrypted? */
	public static function is_encrypted( $stored ) {
		return 0 === strpos( (string) $stored, self::PREFIX );
	}

	/**
	 * Mask a secret for display — never echo a live key back to a screen.
	 * Shows only enough to recognise which key is configured.
	 */
	public static function mask( $secret ) {
		$secret = (string) $secret;
		$len    = strlen( $secret );
		if ( $len < 8 ) {
			return $len ? str_repeat( '•', $len ) : '';
		}
		return substr( $secret, 0, 4 ) . str_repeat( '•', 8 ) . substr( $secret, -4 );
	}

	/**
	 * Admin warning when secrets are protected only by WordPress salts.
	 * Deliberately visible: an operator running a multi-tenant SaaS should
	 * know the difference.
	 */
	public static function config_notice() {
		if ( self::has_dedicated_key() || ! current_user_can( 'manage_options' ) ) {
			return '';
		}
		if ( ! self::available() ) {
			return __( 'OpenSSL is unavailable on this server, so connected-store credentials cannot be encrypted at rest. Contact your host before connecting live customer stores.', 'wc-enterprise-erp' );
		}
		return __( 'Connected-store credentials are encrypted using WordPress salts. For a multi-tenant deployment, add a dedicated key to wp-config.php: define( \'WCEERP_VAULT_KEY\', \'<64 random hex characters>\' );', 'wc-enterprise-erp' );
	}
}
