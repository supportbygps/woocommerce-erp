<?php
/**
 * Progressive Web App support for the staff portal.
 *
 * Makes /erp installable, so staff get a home-screen icon that opens
 * full-screen with no browser chrome — it behaves like an installed app
 * without an app store.
 *
 * Three pieces are required:
 *
 *   1. A manifest declaring name, icons, colours and display mode. This
 *      is what makes a browser offer "Install".
 *   2. A service worker that caches the shell so the app opens instantly
 *      and shows something useful when the connection drops.
 *   3. HTTPS. Browsers refuse to install a PWA otherwise.
 *
 * HONEST LIMIT ON OFFLINE. ERP screens are rendered by PHP on the server.
 * A service worker can cache the shell and static assets; it cannot
 * render inventory or reports without a connection. So offline gives a
 * branded "you are offline" screen, not a working ERP.
 *
 * The exception is the POS terminal, which already has its own offline
 * engine with local storage and sync — that keeps selling. The offline
 * page points staff there when it is available.
 *
 * The caching strategy is deliberately NETWORK-FIRST for pages: an ERP
 * showing yesterday's stock figures from a cache would be worse than
 * showing nothing. Static assets are cache-first because they only change
 * when the plugin version does.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_PWA {

	const QUERY_VAR = 'wceerp_pwa';

	public static function boot() {
		// Priority 5: PWA rules must be registered before the portal's
		// self-heal (priority 10) checks whether they are present.
		add_action( 'init', array( __CLASS__, 'add_routes' ), 5 );
		add_filter( 'query_vars', array( __CLASS__, 'add_query_var' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 4 );
	}

	public static function add_query_var( $vars ) {
		$vars[] = self::QUERY_VAR;
		// Without this the icon size never reaches serve_icon(), icons 404,
		// and the browser silently refuses to offer installation.
		$vars[] = 'wceerp_size';
		return $vars;
	}

	public static function add_routes() {
		if ( ! class_exists( 'WCEERP_Portal' ) ) {
			return;
		}
		$slug = WCEERP_Portal::slug();
		add_rewrite_rule( '^' . $slug . '/manifest\.json$', 'index.php?' . self::QUERY_VAR . '=manifest', 'top' );
		add_rewrite_rule( '^' . $slug . '/sw\.js$', 'index.php?' . self::QUERY_VAR . '=sw', 'top' );
		add_rewrite_rule( '^' . $slug . '/offline$', 'index.php?' . self::QUERY_VAR . '=offline', 'top' );
		add_rewrite_rule( '^' . $slug . '/icon-([0-9]+)\.png$', 'index.php?' . self::QUERY_VAR . '=icon&wceerp_size=$matches[1]', 'top' );
	}

	protected static function base() {
		return class_exists( 'WCEERP_Portal' ) ? WCEERP_Portal::url() : home_url( '/erp' );
	}

	protected static function brand() {
		return apply_filters( 'wceerp_brand', 'WooCommerce ERP' );
	}

	/** Short name has to survive under a home-screen icon — keep it tight. */
	protected static function short_name() {
		$name = get_bloginfo( 'name' );
		return mb_substr( $name ?: 'ERP', 0, 12 );
	}

	protected static function theme_colour() {
		// Kept in step with the portal accent so the installed icon, splash
		// screen and status bar match the app the user actually sees.
		return apply_filters( 'wceerp_pwa_theme_colour', '#5b3df5' );
	}

	public static function maybe_serve() {
		$what = get_query_var( self::QUERY_VAR );
		if ( ! $what ) {
			return;
		}
		switch ( $what ) {
			case 'manifest':
				self::serve_manifest();
				break;
			case 'sw':
				self::serve_service_worker();
				break;
			case 'offline':
				self::serve_offline();
				break;
			case 'icon':
				self::serve_icon( (int) get_query_var( 'wceerp_size' ) );
				break;
			default:
				return;
		}
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Manifest.
	 * ------------------------------------------------------------------- */

	protected static function serve_manifest() {
		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );

		$base = trailingslashit( self::base() );
		$manifest = array(
			'name'             => get_bloginfo( 'name' ) . ' — ERP',
			'short_name'       => self::short_name(),
			'description'      => __( 'Business management: sales, stock, courier and accounts.', 'wc-enterprise-erp' ),
			'start_url'        => $base,
			// Scoped to the portal only. Installing the whole storefront as
			// an app would confuse staff and customers alike.
			'scope'            => $base,
			'display'          => 'standalone',
			'orientation'      => 'any',
			'background_color' => '#f6f7fb',
			'theme_color'      => self::theme_colour(),
			'lang'             => get_bloginfo( 'language' ),
			'dir'              => is_rtl() ? 'rtl' : 'ltr',
			'icons'            => array(
				array(
					'src'     => $base . 'icon-192.png',
					'sizes'   => '192x192',
					'type'    => 'image/png',
					'purpose' => 'any',
				),
				array(
					'src'     => $base . 'icon-512.png',
					'sizes'   => '512x512',
					'type'    => 'image/png',
					'purpose' => 'any maskable',
				),
			),
		);

		// Shortcuts appear on long-press of the home-screen icon.
		$shortcuts = array();
		if ( function_exists( 'wceerp' ) && method_exists( wceerp(), 'modules' ) ) {
			$modules = (array) wceerp()->modules();
			if ( isset( $modules['pos'] ) && $modules['pos']->is_active() ) {
				$shortcuts[] = array(
					'name'  => __( 'POS', 'wc-enterprise-erp' ),
					'url'   => home_url( '/wceerp-pos' ),
					'icons' => array( array( 'src' => $base . 'icon-192.png', 'sizes' => '192x192' ) ),
				);
			}
			if ( isset( $modules['expenses'] ) && $modules['expenses']->is_active() ) {
				$shortcuts[] = array(
					'name' => __( 'Record expense', 'wc-enterprise-erp' ),
					'url'  => $base . 'expenses',
				);
			}
		}
		if ( $shortcuts ) {
			$manifest['shortcuts'] = $shortcuts;
		}

		echo wp_json_encode( apply_filters( 'wceerp_pwa_manifest', $manifest ) );
	}

	/* ---------------------------------------------------------------------
	 * Service worker.
	 * ------------------------------------------------------------------- */

	protected static function serve_service_worker() {
		nocache_headers();
		header( 'Content-Type: application/javascript; charset=utf-8' );
		// Scope header lets a worker served from /erp/ control that path.
		header( 'Service-Worker-Allowed: ' . wp_parse_url( trailingslashit( self::base() ), PHP_URL_PATH ) );

		$base    = trailingslashit( self::base() );
		$version = defined( 'WCEERP_VERSION' ) ? WCEERP_VERSION : '1';
		$offline = $base . 'offline';
		?>
/* WooCommerce ERP — service worker (v<?php echo esc_js( $version ); ?>) */
var CACHE = 'wceerp-shell-v<?php echo esc_js( $version ); ?>';
var OFFLINE_URL = '<?php echo esc_js( $offline ); ?>';
var SHELL = [
	OFFLINE_URL,
	'<?php echo esc_js( $base ); ?>icon-192.png',
	'<?php echo esc_js( $base ); ?>icon-512.png'
];

self.addEventListener('install', function (e) {
	// Pre-cache the offline page and icons so the app always has
	// something to show, then take over immediately.
	e.waitUntil(
		caches.open(CACHE).then(function (c) { return c.addAll(SHELL); })
			.then(function () { return self.skipWaiting(); })
	);
});

self.addEventListener('activate', function (e) {
	// Drop caches from older plugin versions so a stale shell can never
	// outlive an upgrade.
	e.waitUntil(
		caches.keys().then(function (keys) {
			return Promise.all(keys.map(function (k) {
				if (k !== CACHE) { return caches.delete(k); }
			}));
		}).then(function () { return self.clients.claim(); })
	);
});

self.addEventListener('fetch', function (e) {
	var req = e.request;

	// Only GET, only same-origin. Never interfere with form posts —
	// a cached response to a POST could silently lose a sale.
	if (req.method !== 'GET') { return; }
	if (new URL(req.url).origin !== self.location.origin) { return; }

	var isAsset = /\.(css|js|png|jpg|jpeg|svg|woff2?|ttf)$/i.test(req.url);

	if (isAsset) {
		// Assets change only with the plugin version: cache first.
		e.respondWith(
			caches.match(req).then(function (hit) {
				return hit || fetch(req).then(function (res) {
					var copy = res.clone();
					caches.open(CACHE).then(function (c) { c.put(req, copy); });
					return res;
				});
			})
		);
		return;
	}

	// Pages: network first. Showing yesterday's stock figures from a
	// cache would be worse than showing nothing at all.
	e.respondWith(
		fetch(req).catch(function () {
			return caches.match(req).then(function (hit) {
				return hit || caches.match(OFFLINE_URL);
			});
		})
	);
});
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Offline page.
	 * ------------------------------------------------------------------- */

	protected static function serve_offline() {
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		$pos_on = false;
		if ( function_exists( 'wceerp' ) && method_exists( wceerp(), 'modules' ) ) {
			$modules = (array) wceerp()->modules();
			$pos_on  = isset( $modules['pos'] ) && $modules['pos']->is_active();
		}
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<title><?php esc_html_e( 'Offline', 'wc-enterprise-erp' ); ?></title>
	<style>
		*{box-sizing:border-box}
		body{margin:0;min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center;
			padding:24px;background:#f4f6f5;color:#111a17;
			font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}
		.box{background:#fff;border:1px solid #e4e8e5;border-radius:20px;padding:34px 26px;
			max-width:380px;width:100%;text-align:center;box-shadow:0 10px 40px rgba(16,24,20,.08)}
		.ic{font-size:44px;line-height:1;margin-bottom:14px}
		h1{font-size:19px;margin:0 0 8px}
		p{color:#5f6b66;font-size:14px;line-height:1.6;margin:0 0 18px}
		a.btn{display:block;background:#075742;color:#fff;text-decoration:none;padding:13px;
			border-radius:12px;font-weight:650;font-size:15px;margin-bottom:9px}
		a.ghost{background:#fff;color:#075742;border:1.5px solid #075742}
		small{color:#8e9a95;font-size:12px}
	</style>
</head>
<body>
	<div class="box">
		<div class="ic">📡</div>
		<h1><?php esc_html_e( 'No connection', 'wc-enterprise-erp' ); ?></h1>
		<p>
			<?php esc_html_e( 'The ERP needs a connection to show live figures — stock, orders and accounts all come from the server.', 'wc-enterprise-erp' ); ?>
		</p>
		<?php if ( $pos_on ) : ?>
			<p><strong><?php esc_html_e( 'You can still sell.', 'wc-enterprise-erp' ); ?></strong>
			<?php esc_html_e( 'The POS keeps working offline and syncs when you are back.', 'wc-enterprise-erp' ); ?></p>
			<a class="btn" href="<?php echo esc_url( home_url( '/wceerp-pos' ) ); ?>"><?php esc_html_e( 'Open POS', 'wc-enterprise-erp' ); ?></a>
		<?php endif; ?>
		<a class="btn ghost" href="<?php echo esc_url( self::base() ); ?>" onclick="location.reload();return false;"><?php esc_html_e( 'Try again', 'wc-enterprise-erp' ); ?></a>
		<small><?php echo esc_html( self::brand() ); ?></small>
	</div>
	<script>
		// Reload automatically the moment the connection returns.
		window.addEventListener('online', function () { location.href = '<?php echo esc_js( self::base() ); ?>'; });
	</script>
</body>
</html>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Icons.
	 *
	 * Generated from the brand colour and initials so a fresh install is
	 * installable straight away with no asset pipeline. An operator can
	 * override with a real logo through the filter below.
	 * ------------------------------------------------------------------- */

	protected static function serve_icon( $size ) {
		$size = in_array( $size, array( 192, 512 ), true ) ? $size : 192;

		$custom = apply_filters( 'wceerp_pwa_icon_url', '', $size );
		if ( $custom ) {
			wp_safe_redirect( $custom, 302 );
			exit;
		}

		if ( ! function_exists( 'imagecreatetruecolor' ) ) {
			// No GD: fall back to a flat SVG, which every browser renders.
			header( 'Content-Type: image/svg+xml; charset=utf-8' );
			$initials = esc_html( mb_strtoupper( mb_substr( self::short_name(), 0, 2 ) ) );
			echo '<svg xmlns="http://www.w3.org/2000/svg" width="' . (int) $size . '" height="' . (int) $size . '">'
				. '<rect width="100%" height="100%" rx="' . (int) ( $size * 0.22 ) . '" fill="' . esc_attr( self::theme_colour() ) . '"/>'
				. '<text x="50%" y="50%" dy=".35em" text-anchor="middle" fill="#ffffff" '
				. 'font-family="Arial,Helvetica,sans-serif" font-weight="bold" font-size="' . (int) ( $size * 0.36 ) . '">'
				. $initials . '</text></svg>';
			return;
		}

		header( 'Content-Type: image/png' );
		header( 'Cache-Control: public, max-age=604800' );

		$img = imagecreatetruecolor( $size, $size );
		imagesavealpha( $img, true );

		// Brand colour background.
		list( $r, $g, $b ) = sscanf( self::theme_colour(), '#%02x%02x%02x' );
		$bg = imagecolorallocate( $img, (int) $r, (int) $g, (int) $b );
		imagefilledrectangle( $img, 0, 0, $size, $size, $bg );

		// Initials, centred with the built-in font scaled up.
		$white    = imagecolorallocate( $img, 255, 255, 255 );
		$initials = mb_strtoupper( mb_substr( self::short_name(), 0, 2 ) );
		$font     = 5;
		$scale    = max( 1, (int) round( $size / 40 ) );
		$tmp_w    = imagefontwidth( $font ) * strlen( $initials );
		$tmp_h    = imagefontheight( $font );
		$tmp      = imagecreatetruecolor( $tmp_w, $tmp_h );
		$tmp_bg   = imagecolorallocate( $tmp, (int) $r, (int) $g, (int) $b );
		imagefilledrectangle( $tmp, 0, 0, $tmp_w, $tmp_h, $tmp_bg );
		imagestring( $tmp, $font, 0, 0, $initials, imagecolorallocate( $tmp, 255, 255, 255 ) );
		imagecopyresampled(
			$img, $tmp,
			(int) ( ( $size - $tmp_w * $scale ) / 2 ),
			(int) ( ( $size - $tmp_h * $scale ) / 2 ),
			0, 0,
			$tmp_w * $scale, $tmp_h * $scale,
			$tmp_w, $tmp_h
		);
		imagedestroy( $tmp );
		unset( $white );

		imagepng( $img );
		imagedestroy( $img );
	}

	/* ---------------------------------------------------------------------
	 * Head tags + install prompt, printed inside the portal shell.
	 * ------------------------------------------------------------------- */

	public static function head_tags() {
		$base = trailingslashit( self::base() );
		?>
		<link rel="manifest" href="<?php echo esc_url( $base . 'manifest.json' ); ?>">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
		<meta name="apple-mobile-web-app-title" content="<?php echo esc_attr( self::short_name() ); ?>">
		<link rel="apple-touch-icon" href="<?php echo esc_url( $base . 'icon-192.png' ); ?>">
		<link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( $base . 'icon-192.png' ); ?>">
		<?php
	}

	public static function install_script() {
		$base = trailingslashit( self::base() );
		?>
		<style>
			.pwa-install{position:fixed;left:14px;right:14px;bottom:calc(14px + env(safe-area-inset-bottom));
				background:#111a17;color:#fff;border-radius:14px;padding:13px 15px;display:none;
				align-items:center;gap:12px;z-index:60;box-shadow:0 12px 34px rgba(0,0,0,.28);max-width:520px;margin:0 auto}
			.pwa-install .t{flex:1;font-size:13.5px;line-height:1.4}
			.pwa-install button{border:0;border-radius:9px;padding:9px 14px;font-size:13px;font-weight:650;cursor:pointer}
			.pwa-install .yes{background:#25d366;color:#fff}
			.pwa-install .no{background:transparent;color:#8e9a95}
		</style>
		<div class="pwa-install" id="pwa-install">
			<span class="t"><?php esc_html_e( 'Add this to your home screen for quick access.', 'wc-enterprise-erp' ); ?></span>
			<button class="yes" id="pwa-yes"><?php esc_html_e( 'Install', 'wc-enterprise-erp' ); ?></button>
			<button class="no" id="pwa-no"><?php esc_html_e( 'Later', 'wc-enterprise-erp' ); ?></button>
		</div>
		<script>
		(function () {
			if ('serviceWorker' in navigator) {
				navigator.serviceWorker.register('<?php echo esc_js( $base ); ?>sw.js', { scope: '<?php echo esc_js( wp_parse_url( $base, PHP_URL_PATH ) ); ?>' })
					.catch(function (e) { /* registration failure must never break the page */ });
			}

			var prompt = null;
			var bar = document.getElementById('pwa-install');
			// Respect a previous dismissal for a week.
			var snoozed = localStorage.getItem('wceerp_pwa_snooze');
			var isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;

			window.addEventListener('beforeinstallprompt', function (e) {
				e.preventDefault();
				prompt = e;
				if (!isStandalone && (!snoozed || Date.now() > Number(snoozed))) {
					bar.style.display = 'flex';
				}
			});

			document.getElementById('pwa-yes').addEventListener('click', function () {
				bar.style.display = 'none';
				if (prompt) { prompt.prompt(); prompt = null; }
			});
			document.getElementById('pwa-no').addEventListener('click', function () {
				bar.style.display = 'none';
				localStorage.setItem('wceerp_pwa_snooze', String(Date.now() + 7 * 864e5));
			});

			// iOS gives no install event, so show manual guidance once.
			var isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
			if (isIOS && !isStandalone && (!snoozed || Date.now() > Number(snoozed))) {
				bar.querySelector('.t').textContent = <?php echo wp_json_encode( __( 'Tap Share, then "Add to Home Screen" to install.', 'wc-enterprise-erp' ) ); ?>;
				document.getElementById('pwa-yes').style.display = 'none';
				bar.style.display = 'flex';
			}
		})();
		</script>
		<?php
	}
}
