<?php
/**
 * ERP PIN gate.
 *
 * A second lock in front of the whole ERP, on top of WordPress login and
 * ERP capabilities. Any admin user who can reach the ERP menu must enter
 * a shared 4-digit PIN before seeing a single ERP screen. This keeps
 * accounting, profit, payroll and dues away from staff who share a
 * browser or a WordPress account but shouldn't see the money.
 *
 * Model (as configured):
 *   - ONE shared PIN for the whole ERP. Default 1234 on a fresh install
 *     (Starter). The owner changes it in Modules & Settings.
 *   - Wrong / no PIN → blocked entirely; no ERP screen renders.
 *   - Unlock lasts only while the user stays on ERP pages. The moment
 *     they load any non-ERP admin page, the unlock is cleared, so
 *     returning to the ERP asks for the PIN again.
 *
 * The PIN is stored hashed (wp_hash_password); the unlock flag lives in
 * the PHP session-like transient keyed to the user, never in a cookie
 * the user can forge.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Pin {

	const OPT_HASH    = 'wceerp_pin_hash';
	const DEFAULT_PIN = '1234';

	/** Per-user unlock flag (transient). Short TTL is a safety net; the
	 * real expiry is "left the ERP", enforced on every admin page load. */
	protected static function unlock_key() {
		return 'wceerp_pin_ok_' . get_current_user_id();
	}

	public static function boot() {
		add_action( 'current_screen', array( __CLASS__, 'guard' ) );
		add_action( 'admin_post_wceerp_pin_submit', array( __CLASS__, 'handle_submit' ) );
		add_action( 'admin_post_wceerp_pin_change', array( __CLASS__, 'handle_change' ) );
		add_action( 'admin_post_wceerp_pin_reset', array( __CLASS__, 'handle_reset' ) );
	}

	/** Is the currently requested admin page an ERP page? */
	public static function is_erp_page() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, 'wceerp' ) ) {
			return true;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		return $page && 0 === strpos( $page, 'wceerp' );
	}

	/** Marker showing the user has stepped away from the ERP. */
	protected static function grace_key() {
		return 'wceerp_pin_grace_' . get_current_user_id();
	}

	/**
	 * How long an unlock survives after leaving the ERP screens.
	 *
	 * Re-locking the instant someone opens Products or Media made the PIN
	 * infuriating in normal use -- staff hop in and out of WooCommerce
	 * constantly. A short grace window keeps the protection meaningful
	 * against a walked-away-from screen while removing the nuisance.
	 */
	public static function grace_seconds() {
		$mins = (int) wceerp_get_option( 'pin_grace_minutes', 5 );
		$mins = max( 0, min( 120, $mins ) );
		return (int) apply_filters( 'wceerp_pin_grace', $mins * MINUTE_IN_SECONDS );
	}

	/**
	 * Is the PIN gate switched on at all?
	 *
	 * A single-operator shop finds re-entering a PIN every session pure
	 * friction, and the gate protects nothing there — anyone reaching these
	 * screens already signed into WordPress with an ERP capability. A shop
	 * with counter staff on a shared terminal wants the opposite. So it is
	 * a choice, not a rule.
	 *
	 * A PIN enforced from the licence server always wins: that exists for
	 * shop owners who want their own staff unable to switch it off.
	 */
	public static function enabled() {
		if ( function_exists( 'wceerp_get_option' ) && wceerp_get_option( 'remote_pin', '' ) ) {
			return true;
		}
		$setting = function_exists( 'wceerp_get_option' ) ? wceerp_get_option( 'pin_enabled', 'yes' ) : 'yes';
		return 'no' !== $setting;
	}

	public static function is_unlocked() {
		// Switched off means permanently unlocked.
		if ( ! self::enabled() ) {
			return true;
		}
		return (bool) get_transient( self::unlock_key() );
	}

	public static function set_unlocked( $on ) {
		if ( $on ) {
			set_transient( self::unlock_key(), 1, 8 * HOUR_IN_SECONDS );
			delete_transient( self::grace_key() );
		} else {
			delete_transient( self::unlock_key() );
			delete_transient( self::grace_key() );
		}
	}

	/**
	 * Vendor-enforced PIN.
	 *
	 * When a licence carries a PIN, it is authoritative: the customer
	 * cannot change it, and the default 1234 stops working. Passing an
	 * empty value clears the enforcement and hands control back.
	 */
	public static function apply_remote_pin( $pin ) {
		$pin = preg_replace( '/\D/', '', (string) $pin );
		if ( 4 === strlen( $pin ) ) {
			update_option( 'wceerp_pin_remote', wp_hash_password( $pin ), false );
			update_option( 'wceerp_pin_enforced', 1, false );
			// Drop any active unlocks so the new PIN takes effect at once.
			delete_transient( self::unlock_key() );
		} else {
			delete_option( 'wceerp_pin_remote' );
			delete_option( 'wceerp_pin_enforced' );
		}
	}

	/** Is the PIN being enforced by the vendor licence? */
	public static function is_enforced() {
		return (bool) get_option( 'wceerp_pin_enforced', 0 ) && get_option( 'wceerp_pin_remote', '' );
	}

	/** Stored hash, seeding the default PIN on first run. */
	protected static function hash() {
		// A vendor-enforced PIN wins over anything stored locally.
		if ( self::is_enforced() ) {
			return get_option( 'wceerp_pin_remote', '' );
		}
		$hash = get_option( self::OPT_HASH, '' );
		if ( ! $hash ) {
			$hash = wp_hash_password( self::DEFAULT_PIN );
			update_option( self::OPT_HASH, $hash );
		}
		return $hash;
	}

	public static function check_pin( $pin ) {
		return wp_check_password( (string) $pin, self::hash() );
	}

	public static function is_default_pin() {
		return wp_check_password( self::DEFAULT_PIN, self::hash() );
	}

	/**
	 * The guard. Runs on every admin page:
	 *   - Not an ERP page → clear the unlock (so leaving re-locks) and let
	 *     WordPress render normally.
	 *   - ERP page, already unlocked → allow.
	 *   - ERP page, locked → render the PIN screen and stop.
	 */
	public static function guard() {
		if ( ! is_admin() || wp_doing_ajax() ) {
			return;
		}
		if ( ! self::is_erp_page() ) {
			/* Left the ERP. Rather than locking instantly, start a short
			 * countdown: come back within the grace window and the unlock
			 * still stands; stay away longer and it expires by itself. */
			if ( self::is_unlocked() ) {
				$grace = self::grace_seconds();
				if ( $grace <= 0 ) {
					self::set_unlocked( false );
				} elseif ( ! get_transient( self::grace_key() ) ) {
					set_transient( self::grace_key(), 1, $grace );
					set_transient( self::unlock_key(), 1, $grace );
				}
			}
			return;
		}
		if ( self::is_unlocked() ) {
			// Back on an ERP screen: cancel the countdown and restore the
			// full session length.
			if ( get_transient( self::grace_key() ) ) {
				delete_transient( self::grace_key() );
				set_transient( self::unlock_key(), 1, 8 * HOUR_IN_SECONDS );
			}
			return;
		}
		self::render_lock_screen();
		exit;
	}

	public static function handle_submit() {
		if ( ! is_user_logged_in() || ! check_admin_referer( 'wceerp_pin_submit' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		$pin    = preg_replace( '/\D/', '', (string) ( $_POST['pin'] ?? '' ) );
		$return = isset( $_POST['return'] ) ? esc_url_raw( wp_unslash( $_POST['return'] ) ) : admin_url( 'admin.php?page=wceerp' );
		if ( self::check_pin( $pin ) ) {
			self::set_unlocked( true );
		} else {
			$return = add_query_arg( 'wceerp_pin', 'bad', $return );
		}
		wp_safe_redirect( $return );
		exit;
	}

	public static function handle_change() {
		if ( ! check_admin_referer( 'wceerp_pin_change' ) || ! wceerp_user_can( 'wceerp_manage_settings' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		$current = preg_replace( '/\D/', '', (string) ( $_POST['current_pin'] ?? '' ) );
		$new     = preg_replace( '/\D/', '', (string) ( $_POST['new_pin'] ?? '' ) );
		$args    = array( 'page' => 'wceerp-settings' );
		if ( self::is_enforced() ) {
			$args['pin_err'] = 'enforced';
			wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
			exit;
		}
		if ( ! self::check_pin( $current ) ) {
			$args['pin_err'] = 'current';
		} elseif ( strlen( $new ) !== 4 ) {
			$args['pin_err'] = 'len';
		} else {
			update_option( self::OPT_HASH, wp_hash_password( $new ) );
			$args['pin_ok'] = 1;
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function handle_reset() {
		if ( ! check_admin_referer( 'wceerp_pin_reset' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'wc-enterprise-erp' ) );
		}
		if ( self::is_enforced() ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'wceerp-settings', 'pin_err' => 'enforced' ), admin_url( 'admin.php' ) ) );
			exit;
		}
		update_option( self::OPT_HASH, wp_hash_password( self::DEFAULT_PIN ) );
		self::set_unlocked( false );
		wp_safe_redirect( add_query_arg( array( 'page' => 'wceerp-settings', 'pin_reset' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Full-screen PIN entry, styled to match the ERP. */
	protected static function render_lock_screen() {
		$return = esc_url( ( is_ssl() ? 'https://' : 'http://' ) . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' ) );
		$bad    = isset( $_GET['wceerp_pin'] ) && 'bad' === $_GET['wceerp_pin'];
		$brand  = function_exists( 'apply_filters' ) ? apply_filters( 'wceerp_brand', 'WooCommerce ERP' ) : 'WooCommerce ERP';
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php esc_html_e( 'Enter ERP PIN', 'wc-enterprise-erp' ); ?></title>
			<style>
				body{margin:0;font-family:-apple-system,'Segoe UI',Roboto,Arial,sans-serif;background:linear-gradient(135deg,#063f30,#0a6e54);min-height:100vh;display:flex;align-items:center;justify-content:center}
				.box{background:#fff;border-radius:18px;padding:34px 30px;width:330px;box-shadow:0 20px 60px rgba(0,0,0,.3);text-align:center}
				.logo{width:52px;height:52px;border-radius:13px;background:linear-gradient(135deg,#075742,#0a6e54);color:#fff;font-weight:800;font-size:22px;display:flex;align-items:center;justify-content:center;margin:0 auto 14px}
				h1{font-size:17px;margin:0 0 4px;color:#1f2430}
				p.sub{color:#8a8f98;font-size:13px;margin:0 0 20px}
				.pin-in{width:100%;font-size:34px;letter-spacing:18px;text-align:center;padding:12px 0 12px 18px;border:2px solid #dcdcd4;border-radius:12px;font-weight:700;color:#075742}
				.pin-in:focus{outline:0;border-color:#0a6e54}
				.err{color:#c8302e;font-size:13px;margin:12px 0 0;min-height:18px}
				button{margin-top:16px;width:100%;background:#075742;color:#fff;border:0;border-radius:12px;padding:13px;font-size:15px;font-weight:600;cursor:pointer}
				button:hover{background:#0a6e54}
				.pad{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-top:16px}
				.pad button{margin:0;background:#f3f4f2;color:#1f2430;font-size:19px;padding:15px 0;border-radius:11px}
				.pad button:hover{background:#e6e8e4}
				.pad .wide{grid-column:span 1}
				.logo-img{max-width:210px;height:auto;margin:0 auto 18px;display:block}
				.foot{margin-top:16px;font-size:12px;color:#a2a7ae}
				.foot a{color:#075742;text-decoration:none}
			</style>
		</head>
		<body>
			<div class="box">
				<?php
				/* Prefer a real logo. White-label branding wins, then the
				 * bundled mark, then the two-letter initials fallback so the
				 * screen never looks broken if an image is missing. */
				$logo_url = apply_filters( 'wceerp_pin_logo', '' );
				if ( ! $logo_url ) {
					$wl = function_exists( 'wceerp_get_option' ) ? wceerp_get_option( 'whitelabel_logo', '' ) : '';
					if ( $wl ) {
						$logo_url = $wl;
					} elseif ( file_exists( WCEERP_PATH . 'assets/branding/logo.png' ) ) {
						$logo_url = WCEERP_URL . 'assets/branding/logo.png';
					}
				}
				?>
				<?php if ( $logo_url ) : ?>
					<?php /* The logo already carries the name, so repeating it
					         as a heading just crowds a small screen. The alt
					         text keeps it available to screen readers. */ ?>
					<img class="logo-img" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $brand ); ?>">
				<?php else : ?>
					<div class="logo"><?php echo esc_html( mb_substr( $brand, 0, 2 ) ); ?></div>
					<h1><?php echo esc_html( $brand ); ?></h1>
				<?php endif; ?>
				<p class="sub"><?php esc_html_e( 'Enter your 4-digit PIN to continue', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="pinform">
					<input type="hidden" name="action" value="wceerp_pin_submit">
					<input type="hidden" name="return" value="<?php echo esc_attr( remove_query_arg( 'wceerp_pin', $return ) ); ?>">
					<?php wp_nonce_field( 'wceerp_pin_submit' ); ?>
					<input class="pin-in" id="pin" name="pin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off" autofocus placeholder="••••">
					<div class="err"><?php echo $bad ? esc_html__( 'Wrong PIN. Try again.', 'wc-enterprise-erp' ) : ''; ?></div>
					<div class="pad">
						<?php for ( $i = 1; $i <= 9; $i++ ) : ?>
							<button type="button" data-k="<?php echo (int) $i; ?>"><?php echo (int) $i; ?></button>
						<?php endfor; ?>
						<button type="button" data-clear="1">⌫</button>
						<button type="button" data-k="0">0</button>
						<button type="submit">↵</button>
					</div>
				</form>
				<div class="foot">
					<a href="<?php echo esc_url( admin_url() ); ?>">← <?php esc_html_e( 'Back to WordPress', 'wc-enterprise-erp' ); ?></a>
				</div>
			</div>
			<script>
				var pin=document.getElementById('pin');
				document.querySelectorAll('.pad button[data-k]').forEach(function(b){b.addEventListener('click',function(){if(pin.value.length<4){pin.value+=b.dataset.k;}if(pin.value.length===4){document.getElementById('pinform').submit();}});});
				document.querySelector('.pad button[data-clear]').addEventListener('click',function(){pin.value='';pin.focus();});
			</script>
		</body>
		</html>
		<?php
	}

	/** Settings-screen fragment: change PIN + default-PIN warning. */
	public static function render_settings_fragment() {
		$err = isset( $_GET['pin_err'] ) ? sanitize_key( $_GET['pin_err'] ) : '';
		?>
		<hr>
		<h2><?php esc_html_e( 'ERP access PIN', 'wc-enterprise-erp' ); ?></h2>
		<?php if ( self::is_enforced() ) : ?>
			<div class="notice notice-info inline" style="margin:8px 0"><p>
				🔒 <strong><?php esc_html_e( 'This PIN is set by your provider.', 'wc-enterprise-erp' ); ?></strong>
				<?php esc_html_e( 'It cannot be changed or reset from here. Contact your provider if you need it altered.', 'wc-enterprise-erp' ); ?>
			</p></div>
			<?php return; ?>
		<?php endif; ?>
		<p class="description"><?php esc_html_e( 'A 4-digit PIN gate in front of the whole ERP. Everyone who opens the ERP must enter it; leaving the ERP re-locks it. This keeps accounting, profit, payroll and dues away from staff who share this login.', 'wc-enterprise-erp' ); ?></p>
		<?php if ( self::is_default_pin() ) : ?>
			<div class="notice notice-warning inline" style="margin:8px 0"><p><strong><?php esc_html_e( 'You are still using the default PIN 1234.', 'wc-enterprise-erp' ); ?></strong> <?php esc_html_e( 'Change it now.', 'wc-enterprise-erp' ); ?></p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['pin_ok'] ) ) : ?>
			<div class="notice notice-success inline" style="margin:8px 0"><p><?php esc_html_e( 'PIN updated.', 'wc-enterprise-erp' ); ?></p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['pin_reset'] ) ) : ?>
			<div class="notice notice-warning inline" style="margin:8px 0"><p><?php esc_html_e( 'PIN has been reset to 1234. Change it now.', 'wc-enterprise-erp' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wceerp_pin_change">
			<?php wp_nonce_field( 'wceerp_pin_change' ); ?>
			<table class="form-table"><tbody>
				<tr><th><?php esc_html_e( 'Current PIN', 'wc-enterprise-erp' ); ?></th>
					<td><input type="password" name="current_pin" inputmode="numeric" maxlength="4" class="small-text" required>
						<?php if ( 'current' === $err ) : ?><span style="color:#c8302e"><?php esc_html_e( 'Current PIN is wrong.', 'wc-enterprise-erp' ); ?></span><?php endif; ?></td></tr>
				<tr><th><?php esc_html_e( 'New PIN (4 digits)', 'wc-enterprise-erp' ); ?></th>
					<td><input type="password" name="new_pin" inputmode="numeric" maxlength="4" pattern="[0-9]{4}" class="small-text" required>
						<?php if ( 'len' === $err ) : ?><span style="color:#c8302e"><?php esc_html_e( 'PIN must be exactly 4 digits.', 'wc-enterprise-erp' ); ?></span><?php endif; ?></td></tr>
			</tbody></table>
			<?php submit_button( __( 'Change PIN', 'wc-enterprise-erp' ), 'secondary' ); ?>
		</form>

		<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<p class="description"><?php esc_html_e( 'Forgot the PIN? An administrator can reset it back to the default 1234.', 'wc-enterprise-erp' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Reset the ERP PIN to 1234? Everyone will use 1234 until you change it again.', 'wc-enterprise-erp' ) ); ?>');">
				<input type="hidden" name="action" value="wceerp_pin_reset">
				<?php wp_nonce_field( 'wceerp_pin_reset' ); ?>
				<?php submit_button( __( 'Reset PIN to default', 'wc-enterprise-erp' ), 'delete', 'submit', false ); ?>
			</form>
		<?php endif; ?>
		<?php
	}
}
