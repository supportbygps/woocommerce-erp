<?php
/**
 * WCEERP_PDF — a tiny dependency-free PDF writer.
 *
 * Enough for A4 business documents: text (Helvetica / Helvetica-Bold),
 * lines, rectangles, right-aligned cells and multi-page output. Text is
 * Latin-1 (PDF base-14 fonts); Bangla strings are transliterated and ৳
 * becomes "Tk". For fully localised Bangla PDFs swap in dompdf/mPDF —
 * this class keeps the plugin self-contained with zero dependencies.
 *
 * Coordinates are in points from the TOP-LEFT of the page (A4 = 595×842).
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_PDF {

	const PAGE_W = 595.28; // A4 portrait.
	const PAGE_H = 841.89;

	protected $pages   = array(); // each = content stream string.
	protected $current = -1;
	protected $font    = 'F1';   // F1 = Helvetica, F2 = Helvetica-Bold.
	protected $size    = 10;

	public function add_page() {
		$this->pages[] = '';
		$this->current = count( $this->pages ) - 1;
		return $this;
	}

	public function set_font( $size = 10, $bold = false ) {
		$this->size = (float) $size;
		$this->font = $bold ? 'F2' : 'F1';
		return $this;
	}

	/**
	 * Make arbitrary UTF-8 text safe for base-14 fonts.
	 */
	public static function latinise( $text ) {
		$text = str_replace( array( '৳', '–', '—', '…' ), array( 'Tk ', '-', '-', '...' ), (string) $text );
		$text = remove_accents( $text );
		// Drop anything that still is not printable Latin-1.
		$text = preg_replace( '/[^\x20-\x7E\xA0-\xFF]/u', '', $text );
		return $text;
	}

	protected function escape( $text ) {
		return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), self::latinise( $text ) );
	}

	/**
	 * Rough Helvetica width (points) for alignment — 0.52em average.
	 */
	public function width( $text ) {
		return strlen( self::latinise( $text ) ) * $this->size * 0.52;
	}

	public function text( $x, $y, $text ) {
		$this->pages[ $this->current ] .= sprintf(
			"BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET\n",
			$this->font, $this->size, $x, self::PAGE_H - $y, $this->escape( $text )
		);
		return $this;
	}

	public function text_right( $x_right, $y, $text ) {
		return $this->text( $x_right - $this->width( $text ), $y, $text );
	}

	public function text_center( $x_center, $y, $text ) {
		return $this->text( $x_center - $this->width( $text ) / 2, $y, $text );
	}

	public function line( $x1, $y1, $x2, $y2, $w = 0.7 ) {
		$this->pages[ $this->current ] .= sprintf(
			"%.2F w %.2F %.2F m %.2F %.2F l S\n",
			$w, $x1, self::PAGE_H - $y1, $x2, self::PAGE_H - $y2
		);
		return $this;
	}

	public function rect( $x, $y, $w, $h, $stroke_w = 0.7 ) {
		$this->pages[ $this->current ] .= sprintf(
			"%.2F w %.2F %.2F %.2F %.2F re S\n",
			$stroke_w, $x, self::PAGE_H - $y - $h, $w, $h
		);
		return $this;
	}

	/**
	 * Build the PDF document as a byte string.
	 */
	public function output() {
		$objects = array();

		// 1: catalog, 2: pages, 3: F1, 4: F2, then per page: page obj + content obj.
		$page_count = count( $this->pages );
		$kids       = array();
		$next       = 5;
		$page_objs  = array();

		foreach ( $this->pages as $stream ) {
			$page_no    = $next++;
			$content_no = $next++;
			$kids[]     = $page_no . ' 0 R';
			$page_objs[] = array( $page_no, $content_no, $stream );
		}

		$objects[1] = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
		$objects[2] = "2 0 obj\n<< /Type /Pages /Kids [" . implode( ' ', $kids ) . "] /Count $page_count >>\nendobj\n";
		$objects[3] = "3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n";
		$objects[4] = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n";

		foreach ( $page_objs as $def ) {
			list( $page_no, $content_no, $stream ) = $def;
			$objects[ $page_no ] = sprintf(
				"%d 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2F %.2F] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>\nendobj\n",
				$page_no, self::PAGE_W, self::PAGE_H, $content_no
			);
			$objects[ $content_no ] = sprintf(
				"%d 0 obj\n<< /Length %d >>\nstream\n%sendstream\nendobj\n",
				$content_no, strlen( $stream ), $stream
			);
		}

		ksort( $objects );

		$pdf     = "%PDF-1.4\n";
		$offsets = array();
		foreach ( $objects as $num => $obj ) {
			$offsets[ $num ] = strlen( $pdf );
			$pdf            .= $obj;
		}

		$xref_pos = strlen( $pdf );
		$max      = max( array_keys( $objects ) );
		$pdf     .= "xref\n0 " . ( $max + 1 ) . "\n";
		$pdf     .= "0000000000 65535 f \n";
		for ( $i = 1; $i <= $max; $i++ ) {
			$pdf .= isset( $offsets[ $i ] )
				? sprintf( "%010d 00000 n \n", $offsets[ $i ] )
				: "0000000000 65535 f \n";
		}
		$pdf .= "trailer\n<< /Size " . ( $max + 1 ) . " /Root 1 0 R >>\nstartxref\n$xref_pos\n%%EOF";

		return $pdf;
	}

	/**
	 * Stream the PDF to the browser.
	 */
	public function stream( $filename ) {
		$data = $this->output();
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: inline; filename="' . sanitize_file_name( $filename ) . '"' );
		header( 'Content-Length: ' . strlen( $data ) );
		echo $data; // phpcs:ignore WordPress.Security.EscapeOutput -- binary PDF.
		exit;
	}
}
