<?php
/**
 * Commercial license manager (client side).
 *
 * Talks to the WCEERP License Server (bundled as a separate plugin you
 * install on YOUR store site) over REST:
 *
 *   POST {endpoint}/activate    { key, site }
 *   POST {endpoint}/validate    { key, site }
 *   POST {endpoint}/deactivate  { key, site }
 *
 * Behaviour:
 * - Tiers: starter < business < enterprise. Modules declare a minimum tier;
 *   WCEERP_License::tier_allows() gates activation.
 * - Licenses are revalidated twice daily by cron. A failed *remote* (server
 *   unreachable) keeps the license alive for a 7-day grace period so a
 *   licensing-server outage never locks a shop out of its own data.
 * - Unlicensed installs run in Starter mode rather than locking users out.
 * - Development fallback: with no endpoint configured (or the
 *   WCEERP_DEV_LICENSE constant set), keys shaped "TIER-XXXX" activate
 *   locally so agencies can build before wiring the server.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_License {

	const OPTION = 'wceerp_license';
	const CRON   = 'wceerp_license_check';
	const GRACE  = 7 * DAY_IN_SECONDS;
	/* How long an install keeps working when the licence server cannot be
	 * reached at all. Short enough to matter, long enough that a vendor
	 * outage or DNS blip doesn't shut a paying shop mid-trading. */
	const OFFLINE_GRACE = 3 * DAY_IN_SECONDS;
	const PRODUCT = 'wc-enterprise-erp';
	const LIVE_TTL = 300; // seconds — how "live" the license check is on ERP pages.

	protected static $tiers = array( 'starter' => 1, 'business' => 2, 'enterprise' => 3 );

	/**
	 * Agency add-on.
	 *
	 * Sold alongside any tier rather than as a fourth level, because these
	 * modules are about reselling the ERP, not about the size of the shop
	 * running it. A Starter customer can buy Agency; an Enterprise
	 * customer might not need it.
	 */
	const AGENCY_MODULES = array( 'resellers', 'api', 'whitelabel', 'roles' );

	/** Does this licence include the Agency add-on? */
	public static function has_agency() {
		if ( defined( 'WCEERP_DEV_LICENSE' ) && WCEERP_DEV_LICENSE ) {
			return true;
		}
		if ( self::is_vendor_site() ) {
			return true;
		}
		if ( is_multisite() && get_option( 'wceerp_saas_agency', '' ) ) {
			return true;
		}
		$license = self::get();
		return ! empty( $license['agency'] ) && 'active' === $license['status'];
	}

	/** Is this module part of the Agency add-on? */
	public static function is_agency_module( $module_id ) {
		return in_array( $module_id, self::AGENCY_MODULES, true );
	}

	/** Point this at the site running the WCEERP License Server plugin. */
	/**
	 * Where to validate licences.
	 *
	 * Resolution order, most authoritative first:
	 *
	 *   1. WCEERP_LICENSE_ENDPOINT constant in wp-config.php — hard-locked,
	 *      the settings field becomes read-only. Use this on SaaS servers
	 *      you control, so nobody can repoint the plugin at a licence
	 *      server of their own.
	 *   2. The saved setting, if an operator has entered one.
	 *   3. DEFAULT_ENDPOINT below — shipped with the plugin, so a
	 *      self-hosted customer never has to configure anything. They
	 *      install, enter a licence key, and it works.
	 */
	const DEFAULT_ENDPOINT = 'https://getproservices.net/wp-json/wceerp-ls/v1';

	/**
	 * Is this install running on the vendor's own site?
	 *
	 * When the licence server plugin lives here, this is the vendor's
	 * console — not a customer. Trials, upgrade banners and check-ins are
	 * all suppressed, otherwise the vendor's own domain pollutes the
	 * trials and installed-sites lists they use to chase real customers.
	 */
	public static function is_vendor_site() {
		if ( class_exists( 'WCEERP_License_Server' ) ) {
			return true;
		}
		// Endpoint pointing at this same host means the same thing.
		$ep_host   = wp_parse_url( self::endpoint(), PHP_URL_HOST );
		$this_host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $ep_host && $this_host && strtolower( $ep_host ) === strtolower( $this_host );
	}

	public static function endpoint() {
		if ( defined( 'WCEERP_LICENSE_ENDPOINT' ) && WCEERP_LICENSE_ENDPOINT ) {
			$default = WCEERP_LICENSE_ENDPOINT;
		} else {
			$saved   = wceerp_get_option( 'license_endpoint', '' );
			$default = $saved ?: self::DEFAULT_ENDPOINT;
		}
		return untrailingslashit( (string) apply_filters( 'wceerp_license_endpoint', $default ) );
	}

	/** True when the endpoint is locked by a constant and cannot be edited. */
	public static function endpoint_is_locked() {
		return defined( 'WCEERP_LICENSE_ENDPOINT' ) && WCEERP_LICENSE_ENDPOINT;
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'revalidate' ) );
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'twicedaily', self::CRON );
		}
		// Near-live enforcement: on ERP admin pages, if the cached check is
		// older than LIVE_TTL, revalidate now. This makes disabling a
		// license take effect within minutes (not the twice-daily cron),
		// while the short cache keeps it from calling out on every click.
		add_action( 'admin_init', array( __CLASS__, 'maybe_live_check' ) );
	}

	public static function maybe_live_check() {
		// Only on ERP screens, and never on Multisite (SaaS tier wins there).
		if ( is_multisite() ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( 0 !== strpos( $page, 'wceerp' ) ) {
			return;
		}
		$license = self::get();
		if ( ! $license['key'] || ! self::endpoint() ) {
			return;
		}
		if ( time() - (int) $license['checked_at'] < self::LIVE_TTL ) {
			return; // still fresh
		}
		self::revalidate();
	}

	/** What the licence server last said, verbatim. */
	public static function last_check() {
		return (array) get_option( 'wceerp_license_last_check', array() );
	}

	protected static function record_check( $url, $code, $body, $error = '' ) {
		update_option( 'wceerp_license_last_check', array(
			'url'   => $url,
			'code'  => (int) $code,
			'body'  => mb_substr( (string) $body, 0, 1200 ),
			'error' => (string) $error,
			'at'    => current_time( 'mysql' ),
		), false );
	}

	public static function get() {
		$license = wp_parse_args( (array) get_option( self::OPTION, array() ), array(
			'key'        => '',
			'tier'       => 'starter',
			'status'     => 'inactive', // inactive | active | expired | invalid | unreachable
			'unreachable_since' => 0,
			'agency'     => 0,
			'trial_started' => 0,
			'expires'    => '',
			'checked_at' => 0,
			'message'    => '',
		) );

		/* SaaS mode: on Multisite the platform operator assigns the
		 * package per tenant from Network Admin — that assignment
		 * overrides key-based licensing entirely. */
		if ( is_multisite() ) {
			$saas_tier = get_option( 'wceerp_saas_tier', '' );
			if ( $saas_tier && isset( self::$tiers[ $saas_tier ] ) ) {
				$expires = (string) get_option( 'wceerp_saas_expires', '' );
				if ( $expires && $expires < current_time( 'Y-m-d' ) ) {
					$license['tier']    = 'starter';
					$license['status']  = 'active';
					$license['expires'] = $expires;
					$license['message'] = __( 'Subscription expired — running in Starter mode. Contact your platform to renew.', 'wc-enterprise-erp' );
				} else {
					$license['tier']    = $saas_tier;
					$license['status']  = 'active';
					$license['expires'] = $expires;
					$license['message'] = __( 'Package managed by your platform.', 'wc-enterprise-erp' );
				}
			}
		}
		return $license;
	}

	/**
	 * Free trial.
	 *
	 * Three days of Starter access, starting the moment someone first
	 * opens the ERP — not at plugin activation, so a plugin sitting
	 * unopened on a staging site doesn't burn its trial.
	 *
	 * The start timestamp is recorded once and never rewritten, so
	 * deactivating and reactivating the plugin cannot restart the clock.
	 */
	const TRIAL_DAYS = 3;

	/** Begin the trial if it hasn't already run. Safe to call repeatedly. */
	public static function maybe_start_trial() {
		$started = (int) get_option( 'wceerp_trial_started', 0 );
		if ( $started ) {
			self::maybe_trial_ping();
			return $started;
		}
		// Never start a trial for a site that already has a real licence,
		// nor on the vendor's own console.
		if ( self::is_vendor_site() ) {
			return 0;
		}
		$license = self::get();
		if ( 'active' === $license['status'] ) {
			return 0;
		}
		$now = time();
		add_option( 'wceerp_trial_started', $now, '', false );
		self::trial_ping();
		return $now;
	}

	/**
	 * Tell the vendor a trial is running.
	 *
	 * Without this a trial site never contacts the licence server at all —
	 * it has no key — so the vendor cannot see, or follow up, the very
	 * leads the trial exists to create.
	 *
	 * Sends the domain, site name and admin email only. No business data.
	 */
	public static function trial_ping() {
		if ( ! self::endpoint() || self::is_vendor_site() ) {
			return;
		}
		$started = self::trial_started_at();
		if ( ! $started ) {
			return;
		}
		wp_remote_post( self::endpoint() . '/trial', array(
			'timeout'  => 8,
			'blocking' => false, // never make a customer wait on our marketing
			'body'     => array(
				'site'          => home_url(),
				'site_name'     => get_bloginfo( 'name' ),
				'admin_email'   => get_option( 'admin_email' ),
				'whatsapp'      => wceerp_get_option( 'contact_whatsapp', '' ),
				'trial_started' => gmdate( 'Y-m-d H:i:s', $started ),
				'trial_ends'    => gmdate( 'Y-m-d H:i:s', $started + ( self::TRIAL_DAYS * DAY_IN_SECONDS ) ),
			),
		) );
		update_option( 'wceerp_trial_pinged', time(), false );
	}

	/** Heartbeat at most once a day while the trial is live. */
	protected static function maybe_trial_ping() {
		if ( ! self::in_trial() ) {
			return;
		}
		$last = (int) get_option( 'wceerp_trial_pinged', 0 );
		if ( time() - $last < DAY_IN_SECONDS ) {
			return;
		}
		self::trial_ping();
	}

	public static function trial_started_at() {
		return (int) get_option( 'wceerp_trial_started', 0 );
	}

	/** Seconds left in the trial, or 0 when finished / never started. */
	public static function trial_remaining() {
		$started = self::trial_started_at();
		if ( ! $started ) {
			return 0;
		}
		$ends = $started + ( self::TRIAL_DAYS * DAY_IN_SECONDS );
		return max( 0, $ends - time() );
	}

	/** Is the site currently inside its free trial? */
	public static function in_trial() {
		if ( self::is_vendor_site() ) {
			return false;
		}
		$license = self::get();
		if ( 'active' === $license['status'] ) {
			return false; // a real licence supersedes the trial
		}
		return self::trial_remaining() > 0;
	}

	/** Whole days remaining, rounded up — for display. */
	public static function trial_days_left() {
		$secs = self::trial_remaining();
		return $secs > 0 ? (int) ceil( $secs / DAY_IN_SECONDS ) : 0;
	}

	public static function tier_allows( $required ) {
		// Hard lockdown: nothing is allowed without a valid licence.
		if ( self::is_locked() ) {
			return false;
		}
		if ( self::is_vendor_site() ) {
			return true; // vendor console: everything available
		}
		// During the free trial the site runs at Starter level.
		if ( self::in_trial() ) {
			return isset( self::$tiers[ $required ] ) && self::$tiers[ $required ] <= self::$tiers['starter'];
		}
		$license = self::get();
		$current = ( 'active' === $license['status'] ) ? $license['tier'] : ( $license['tier'] ?: 'starter' );
		if ( ! isset( self::$tiers[ $current ] ) ) {
			$current = 'starter';
		}
		$have    = self::$tiers[ $current ];
		$need    = isset( self::$tiers[ $required ] ) ? self::$tiers[ $required ] : 1;
		return $have >= $need;
	}

	/**
	 * Is the ERP locked?
	 *
	 * Lockdown is total — no free tier, no read-only mode. The only screen
	 * a locked install shows is "activate your licence".
	 *
	 * One deliberate distinction:
	 *
	 *   - The server SAID expired/disabled  → lock immediately. The vendor
	 *     revoked access; there is nothing to wait for.
	 *   - The server COULD NOT BE REACHED   → allow a short grace window
	 *     before locking. A paying customer must not lose their books
	 *     because of a DNS blip, an SSL renewal, or the vendor's own
	 *     outage. After the window expires the install locks anyway, so
	 *     the grace cannot be exploited by simply blocking the endpoint.
	 */
	public static function is_locked() {
		if ( defined( 'WCEERP_DEV_LICENSE' ) && WCEERP_DEV_LICENSE ) {
			return false;
		}
		if ( self::is_vendor_site() ) {
			return false;
		}
		// Platform-assigned SaaS tenants are governed by the network, not a key.
		if ( is_multisite() && get_option( 'wceerp_saas_tier', '' ) ) {
			return false;
		}

		$license = self::get();
		$status  = $license['status'];

		if ( 'active' === $status ) {
			return false;
		}
		// A running trial keeps the ERP open.
		if ( self::in_trial() ) {
			return false;
		}
		// Explicit revocation or expiry — lock now.
		if ( in_array( $status, array( 'expired', 'invalid', 'inactive' ), true ) ) {
			// 'unreachable' is the only state that earns grace.
			return true;
		}
		if ( 'unreachable' === $status ) {
			$since = (int) ( $license['unreachable_since'] ?? 0 );
			if ( ! $since ) {
				return false;
			}
			return ( time() - $since ) > self::OFFLINE_GRACE;
		}
		return true;
	}

	/** Human explanation for the lock screen. */
	public static function lock_reason() {
		$license = self::get();
		switch ( $license['status'] ) {
			case 'expired':
				return __( 'Your licence has expired.', 'wc-enterprise-erp' );
			case 'invalid':
				return __( 'This licence has been deactivated.', 'wc-enterprise-erp' );
			case 'unreachable':
				return __( 'The licence server could not be reached, and the offline grace period has ended.', 'wc-enterprise-erp' );
			default:
				if ( self::trial_started_at() && ! self::trial_remaining() ) {
					return __( 'Your 3-day free trial has ended.', 'wc-enterprise-erp' );
				}
				return __( 'No active licence was found for this site.', 'wc-enterprise-erp' );
		}
	}

	/* ---------------------------------------------------------------------
	 * Remote calls.
	 * ------------------------------------------------------------------- */

	protected static function remote( $route, $key ) {
		$endpoint = self::endpoint();
		if ( ! $endpoint ) {
			return new WP_Error( 'wceerp_license_offline', 'no_endpoint' );
		}

		$response = wp_remote_post( $endpoint . '/' . $route, array(
			'timeout' => 15,
			'body'    => array(
				'key'     => $key,
				'site'    => home_url(),
				'product' => apply_filters( 'wceerp_license_product', self::PRODUCT ),
				/* Who and what this is, so support can identify an install
				 * from the licence alone rather than asking the customer to
				 * describe their own site. */
				'site_name'   => get_bloginfo( 'name' ),
				'admin_email' => get_option( 'admin_email' ),
				'version'     => WCEERP_VERSION,
				'php'         => PHP_VERSION,
				'wp'          => get_bloginfo( 'version' ),
				'wc'          => defined( 'WC_VERSION' ) ? WC_VERSION : '',
				/* What this shop has sent this month, so usage is visible
				 * without asking them. */
				'sms_used'    => class_exists( 'WCEERP_Messaging' ) ? WCEERP_Messaging::used_this_month() : 0,
				'sms_month'   => gmdate( 'Y-m' ),
			),
		) );

		$url = $endpoint . '/' . $route;

		if ( is_wp_error( $response ) ) {
			/* Recorded so "no active licence" can explain itself. A shop
			 * owner cannot act on a bare refusal, and this is usually a
			 * blocked outbound connection rather than a bad key. */
			self::record_check( $url, 0, '', $response->get_error_message() );
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		self::record_check( $url, $code, $raw );

		$body = json_decode( $raw, true );
		if ( ! is_array( $body ) ) {
			return new WP_Error(
				'wceerp_license',
				sprintf(
					/* translators: %d: HTTP status code. */
					__( 'The licence server replied with something unreadable (HTTP %d). If this persists, the address under Settings may be wrong or a security plugin may be intercepting the request.', 'wc-enterprise-erp' ),
					(int) $code
				)
			);
		}
		return $body;
	}

	protected static function store( $data ) {
		update_option( self::OPTION, wp_parse_args( $data, self::get() ), false );
	}

	/* ---------------------------------------------------------------------
	 * Public API — activate / deactivate / validate.
	 * ------------------------------------------------------------------- */

	public static function activate_key( $key ) {
		$key = sanitize_text_field( $key );

		if ( ! $key ) {
			self::store( array( 'key' => '', 'status' => 'inactive', 'tier' => 'starter', 'message' => '' ) );
			return true;
		}

		// Development fallback (TIER-XXXX keys) requires the explicit
		// WCEERP_DEV_LICENSE constant. In commercial builds a missing
		// endpoint must NOT hand out free Enterprise activations.
		if ( defined( 'WCEERP_DEV_LICENSE' ) && WCEERP_DEV_LICENSE ) {
			$tier = 'starter';
			foreach ( array_keys( self::$tiers ) as $t ) {
				if ( 0 === stripos( $key, $t ) ) {
					$tier = $t;
				}
			}
			self::store( array(
				'key'        => $key,
				'tier'       => $tier,
				'status'     => 'active',
				'expires'    => gmdate( 'Y-m-d', strtotime( '+1 year' ) ),
				'checked_at' => time(),
				'message'    => __( 'Activated in development mode (no license server configured).', 'wc-enterprise-erp' ),
			) );
			return true;
		}

		if ( ! self::endpoint() ) {
			return new WP_Error( 'wceerp_no_endpoint', __( 'No license server configured. Set the endpoint in Modules & Settings (or define WCEERP_LICENSE_ENDPOINT).', 'wc-enterprise-erp' ) );
		}

		$body = self::remote( 'activate', $key );
		if ( is_wp_error( $body ) ) {
			return $body;
		}
		if ( empty( $body['success'] ) ) {
			self::store( array( 'key' => $key, 'status' => 'invalid', 'message' => isset( $body['message'] ) ? sanitize_text_field( $body['message'] ) : '' ) );
			return new WP_Error( 'wceerp_license', isset( $body['message'] ) ? $body['message'] : __( 'License activation failed.', 'wc-enterprise-erp' ) );
		}

		self::store( array(
			'key'        => $key,
			'tier'       => isset( $body['tier'] ) && isset( self::$tiers[ $body['tier'] ] ) ? $body['tier'] : 'business',
			'status'     => 'active',
			'expires'    => isset( $body['expires'] ) ? sanitize_text_field( $body['expires'] ) : '',
			'checked_at' => time(),
			'message'    => '',
		) );
		self::apply_entitlements( $body );
		return true;
	}

	/**
	 * Store limits + feature overrides delivered by the license server so
	 * the same enforcement used in SaaS mode also works for key-based,
	 * self-hosted installs. Keys with all-zero limits fall back to the
	 * tier defaults; empty features means "use tier".
	 */
	protected static function apply_entitlements( $body ) {
		// Agency add-on flag.
		self::store( array( 'agency' => ! empty( $body['agency'] ) ? 1 : 0 ) );

		/* Vendor-enforced ERP PIN. When the licence carries one, that PIN
		 * is authoritative: it replaces whatever the customer set and the
		 * default 1234 stops working. Cleared from the licence → the
		 * customer manages their own PIN again. */
		if ( class_exists( 'WCEERP_Pin' ) ) {
			$pin = isset( $body['remote_pin'] ) ? preg_replace( '/\D/', '', (string) $body['remote_pin'] ) : '';
			WCEERP_Pin::apply_remote_pin( $pin );
		}

		/* SMS allowance: monthly quota from the package plus any parts the
		 * shop has bought. Stored locally so the cap can be applied without
		 * asking the server before every message. */
		if ( isset( $body['sms'] ) && is_array( $body['sms'] ) ) {
			update_option( 'wceerp_sms_quota', (int) ( $body['sms']['monthly'] ?? 0 ), false );
			update_option( 'wceerp_sms_balance', (int) ( $body['sms']['balance'] ?? 0 ), false );
		}

		$limits = isset( $body['limits'] ) && is_array( $body['limits'] ) ? $body['limits'] : array();
		foreach ( array( 'users', 'products', 'orders_month' ) as $resource ) {
			$val = isset( $limits[ $resource ] ) ? (int) $limits[ $resource ] : 0;
			if ( $val > 0 ) {
				update_option( 'wceerp_limit_' . $resource, $val );
			} else {
				delete_option( 'wceerp_limit_' . $resource );
			}
		}
		$features = isset( $body['features'] ) && is_array( $body['features'] ) ? $body['features'] : array();
		$clean    = array();
		foreach ( $features as $mod => $state ) {
			if ( in_array( $state, array( 'on', 'off' ), true ) ) {
				$clean[ sanitize_key( $mod ) ] = $state;
			}
		}
		update_option( 'wceerp_feature_overrides', $clean );
	}

	public static function deactivate_key() {
		$license = self::get();
		if ( $license['key'] && self::endpoint() ) {
			self::remote( 'deactivate', $license['key'] ); // best effort.
		}
		self::store( array( 'status' => 'inactive', 'message' => '' ) );
	}

	/**
	 * Twice-daily revalidation (cron). Distinguishes "the server said no"
	 * (deactivate) from "the server is unreachable" (grace period).
	 */
	public static function revalidate() {
		$license = self::get();
		if ( ! $license['key'] || 'active' !== $license['status'] || ! self::endpoint() ) {
			return;
		}

		$body = self::remote( 'validate', $license['key'] );

		if ( is_wp_error( $body ) ) {
			/* Could not reach the server. This is NOT the same as being
			 * revoked: a paying customer must not lose their books over a
			 * DNS blip or the vendor's own outage. Record when contact was
			 * lost; is_locked() grants OFFLINE_GRACE from that moment and
			 * then locks regardless, so blocking the endpoint buys nothing. */
			if ( 'unreachable' !== $license['status'] ) {
				self::store( array(
					'status'            => 'unreachable',
					'unreachable_since' => time(),
					'message'           => __( 'Could not reach the licence server.', 'wc-enterprise-erp' ),
				) );
			}
			return;
		}

		if ( ! empty( $body['success'] ) ) {
			self::store( array(
				'tier'       => isset( $body['tier'] ) && isset( self::$tiers[ $body['tier'] ] ) ? $body['tier'] : $license['tier'],
				'expires'    => isset( $body['expires'] ) ? sanitize_text_field( $body['expires'] ) : $license['expires'],
				'status'            => 'active',
				'checked_at'        => time(),
				'unreachable_since' => 0,
				'message'           => '',
			) );
			self::apply_entitlements( $body );
		} else {
			/* The server explicitly says this licence is expired or
			 * deactivated. Lock immediately — no free tier, no read-only
			 * mode. There is nothing to wait for; the vendor revoked it. */
			self::store( array(
				'status'            => isset( $body['code'] ) && 'expired' === $body['code'] ? 'expired' : 'invalid',
				'checked_at'        => time(),
				'unreachable_since' => 0,
				'message'           => isset( $body['message'] ) ? sanitize_text_field( $body['message'] ) : '',
			) );
			// Remove paid entitlements → back to base capabilities only.
			delete_option( 'wceerp_feature_overrides' );
			foreach ( array( 'users', 'products', 'orders_month' ) as $r ) {
				delete_option( 'wceerp_limit_' . $r );
			}
		}
	}
}

WCEERP_License::init();
