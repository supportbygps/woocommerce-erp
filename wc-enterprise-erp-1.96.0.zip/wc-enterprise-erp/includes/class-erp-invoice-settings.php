<?php
/**
 * Shared invoice / document branding.
 *
 * One source of truth for how printed documents look, consumed by both
 * the POS A4 invoice (HTML/CSS print) and the quotation PDF
 * (WCEERP_PDF). Presets set sensible defaults for a look; individual
 * settings override any preset field.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Invoice_Settings {

	const PRESETS = array(
		'classic' => array(
			'label'       => 'Classic',
			'accent'      => '#111111',
			'header_bg'   => '#ffffff',
			'font'        => 'serif',
			'show_lines'  => 'yes',
			'zebra'       => 'no',
		),
		'modern' => array(
			'label'       => 'Modern',
			'accent'      => '#075742',
			'header_bg'   => '#f3f7f5',
			'font'        => 'sans',
			'show_lines'  => 'no',
			'zebra'       => 'yes',
		),
		'bold' => array(
			'label'       => 'Bold',
			'accent'      => '#b98a2f',
			'header_bg'   => '#1f2937',
			'font'        => 'sans',
			'show_lines'  => 'yes',
			'zebra'       => 'yes',
		),
	);

	/**
	 * Resolved settings = preset defaults with per-field overrides on top.
	 * All rendering code should read from here, never from raw options.
	 */
	public static function get() {
		$preset_key = wceerp_get_option( 'inv_preset', 'classic' );
		$preset     = self::PRESETS[ $preset_key ] ?? self::PRESETS['classic'];

		$override = function ( $key, $fallback ) {
			$v = wceerp_get_option( 'inv_' . $key, '' );
			return '' !== $v ? $v : $fallback;
		};

		return array(
			'preset'       => $preset_key,
			'company_name' => wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ),
			'address'      => wceerp_get_option( 'inv_address', wceerp_get_option( 'pos_invoice_address', wceerp_get_option( 'company_address', '' ) ) ),
			'bin'          => wceerp_get_option( 'inv_bin', wceerp_get_option( 'pos_invoice_bin', wceerp_get_option( 'company_bin', '' ) ) ),
			'phone'        => wceerp_get_option( 'inv_phone', '' ),
			'email'        => wceerp_get_option( 'inv_email', '' ),
			'logo'         => wceerp_get_option( 'inv_logo', '' ),
			'accent'       => wceerp_hex_colour( $override( 'accent', $preset['accent'] ) ) ?: $preset['accent'],
			'header_bg'    => wceerp_hex_colour( $override( 'header_bg', $preset['header_bg'] ) ) ?: $preset['header_bg'],
			'font'         => $override( 'font', $preset['font'] ),
			'show_lines'   => $override( 'show_lines', $preset['show_lines'] ),
			'zebra'        => $override( 'zebra', $preset['zebra'] ),
			'footer'       => wceerp_get_option( 'inv_footer', __( 'Thank you for your business.', 'wc-enterprise-erp' ) ),
			'terms'        => wceerp_get_option( 'inv_terms', '' ),
			'signature'    => wceerp_get_option( 'inv_signature', 'yes' ),

			/* Letterhead: a full-width image printed at the top of the page,
			 * for shops that already have designed stationery. It replaces
			 * the generated header rather than sitting alongside it, so the
			 * company name is not printed twice. */
			'letterhead'   => wceerp_get_option( 'inv_letterhead', '' ),
			'letterhead_h' => (int) wceerp_get_option( 'inv_letterhead_h', 110 ),
			'lh_replace'   => wceerp_get_option( 'inv_lh_replace', 'yes' ),
			'footer_img'   => wceerp_get_option( 'inv_footer_img', '' ),

			/* Product thumbnails on the lines. */
			'show_images'  => wceerp_get_option( 'inv_show_images', '' ),
			'image_size'   => max( 24, min( 96, (int) wceerp_get_option( 'inv_image_size', 44 ) ) ),
		);
	}

	/** CSS font-family string for the chosen font token. */
	public static function css_font( $token ) {
		return 'sans' === $token
			? "-apple-system, 'Segoe UI', Roboto, Arial, sans-serif"
			: "Georgia, 'Times New Roman', serif";
	}

	/** Persist the settings screen. Called from the Invoice settings tab. */
	public static function save() {
		foreach ( array( 'inv_lh_replace', 'inv_show_images' ) as $flag ) {
			wceerp_update_option( $flag, empty( $_POST[ $flag ] ) ? '' : 'yes' );
		}
		wceerp_update_option( 'inv_letterhead_h', max( 40, min( 300, (int) ( $_POST['inv_letterhead_h'] ?? 110 ) ) ) );
		wceerp_update_option( 'inv_image_size', max( 24, min( 96, (int) ( $_POST['inv_image_size'] ?? 44 ) ) ) );

		$keys_text = array( 'inv_address', 'inv_phone', 'inv_email', 'inv_logo', 'inv_footer', 'inv_terms', 'inv_bin', 'inv_letterhead', 'inv_footer_img' );
		foreach ( $keys_text as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				$val = in_array( $k, array( 'inv_address', 'inv_terms' ), true )
					? sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) )
					: ( in_array( $k, array( 'inv_logo', 'inv_letterhead', 'inv_footer_img' ), true )
						? esc_url_raw( wp_unslash( $_POST[ $k ] ) )
						: sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
				wceerp_update_option( $k, $val );
			}
		}
		wceerp_update_option( 'inv_preset', array_key_exists( $_POST['inv_preset'] ?? '', self::PRESETS ) ? $_POST['inv_preset'] : 'classic' );
		wceerp_update_option( 'inv_accent', wceerp_hex_colour( wp_unslash( $_POST['inv_accent'] ?? '' ) ) ?: '' );
		wceerp_update_option( 'inv_header_bg', wceerp_hex_colour( wp_unslash( $_POST['inv_header_bg'] ?? '' ) ) ?: '' );
		wceerp_update_option( 'inv_font', in_array( $_POST['inv_font'] ?? '', array( 'sans', 'serif' ), true ) ? $_POST['inv_font'] : '' );
		wceerp_update_option( 'inv_show_lines', ! empty( $_POST['inv_show_lines'] ) ? 'yes' : 'no' );
		wceerp_update_option( 'inv_zebra', ! empty( $_POST['inv_zebra'] ) ? 'yes' : 'no' );
		wceerp_update_option( 'inv_signature', ! empty( $_POST['inv_signature'] ) ? 'yes' : 'no' );
	}

	/** Render the settings form fields (embedded in Modules & Settings). */
	/**
	 * An image field with a real picker.
	 *
	 * Asking a shop owner to upload to Media, find the file, copy its URL
	 * and paste it back is four steps and a chance to paste the attachment
	 * page rather than the file. The picker does it in one, and the preview
	 * confirms the right image before anything is printed on an invoice.
	 */
	protected static function image_field( $name, $value, $help = '' ) {
		$id = esc_attr( $name );
		?>
		<div class="wceerp-imgfield" data-target="<?php echo $id; ?>">
			<div class="wceerp-imgprev" id="<?php echo $id; ?>-prev" style="<?php echo $value ? '' : 'display:none'; ?>">
				<img src="<?php echo esc_url( $value ); ?>" alt=""
					style="max-width:220px;max-height:90px;height:auto;border:1px solid #E3E0E8;border-radius:6px;padding:5px;background:#fff;display:block;margin-bottom:8px">
			</div>
			<input type="hidden" name="<?php echo $id; ?>" id="<?php echo $id; ?>" value="<?php echo esc_attr( $value ); ?>">
			<button type="button" class="button wceerp-imgpick"><?php esc_html_e( 'Choose image', 'wc-enterprise-erp' ); ?></button>
			<button type="button" class="button wceerp-imgclear" style="<?php echo $value ? '' : 'display:none'; ?>">
				<?php esc_html_e( 'Remove', 'wc-enterprise-erp' ); ?>
			</button>
			<?php if ( $help ) : ?>
				<p class="description"><?php echo esc_html( $help ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/** The picker behaviour, printed once per screen. */
	protected static function image_field_script() {
		?>
		<script>
		(function () {
			if ( ! window.wp || ! wp.media ) { return; }
			document.querySelectorAll( '.wceerp-imgfield' ).forEach( function ( box ) {
				var input = box.querySelector( 'input[type=hidden]' );
				var prev  = box.querySelector( '.wceerp-imgprev' );
				var img   = prev ? prev.querySelector( 'img' ) : null;
				var clear = box.querySelector( '.wceerp-imgclear' );
				var frame;

				box.querySelector( '.wceerp-imgpick' ).addEventListener( 'click', function () {
					/* One frame per field, reused — creating a new one on
					   every click leaks and eventually slows the screen. */
					if ( ! frame ) {
						frame = wp.media( {
							title: <?php echo wp_json_encode( __( 'Choose an image', 'wc-enterprise-erp' ) ); ?>,
							library: { type: 'image' },
							button: { text: <?php echo wp_json_encode( __( 'Use this image', 'wc-enterprise-erp' ) ); ?> },
							multiple: false
						} );
						frame.on( 'select', function () {
							var a = frame.state().get( 'selection' ).first().toJSON();
							/* Prefer a sized version where one exists: a 4MB
							   original on every invoice is slow to print and
							   pointless at letterhead size. */
							var url = ( a.sizes && a.sizes.large ) ? a.sizes.large.url : a.url;
							input.value = url;
							if ( img ) { img.src = url; }
							if ( prev ) { prev.style.display = ''; }
							if ( clear ) { clear.style.display = ''; }
						} );
					}
					frame.open();
				} );

				if ( clear ) {
					clear.addEventListener( 'click', function () {
						input.value = '';
						if ( prev ) { prev.style.display = 'none'; }
						clear.style.display = 'none';
					} );
				}
			} );
		})();
		</script>
		<?php
	}

	public static function render_form() {
		/* wp.media is not on the page unless asked for. Without this the
		 * picker button does nothing at all. */
		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}
		$s = self::get();
		?>
		<h2><?php esc_html_e( 'Invoice & document design', 'wc-enterprise-erp' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Applies to the POS A4 invoice and quotation PDF. Pick a preset, then tweak any field.', 'wc-enterprise-erp' ); ?></p>
		<table class="form-table"><tbody>
			<tr><th><?php esc_html_e( 'Preset', 'wc-enterprise-erp' ); ?></th>
				<td><select name="inv_preset">
					<?php foreach ( self::PRESETS as $key => $p ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['preset'], $key ); ?>><?php echo esc_html( $p['label'] ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Logo URL', 'wc-enterprise-erp' ); ?></th>
				<td>
					<?php self::image_field( 'inv_logo', $s['logo'], __( 'Small mark printed beside your company name.', 'wc-enterprise-erp' ) ); ?>
				</td></tr>

			<tr><th><?php esc_html_e( 'Letterhead image', 'wc-enterprise-erp' ); ?></th>
				<td>
					<?php
					self::image_field(
						'inv_letterhead',
						$s['letterhead'],
						__( 'Full-width image printed across the top, for shops with designed stationery.', 'wc-enterprise-erp' )
					);
					?>
					<p>
						<label><?php esc_html_e( 'Height', 'wc-enterprise-erp' ); ?>
							<input type="number" name="inv_letterhead_h" min="40" max="300" style="width:80px"
								value="<?php echo esc_attr( $s['letterhead_h'] ); ?>"> px</label>
						<label style="margin-left:16px">
							<input type="checkbox" name="inv_lh_replace" value="yes" <?php checked( 'yes', $s['lh_replace'] ); ?>>
							<?php esc_html_e( 'Replace the printed company name and address', 'wc-enterprise-erp' ); ?>
						</label>
					</p>
					<p class="description">
						<?php esc_html_e( 'Leave that ticked if your letterhead already shows the name and address, otherwise they appear twice.', 'wc-enterprise-erp' ); ?>
					</p>
				</td></tr>

			<tr><th><?php esc_html_e( 'Footer image', 'wc-enterprise-erp' ); ?></th>
				<td>
					<?php self::image_field( 'inv_footer_img', $s['footer_img'], __( 'Optional strip printed at the bottom — bank details, a stamp, or the rest of your stationery.', 'wc-enterprise-erp' ) ); ?>
				</td></tr>

			<tr><th><?php esc_html_e( 'Product images', 'wc-enterprise-erp' ); ?></th>
				<td>
					<label class="wceerp-switch">
						<input type="checkbox" name="inv_show_images" value="yes" <?php checked( 'yes', $s['show_images'] ); ?>>
						<span class="wceerp-track"></span>
						<span><?php esc_html_e( 'Show a picture of each product on the lines', 'wc-enterprise-erp' ); ?></span>
					</label>
					<p>
						<label><?php esc_html_e( 'Size', 'wc-enterprise-erp' ); ?>
							<input type="number" name="inv_image_size" min="24" max="96" style="width:80px"
								value="<?php echo esc_attr( $s['image_size'] ); ?>"> px</label>
					</p>
					<p class="description">
						<?php esc_html_e( 'Useful for quotations, where a customer is choosing. Images appear on the printable view — the plain PDF stays text-only so it prints fast and never fails on slow hosting.', 'wc-enterprise-erp' ); ?>
					</p>
				</td></tr>
			<tr><th><?php esc_html_e( 'Address', 'wc-enterprise-erp' ); ?></th>
				<td><textarea name="inv_address" rows="3" class="regular-text"><?php echo esc_textarea( $s['address'] ); ?></textarea></td></tr>
			<tr><th><?php esc_html_e( 'Phone / Email', 'wc-enterprise-erp' ); ?></th>
				<td><input type="text" name="inv_phone" value="<?php echo esc_attr( $s['phone'] ); ?>" placeholder="<?php esc_attr_e( 'Phone', 'wc-enterprise-erp' ); ?>">
					<input type="email" name="inv_email" value="<?php echo esc_attr( $s['email'] ); ?>" placeholder="Email"></td></tr>
			<tr><th><?php esc_html_e( 'BIN / VAT reg.', 'wc-enterprise-erp' ); ?></th>
				<td><input type="text" name="inv_bin" value="<?php echo esc_attr( $s['bin'] ); ?>"></td></tr>
			<tr><th><?php esc_html_e( 'Accent / header colours', 'wc-enterprise-erp' ); ?></th>
				<td><input type="text" name="inv_accent" value="<?php echo esc_attr( $s['accent'] ); ?>" placeholder="#075742" style="width:100px">
					<input type="text" name="inv_header_bg" value="<?php echo esc_attr( $s['header_bg'] ); ?>" placeholder="#f3f7f5" style="width:100px">
					<span class="description"><?php esc_html_e( 'accent · header background', 'wc-enterprise-erp' ); ?></span></td></tr>
			<tr><th><?php esc_html_e( 'Font', 'wc-enterprise-erp' ); ?></th>
				<td><select name="inv_font">
					<option value="serif" <?php selected( $s['font'], 'serif' ); ?>><?php esc_html_e( 'Serif (classic)', 'wc-enterprise-erp' ); ?></option>
					<option value="sans" <?php selected( $s['font'], 'sans' ); ?>><?php esc_html_e( 'Sans-serif (modern)', 'wc-enterprise-erp' ); ?></option>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Layout options', 'wc-enterprise-erp' ); ?></th>
				<td>
					<label><input type="checkbox" name="inv_show_lines" value="1" <?php checked( $s['show_lines'], 'yes' ); ?>> <?php esc_html_e( 'Table borders', 'wc-enterprise-erp' ); ?></label><br>
					<label><input type="checkbox" name="inv_zebra" value="1" <?php checked( $s['zebra'], 'yes' ); ?>> <?php esc_html_e( 'Striped rows', 'wc-enterprise-erp' ); ?></label><br>
					<label><input type="checkbox" name="inv_signature" value="1" <?php checked( $s['signature'], 'yes' ); ?>> <?php esc_html_e( 'Signature lines', 'wc-enterprise-erp' ); ?></label>
				</td></tr>
			<tr><th><?php esc_html_e( 'Footer note', 'wc-enterprise-erp' ); ?></th>
				<td><input type="text" name="inv_footer" class="regular-text" value="<?php echo esc_attr( $s['footer'] ); ?>"></td></tr>
			<tr><th><?php esc_html_e( 'Terms & conditions', 'wc-enterprise-erp' ); ?></th>
				<td><textarea name="inv_terms" rows="2" class="regular-text"><?php echo esc_textarea( $s['terms'] ); ?></textarea></td></tr>
		</tbody></table>
		<?php

		self::image_field_script();
	}
}
