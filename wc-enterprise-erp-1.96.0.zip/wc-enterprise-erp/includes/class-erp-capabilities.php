<?php
/**
 * Role & permission module core. Creates dedicated ERP roles and granular
 * capabilities so an accountant can post journals without seeing purchase
 * costs, a store keeper can move stock without touching money, etc.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Capabilities {

	public static function all_caps() {
		return array(
			'wceerp_view_dashboard'     => __( 'View ERP dashboard', 'wc-enterprise-erp' ),
			'wceerp_manage_inventory'   => __( 'Manage inventory & stock', 'wc-enterprise-erp' ),
			'wceerp_manage_purchases'   => __( 'Manage purchases', 'wc-enterprise-erp' ),
			'wceerp_manage_suppliers'   => __( 'Manage suppliers', 'wc-enterprise-erp' ),
			'wceerp_manage_expenses'    => __( 'Manage expenses', 'wc-enterprise-erp' ),
			'wceerp_manage_warehouses'  => __( 'Manage warehouses', 'wc-enterprise-erp' ),
			'wceerp_manage_accounting'  => __( 'Manage accounting & journals', 'wc-enterprise-erp' ),
			'wceerp_manage_payments'    => __( 'Record payments (dues)', 'wc-enterprise-erp' ),
			'wceerp_manage_resellers'   => __( 'Manage resellers & commission', 'wc-enterprise-erp' ),
			'wceerp_manage_quotations'  => __( 'Manage quotations', 'wc-enterprise-erp' ),
			'wceerp_manage_courier'     => __( 'Manage courier & COD', 'wc-enterprise-erp' ),
			'wceerp_manage_assets'      => __( 'Manage fixed assets', 'wc-enterprise-erp' ),
			'wceerp_view_audit'         => __( 'View audit log', 'wc-enterprise-erp' ),
			'wceerp_manage_rfq'         => __( 'Manage RFQs & vendor quotes', 'wc-enterprise-erp' ),
			'wceerp_approve_purchases'  => __( 'Approve purchase orders', 'wc-enterprise-erp' ),
			'wceerp_view_analytics'     => __( 'View business analytics', 'wc-enterprise-erp' ),
			'wceerp_manage_branches'    => __( 'Manage branches', 'wc-enterprise-erp' ),
			'wceerp_manage_dealers'     => __( 'Manage dealers & wholesale', 'wc-enterprise-erp' ),
			'wceerp_use_pos'            => __( 'Use the POS terminal', 'wc-enterprise-erp' ),
			'wceerp_use_api'            => __( 'Use the mobile/REST API', 'wc-enterprise-erp' ),
			'wceerp_manage_hr'          => __( 'Manage HR & payroll', 'wc-enterprise-erp' ),
			'wceerp_manage_crm'         => __( 'Manage CRM & leads', 'wc-enterprise-erp' ),
			'wceerp_manage_service'     => __( 'Manage services & tickets', 'wc-enterprise-erp' ),
			'wceerp_manage_manufacturing' => __( 'Manage manufacturing', 'wc-enterprise-erp' ),
			'wceerp_view_reports'       => __( 'View financial reports', 'wc-enterprise-erp' ),
			'wceerp_manage_settings'    => __( 'Manage ERP settings & modules', 'wc-enterprise-erp' ),
			'wceerp_import_export'      => __( 'Import / export data', 'wc-enterprise-erp' ),
		);
	}

	public static function install_roles() {
		$caps = array_keys( self::all_caps() );

		// Administrators & shop managers get everything.
		foreach ( array( 'administrator', 'shop_manager' ) as $role_id ) {
			$role = get_role( $role_id );
			if ( $role ) {
				foreach ( $caps as $cap ) {
					$role->add_cap( $cap );
				}
			}
		}

		add_role( 'wceerp_accountant', __( 'ERP Accountant', 'wc-enterprise-erp' ), array(
			'read'                     => true,
			'wceerp_view_dashboard'    => true,
			'wceerp_manage_accounting' => true,
			'wceerp_manage_payments'   => true,
			'wceerp_view_reports'      => true,
		) );

		add_role( 'wceerp_store_keeper', __( 'ERP Store Keeper', 'wc-enterprise-erp' ), array(
			'read'                    => true,
			'wceerp_view_dashboard'   => true,
			'wceerp_manage_inventory' => true,
			'wceerp_manage_warehouses'=> true,
		) );

		add_role( 'wceerp_purchase_officer', __( 'ERP Purchase Officer', 'wc-enterprise-erp' ), array(
			'read'                     => true,
			'wceerp_view_dashboard'    => true,
			'wceerp_manage_purchases'  => true,
			'wceerp_manage_suppliers'  => true,
			'wceerp_manage_expenses'   => true,
		) );

		add_role( 'wceerp_reseller', __( 'ERP Reseller', 'wc-enterprise-erp' ), array(
			'read' => true,
		) );
	}
}
