<?php
/**
 * Core: loads modules, builds the ERP menu, enqueues assets and renders
 * the Settings / Modules / License screens.
 *
 * @package WCEERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Core {

	/** @var WCEERP_Core */
	protected static $instance = null;

	/** @var WCEERP_Module[] */
	public $modules = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** All instantiated modules, keyed by id. */
	public function modules() {
		return $this->modules;
	}

	public function boot() {
		require_once WCEERP_PATH . 'includes/class-erp-accounting.php';
		require_once WCEERP_PATH . 'includes/class-erp-pdf.php';
		require_once WCEERP_PATH . 'includes/class-erp-wc-bridge.php';

		$this->load_modules();

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ), 20 ); // after WooCommerce registers wc-enhanced-select.
		add_action( 'admin_init', array( $this, 'handle_settings_save' ) );
		add_action( 'current_screen', array( $this, 'enforce_lockdown' ), 5 );
		add_action( 'admin_post_wceerp_activate_license', array( $this, 'handle_lock_activation' ) );
		add_action( 'admin_post_wceerp_reset_data', array( $this, 'handle_reset_data' ) );
		add_action( 'admin_post_wceerp_health_repair', array( $this, 'handle_health_repair' ) );
		add_action( 'admin_post_wceerp_backup_create', array( $this, 'handle_backup_create' ) );
		add_action( 'admin_post_wceerp_backup_download', array( $this, 'handle_backup_download' ) );
		add_action( 'admin_post_wceerp_backup_delete', array( $this, 'handle_backup_delete' ) );
		add_action( 'admin_post_wceerp_backup_restore', array( $this, 'handle_backup_restore' ) );
		add_action( 'wp_ajax_wceerp_customer_lookup', array( $this, 'ajax_customer_lookup' ) );

		// SaaS usage limits (Multisite tenants only).
		if ( class_exists( 'WCEERP_Limits' ) && WCEERP_Limits::active() ) {
			add_action( 'user_register', array( $this, 'enforce_user_limit' ), 5 );
			add_action( 'admin_notices', array( $this, 'usage_notices' ) );
			add_filter( 'wp_insert_post_data', array( $this, 'enforce_product_limit' ), 10, 2 );
		}

		WCEERP_WC_Bridge::init();
	}

	/**
	 * Module registry. Each file is self-contained and can ship as a
	 * separate add-on; third parties can register via the filter below.
	 */
	protected function load_modules() {
		$files = array(
			'dashboard'     => 'WCEERP_Module_Dashboard',
			'plan'          => 'WCEERP_Module_Plan',
			'staff'         => 'WCEERP_Module_Staff',
			'inventory'     => 'WCEERP_Module_Inventory',
			'warehouses'    => 'WCEERP_Module_Warehouses',
			'suppliers'     => 'WCEERP_Module_Suppliers',
			'purchases'     => 'WCEERP_Module_Purchases',
			'quotations'    => 'WCEERP_Module_Quotations',
			'courier'       => 'WCEERP_Module_Courier',
			'procurement'   => 'WCEERP_Module_Procurement',
			'analytics'     => 'WCEERP_Module_Analytics',
			'branches'      => 'WCEERP_Module_Branches',
			'dealers'       => 'WCEERP_Module_Dealers',
			'pos'           => 'WCEERP_Module_POS',
			'api'           => 'WCEERP_Module_API',
			'hr'            => 'WCEERP_Module_HR',
			'crm'           => 'WCEERP_Module_CRM',
			/* Built but never listed here, so it had no menu, no settings
			 * and no way in — the feature existed and was unreachable. */
			'messaging'     => 'WCEERP_Module_Messaging',
			'service'       => 'WCEERP_Module_Service',
			'ai'            => 'WCEERP_Module_AI',
			'whitelabel'    => 'WCEERP_Module_Whitelabel',
			'banking'       => 'WCEERP_Module_Banking',
			'assets'        => 'WCEERP_Module_Assets',
			'audit'         => 'WCEERP_Module_Audit',
			'accounting'    => 'WCEERP_Module_Accounting',
			'expenses'      => 'WCEERP_Module_Expenses',
			'connect'       => 'WCEERP_Module_Connect',
			'customers'     => 'WCEERP_Module_Customers',
			'dues'          => 'WCEERP_Module_Dues',
			'resellers'     => 'WCEERP_Module_Resellers',
			'manufacturing' => 'WCEERP_Module_Manufacturing',
			'barcode'       => 'WCEERP_Module_Barcode',
			'tax'           => 'WCEERP_Module_Tax',
			'reports'       => 'WCEERP_Module_Reports',
			'import-export' => 'WCEERP_Module_Import_Export',
			'notifications' => 'WCEERP_Module_Notifications',
			'roles'         => 'WCEERP_Module_Roles',
		);

		foreach ( $files as $slug => $class ) {
			$path = WCEERP_PATH . 'includes/modules/class-module-' . $slug . '.php';
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}

		$classes = apply_filters( 'wceerp_modules', array_values( $files ) );

		foreach ( $classes as $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}
			$module = new $class();
			$this->modules[ $module->get_id() ] = $module;
			if ( $module->is_active() ) {
				$module->init();
			}
		}

		uasort( $this->modules, function ( $a, $b ) {
			return $a->get_order() <=> $b->get_order();
		} );
	}

	public function module( $id ) {
		return isset( $this->modules[ $id ] ) ? $this->modules[ $id ] : null;
	}

	/* ------------------------------------------------------------------ */
	/*  Admin menu                                                         */
	/* ------------------------------------------------------------------ */

	public function admin_menu() {
		$unread = WCEERP_Module_Notifications::unread_count();
		$badge  = $unread ? ' <span class="awaiting-mod">' . (int) $unread . '</span>' : '';

		add_menu_page(
			__( 'WooCommerce ERP', 'wc-enterprise-erp' ),
			__( 'ERP', 'wc-enterprise-erp' ) . $badge,
			'read',
			'wceerp',
			array( $this, 'render_root' ),
			'dashicons-chart-area',
			56
		);

		foreach ( $this->modules as $module ) {
			if ( $module->is_active() && wceerp_user_can( $module->get_capability() ) ) {
				$module->register_menu( 'wceerp' );
			}
		}

		/* These two are not modules, so they need their icon adding by hand
		 * or they sit in the menu with a blank space where every other
		 * entry has a glyph. */
		add_submenu_page(
			'wceerp',
			__( 'Modules & Settings', 'wc-enterprise-erp' ),
			'<span class="wceerp-mi dashicons dashicons-admin-settings" aria-hidden="true"></span><span class="wceerp-ml">' . esc_html__( 'Modules & Settings', 'wc-enterprise-erp' ) . '</span>',
			'wceerp_manage_settings',
			'wceerp-settings',
			array( $this, 'render_settings' )
		);

		/* A direct link to the staff app. Registered as a menu entry with a
		 * null callback and rewritten below, because add_submenu_page()
		 * cannot point at an external URL on its own. */
		if ( class_exists( 'WCEERP_Portal' ) && WCEERP_Portal::is_enabled() ) {
			add_submenu_page(
				'wceerp',
				__( 'Staff app', 'wc-enterprise-erp' ),
				'<span class="wceerp-mi dashicons dashicons-smartphone" aria-hidden="true"></span><span class="wceerp-ml">' . esc_html__( 'Staff app ↗', 'wc-enterprise-erp' ) . '</span>',
				'read',
				'wceerp-portal-link',
				'__return_null'
			);
			add_action( 'admin_footer', array( $this, 'portal_menu_link' ) );
		}

		/* Rename the automatic first entry rather than removing it.
		 *
		 * WordPress creates a submenu mirroring the top-level item, labelled
		 * "ERP" — a duplicate that says nothing. Deleting it was tidy but it
		 * took the dashboard with it: that entry *is* the dashboard, and
		 * without it the screen people open most had no way in from the
		 * menu. Adding a separate item does not work either, because it
		 * shares the slug and gets removed alongside.
		 *
		 * So the label is rewritten in place. */
		global $submenu;
		if ( ! empty( $submenu['wceerp'] ) ) {
			foreach ( $submenu['wceerp'] as $i => $item ) {
				if ( isset( $item[2] ) && 'wceerp' === $item[2] ) {
					$submenu['wceerp'][ $i ][0] =
						'<span class="wceerp-mi dashicons dashicons-chart-area" aria-hidden="true"></span>'
						. '<span class="wceerp-ml">' . esc_html__( 'Dashboard', 'wc-enterprise-erp' ) . '</span>';
					break;
				}
			}
		}
	}

	public function render_root() {
		$dashboard = $this->module( 'dashboard' );
		if ( $dashboard && $dashboard->is_active() ) {
			$dashboard->render_page();
			return;
		}
		echo '<div class="wrap"><h1>' . esc_html__( 'WooCommerce ERP', 'wc-enterprise-erp' ) . '</h1></div>';
	}

	public function assets( $hook ) {
		if ( false === strpos( $hook, 'wceerp' ) ) {
			return;
		}
		wp_enqueue_style( 'wceerp-admin', WCEERP_URL . 'assets/css/admin.css', array(), WCEERP_VERSION );
		/* Design system, loaded after the base sheet so it wins on the
		 * shared classes every module already uses. */
		wp_enqueue_style( 'wceerp-admin-ui', WCEERP_URL . 'assets/css/admin-ui.css', array( 'wceerp-admin' ), WCEERP_VERSION );
		wp_enqueue_script( 'wceerp-admin', WCEERP_URL . 'assets/js/admin.js', array( 'jquery' ), WCEERP_VERSION, true );

		// WooCommerce AJAX product search (selectWoo) on ERP screens.
		if ( wp_script_is( 'wc-enhanced-select', 'registered' ) ) {
			wp_enqueue_script( 'wc-enhanced-select' );
		}
		if ( wp_style_is( 'woocommerce_admin_styles', 'registered' ) ) {
			wp_enqueue_style( 'woocommerce_admin_styles' );
		}
		wp_add_inline_script( 'wceerp-admin', "jQuery(function($){ $(document.body).trigger('wc-enhanced-select-init'); });" );
		wp_localize_script( 'wceerp-admin', 'wceerp', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'wceerp_ajax' ),
			'i18n'  => array(
				'confirmDelete' => __( 'Delete this record? This cannot be undone.', 'wc-enterprise-erp' ),
				'rowRemove'     => __( 'Remove', 'wc-enterprise-erp' ),
			),
		) );
	}

	/* ------------------------------------------------------------------ */
	/*  Settings / Modules / License                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * Block new products once the plan's product cap is reached. A blocked
	 * publish reverts to draft rather than erroring, so nothing is lost.
	 */
	public function enforce_product_limit( $data, $postarr ) {
		if ( 'product' !== ( $data['post_type'] ?? '' ) || 'publish' !== ( $data['post_status'] ?? '' ) ) {
			return $data;
		}
		// Existing product being updated is fine; only new publishes count.
		$is_new = empty( $postarr['ID'] ) || 'auto-draft' === get_post_status( $postarr['ID'] );
		if ( $is_new && ! WCEERP_Limits::can_add( 'products', 1 ) ) {
			$data['post_status'] = 'draft';
			set_transient( 'wceerp_limit_hit_products', 1, 60 );
		}
		return $data;
	}

	/**
	 * Prevent creating staff users beyond the plan cap. Runs early on
	 * user_register; over-limit users are demoted to no role and flagged.
	 */
	public function enforce_user_limit( $user_id ) {
		if ( WCEERP_Limits::can_add( 'users', 0 ) ) {
			return; // still room (usage already includes the new row).
		}
		set_transient( 'wceerp_limit_hit_users', 1, 60 );
	}

	/** Surface friendly limit notices in wp-admin. */
	public function usage_notices() {
		foreach ( array( 'products', 'users', 'orders_month' ) as $resource ) {
			if ( get_transient( 'wceerp_limit_hit_' . $resource ) ) {
				delete_transient( 'wceerp_limit_hit_' . $resource );
				printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( WCEERP_Limits::limit_message( $resource ) ) );
			}
		}
	}

	/** Activate a key from the lock screen. */
	/**
	 * Point the "Staff app" menu item at the portal and open it in a new
	 * tab. Done in the footer because WordPress menu items must resolve to
	 * an admin page, and we want an external destination.
	 */
	public function portal_menu_link() {
		$url = esc_url( WCEERP_Portal::url() );
		?>
		<script>
		(function () {
			var a = document.querySelector('a[href*="page=wceerp-portal-link"]');
			if (a) { a.setAttribute('href', '<?php echo $url; // phpcs:ignore ?>'); a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener'); }
		})();
		</script>
		<?php
	}

	public function handle_lock_activation() {
		if ( ! is_user_logged_in() || ! check_admin_referer( 'wceerp_activate_license' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}
		$key    = sanitize_text_field( wp_unslash( $_POST['license_key'] ?? '' ) );
		$result = $key ? WCEERP_License::activate_key( $key ) : new WP_Error( 'empty', 'no key' );
		$args   = array( 'page' => 'wceerp' );
		if ( is_wp_error( $result ) ) {
			$args['activated'] = 'fail';
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Licence lockdown.
	 *
	 * When the licence is expired or deactivated, the ERP stops entirely —
	 * no free tier, no read-only browsing. Every ERP screen is replaced by
	 * a single activation page.
	 *
	 * Data is never touched: tables, journals and stock stay exactly as
	 * they are, and everything returns the moment a valid key is entered.
	 * Locking a customer out of their books is a commercial lever, not a
	 * reason to destroy their records.
	 */
	public function enforce_lockdown() {
		if ( ! is_admin() || wp_doing_ajax() ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		// First sight of the ERP starts the free trial clock.
		if ( 0 === strpos( $page, 'wceerp' ) && class_exists( 'WCEERP_License' ) ) {
			WCEERP_License::maybe_start_trial();
		}
		if ( ! class_exists( 'WCEERP_License' ) || ! WCEERP_License::is_locked() ) {
			return;
		}
		if ( 0 !== strpos( $page, 'wceerp' ) ) {
			return; // Only ERP screens are locked; the rest of WP is untouched.
		}
		$this->render_lock_screen();
		exit;
	}

	/** Full-screen "activate your licence" page. */
	protected function render_lock_screen() {
		$reason  = WCEERP_License::lock_reason();
		$license = WCEERP_License::get();
		$brand   = apply_filters( 'wceerp_brand', 'WooCommerce ERP' );
		$notice  = '';
		if ( isset( $_GET['activated'] ) ) {
			$notice = 'fail' === $_GET['activated']
				? __( 'That licence key could not be activated. Check the key and try again.', 'wc-enterprise-erp' )
				: '';
		}
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php esc_html_e( 'Licence required', 'wc-enterprise-erp' ); ?></title>
			<style>
				body{margin:0;font-family:-apple-system,'Segoe UI',Roboto,Arial,sans-serif;background:#f3f4f2;color:#1f2430;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
				.box{background:#fff;border:1px solid #e6e3d8;border-radius:16px;padding:34px 32px;max-width:460px;width:100%;box-shadow:0 10px 40px rgba(0,0,0,.08)}
				.logo{width:52px;height:52px;border-radius:13px;background:linear-gradient(135deg,#075742,#0a6e54);color:#fff;font-weight:800;font-size:20px;display:flex;align-items:center;justify-content:center;margin-bottom:18px}
				h1{font-size:20px;margin:0 0 8px}
				.reason{background:#fdf3f2;border-left:4px solid #c8302e;border-radius:8px;padding:12px 14px;font-size:14px;margin:0 0 18px}
				p.help{color:#6f7680;font-size:13.5px;line-height:1.6;margin:0 0 18px}
				label{display:block;font-size:13px;font-weight:600;margin-bottom:6px}
				input[type=text]{width:100%;padding:12px;border:2px solid #dcdcd4;border-radius:10px;font-size:15px;font-family:monospace}
				input[type=text]:focus{outline:0;border-color:#075742}
				button{margin-top:14px;width:100%;background:#075742;color:#fff;border:0;border-radius:10px;padding:13px;font-size:15px;font-weight:600;cursor:pointer}
				button:hover{background:#0a6e54}
				.err{color:#c8302e;font-size:13px;margin-top:10px}
				.foot{margin-top:20px;font-size:12.5px;color:#8a8f98;text-align:center}
				.foot a{color:#075742;text-decoration:none}
				.safe{background:#f5faf7;border:1px solid #d8ebe1;border-radius:8px;padding:11px 13px;font-size:12.5px;color:#2f6b52;margin-top:16px}
			</style>
		</head>
		<body>
			<div class="box">
				<div class="logo"><?php echo esc_html( mb_substr( $brand, 0, 2 ) ); ?></div>
				<h1><?php echo esc_html( $brand ); ?></h1>
				<div class="reason"><?php echo esc_html( $reason ); ?></div>
				<p class="help"><?php esc_html_e( 'Enter an active licence key to restore access.', 'wc-enterprise-erp' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wceerp_activate_license">
					<?php wp_nonce_field( 'wceerp_activate_license' ); ?>
					<label for="lk"><?php esc_html_e( 'Licence key', 'wc-enterprise-erp' ); ?></label>
					<input type="text" id="lk" name="license_key" autocomplete="off" autofocus
						value="<?php echo esc_attr( $license['key'] ?? '' ); ?>" placeholder="XXXX-XXXX-XXXX">
					<?php if ( $notice ) : ?><div class="err"><?php echo esc_html( $notice ); ?></div><?php endif; ?>
					<button type="submit"><?php esc_html_e( 'Activate licence', 'wc-enterprise-erp' ); ?></button>
				</form>
				<div class="safe">
					<?php esc_html_e( 'Your data is safe. Nothing has been deleted — every record returns as soon as the licence is active.', 'wc-enterprise-erp' ); ?>
				</div>
				<div class="foot">
					<a href="<?php echo esc_url( admin_url() ); ?>">← <?php esc_html_e( 'Back to WordPress', 'wc-enterprise-erp' ); ?></a>
					·
					<a href="https://getproservices.net" target="_blank" rel="noopener"><?php esc_html_e( 'Renew or get support', 'wc-enterprise-erp' ); ?></a>
				</div>
			</div>
		</body>
		</html>
		<?php
	}

	/**
	 * AJAX: return a WooCommerce customer's contact details for auto-fill
	 * (used by the quotation and other customer pickers).
	 */
	public function ajax_customer_lookup() {
		check_ajax_referer( 'wceerp_customer_lookup' );
		if ( ! wceerp_user_can( 'wceerp_view_dashboard' ) ) {
			wp_send_json_error();
		}
		$user = get_userdata( (int) ( $_POST['id'] ?? 0 ) );
		if ( ! $user ) {
			wp_send_json_error();
		}
		$id      = $user->ID;
		$name    = trim( get_user_meta( $id, 'billing_first_name', true ) . ' ' . get_user_meta( $id, 'billing_last_name', true ) );
		$addr    = array_filter( array(
			get_user_meta( $id, 'billing_address_1', true ),
			get_user_meta( $id, 'billing_address_2', true ),
			get_user_meta( $id, 'billing_city', true ),
		) );
		wp_send_json_success( array(
			'name'    => $name ?: $user->display_name,
			'phone'   => (string) get_user_meta( $id, 'billing_phone', true ),
			'email'   => $user->user_email,
			'address' => implode( ', ', $addr ),
		) );
	}

	public function handle_settings_save() {
		if ( ! isset( $_POST['wceerp_settings_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_key( $_POST['wceerp_settings_nonce'] ), 'wceerp_settings' ) || ! wceerp_user_can( 'wceerp_manage_settings' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'wc-enterprise-erp' ) );
		}

		// Module toggles. Only modules shown on the form (included in the
		// current package) are processed; the disabled-state of hidden,
		// out-of-package modules is preserved untouched.
		$enabled  = isset( $_POST['modules'] ) ? array_map( 'sanitize_key', (array) $_POST['modules'] ) : array();
		$prev_disabled = (array) get_option( 'wceerp_disabled_modules', array() );
		$disabled = array();
		foreach ( $this->modules as $id => $module ) {
			if ( 'dashboard' === $id ) {
				continue; // Dashboard always on.
			}

			// Is this module part of the current package (mirrors the form)?
			$included = WCEERP_License::tier_allows( $module->get_tier() );
			if ( class_exists( 'WCEERP_Limits' ) ) {
				$ov = WCEERP_Limits::feature_override( $id );
				if ( 'on' === $ov ) {
					$included = true;
				} elseif ( 'off' === $ov ) {
					$included = false;
				}
			}

			if ( ! $included ) {
				// Not on the form — keep whatever state it already had.
				if ( in_array( $id, $prev_disabled, true ) ) {
					$disabled[] = $id;
				}
				continue;
			}

			if ( ! in_array( $id, $enabled, true ) ) {
				$disabled[] = $id;
			}
		}
		update_option( 'wceerp_disabled_modules', $disabled );

		// A module may have just been enabled (e.g. POS) whose front-end
		// route isn't in the compiled rewrite table yet. Re-arm the POS
		// self-heal and flush so the terminal URL works without the admin
		// having to visit Permalinks manually.
		delete_option( 'wceerp_pos_flushed' );
		flush_rewrite_rules( false );

		// General settings.
		$fields = array( 'fiscal_year_start_month', 'number_grouping', 'bangla_digits', 'default_vat_rate', 'company_name', 'company_bin', 'company_address', 'mushak_prefix', 'low_stock_threshold', 'portal_slug', 'contact_whatsapp', 'history_mode', 'start_date', 'sale_post_trigger', 'cn_prefix', 'cn_pattern', 'cn_pad', 'pin_grace_minutes' );

		/* Checkboxes send nothing when unticked, so they cannot ride in the
		 * text-field loop — absent has to mean "no", not "leave as is". */
		wceerp_update_option( 'pin_enabled', empty( $_POST['pin_enabled'] ) ? 'no' : 'yes' );
		if ( isset( $_POST['wceerp_settings_nonce'] ) ) {
			wceerp_update_option( 'portal_enabled', empty( $_POST['portal_enabled'] ) ? 'no' : 'yes' );
			wceerp_update_option( 'portal_2fa_required', empty( $_POST['portal_2fa_required'] ) ? 'no' : 'yes' );
			delete_option( 'wceerp_portal_flushed' );
		}
		if ( isset( $_POST['inv_preset'] ) ) {
			WCEERP_Invoice_Settings::save();
		}
		foreach ( $fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				wceerp_update_option( $field, sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) );
			}
		}

		// License.
		if ( isset( $_POST['license_endpoint'] ) && ! defined( 'WCEERP_LICENSE_ENDPOINT' ) ) {
			wceerp_update_option( 'license_endpoint', esc_url_raw( wp_unslash( $_POST['license_endpoint'] ) ) );
		}
		if ( ! empty( $_POST['license_key'] ) ) {
			WCEERP_License::activate_key( sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) );
		}

		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'ERP settings saved.', 'wc-enterprise-erp' ) . '</p></div>';
		} );
	}

	public function render_settings() {
		$disabled = (array) get_option( 'wceerp_disabled_modules', array() );
		$license  = WCEERP_License::get();
		?>
		<div class="wrap wceerp-wrap">
			<h1><?php esc_html_e( 'Modules & Settings', 'wc-enterprise-erp' ); ?></h1>
			<p class="wceerp-lede"><?php esc_html_e( 'Everything that changes how the ERP behaves, grouped so you only see one decision at a time.', 'wc-enterprise-erp' ); ?></p>

			<?php
			/* Flags on the index so a problem is visible before you click
			 * into the section that owns it. */
			$health_flag = '';
			if ( class_exists( 'WCEERP_Health' ) ) {
				$h = WCEERP_Health::run();
				if ( empty( $h['tables']['ok'] ) || empty( $h['accounts']['ok'] ) || empty( $h['writes']['ok'] ) ) {
					$health_flag = 'wceerp-flag-bad';
				} else {
					foreach ( (array) $h['lookups'] as $lk ) {
						if ( null === $lk['count'] || $lk['count'] < 1 ) {
							$health_flag = 'wceerp-flag-bad';
							break;
						}
					}
				}
			}
			$books_flag = wceerp_get_option( 'start_date', '' ) ? '' : 'wceerp-flag-warn';

			$sections = array(
				'modules'   => array( __( 'Modules', 'wc-enterprise-erp' ), '' ),
				'company'   => array( __( 'Company', 'wc-enterprise-erp' ), '' ),
				'licence'   => array( __( 'Licence', 'wc-enterprise-erp' ), '' ),
				'portal'    => array( __( 'Staff portal', 'wc-enterprise-erp' ), '' ),
				'sale'      => array( __( 'When sales record', 'wc-enterprise-erp' ), '' ),
				'numbering' => array( __( 'Numbering', 'wc-enterprise-erp' ), '' ),
				'pin'       => array( __( 'Access & PIN', 'wc-enterprise-erp' ), '' ),
				'books'     => array( __( 'Books & period', 'wc-enterprise-erp' ), $books_flag ),
				'invoice'   => array( __( 'Invoices', 'wc-enterprise-erp' ), '' ),
				'health'    => array( __( 'System health', 'wc-enterprise-erp' ), $health_flag ),
				'backup'    => array( __( 'Backup', 'wc-enterprise-erp' ), '' ),
				'danger'    => array( __( 'Reset data', 'wc-enterprise-erp' ), '' ),
			);
			$i = 0;
			?>

			<div class="wceerp-settings">
				<aside class="wceerp-index">
					<div class="wceerp-index-head"><span class="wceerp-eyebrow"><?php esc_html_e( 'Sections', 'wc-enterprise-erp' ); ?></span></div>
					<?php foreach ( $sections as $key => $meta ) : $i++; ?>
						<button type="button" class="wceerp-tab<?php echo 1 === $i ? ' is-on' : ''; ?>" data-panel="wceerp-p-<?php echo esc_attr( $key ); ?>">
							<span class="wceerp-n"><?php echo esc_html( sprintf( '%02d', $i ) ); ?></span>
							<?php echo esc_html( $meta[0] ); ?>
							<?php if ( $meta[1] ) : ?><span class="wceerp-flag <?php echo esc_attr( $meta[1] ); ?>"></span><?php endif; ?>
						</button>
					<?php endforeach; ?>
				</aside>

				<div class="wceerp-panels">
			<form method="post">
				<?php wp_nonce_field( 'wceerp_settings', 'wceerp_settings_nonce' ); ?>

				<div class="wceerp-panel is-on" id="wceerp-p-modules"><div class="wceerp-card">
				<h2><?php esc_html_e( 'Modules', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'These are the modules included in your current plan. Switch them on or off — data is kept when a module is off.', 'wc-enterprise-erp' ); ?></p>
				<div class="wceerp-modules-grid">
					<?php
					$hidden_count = 0;
					foreach ( $this->modules as $id => $module ) :
						// Phase 4: only show features the current package includes.
						// A per-tenant "on" override also counts as included.
						$included = WCEERP_License::tier_allows( $module->get_tier() );
						if ( class_exists( 'WCEERP_Limits' ) ) {
							$ov = WCEERP_Limits::feature_override( $id );
							if ( 'on' === $ov ) {
								$included = true;
							} elseif ( 'off' === $ov ) {
								$included = false;
							}
						}
						if ( 'dashboard' === $id ) {
							$included = true; // always available
						}
						if ( ! $included ) {
							$hidden_count++;
							continue;
						}
						?>
						<?php $is_off = in_array( $id, $disabled, true ); ?>
						<div class="wceerp-module<?php echo $is_off ? ' is-off' : ''; ?>">
							<label class="wceerp-switch">
								<input type="checkbox" name="modules[]" value="<?php echo esc_attr( $id ); ?>"
									<?php checked( ! $is_off ); ?>
									<?php disabled( 'dashboard' === $id ); ?> />
								<span class="wceerp-track"></span>
								<span class="screen-reader-text"><?php echo esc_html( $module->get_title() ); ?></span>
							</label>
							<span>
								<span class="wceerp-module-name"><?php echo esc_html( $module->get_title() ); ?></span>
								<span class="wceerp-module-desc"><?php echo esc_html( ucfirst( $module->get_tier() ) ); ?><?php echo 'dashboard' === $id ? ' · ' . esc_html__( 'always on', 'wc-enterprise-erp' ) : ''; ?></span>
							</span>
						</div>
					<?php endforeach; ?>
				</div>
				<script>
				document.querySelectorAll( '.wceerp-module .wceerp-switch input' ).forEach( function ( cb ) {
					cb.addEventListener( 'change', function () {
						cb.closest( '.wceerp-module' ).classList.toggle( 'is-off', ! cb.checked );
					} );
				} );
				</script>
				<?php if ( $hidden_count > 0 ) : ?>
					<p class="description" style="margin-top:10px">
						<?php
						printf(
							/* translators: %d: number of features not in the current plan */
							esc_html__( '%d more feature(s) are available on higher plans. Contact Get Pro Services to upgrade.', 'wc-enterprise-erp' ),
							(int) $hidden_count
						);
						?>
					</p>
				<?php endif; ?>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-company"><div class="wceerp-card">
				<h2><?php esc_html_e( 'Company & Localisation (Bangladesh)', 'wc-enterprise-erp' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><label for="company_name"><?php esc_html_e( 'Company name', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" class="regular-text" name="company_name" id="company_name" value="<?php echo esc_attr( wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ) ); ?>"></td>
					</tr>
					<tr>
						<th><label for="company_bin"><?php esc_html_e( 'BIN (VAT registration no.)', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" class="regular-text" name="company_bin" id="company_bin" value="<?php echo esc_attr( wceerp_get_option( 'company_bin', '' ) ); ?>" placeholder="0000000000-0000"></td>
					</tr>
					<tr>
						<th><label for="company_address"><?php esc_html_e( 'Company address', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" class="large-text" name="company_address" id="company_address" value="<?php echo esc_attr( wceerp_get_option( 'company_address', '' ) ); ?>"></td>
					</tr>
					<tr>
						<th><label for="fiscal_year_start_month"><?php esc_html_e( 'Fiscal year starts', 'wc-enterprise-erp' ); ?></label></th>
						<td>
							<select name="fiscal_year_start_month" id="fiscal_year_start_month">
								<?php for ( $m = 1; $m <= 12; $m++ ) : ?>
									<option value="<?php echo (int) $m; ?>" <?php selected( (int) wceerp_get_option( 'fiscal_year_start_month', 7 ), $m ); ?>>
										<?php echo esc_html( date_i18n( 'F', mktime( 0, 0, 0, $m, 1 ) ) ); ?>
									</option>
								<?php endfor; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Bangladesh fiscal year: July – June.', 'wc-enterprise-erp' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Number grouping', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label><input type="radio" name="number_grouping" value="lakh" <?php checked( wceerp_get_option( 'number_grouping', 'lakh' ), 'lakh' ); ?>> <?php esc_html_e( 'Lakh / Crore (12,34,567.00)', 'wc-enterprise-erp' ); ?></label><br>
							<label><input type="radio" name="number_grouping" value="thousand" <?php checked( wceerp_get_option( 'number_grouping', 'lakh' ), 'thousand' ); ?>> <?php esc_html_e( 'Thousands (1,234,567.00)', 'wc-enterprise-erp' ); ?></label>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Bangla digits', 'wc-enterprise-erp' ); ?></th>
						<td><label><input type="checkbox" name="bangla_digits" value="yes" <?php checked( wceerp_get_option( 'bangla_digits', 'no' ), 'yes' ); ?>> <?php esc_html_e( 'Show amounts in Bangla numerals (৳১,২৩,৪৫৬)', 'wc-enterprise-erp' ); ?></label></td>
					</tr>
					<tr>
						<th><label for="default_vat_rate"><?php esc_html_e( 'Default VAT rate (%)', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="number" step="0.01" name="default_vat_rate" id="default_vat_rate" value="<?php echo esc_attr( wceerp_get_option( 'default_vat_rate', '15' ) ); ?>" class="small-text"> <span class="description"><?php esc_html_e( 'NBR standard rate is 15%.', 'wc-enterprise-erp' ); ?></span></td>
					</tr>
					<tr>
						<th><label for="mushak_prefix"><?php esc_html_e( 'Mushak-6.3 invoice prefix', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="text" name="mushak_prefix" id="mushak_prefix" value="<?php echo esc_attr( wceerp_get_option( 'mushak_prefix', 'MUS63' ) ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label for="low_stock_threshold"><?php esc_html_e( 'Default low-stock alert level', 'wc-enterprise-erp' ); ?></label></th>
						<td><input type="number" name="low_stock_threshold" id="low_stock_threshold" value="<?php echo esc_attr( wceerp_get_option( 'low_stock_threshold', '5' ) ); ?>" class="small-text"></td>
					</tr>
				</table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-licence"><div class="wceerp-card">
				<h2><?php esc_html_e( 'License', 'wc-enterprise-erp' ); ?></h2>
				<table class="form-table">
					<?php if ( is_multisite() && get_option( 'wceerp_saas_tier', '' ) ) : ?>
					<tr>
						<th><?php esc_html_e( 'Subscription', 'wc-enterprise-erp' ); ?></th>
						<td>
							<strong><?php echo esc_html( ucfirst( get_option( 'wceerp_saas_tier' ) ) ); ?></strong> <?php esc_html_e( 'package — managed by your platform.', 'wc-enterprise-erp' ); ?>
							<?php $sx = get_option( 'wceerp_saas_expires', '' ); ?>
							<?php if ( $sx ) : ?><br><small><?php printf( esc_html__( 'Paid until %s.', 'wc-enterprise-erp' ), esc_html( $sx ) ); ?></small><?php endif; ?>
							<p class="description"><?php esc_html_e( 'Contact your platform to change plans. Manual license keys are not used on this hosted account.', 'wc-enterprise-erp' ); ?></p>
						</td>
					</tr>
					<?php else : ?>
					<?php
					/* The endpoint field is hidden by default. A customer never
					 * needs it — the plugin ships knowing where to validate —
					 * and exposing it invites someone to repoint the plugin at
					 * a licence server of their own. Reveal it only for
					 * deliberate self-hosted/white-label deployments. */
					$show_endpoint = apply_filters( 'wceerp_show_license_endpoint_field', defined( 'WCEERP_SHOW_ENDPOINT_FIELD' ) && WCEERP_SHOW_ENDPOINT_FIELD );
					?>
					<?php if ( $show_endpoint ) : ?>
					<tr>
						<th><label for="license_endpoint"><?php esc_html_e( 'License server endpoint', 'wc-enterprise-erp' ); ?></label></th>
						<td>
							<?php $ep_locked = WCEERP_License::endpoint_is_locked(); ?>
							<input type="url" class="regular-text" name="license_endpoint" id="license_endpoint"
								value="<?php echo esc_attr( $ep_locked ? WCEERP_License::endpoint() : wceerp_get_option( 'license_endpoint', '' ) ); ?>"
								placeholder="<?php echo esc_attr( WCEERP_License::DEFAULT_ENDPOINT ); ?>"
								<?php disabled( $ep_locked ); ?>>
							<?php if ( $ep_locked ) : ?>
								<p class="description">🔒 <?php esc_html_e( 'Locked by the WCEERP_LICENSE_ENDPOINT constant in wp-config.php. This cannot be changed from the admin, which prevents anyone repointing the plugin at a different licence server.', 'wc-enterprise-erp' ); ?></p>
							<?php else : ?>
								<p class="description">
									<?php
									printf(
										/* translators: %s: default endpoint URL */
										esc_html__( 'Leave blank to use the built-in default (%s). Only change this if you were given a different licence server address.', 'wc-enterprise-erp' ),
										'<code>' . esc_html( WCEERP_License::DEFAULT_ENDPOINT ) . '</code>'
									);
									?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<?php endif; ?>
					<tr>
						<th><label for="license_key"><?php esc_html_e( 'License key', 'wc-enterprise-erp' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" name="license_key" id="license_key" value="<?php echo esc_attr( $license['key'] ); ?>">
							<p class="description">
								<?php
								printf(
									/* translators: 1: status 2: tier 3: expiry */
									esc_html__( 'Status: %1$s · Tier: %2$s · Expires: %3$s', 'wc-enterprise-erp' ),
									esc_html( $license['status'] ),
									esc_html( ucfirst( $license['tier'] ) ),
									esc_html( $license['expires'] ? $license['expires'] : '—' )
								);
								?>
							</p>
						</td>
					</tr>
					<?php endif; ?>
				</table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-portal"><div class="wceerp-card">
				<h2><?php esc_html_e( 'Staff portal', 'wc-enterprise-erp' ); ?></h2>
				<p class="description"><?php esc_html_e( 'A clean front door for staff, so they reach the ERP without seeing the WordPress dashboard. They sign in with the shop PIN.', 'wc-enterprise-erp' ); ?></p>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Enable portal', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label><input type="checkbox" name="portal_enabled" value="1" <?php checked( wceerp_get_option( 'portal_enabled', 'no' ), 'yes' ); ?>> <?php esc_html_e( 'Turn on the staff portal', 'wc-enterprise-erp' ); ?></label>
							<p class="description">
								<?php esc_html_e( 'Protected by attempt limits and a lockout, and staff devices stay signed in for 12 hours. Leave off if you would rather everyone went through the WordPress login.', 'wc-enterprise-erp' ); ?>
							</p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Two-factor', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label><input type="checkbox" name="portal_2fa_required" value="1" <?php checked( wceerp_get_option( 'portal_2fa_required', 'no' ), 'yes' ); ?>> <?php esc_html_e( 'Require a verification code for everyone using the portal', 'wc-enterprise-erp' ); ?></label>
							<p class="description"><?php esc_html_e( 'Each person sets this up on their own WordPress profile with an authenticator app. Leave off and it stays optional — anyone who enables it individually will still be asked.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Portal address', 'wc-enterprise-erp' ); ?></th>
						<td>
							<code><?php echo esc_html( home_url( '/' ) ); ?></code>
							<input type="text" name="portal_slug" value="<?php echo esc_attr( wceerp_get_option( 'portal_slug', 'erp' ) ); ?>" style="width:130px">
							<p class="description"><?php esc_html_e( 'Save, then visit Settings → Permalinks once if the address does not work immediately.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
				</tbody></table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-sale"><div class="wceerp-card">
				<h2><?php esc_html_e( 'When a sale is recorded', 'wc-enterprise-erp' ); ?></h2>
				<p class="description" style="max-width:680px">
					<?php esc_html_e( 'Decides the moment stock leaves the ERP and the sale reaches the accounts. Stock and the accounts always move together — separating them would leave your profit figures wrong for the period.', 'wc-enterprise-erp' ); ?>
				</p>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Record sales at', 'wc-enterprise-erp' ); ?></th>
						<td>
							<?php $trig = wceerp_get_option( 'sale_post_trigger', 'processing' ); ?>
							<div class="wceerp-choices">
							<label class="wceerp-choice<?php echo 'processing' === $trig ? ' is-on' : ''; ?>">
								<input type="radio" name="sale_post_trigger" value="processing" <?php checked( $trig, 'processing' ); ?>><span>
								<?php esc_html_e( 'Order is accepted (Processing)', 'wc-enterprise-erp' ); ?>
								<span class="wceerp-choice-desc"><?php esc_html_e( 'Stock drops as soon as the order arrives.', 'wc-enterprise-erp' ); ?></span></span>
							</label>
							<label class="wceerp-choice<?php echo 'courier_booked' === $trig ? ' is-on' : ''; ?>">
								<input type="radio" name="sale_post_trigger" value="courier_booked" <?php checked( $trig, 'courier_booked' ); ?>><span>
								<?php esc_html_e( 'Parcel is booked with a courier', 'wc-enterprise-erp' ); ?>
								<span class="wceerp-choice-desc"><?php esc_html_e( 'Stock and revenue move at dispatch.', 'wc-enterprise-erp' ); ?></span></span>
								<span class="wceerp-tag"><?php esc_html_e( 'Best for COD', 'wc-enterprise-erp' ); ?></span>
							</label>
							<label class="wceerp-choice<?php echo 'completed' === $trig ? ' is-on' : ''; ?>">
								<input type="radio" name="sale_post_trigger" value="completed" <?php checked( $trig, 'completed' ); ?>><span>
								<?php esc_html_e( 'Order is marked Completed', 'wc-enterprise-erp' ); ?></span>
							</label>
							</div>
							<p class="description" style="margin-top:8px">
								<?php esc_html_e( 'POS sales always record immediately — the goods have already left the counter. Marking an order Completed always records it, so an order collected in person is never missed.', 'wc-enterprise-erp' ); ?>
							</p>
						</td></tr>
				</tbody></table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-numbering"><div class="wceerp-card">
				<h2><?php esc_html_e( 'Consignment numbering', 'wc-enterprise-erp' ); ?></h2>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Prefix', 'wc-enterprise-erp' ); ?></th>
						<td><input type="text" name="cn_prefix" maxlength="10" style="width:100px"
							value="<?php echo esc_attr( wceerp_get_option( 'cn_prefix', 'CN' ) ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Format', 'wc-enterprise-erp' ); ?></th>
						<td>
							<?php
							$pat = wceerp_get_option( 'cn_pattern', 'ym' );
							$px  = strtoupper( wceerp_get_option( 'cn_prefix', 'CN' ) );
							$opts = array(
								'ym'  => $px . '-2026-7-0001 ' . __( '(resets monthly)', 'wc-enterprise-erp' ),
								'ymm' => $px . '-2026-07-0001 ' . __( '(resets monthly)', 'wc-enterprise-erp' ),
								'y'   => $px . '-2026-0001 ' . __( '(resets yearly)', 'wc-enterprise-erp' ),
								'fy'  => $px . '-2627-000001 ' . __( '(fiscal year, legacy)', 'wc-enterprise-erp' ),
							);
							?>
							<select name="cn_pattern">
								<?php foreach ( $opts as $ok => $ol ) : ?>
									<option value="<?php echo esc_attr( $ok ); ?>" <?php selected( $pat, $ok ); ?>><?php echo esc_html( $ol ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Changing this starts a fresh sequence for the new format. Existing numbers are untouched.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Sequence digits', 'wc-enterprise-erp' ); ?></th>
						<td><input type="number" name="cn_pad" min="1" max="8" style="width:70px"
							value="<?php echo esc_attr( wceerp_get_option( 'cn_pad', 4 ) ); ?>">
							<p class="description"><?php esc_html_e( 'Next number:', 'wc-enterprise-erp' ); ?>
							<code><?php echo esc_html( wceerp_next_consignment_number( true ) ); ?></code></p></td></tr>
				</tbody></table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-pin"><div class="wceerp-card">
				<h2><?php esc_html_e( 'ERP PIN', 'wc-enterprise-erp' ); ?></h2>

				<?php $pin_forced = (bool) wceerp_get_option( 'remote_pin', '' ); ?>
				<table class="form-table"><tbody>
					<tr>
						<th><?php esc_html_e( 'Ask for a PIN', 'wc-enterprise-erp' ); ?></th>
						<td>
							<label class="wceerp-switch">
								<input type="checkbox" name="pin_enabled" value="yes"
									<?php checked( 'no' !== wceerp_get_option( 'pin_enabled', 'yes' ) ); ?>
									<?php disabled( $pin_forced ); ?>>
								<span class="wceerp-track"></span>
								<span><?php esc_html_e( 'Require a PIN before the ERP screens open', 'wc-enterprise-erp' ); ?></span>
							</label>
							<p class="description">
								<?php esc_html_e( 'Worth having on a shared counter terminal where several people use one WordPress login. If you are the only person who reaches these screens, it protects nothing — everyone here has already signed into WordPress with an ERP permission — and switching it off removes the friction.', 'wc-enterprise-erp' ); ?>
							</p>
							<?php if ( $pin_forced ) : ?>
								<p class="description" style="color:#B7791F">
									<?php esc_html_e( 'Your provider has set a PIN for this site, so it cannot be switched off here.', 'wc-enterprise-erp' ); ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
				</tbody></table>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Stay unlocked for', 'wc-enterprise-erp' ); ?></th>
						<td>
							<input type="number" name="pin_grace_minutes" min="0" max="120" style="width:70px"
								value="<?php echo esc_attr( wceerp_get_option( 'pin_grace_minutes', 5 ) ); ?>">
							<?php esc_html_e( 'minutes after leaving the ERP screens', 'wc-enterprise-erp' ); ?>
							<p class="description"><?php esc_html_e( 'Stops the PIN being demanded every time staff step into Products or Media and come straight back. Set to 0 to re-lock instantly.', 'wc-enterprise-erp' ); ?></p>
						</td></tr>
				</tbody></table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-books"><div class="wceerp-card">
				<h2><?php esc_html_e( 'Books start date', 'wc-enterprise-erp' ); ?></h2>
				<p class="description" style="max-width:640px">
					<?php esc_html_e( 'If this shop was trading before the ERP was installed, you almost certainly do not want years of past WooCommerce orders appearing as ERP activity. Choose where the books begin.', 'wc-enterprise-erp' ); ?>
				</p>
				<table class="form-table"><tbody>
					<tr><th><?php esc_html_e( 'Order history', 'wc-enterprise-erp' ); ?></th>
						<td>
							<?php $hmode = wceerp_get_option( 'history_mode', 'golive' ); ?>
							<label style="display:block;margin-bottom:6px">
								<input type="radio" name="history_mode" value="golive" <?php checked( $hmode, 'golive' ); ?>>
								<?php esc_html_e( 'Start fresh from a chosen date (recommended)', 'wc-enterprise-erp' ); ?>
							</label>
							<label style="display:block">
								<input type="radio" name="history_mode" value="all" <?php checked( $hmode, 'all' ); ?>>
								<?php esc_html_e( 'Include the entire WooCommerce order history', 'wc-enterprise-erp' ); ?>
							</label>
							<p class="description">
								<?php esc_html_e( 'Including everything makes ERP reports disagree with the ledger, because past orders were never posted to the accounts. Only choose it if this shop has no meaningful history.', 'wc-enterprise-erp' ); ?>
							</p>
						</td></tr>
					<tr><th><?php esc_html_e( 'Books start from', 'wc-enterprise-erp' ); ?></th>
						<td>
							<input type="date" name="start_date" value="<?php echo esc_attr( wceerp_get_option( 'start_date', (string) get_option( 'wceerp_installed_on', current_time( 'Y-m-d' ) ) ) ); ?>">
							<p class="description">
								<?php esc_html_e( 'Orders created before this date are ignored completely: never posted to the ledger and excluded from ERP reports. Defaults to the day the ERP was installed.', 'wc-enterprise-erp' ); ?>
							</p>
							<p class="description" style="margin-top:8px">
								<strong><?php esc_html_e( 'Opening balances:', 'wc-enterprise-erp' ); ?></strong>
								<?php esc_html_e( 'Starting fresh means the ledger begins at zero. To make the balance sheet correct from day one, post a manual opening journal dated the day before this date — cash and bank balances, stock value, what customers owe you, and what you owe suppliers. Accounting → Journals.', 'wc-enterprise-erp' ); ?>
							</p>
						</td></tr>
				</tbody></table>

				</div></div>

				<div class="wceerp-panel" id="wceerp-p-invoice"><div class="wceerp-card">
					<?php WCEERP_Invoice_Settings::render_form(); ?>
				</div></div>

				<div class="wceerp-savebar">
					<?php submit_button( __( 'Save settings', 'wc-enterprise-erp' ), 'primary', 'submit', false ); ?>
				</div>
			</form>

			<?php /* Outside the settings form: nested forms are invalid HTML
			         and the browser would submit the outer one instead. */ ?>
			<div class="wceerp-panel" id="wceerp-p-health"><?php WCEERP_Health::render(); ?></div>
			<div class="wceerp-panel" id="wceerp-p-backup"><?php $this->render_backup_tool(); ?></div>
			<div class="wceerp-panel" id="wceerp-p-danger"><?php $this->render_reset_tool(); ?></div>

				</div><!-- /.wceerp-panels -->
			</div><!-- /.wceerp-settings -->

			<script>
			(function () {
				/* Choice cards follow their radio, so the selected option is
				 * obvious without reading the control. */
				document.querySelectorAll( '.wceerp-choice input[type=radio]' ).forEach( function ( r ) {
					r.addEventListener( 'change', function () {
						document.querySelectorAll( 'input[name="' + r.name + '"]' ).forEach( function ( o ) {
							o.closest( '.wceerp-choice' ).classList.toggle( 'is-on', o.checked );
						} );
					} );
				} );

				var tabs   = document.querySelectorAll( '.wceerp-tab' );
				var panels = document.querySelectorAll( '.wceerp-panel' );

				function show( id, push ) {
					panels.forEach( function ( p ) { p.classList.toggle( 'is-on', p.id === id ); } );
					tabs.forEach( function ( t ) { t.classList.toggle( 'is-on', t.dataset.panel === id ); } );
					if ( push ) {
						history.replaceState( null, '', '#' + id );
					}
				}

				tabs.forEach( function ( t ) {
					t.addEventListener( 'click', function () { show( t.dataset.panel, true ); } );
				} );

				/* Deep links and reloads land back on the same section --
				 * saving settings must not throw you to the first tab. */
				if ( location.hash && document.getElementById( location.hash.slice( 1 ) ) ) {
					show( location.hash.slice( 1 ), false );
				}

				/* Carry the open section through the save round-trip. */
				var form = document.querySelector( '.wceerp-panels form' );
				if ( form ) {
					form.addEventListener( 'submit', function () {
						var open = document.querySelector( '.wceerp-panel.is-on' );
						if ( open ) { form.action = location.pathname + location.search + '#' + open.id; }
					} );
				}
			})();
			</script>

			<?php WCEERP_Pin::render_settings_fragment(); ?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------------
	 * Data reset.
	 * ------------------------------------------------------------------- */

	public function handle_reset_data() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_reset_data' );

		$confirm = strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['confirm'] ?? '' ) ) ) );
		if ( 'RESET' !== $confirm ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&reset_err=confirm' ) );
			exit;
		}

		$groups = array_map( 'sanitize_key', (array) ( $_POST['groups'] ?? array() ) );
		if ( ! $groups ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&reset_err=empty' ) );
			exit;
		}

		$removed = WCEERP_Reset::run(
			$groups,
			! empty( $_POST['clear_meta'] ),
			! empty( $_POST['reset_seq'] )
		);

		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&reset_done=' . (int) array_sum( $removed ) ) );
		exit;
	}

	protected function render_reset_tool() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$preview = WCEERP_Reset::preview();
		$groups  = WCEERP_Reset::groups();

		if ( isset( $_GET['reset_done'] ) ) {
			printf(
				'<div class="notice notice-success"><p>%s</p></div>',
				esc_html( sprintf(
					/* translators: %d: rows removed. */
					__( 'Reset complete — %d records cleared. Enter your opening stock and balances before trading again.', 'wc-enterprise-erp' ),
					(int) $_GET['reset_done']
				) )
			);
		}
		if ( isset( $_GET['reset_err'] ) ) {
			$msg = ( 'confirm' === $_GET['reset_err'] )
				? __( 'Type RESET in the confirmation box to proceed.', 'wc-enterprise-erp' )
				: __( 'Select at least one thing to clear.', 'wc-enterprise-erp' );
			printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( $msg ) );
		}
		?>
		<hr>
		<h2 style="color:#b32d2e"><?php esc_html_e( 'Reset ERP data', 'wc-enterprise-erp' ); ?></h2>
		<div style="border:1px solid #f0b7b7;background:#fff8f8;border-radius:6px;padding:14px 16px;max-width:760px">
			<p style="margin-top:0">
				<?php esc_html_e( 'Clears ERP transactions so you can start the books again from a known position. Use this if sales were recorded before opening stock was entered, which makes cost of goods sold — and therefore profit — wrong.', 'wc-enterprise-erp' ); ?>
			</p>
			<p>
				<strong><?php esc_html_e( 'Never touched:', 'wc-enterprise-erp' ); ?></strong>
				<?php esc_html_e( 'WooCommerce orders, customers, products and prices, chart of accounts, warehouses, suppliers, dealers, staff, settings, API keys and the audit trail.', 'wc-enterprise-erp' ); ?>
			</p>
			<p style="color:#b32d2e">
				<strong><?php esc_html_e( 'This cannot be undone. Take a database backup first.', 'wc-enterprise-erp' ); ?></strong>
			</p>
			<p style="background:#fcf9e8;border-left:4px solid #dba617;padding:8px 12px">
				<strong><?php esc_html_e( 'Clearing the ledger on its own is usually a mistake.', 'wc-enterprise-erp' ); ?></strong>
				<?php esc_html_e( 'Every group below writes journal entries. Empty the ledger but keep, say, consignments or purchases, and those records will still claim money moved while the books show nothing behind them — harder to untangle than starting clean. If you are resetting the ledger, tick everything.', 'wc-enterprise-erp' ); ?>
				<br>
				<label style="display:inline-block;margin-top:6px">
					<input type="checkbox" id="wceerp-reset-all">
					<strong><?php esc_html_e( 'Select everything', 'wc-enterprise-erp' ); ?></strong>
				</label>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
				onsubmit="return confirm('<?php echo esc_js( __( 'Permanently clear the selected ERP data? There is no undo.', 'wc-enterprise-erp' ) ); ?>');">
				<?php wp_nonce_field( 'wceerp_reset_data' ); ?>
				<input type="hidden" name="action" value="wceerp_reset_data">

				<table class="widefat striped" style="margin:12px 0">
					<thead><tr>
						<th style="width:28px"></th>
						<th><?php esc_html_e( 'What to clear', 'wc-enterprise-erp' ); ?></th>
						<th class="num" style="width:90px"><?php esc_html_e( 'Records', 'wc-enterprise-erp' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $groups as $key => $g ) : ?>
						<tr>
							<td><input type="checkbox" name="groups[]" value="<?php echo esc_attr( $key ); ?>" id="rg-<?php echo esc_attr( $key ); ?>"></td>
							<td>
								<label for="rg-<?php echo esc_attr( $key ); ?>"><strong><?php echo esc_html( $g['label'] ); ?></strong></label>
								<br><small style="color:#646970"><?php echo esc_html( $g['note'] ); ?></small>
							</td>
							<td class="num"><?php echo (int) ( $preview[ $key ]['total'] ?? 0 ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<p>
					<label>
						<input type="checkbox" name="clear_meta" value="1" checked>
						<?php esc_html_e( 'Also clear the "already recorded" markers on WooCommerce orders', 'wc-enterprise-erp' ); ?>
					</label>
					<br><small style="color:#646970"><?php esc_html_e( 'Leave this ticked. Without it, past orders stay flagged as recorded and can never post again.', 'wc-enterprise-erp' ); ?></small>
				</p>
				<p>
					<label>
						<input type="checkbox" name="reset_seq" value="1">
						<?php esc_html_e( 'Restart document numbering (invoice, consignment, purchase numbers)', 'wc-enterprise-erp' ); ?>
					</label>
				</p>
				<p>
					<label><strong><?php esc_html_e( 'Type RESET to confirm', 'wc-enterprise-erp' ); ?></strong></label><br>
					<input type="text" name="confirm" autocomplete="off" style="width:160px" placeholder="RESET">
				</p>
				<p><button class="button button-large" style="background:#b32d2e;border-color:#b32d2e;color:#fff"><?php esc_html_e( 'Clear selected data', 'wc-enterprise-erp' ); ?></button></p>
			</form>
		</div>
				<script>
		(function () {
			var all = document.getElementById('wceerp-reset-all');
			if (!all) { return; }
			all.addEventListener('change', function () {
				document.querySelectorAll('input[name="groups[]"]').forEach(function (c) { c.checked = all.checked; });
			});
		})();
		</script>
		<?php
	}


	/* ---------------------------------------------------------------------
	 * Backup and restore.
	 * ------------------------------------------------------------------- */

	protected function backup_guard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}
	}

	public function handle_backup_create() {
		$this->backup_guard();
		check_admin_referer( 'wceerp_backup_create' );

		$result = WCEERP_Backup::create( wp_unslash( $_POST['note'] ?? '' ) );
		if ( is_wp_error( $result ) ) {
			set_transient( 'wceerp_backup_msg_' . get_current_user_id(), $result->get_error_message(), 60 );
			wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_err=1' ) );
			exit;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_done=' . (int) $result['rows'] ) );
		exit;
	}

	/**
	 * Stream a backup to the browser.
	 *
	 * Served through PHP rather than linked directly: the file contains the
	 * entire ledger, so access has to be checked on every request.
	 */
	public function handle_backup_download() {
		$this->backup_guard();
		check_admin_referer( 'wceerp_backup_download' );

		$path = WCEERP_Backup::path_for( wp_unslash( $_GET['file'] ?? '' ) );
		if ( is_wp_error( $path ) ) {
			wp_die( esc_html( $path->get_error_message() ) );
		}

		nocache_headers();
		header( 'Content-Type: application/sql' );
		header( 'Content-Disposition: attachment; filename="' . basename( $path ) . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		readfile( $path );
		exit;
	}

	public function handle_backup_delete() {
		$this->backup_guard();
		check_admin_referer( 'wceerp_backup_delete' );
		WCEERP_Backup::delete( wp_unslash( $_POST['file'] ?? '' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_deleted=1' ) );
		exit;
	}

	public function handle_backup_restore() {
		$this->backup_guard();
		check_admin_referer( 'wceerp_backup_restore' );

		if ( 'RESTORE' !== strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['confirm'] ?? '' ) ) ) ) ) {
			set_transient( 'wceerp_backup_msg_' . get_current_user_id(), __( 'Type RESTORE to confirm.', 'wc-enterprise-erp' ), 60 );
			wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_err=1' ) );
			exit;
		}

		$result = WCEERP_Backup::restore( wp_unslash( $_POST['file'] ?? '' ) );
		if ( is_wp_error( $result ) ) {
			set_transient( 'wceerp_backup_msg_' . get_current_user_id(), $result->get_error_message(), 60 );
			wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_err=1' ) );
			exit;
		}
		if ( ! empty( $result['warnings'] ) ) {
			set_transient( 'wceerp_backup_msg_' . get_current_user_id(), implode( ' ', $result['warnings'] ), 120 );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&backup_restored=' . (int) $result['statements'] ) );
		exit;
	}

	protected function render_backup_tool() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$backups = WCEERP_Backup::all();
		$msg     = get_transient( 'wceerp_backup_msg_' . get_current_user_id() );
		if ( $msg ) {
			delete_transient( 'wceerp_backup_msg_' . get_current_user_id() );
		}

		if ( isset( $_GET['backup_done'] ) ) {
			printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( sprintf(
				/* translators: %d: rows. */
				__( 'Backup created — %d records saved.', 'wc-enterprise-erp' ),
				(int) $_GET['backup_done']
			) ) );
		}
		if ( isset( $_GET['backup_restored'] ) ) {
			printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( sprintf(
				/* translators: %d: statements. */
				__( 'Restore complete — %d statements applied.', 'wc-enterprise-erp' ),
				(int) $_GET['backup_restored']
			) ) );
		}
		if ( isset( $_GET['backup_deleted'] ) ) {
			printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html__( 'Backup deleted.', 'wc-enterprise-erp' ) );
		}
		if ( $msg ) {
			printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( $msg ) );
		}
		?>
		<hr>
		<h2><?php esc_html_e( 'Backup &amp; restore', 'wc-enterprise-erp' ); ?></h2>
		<p class="description" style="max-width:760px">
			<?php esc_html_e( 'Saves the ERP tables — ledger, stock, consignments, payments and the rest — to a file you can download and restore later. Take one before a reset, a version upgrade, or any change you are unsure about.', 'wc-enterprise-erp' ); ?>
		</p>
		<div style="border-left:4px solid #dba617;background:#fcf9e8;padding:10px 14px;max-width:760px;margin:10px 0">
			<strong><?php esc_html_e( 'This is not a full site backup.', 'wc-enterprise-erp' ); ?></strong>
			<?php esc_html_e( 'WooCommerce orders, customers and products are not included, because rolling those back would destroy trading records. So restoring an older ERP backup onto a site that has kept trading will leave orders placed since with no ERP entries behind them. For real protection, keep your host\'s database backups as well.', 'wc-enterprise-erp' ); ?>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:14px">
			<?php wp_nonce_field( 'wceerp_backup_create' ); ?>
			<input type="hidden" name="action" value="wceerp_backup_create">
			<input type="text" name="note" class="regular-text" placeholder="<?php esc_attr_e( 'Optional note — e.g. before opening stock entry', 'wc-enterprise-erp' ); ?>">
			<button class="button button-primary"><?php esc_html_e( 'Create backup now', 'wc-enterprise-erp' ); ?></button>
		</form>

		<table class="widefat striped" style="max-width:900px">
			<thead><tr>
				<th><?php esc_html_e( 'Backup', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Taken', 'wc-enterprise-erp' ); ?></th>
				<th class="num"><?php esc_html_e( 'Size', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Version', 'wc-enterprise-erp' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'wc-enterprise-erp' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( ! $backups ) : ?>
				<tr><td colspan="5"><?php esc_html_e( 'No backups yet.', 'wc-enterprise-erp' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $backups as $b ) : ?>
				<tr>
					<td>
						<code style="font-size:11px"><?php echo esc_html( $b['file'] ); ?></code>
						<?php if ( ! empty( $b['manifest']['note'] ) ) : ?>
							<br><small><?php echo esc_html( $b['manifest']['note'] ); ?></small>
						<?php endif; ?>
					</td>
					<td><small><?php echo esc_html( $b['manifest']['created_at'] ?? gmdate( 'Y-m-d H:i', $b['modified'] ) ); ?>
						<?php if ( ! empty( $b['manifest']['created_by'] ) ) : ?>
							<br><?php echo esc_html( $b['manifest']['created_by'] ); ?>
						<?php endif; ?>
					</small></td>
					<td class="num"><?php echo esc_html( size_format( $b['size'] ) ); ?></td>
					<td><small><?php echo esc_html( $b['manifest']['plugin_version'] ?? '—' ); ?></small></td>
					<td>
						<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wceerp_backup_download&file=' . rawurlencode( $b['file'] ) ), 'wceerp_backup_download' ) ); ?>"><?php esc_html_e( 'Download', 'wc-enterprise-erp' ); ?></a>

						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-left:4px">
							<?php wp_nonce_field( 'wceerp_backup_restore' ); ?>
							<input type="hidden" name="action" value="wceerp_backup_restore">
							<input type="hidden" name="file" value="<?php echo esc_attr( $b['file'] ); ?>">
							<input type="text" name="confirm" placeholder="RESTORE" style="width:88px" autocomplete="off">
							<button class="button button-small"
								onclick="return confirm('<?php echo esc_js( __( 'Replace all current ERP data with this backup? There is no undo.', 'wc-enterprise-erp' ) ); ?>');"><?php esc_html_e( 'Restore', 'wc-enterprise-erp' ); ?></button>
						</form>

						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-left:4px"
							onsubmit="return confirm('<?php echo esc_js( __( 'Delete this backup file?', 'wc-enterprise-erp' ) ); ?>');">
							<?php wp_nonce_field( 'wceerp_backup_delete' ); ?>
							<input type="hidden" name="action" value="wceerp_backup_delete">
							<input type="hidden" name="file" value="<?php echo esc_attr( $b['file'] ); ?>">
							<button class="button button-small button-link-delete"><?php esc_html_e( 'Delete', 'wc-enterprise-erp' ); ?></button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}


	public function handle_health_repair() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_health_repair' );
		WCEERP_Health::repair();
		wp_safe_redirect( admin_url( 'admin.php?page=wceerp-settings&repaired=1' ) );
		exit;
	}

}
