<?php
/**
 * Public POS API — the reference implementation for third-party integrations.
 *
 * Namespace: wceerp/public/v1
 *
 * Deliberately versioned and separate from the internal `wceerp/v1` routes
 * that the terminal and mobile app use. Internal routes can change with the
 * product; anything under public/v1 is a contract with somebody else's
 * software and must not break.
 *
 * Conventions every public route follows:
 *   - Authorization: Bearer <key_id>.<secret>
 *   - one scope per route, checked before the callback runs
 *   - { success, data } on success; WordPress error shape on failure
 *   - writes are idempotent on a caller-supplied key
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Public_API {

	const NS = 'wceerp/public/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {

		register_rest_route( self::NS, '/ping', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'ping' ),
			'permission_callback' => WCEERP_API_Auth::require_scope( 'pos:read' ),
		) );

		register_rest_route( self::NS, '/pos/catalogue', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'catalogue' ),
			'permission_callback' => WCEERP_API_Auth::require_scope( 'pos:read' ),
			'args'                => array(
				'page'     => array( 'default' => 1, 'sanitize_callback' => 'absint' ),
				'per_page' => array( 'default' => 100, 'sanitize_callback' => 'absint' ),
			),
		) );

		register_rest_route( self::NS, '/pos/sales', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'create_sale' ),
			'permission_callback' => WCEERP_API_Auth::require_scope( 'pos:write' ),
		) );

		register_rest_route( self::NS, '/pos/sales/(?P<uuid>[A-Za-z0-9\-_]{1,40})', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_sale' ),
			'permission_callback' => WCEERP_API_Auth::require_scope( 'pos:read' ),
		) );
	}

	/** Cheap call for integrators to verify a key and see its scopes. */
	public static function ping( WP_REST_Request $request ) {
		return WCEERP_API_Auth::ok( array(
			'pong'     => true,
			'key_id'   => (string) $request->get_param( '_wceerp_key_id' ),
			'site'     => get_bloginfo( 'name' ),
			'currency' => get_woocommerce_currency(),
			'time'     => current_time( 'mysql' ),
		) );
	}

	public static function catalogue( WP_REST_Request $request ) {
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = max( 1, min( 200, (int) $request->get_param( 'per_page' ) ) );
		$rows     = WCEERP_POS_Service::catalogue( $page, $per_page );

		return WCEERP_API_Auth::ok( $rows, array(
			'page'      => $page,
			'per_page'  => $per_page,
			'returned'  => count( $rows ),
		) );
	}

	/**
	 * Create a sale.
	 *
	 * Idempotent: `uuid` (or an Idempotency-Key header) identifies the
	 * attempt, so a client that times out and retries gets the original
	 * order back instead of ringing the sale twice.
	 */
	public static function create_sale( WP_REST_Request $request ) {
		$uuid = (string) $request->get_param( 'uuid' );
		if ( ! $uuid ) {
			$uuid = (string) $request->get_header( 'idempotency-key' );
		}
		if ( ! $uuid ) {
			return WCEERP_API_Auth::fail(
				'wceerp_bad_request',
				__( 'Supply uuid in the body or an Idempotency-Key header, so a retry cannot create a duplicate sale.', 'wc-enterprise-erp' ),
				400
			);
		}

		$result = WCEERP_POS_Service::create_sale( array(
			'uuid'           => $uuid,
			'items'          => $request->get_param( 'items' ),
			'discount'       => $request->get_param( 'discount' ),
			'received'       => $request->get_param( 'received' ),
			'pay_method'     => $request->get_param( 'pay_method' ),
			'customer_id'    => $request->get_param( 'customer_id' ),
			'customer_name'  => $request->get_param( 'customer_name' ),
			'customer_phone' => $request->get_param( 'customer_phone' ),
			'tier'           => $request->get_param( 'tier' ),
			'shift_uuid'     => $request->get_param( 'shift_uuid' ),
			'sold_at'        => $request->get_param( 'sold_at' ),
			'_via_api'       => true,
		) );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$status = ! empty( $result['duplicate'] ) ? 200 : 201;
		$body   = array( 'success' => true, 'data' => $result );
		return new WP_REST_Response( $body, $status );
	}

	public static function get_sale( WP_REST_Request $request ) {
		global $wpdb;
		$uuid = sanitize_text_field( (string) $request->get_param( 'uuid' ) );

		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'pos_sales' ) . ' WHERE uuid = %s',
			$uuid
		) );
		if ( ! $row ) {
			return WCEERP_API_Auth::fail( 'wceerp_not_found', __( 'No sale with that uuid.', 'wc-enterprise-erp' ), 404 );
		}

		$order = wc_get_order( (int) $row->order_id );
		$data  = array(
			'uuid'       => $row->uuid,
			'order_id'   => (int) $row->order_id,
			'total'      => (float) $row->total,
			'pay_method' => $row->pay_method,
			'sold_at'    => $row->sold_at,
			'status'     => $order ? $order->get_status() : null,
		);
		if ( $order && class_exists( 'WCEERP_Order_Payments' ) ) {
			$data['payment'] = WCEERP_Order_Payments::picture( $order );
		}
		return WCEERP_API_Auth::ok( $data );
	}
}
