<?php
/**
 * Bulk messaging — SMS and WhatsApp.
 *
 * Sending is queued and drained by cron in small batches. A campaign to a few
 * thousand customers cannot go out inside one page request: PHP will time out
 * part-way and you will have no idea who received what. Queueing also means a
 * gateway failure retries that recipient without re-sending everyone else.
 *
 * Two constraints shape this and are worth stating plainly:
 *
 *   SMS in Bangladesh is straightforward — nearly every gateway takes a plain
 *   HTTP request, so one configurable driver covers BulkSMSBD, Elitbuzz, MIM,
 *   Reve, SSL Wireless and most others.
 *
 *   WhatsApp is not. Meta only permits bulk sending through the WhatsApp
 *   Business Cloud API, using templates approved in advance, to people who
 *   opted in. Unofficial automation libraries breach their terms and get the
 *   number permanently banned — usually the shop's main number. So only the
 *   official API is implemented here.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Messaging {

	const CRON  = 'wceerp_message_queue';
	const BATCH = 25;

	public static function init() {
		/* Register the interval before asking for it. wp_schedule_event()
		 * silently returns false for an unknown schedule name, so getting
		 * this order wrong means the queue never drains and nothing says so. */
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedule' ) );
		add_action( self::CRON, array( __CLASS__, 'work_queue' ) );

		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 60, 'wceerp_five_minutes', self::CRON );
		}
	}

	/** Idempotent: harmless if another module registers the same interval. */
	public static function cron_schedule( $schedules ) {
		if ( ! isset( $schedules['wceerp_five_minutes'] ) ) {
			$schedules['wceerp_five_minutes'] = array(
				'interval' => 300,
				'display'  => __( 'Every five minutes (ERP)', 'wc-enterprise-erp' ),
			);
		}
		return $schedules;
	}

	/* ------------------------------------------------------------------
	 * Settings
	 * ---------------------------------------------------------------- */

	public static function setting( $key, $default = '' ) {
		return wceerp_get_option( 'msg_' . $key, $default );
	}

	public static function sms_ready() {
		return (bool) ( self::setting( 'sms_url' ) && self::setting( 'sms_api_key' ) );
	}

	public static function wa_ready() {
		return (bool) ( self::setting( 'wa_token' ) && self::setting( 'wa_phone_id' ) );
	}

	/* ------------------------------------------------------------------
	 * Phone handling
	 * ---------------------------------------------------------------- */

	/** Local 11-digit form, e.g. 01711120544. */
	public static function normalise( $phone ) {
		$d = preg_replace( '/\D+/', '', (string) $phone );
		if ( 0 === strpos( $d, '880' ) ) {
			$d = '0' . substr( $d, 3 );
		}
		if ( 11 === strlen( $d ) && 0 === strpos( $d, '01' ) ) {
			return $d;
		}
		return '';
	}

	/** International form for WhatsApp, e.g. 8801711120544. */
	public static function international( $phone ) {
		$local = self::normalise( $phone );
		return $local ? '88' . $local : '';
	}

	public static function is_opted_out( $phone, $channel ) {
		global $wpdb;
		$phone = self::normalise( $phone );
		if ( ! $phone ) {
			return true;
		}
		return (bool) $wpdb->get_var( $wpdb->prepare(
			'SELECT id FROM ' . wceerp_table( 'message_optouts' ) . " WHERE phone = %s AND channel IN ('all', %s) LIMIT 1",
			$phone, $channel
		) );
	}

	public static function opt_out( $phone, $channel = 'all', $reason = '' ) {
		global $wpdb;
		$phone = self::normalise( $phone );
		if ( ! $phone ) {
			return false;
		}
		$wpdb->query( $wpdb->prepare(
			'INSERT IGNORE INTO ' . wceerp_table( 'message_optouts' ) . ' (phone, channel, reason, created_at) VALUES (%s, %s, %s, %s)',
			$phone, $channel, sanitize_text_field( $reason ), current_time( 'mysql' )
		) );
		wceerp_log( 'messaging', 'opt_out', 0, $phone );
		return true;
	}

	/* ------------------------------------------------------------------
	 * Audiences
	 * ---------------------------------------------------------------- */

	public static function audiences() {
		return apply_filters( 'wceerp_message_audiences', array(
			'recent'    => __( 'Bought in the last 90 days', 'wc-enterprise-erp' ),
			'all'       => __( 'Everyone who has ever ordered', 'wc-enterprise-erp' ),
			'due'       => __( 'Customers who owe money', 'wc-enterprise-erp' ),
			'dealers'   => __( 'Dealers and wholesale buyers', 'wc-enterprise-erp' ),
			'lapsed'    => __( 'Has not ordered in 6 months', 'wc-enterprise-erp' ),
			'intransit' => __( 'Has a parcel out for delivery', 'wc-enterprise-erp' ),
		) );
	}

	/**
	 * Resolve an audience to de-duplicated recipients.
	 *
	 * @return array List of [ phone, name, user_id ].
	 */
	public static function recipients( $audience, $channel = 'sms' ) {
		global $wpdb;
		$out = array();

		$add = function ( $phone, $name = '', $user_id = 0 ) use ( &$out, $channel ) {
			$p = self::normalise( $phone );
			if ( ! $p || isset( $out[ $p ] ) ) {
				return;
			}
			if ( self::is_opted_out( $p, $channel ) ) {
				return;
			}
			$out[ $p ] = array( 'phone' => $p, 'name' => trim( (string) $name ), 'user_id' => (int) $user_id );
		};

		$golive = function_exists( 'wceerp_start_date' ) ? wceerp_start_date() : '';

		if ( 'dealers' === $audience ) {
			$rows = $wpdb->get_results( 'SELECT user_id, name, phone FROM ' . wceerp_table( 'dealers' ) . " WHERE status = 'active'" );
			foreach ( (array) $rows as $r ) {
				$phone = $r->phone;
				if ( ! $phone && $r->user_id ) {
					$phone = get_user_meta( $r->user_id, 'billing_phone', true );
				}
				$add( $phone, $r->name, $r->user_id );
			}
			return array_values( $out );
		}

		if ( 'intransit' === $audience ) {
			$rows = $wpdb->get_results(
				'SELECT recipient_phone, recipient_name FROM ' . wceerp_table( 'consignments' ) . "
				 WHERE status IN ('booked','in_transit') AND recipient_phone <> ''"
			);
			foreach ( (array) $rows as $r ) {
				$add( $r->recipient_phone, $r->recipient_name );
			}
			return array_values( $out );
		}

		if ( 'due' === $audience && class_exists( 'WCEERP_Module_Customers' ) ) {
			foreach ( WCEERP_Module_Customers::due_map() as $user_id => $amount ) {
				$u = get_userdata( $user_id );
				if ( ! $u ) {
					continue;
				}
				$add( get_user_meta( $user_id, 'billing_phone', true ), $u->display_name, $user_id );
			}
			return array_values( $out );
		}

		/* Order-derived audiences. Guests are included by phone, which is
		 * how most shops here reach people at all. */
		$args = array(
			'limit'   => 5000,
			'status'  => array( 'processing', 'completed' ),
			'orderby' => 'date',
			'order'   => 'DESC',
			'return'  => 'objects',
		);
		if ( 'recent' === $audience ) {
			$args['date_created'] = '>=' . gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		} elseif ( 'lapsed' === $audience ) {
			$args['date_created'] = '<' . gmdate( 'Y-m-d', strtotime( '-6 months' ) );
		} elseif ( $golive ) {
			$args['date_created'] = '>=' . $golive;
		}

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$seen_recent = array();
		foreach ( (array) wc_get_orders( $args ) as $order ) {
			$phone = self::normalise( $order->get_billing_phone() );
			if ( ! $phone ) {
				continue;
			}
			/* "Lapsed" means no recent order at all, so anyone who also
			 * appears in the last six months has to be excluded. */
			if ( 'lapsed' === $audience ) {
				if ( ! $seen_recent ) {
					foreach ( (array) wc_get_orders( array(
						'limit'        => 5000,
						'status'       => array( 'processing', 'completed' ),
						'date_created' => '>=' . gmdate( 'Y-m-d', strtotime( '-6 months' ) ),
						'return'       => 'objects',
					) ) as $o2 ) {
						$p2 = self::normalise( $o2->get_billing_phone() );
						if ( $p2 ) {
							$seen_recent[ $p2 ] = 1;
						}
					}
					$seen_recent = $seen_recent ?: array( '__none__' => 1 );
				}
				if ( isset( $seen_recent[ $phone ] ) ) {
					continue;
				}
			}
			$add( $phone, trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ), $order->get_customer_id() );
		}

		return array_values( $out );
	}

	/* ------------------------------------------------------------------
	 * Composing
	 * ---------------------------------------------------------------- */

	/** Merge fields available in a message body. */
	public static function merge_fields() {
		return array(
			'{name}'  => __( 'Customer name', 'wc-enterprise-erp' ),
			'{shop}'  => __( 'Your shop name', 'wc-enterprise-erp' ),
			'{first}' => __( 'First name only', 'wc-enterprise-erp' ),
		);
	}

	public static function render_body( $body, $recipient ) {
		$name  = $recipient['name'] ?: __( 'Customer', 'wc-enterprise-erp' );
		$first = trim( current( explode( ' ', $name ) ) );
		return strtr( (string) $body, array(
			'{name}'  => $name,
			'{first}' => $first ?: $name,
			'{shop}'  => wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ),
		) );
	}

	/**
	 * SMS segment count.
	 *
	 * Bengali characters force UCS-2, which cuts a segment from 160
	 * characters to 70 — a message that looks short can cost four times what
	 * the sender expects, so this is shown before sending.
	 */
	public static function segments( $text ) {
		$len     = mb_strlen( (string) $text );
		$unicode = (bool) preg_match( '/[^\x00-\x7F]/', (string) $text );
		$single  = $unicode ? 70 : 160;
		$multi   = $unicode ? 67 : 153;
		if ( $len <= $single ) {
			return array( 'segments' => $len ? 1 : 0, 'unicode' => $unicode, 'length' => $len );
		}
		return array( 'segments' => (int) ceil( $len / $multi ), 'unicode' => $unicode, 'length' => $len );
	}

	/* ------------------------------------------------------------------
	 * Allowance
	 *
	 * Counted in SMS parts, not messages, because that is what the gateway
	 * charges for — a long Bengali message is four parts and should cost
	 * the shop four.
	 * ---------------------------------------------------------------- */

	/** Parts included each month by the plan. 0 = unlimited. */
	public static function monthly_quota() {
		return max( 0, (int) get_option( 'wceerp_sms_quota', 0 ) );
	}

	/** Extra parts bought on top, which do not expire monthly. */
	public static function extra_balance() {
		return max( 0, (int) get_option( 'wceerp_sms_balance', 0 ) );
	}

	protected static function used_key( $month = '' ) {
		return 'wceerp_sms_used_' . ( $month ?: gmdate( 'Y-m' ) );
	}

	public static function used_this_month() {
		return max( 0, (int) get_option( self::used_key(), 0 ) );
	}

	/** Parts still available: what is left of the quota, plus purchases. */
	public static function remaining() {
		$quota = self::monthly_quota();
		if ( 0 === $quota ) {
			return -1; // unlimited
		}
		return max( 0, $quota - self::used_this_month() ) + self::extra_balance();
	}

	/**
	 * Take parts from the allowance.
	 *
	 * Monthly quota is consumed first and purchased parts only after it is
	 * exhausted — a shop should get what they already pay for before what
	 * they bought separately.
	 *
	 * @return bool False when there is nothing left.
	 */
	public static function consume( $parts ) {
		$parts = max( 1, (int) $parts );
		$quota = self::monthly_quota();

		if ( 0 === $quota ) {
			// Unlimited plan: still counted, so usage reporting is honest.
			update_option( self::used_key(), self::used_this_month() + $parts, false );
			return true;
		}

		$left_in_quota = max( 0, $quota - self::used_this_month() );
		$from_quota    = min( $parts, $left_in_quota );
		$from_balance  = $parts - $from_quota;

		if ( $from_balance > self::extra_balance() ) {
			return false;
		}

		if ( $from_quota ) {
			update_option( self::used_key(), self::used_this_month() + $from_quota, false );
		}
		if ( $from_balance ) {
			update_option( 'wceerp_sms_balance', self::extra_balance() - $from_balance, false );
		}
		return true;
	}

	/** Human summary for the UI. */
	public static function allowance_text() {
		$quota = self::monthly_quota();
		if ( 0 === $quota ) {
			return __( 'Unlimited SMS on your plan.', 'wc-enterprise-erp' );
		}
		$left = self::remaining();
		return sprintf(
			/* translators: 1: remaining, 2: monthly quota, 3: purchased extra. */
			__( '%1$s parts left this month — %2$s included in your plan, %3$s bought.', 'wc-enterprise-erp' ),
			number_format_i18n( $left ),
			number_format_i18n( $quota ),
			number_format_i18n( self::extra_balance() )
		);
	}

	/* ------------------------------------------------------------------
	 * Transactional messages
	 *
	 * One-off sends triggered by something happening — a parcel booked, a
	 * parcel delivered — as opposed to a campaign. They go through the same
	 * queue so a slow gateway never holds up the person who pressed Book.
	 * ---------------------------------------------------------------- */

	/** Events a shop can send an automatic message on. */
	public static function events() {
		return apply_filters( 'wceerp_message_events', array(
			'booked'    => array(
				'label'   => __( 'Parcel booked with a courier', 'wc-enterprise-erp' ),
				'default' => __( 'Dear {name}, your order from {shop} has been handed to {courier}. Tracking: {tracking}. Please keep {cod} ready. Thank you.', 'wc-enterprise-erp' ),
			),
			'delivered' => array(
				'label'   => __( 'Parcel delivered', 'wc-enterprise-erp' ),
				'default' => __( 'Dear {name}, your order from {shop} has been delivered. Thank you for shopping with us.', 'wc-enterprise-erp' ),
			),
			'returned'  => array(
				'label'   => __( 'Parcel returned', 'wc-enterprise-erp' ),
				'default' => __( 'Dear {name}, your parcel from {shop} could not be delivered and is coming back to us. Please contact us to arrange redelivery.', 'wc-enterprise-erp' ),
			),
		) );
	}

	public static function event_enabled( $event ) {
		return '1' === (string) self::setting( 'evt_' . $event, '' );
	}

	public static function event_template( $event ) {
		$events = self::events();
		$saved  = (string) self::setting( 'tpl_' . $event, '' );
		return $saved !== '' ? $saved : ( $events[ $event ]['default'] ?? '' );
	}

	/** Merge fields available to a consignment message. */
	public static function consignment_tokens( $c ) {
		$courier = $c->courier ? ucfirst( $c->courier ) : __( 'our courier', 'wc-enterprise-erp' );
		return array(
			'{name}'     => $c->recipient_name ?: __( 'Customer', 'wc-enterprise-erp' ),
			'{first}'    => trim( current( explode( ' ', (string) $c->recipient_name ) ) ) ?: __( 'Customer', 'wc-enterprise-erp' ),
			'{shop}'     => wceerp_get_option( 'company_name', get_bloginfo( 'name' ) ),
			'{courier}'  => $courier,
			'{tracking}' => $c->tracking_code ?: $c->remote_id ?: $c->doc_no,
			'{cn}'       => $c->doc_no,
			'{order}'    => '#' . (int) $c->order_id,
			'{cod}'      => wp_strip_all_tags( wceerp_money( $c->cod_amount ) ),
		);
	}

	/**
	 * Send an automatic message about a consignment.
	 *
	 * Silent when the event is switched off, no gateway is set up, the
	 * number is unusable, or the customer has opted out — a shop should
	 * never have a booking fail because an SMS could not be sent.
	 *
	 * @return bool Whether a message was queued.
	 */
	public static function send_event( $event, $c ) {
		global $wpdb;

		if ( ! self::event_enabled( $event ) || ! self::sms_ready() ) {
			return false;
		}

		$phone = self::normalise( $c->recipient_phone );
		if ( ! $phone || self::is_opted_out( $phone, 'sms' ) ) {
			return false;
		}

		$body = strtr( self::event_template( $event ), self::consignment_tokens( $c ) );
		$body = trim( $body );
		if ( '' === $body ) {
			return false;
		}

		/* Guard against duplicates: re-syncing a delivered parcel must not
		 * message the customer again every hour. */
		$marker = 'wceerp_sms_' . $event . '_' . (int) $c->id;
		if ( get_option( $marker ) ) {
			return false;
		}
		update_option( $marker, time(), false );

		$wpdb->insert( wceerp_table( 'message_queue' ), array(
			'campaign_id' => 0,
			'channel'     => 'sms',
			'recipient'   => $phone,
			'name'        => $c->recipient_name,
			'body'        => $body,
			'status'      => 'queued',
			'created_at'  => current_time( 'mysql' ),
		) );

		wceerp_log( 'messaging', 'event_' . $event, (int) $c->id, $phone );

		// Nudge the queue rather than waiting up to five minutes.
		wp_schedule_single_event( time() + 10, self::CRON );
		return true;
	}

	/* ------------------------------------------------------------------
	 * Queue
	 * ---------------------------------------------------------------- */

	/**
	 * Create a campaign and queue its recipients.
	 *
	 * @return int|WP_Error Campaign id.
	 */
	public static function create_campaign( $args ) {
		global $wpdb;

		$channel = in_array( ( $args['channel'] ?? 'sms' ), array( 'sms', 'whatsapp' ), true ) ? $args['channel'] : 'sms';
		$body    = trim( (string) ( $args['body'] ?? '' ) );
		$name    = sanitize_text_field( $args['name'] ?? '' ) ?: gmdate( 'j M Y H:i' );
		$audience = sanitize_key( $args['audience'] ?? 'recent' );

		if ( 'sms' === $channel && ! self::sms_ready() ) {
			return new WP_Error( 'wceerp_msg', __( 'Add your SMS gateway details before sending.', 'wc-enterprise-erp' ) );
		}
		if ( 'whatsapp' === $channel && ! self::wa_ready() ) {
			return new WP_Error( 'wceerp_msg', __( 'Add your WhatsApp Cloud API details before sending.', 'wc-enterprise-erp' ) );
		}
		if ( 'sms' === $channel && '' === $body ) {
			return new WP_Error( 'wceerp_msg', __( 'Write the message first.', 'wc-enterprise-erp' ) );
		}

		$recipients = self::recipients( $audience, $channel );
		if ( ! $recipients ) {
			return new WP_Error( 'wceerp_msg', __( 'No one in that audience has a usable phone number.', 'wc-enterprise-erp' ) );
		}

		$wpdb->insert( wceerp_table( 'campaigns' ), array(
			'name'          => $name,
			'channel'       => $channel,
			'body'          => $body,
			'template_name' => sanitize_text_field( $args['template'] ?? '' ),
			'audience'      => $audience,
			'status'        => 'sending',
			'total'         => count( $recipients ),
			'created_by'    => get_current_user_id(),
			'created_at'    => current_time( 'mysql' ),
		) );
		$campaign_id = (int) $wpdb->insert_id;

		$now = current_time( 'mysql' );
		foreach ( $recipients as $r ) {
			$wpdb->insert( wceerp_table( 'message_queue' ), array(
				'campaign_id' => $campaign_id,
				'channel'     => $channel,
				'recipient'   => $r['phone'],
				'name'        => $r['name'],
				'user_id'     => $r['user_id'],
				'body'        => self::render_body( $body, $r ),
				'status'      => 'queued',
				'created_at'  => $now,
			) );
		}

		wceerp_log( 'messaging', 'campaign_created', $campaign_id, $channel . ' → ' . count( $recipients ) );

		// Start immediately rather than waiting for the next cron tick.
		wp_schedule_single_event( time() + 5, self::CRON );

		return $campaign_id;
	}

	/** Drain a batch. Called by cron every five minutes. */
	public static function work_queue() {
		global $wpdb;
		$table = wceerp_table( 'message_queue' );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE status = 'queued' AND attempts < 3 ORDER BY id LIMIT %d",
			self::BATCH
		) );
		if ( ! $rows ) {
			self::close_finished_campaigns();
			return;
		}

		foreach ( $rows as $row ) {
			// Claim it first, so an overlapping cron run cannot double-send.
			$wpdb->update( $table, array( 'status' => 'sending', 'attempts' => (int) $row->attempts + 1 ), array( 'id' => $row->id ) );

			/* Check the allowance immediately before sending, not when the
			 * campaign was queued — a long queue could otherwise sail past
			 * the cap that was fine an hour ago. */
			if ( 'sms' === $row->channel ) {
				$seg = self::segments( $row->body );
				if ( ! self::consume( $seg['segments'] ) ) {
					$wpdb->update( $table, array(
						'status' => 'failed',
						'error'  => __( 'Monthly SMS allowance used up. Buy more parts to continue.', 'wc-enterprise-erp' ),
					), array( 'id' => $row->id ) );
					$wpdb->query( $wpdb->prepare( 'UPDATE ' . wceerp_table( 'campaigns' ) . ' SET failed = failed + 1 WHERE id = %d', $row->campaign_id ) );
					wceerp_log( 'messaging', 'quota_exhausted', (int) $row->id );
					continue;
				}
			}

			$result = ( 'whatsapp' === $row->channel )
				? self::send_whatsapp( $row )
				: self::send_sms( $row );

			if ( is_wp_error( $result ) ) {
				$final = ( (int) $row->attempts + 1 ) >= 3;
				$wpdb->update( $table, array(
					'status' => $final ? 'failed' : 'queued',
					'error'  => mb_substr( $result->get_error_message(), 0, 255 ),
				), array( 'id' => $row->id ) );
				if ( $final ) {
					$wpdb->query( $wpdb->prepare( 'UPDATE ' . wceerp_table( 'campaigns' ) . ' SET failed = failed + 1 WHERE id = %d', $row->campaign_id ) );
				}
				continue;
			}

			$wpdb->update( $table, array(
				'status'    => 'sent',
				'remote_id' => is_string( $result ) ? mb_substr( $result, 0, 100 ) : '',
				'sent_at'   => current_time( 'mysql' ),
				'error'     => '',
			), array( 'id' => $row->id ) );
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . wceerp_table( 'campaigns' ) . ' SET sent = sent + 1 WHERE id = %d', $row->campaign_id ) );
		}

		// More waiting? Come back promptly rather than in five minutes.
		$left = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'queued' AND attempts < 3" );
		if ( $left ) {
			wp_schedule_single_event( time() + 30, self::CRON );
		} else {
			self::close_finished_campaigns();
		}
	}

	protected static function close_finished_campaigns() {
		global $wpdb;
		$wpdb->query(
			'UPDATE ' . wceerp_table( 'campaigns' ) . " c
			 SET c.status = 'done', c.finished_at = NOW()
			 WHERE c.status = 'sending'
			   AND NOT EXISTS (
			     SELECT 1 FROM " . wceerp_table( 'message_queue' ) . " q
			     WHERE q.campaign_id = c.id AND q.status IN ('queued','sending')
			   )"
		);
	}

	/* ------------------------------------------------------------------
	 * Providers
	 * ---------------------------------------------------------------- */

	/**
	 * SMS via a configurable HTTP gateway.
	 *
	 * Almost every Bangladeshi provider accepts a GET or POST with an API
	 * key, sender id, number and text, so the field names are configurable
	 * rather than hard-coded per provider.
	 */
	protected static function send_sms( $row ) {
		$url = self::setting( 'sms_url' );
		if ( ! $url ) {
			return new WP_Error( 'wceerp_msg', __( 'No SMS gateway URL configured.', 'wc-enterprise-erp' ) );
		}

		$params = array(
			self::setting( 'sms_field_key', 'api_key' )    => self::setting( 'sms_api_key' ),
			self::setting( 'sms_field_to', 'msisdn' )      => self::setting( 'sms_intl' ) ? self::international( $row->recipient ) : $row->recipient,
			self::setting( 'sms_field_text', 'sms' )       => $row->body,
		);
		if ( self::setting( 'sms_sender' ) ) {
			$params[ self::setting( 'sms_field_sender', 'senderid' ) ] = self::setting( 'sms_sender' );
		}
		$params = apply_filters( 'wceerp_sms_params', $params, $row );

		$method = strtoupper( self::setting( 'sms_method', 'GET' ) );
		$args   = array( 'timeout' => 20 );

		if ( 'POST' === $method ) {
			$args['body'] = $params;
			$res          = wp_remote_post( $url, $args );
		} else {
			$res = wp_remote_get( add_query_arg( array_map( 'rawurlencode', $params ), $url ), $args );
		}

		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = trim( (string) wp_remote_retrieve_body( $res ) );

		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'wceerp_msg', sprintf( 'HTTP %d — %s', $code, mb_substr( wp_strip_all_tags( $body ), 0, 160 ) ) );
		}

		/* Gateways here nearly all return 200 even on failure, with the real
		 * outcome in the body. Treat known error words as failures rather
		 * than reporting a delivery that never happened. */
		if ( preg_match( '/\b(error|invalid|fail|insufficient|balance|unauthor|reject)\b/i', $body ) ) {
			return new WP_Error( 'wceerp_msg', mb_substr( wp_strip_all_tags( $body ), 0, 200 ) );
		}

		return mb_substr( $body, 0, 100 );
	}

	/** WhatsApp via Meta's Cloud API. */
	protected static function send_whatsapp( $row ) {
		$token    = self::setting( 'wa_token' );
		$phone_id = self::setting( 'wa_phone_id' );
		$version  = self::setting( 'wa_version', 'v21.0' );

		if ( ! $token || ! $phone_id ) {
			return new WP_Error( 'wceerp_msg', __( 'WhatsApp Cloud API is not configured.', 'wc-enterprise-erp' ) );
		}

		$to = self::international( $row->recipient );
		if ( ! $to ) {
			return new WP_Error( 'wceerp_msg', __( 'Not a valid Bangladeshi mobile number.', 'wc-enterprise-erp' ) );
		}

		global $wpdb;
		$template = $wpdb->get_var( $wpdb->prepare(
			'SELECT template_name FROM ' . wceerp_table( 'campaigns' ) . ' WHERE id = %d',
			(int) $row->campaign_id
		) );

		/* Marketing messages must use a template Meta has approved. Free-form
		 * text is only allowed inside a 24-hour window opened by the customer
		 * messaging you first, which a bulk campaign never satisfies. */
		if ( ! $template ) {
			return new WP_Error( 'wceerp_msg', __( 'WhatsApp needs an approved template name. Free text is not permitted for bulk sending.', 'wc-enterprise-erp' ) );
		}

		$payload = array(
			'messaging_product' => 'whatsapp',
			'to'                => $to,
			'type'              => 'template',
			'template'          => array(
				'name'     => $template,
				'language' => array( 'code' => self::setting( 'wa_lang', 'en' ) ),
			),
		);

		// The customer's name fills the template's first variable.
		if ( $row->name ) {
			$payload['template']['components'] = array(
				array(
					'type'       => 'body',
					'parameters' => array( array( 'type' => 'text', 'text' => $row->name ) ),
				),
			);
		}
		$payload = apply_filters( 'wceerp_whatsapp_payload', $payload, $row );

		$res = wp_remote_post( "https://graph.facebook.com/{$version}/{$phone_id}/messages", array(
			'timeout' => 25,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( $payload ),
		) );

		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( $code < 200 || $code >= 300 ) {
			$msg = $data['error']['message'] ?? sprintf( 'HTTP %d', $code );
			return new WP_Error( 'wceerp_msg', mb_substr( (string) $msg, 0, 200 ) );
		}

		return (string) ( $data['messages'][0]['id'] ?? '' );
	}
}
