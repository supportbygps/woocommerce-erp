<?php
/**
 * Printable documents — invoices and quotations.
 *
 * Rendered as HTML and printed by the browser rather than drawn into the
 * bundled PDF writer. That writer is 165 lines of hand-built PDF and has no
 * image support at all: adding it would mean XObject dictionaries, image
 * streams and colour space handling, and would still only accept baseline
 * JPEG. Fetching and embedding a thumbnail per line on top of that is a
 * reliable way to exhaust memory on cheap hosting and produce a corrupt file.
 *
 * The browser already does all of this correctly, prints to A4, and saves as
 * PDF from the same dialog. The existing text-only PDF is untouched and
 * remains the fast path for anyone who wants a plain document.
 *
 * @package WC_Enterprise_ERP
 */

defined( 'ABSPATH' ) || exit;

class WCEERP_Document {

	public static function init() {
		add_action( 'admin_post_wceerp_print_doc', array( __CLASS__, 'render' ) );

		/* An Invoice action on the WooCommerce order list, which is where
		 * most people go looking for one. */
		add_filter( 'woocommerce_admin_order_actions', array( __CLASS__, 'order_action' ), 20, 2 );
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'order_button' ) );
	}

	public static function order_action( $actions, $order ) {
		$actions['wceerp_invoice'] = array(
			'url'    => self::url( 'invoice', $order->get_id() ),
			'name'   => __( 'Invoice', 'wc-enterprise-erp' ),
			'action' => 'wceerp-invoice',
		);
		$actions['wceerp_challan'] = array(
			'url'    => self::url( 'challan', $order->get_id() ),
			'name'   => __( 'Challan', 'wc-enterprise-erp' ),
			'action' => 'wceerp-challan',
		);
		return $actions;
	}

	public static function order_button( $order ) {
		printf(
			'<p class="form-field form-field-wide">
				<a href="%s" target="_blank" class="button">%s</a>
				<a href="%s" target="_blank" class="button">%s</a>
			</p>',
			esc_url( self::url( 'invoice', $order->get_id() ) ),
			esc_html__( 'Print invoice', 'wc-enterprise-erp' ),
			esc_url( self::url( 'challan', $order->get_id() ) ),
			esc_html__( 'Print challan', 'wc-enterprise-erp' )
		);
	}

	/** Link to the printable view of a document. */
	public static function url( $type, $id ) {
		/* add_query_arg rather than a hand-built string, so the parameters
		 * are encoded once and callers can pass this straight to esc_url
		 * without the ampersands being escaped twice. */
		$url = add_query_arg(
			array(
				'action' => 'wceerp_print_doc',
				'type'   => $type,
				'id'     => (int) $id,
			),
			admin_url( 'admin-post.php' )
		);
		return wp_nonce_url( $url, 'wceerp_print_doc' );
	}

	/**
	 * Thumbnail for a line.
	 *
	 * Uses WordPress's own thumbnail size rather than the full image — a
	 * quotation with twenty lines would otherwise pull twenty full-size
	 * photographs into one page.
	 */
	protected static function product_image( $product_id, $px ) {
		if ( ! $product_id || ! function_exists( 'wc_get_product' ) ) {
			return '';
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return '';
		}
		$thumb_id = $product->get_image_id();
		if ( ! $thumb_id ) {
			return '';
		}
		$src = wp_get_attachment_image_url( $thumb_id, 'thumbnail' );
		if ( ! $src ) {
			return '';
		}
		return sprintf(
			'<img src="%s" alt="" style="width:%dpx;height:%dpx;object-fit:cover;border-radius:4px;border:1px solid #e0e0e0">',
			esc_url( $src ),
			(int) $px,
			(int) $px
		);
	}

	public static function render() {
		if ( ! wceerp_user_can( 'wceerp_view_reports' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this.', 'wc-enterprise-erp' ) );
		}
		check_admin_referer( 'wceerp_print_doc' );

		$type = isset( $_GET['type'] ) ? sanitize_key( $_GET['type'] ) : 'invoice';
		$id   = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;

		/* Recorded before anything can fail.
		 *
		 * If a document comes back blank and there is no entry here, the
		 * handler was never reached at all — a routing or permission problem
		 * rather than a rendering one. That distinction is otherwise
		 * invisible and takes a long time to work out. */
		if ( function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'document', 'print_requested', $id, $type );
		}

		/* Building the data can fail as easily as drawing it — a deleted
		 * product, a missing WooCommerce method — and that half used to sit
		 * outside the safety net, which is why a blank page survived the
		 * first attempt at catching this. */
		try {
			$doc = apply_filters( 'wceerp_document_data', null, $type, $id );
			if ( ! $doc ) {
				if ( 'quotation' === $type ) {
					$doc = self::quotation_data( $id );
				} else {
					$doc = self::invoice_data( $id );
				}
			}
		} catch ( Throwable $e ) {
			self::fail( $e, $type, $id );
			exit;
		}

		if ( ! $doc ) {
			self::fail(
				new Exception( sprintf(
					/* translators: 1: type, 2: id. */
					__( 'No data could be built for %1$s %2$d. If this is an order, check it still exists in WooCommerce.', 'wc-enterprise-erp' ),
					$type,
					$id
				) ),
				$type,
				$id
			);
			exit;
		}

		/* A challan is the same document with the money removed. Built by
		 * stripping rather than by a separate template, so the two can never
		 * drift apart and show different quantities for the same order —
		 * which is exactly the discrepancy a delivery note exists to
		 * prevent. */
		if ( 'challan' === $type ) {
			$doc['title']    = __( 'Delivery Challan', 'wc-enterprise-erp' );
			$doc['no_price'] = true;
		}

		/* A blank page is the least useful failure there is.
		 *
		 * Anything fatal inside the renderer used to leave an empty tab with
		 * nothing to act on — no message, no line, nothing to send anyone.
		 * Catching it turns a dead end into a report, and the exception is
		 * still written to the error log for whoever has access to it. */
		try {
			self::output( $doc );
		} catch ( Throwable $e ) {
			self::fail( $e, $type, $id );
		}
		exit;
	}

	/* ------------------------------------------------------------------
	 * Data
	 * ---------------------------------------------------------------- */

	protected static function quotation_data( $id ) {
		global $wpdb;
		$q = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'quotations' ) . ' WHERE id = %d',
			$id
		) );
		if ( ! $q ) {
			return null;
		}
		$items = (array) $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . wceerp_table( 'quotation_items' ) . ' WHERE quotation_id = %d ORDER BY id',
			$id
		) );

		$lines = array();
		foreach ( $items as $it ) {
			$lines[] = array(
				'product_id' => (int) ( $it->product_id ?? 0 ),
				'name'       => (string) ( $it->description ?? '' ),
				'qty'        => (float) ( $it->qty ?? 0 ),
				'price'      => (float) ( $it->unit_price ?? 0 ),
				'total'      => (float) ( $it->line_total ?? ( (float) ( $it->qty ?? 0 ) * (float) ( $it->unit_price ?? 0 ) ) ),
			);
		}

		return array(
			'title'    => __( 'Quotation', 'wc-enterprise-erp' ),
			'number'   => $q->doc_no ?? (string) $q->id,
			'date'     => $q->created_at ?? current_time( 'mysql' ),
			'valid'    => $q->valid_until ?? '',
			'to_name'  => $q->customer_name ?? '',
			'to_phone' => $q->customer_phone ?? '',
			'to_addr'  => $q->customer_address ?? '',
			'lines'    => $lines,
			'subtotal' => (float) ( $q->subtotal ?? 0 ),
			'discount' => (float) ( $q->discount ?? 0 ),
			'tax'      => (float) ( $q->tax_total ?? 0 ),
			'total'    => (float) ( $q->grand_total ?? 0 ),
			'note'     => $q->note ?? '',
		);
	}

	protected static function invoice_data( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return null;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return null;
		}

		$lines = array();
		foreach ( $order->get_items() as $item ) {
			$lines[] = array(
				'product_id' => $item->get_product_id(),
				'name'       => $item->get_name(),
				'qty'        => (float) $item->get_quantity(),
				'price'      => (float) $order->get_item_subtotal( $item, false, false ),
				'total'      => (float) $item->get_total(),
			);
		}

		return array(
			'title'    => __( 'Invoice', 'wc-enterprise-erp' ),
			'number'   => $order->get_order_number(),
			'date'     => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
			'valid'    => '',
			'to_name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
			'to_phone' => $order->get_billing_phone(),
			'to_addr'  => wp_strip_all_tags( $order->get_formatted_billing_address() ),
			'lines'    => $lines,
			'subtotal' => (float) $order->get_subtotal(),
			'discount' => (float) $order->get_total_discount(),
			'tax'      => (float) $order->get_total_tax(),
			'total'    => (float) $order->get_total(),
			'note'     => $order->get_customer_note(),
		);
	}

	/* ------------------------------------------------------------------
	 * Output
	 * ---------------------------------------------------------------- */

	/**
	 * Report a failure instead of leaving an empty tab.
	 *
	 * A blank page is the least useful failure there is: nothing to read,
	 * nothing to send on, no way to tell a permission problem from a broken
	 * template. This prints what went wrong and logs the same thing.
	 */
	protected static function fail( $e, $type, $id ) {
		if ( function_exists( 'wceerp_log' ) ) {
			wceerp_log( 'document', 'print_failed', (int) $id, $type . ': ' . $e->getMessage() );
		}
		error_log( 'WCEERP document failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );

		if ( ! headers_sent() ) {
			status_header( 500 );
			nocache_headers();
		}

		echo '<!DOCTYPE html><meta charset="utf-8"><title>Document error</title>';
		echo '<div style="font:15px/1.6 system-ui,-apple-system,sans-serif;max-width:640px;margin:60px auto;padding:0 20px">';
		echo '<h1 style="font-size:20px;margin:0 0 8px">' . esc_html__( 'This document could not be produced', 'wc-enterprise-erp' ) . '</h1>';
		echo '<p style="color:#5B6675">' . esc_html__( 'The details below say what failed. Send them on and it can be fixed.', 'wc-enterprise-erp' ) . '</p>';
		echo '<pre style="background:#f6f5f8;padding:14px;border-radius:8px;white-space:pre-wrap;font-size:12.5px;border-left:3px solid #C0392B">';
		echo esc_html( $e->getMessage() ) . "\n";
		echo esc_html( basename( $e->getFile() ) . ':' . $e->getLine() );
		echo '</pre>';
		echo '<p style="color:#5B6675;font-size:13.5px">'
			. esc_html( sprintf(
				/* translators: 1: document type, 2: record id. */
				__( 'Document: %1$s · record %2$d', 'wc-enterprise-erp' ),
				$type,
				(int) $id
			) )
			. '</p></div>';
	}

	protected static function output( $doc ) {
		$inv    = WCEERP_Invoice_Settings::get();
		$images = ( 'yes' === $inv['show_images'] );
		$px     = (int) $inv['image_size'];
		$accent = $inv['accent'];

		/* A challan is a goods-received note: the person signing it is
		 * confirming what arrived, not what it cost. Prices, totals and VAT
		 * are all withheld. */
		$money = empty( $doc['no_price'] );

		/* A letterhead that already carries the name and address replaces
		 * the generated header, otherwise both print and the page looks
		 * duplicated. */
		$lh        = $inv['letterhead'];
		$lh_only   = ( $lh && 'yes' === $inv['lh_replace'] );

		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $doc['title'] . ' ' . $doc['number'] ); ?></title>
<style>
	:root { --accent: <?php echo esc_html( $accent ); ?>; }
	* { box-sizing: border-box; }
	body {
		margin: 0;
		background: #f2f2f4;
		font: 13px/1.55 <?php echo WCEERP_Invoice_Settings::css_font( $inv['font'] ); ?>;
		color: #1d2327;
	}
	.sheet {
		width: 210mm;
		min-height: 297mm;
		margin: 18px auto;
		background: #fff;
		padding: 16mm 15mm;
		box-shadow: 0 6px 26px rgba(0,0,0,.12);
		position: relative;
	}
	.lh { width: 100%; height: auto; max-height: <?php echo (int) $inv['letterhead_h']; ?>px; object-fit: contain; display: block; margin-bottom: 14px; }
	.head { display: flex; justify-content: space-between; gap: 20px; align-items: flex-start; margin-bottom: 18px; }
	.co strong { font-size: 17px; display: block; }
	.co small, .meta small { color: #555; display: block; font-size: 11.5px; }
	.logo { max-height: 54px; width: auto; margin-bottom: 6px; }
	.doctype { font-size: 20px; font-weight: 700; letter-spacing: .04em; color: var(--accent); text-align: right; }
	.meta { text-align: right; margin-top: 4px; }
	.parties { display: flex; gap: 24px; margin: 16px 0 14px; }
	.party { flex: 1; }
	.party b { display: block; font-size: 10px; letter-spacing: .12em; text-transform: uppercase; color: #777; margin-bottom: 3px; }
	table { width: 100%; border-collapse: collapse; margin-top: 6px; }
	th {
		text-align: left; font-size: 10px; letter-spacing: .08em; text-transform: uppercase;
		color: #fff; background: <?php echo esc_html( $inv['header_bg'] ); ?>;
		padding: 8px 9px;
	}
	td { padding: 9px; border-bottom: 1px solid #eceaef; vertical-align: middle; }
	<?php if ( $inv['zebra'] ) : ?>
	tbody tr:nth-child(even) td { background: #fafafb; }
	<?php endif; ?>
	.n { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
	.thumb { width: <?php echo (int) $px + 10; ?>px; }
	tfoot td { border: 0; padding: 4px 9px; }
	tfoot tr.grand td { border-top: 2.5px double #1d2327; font-weight: 700; font-size: 14px; padding-top: 9px; }
	.note { margin-top: 18px; font-size: 12px; color: #444; }
	.terms { margin-top: 10px; font-size: 11px; color: #666; white-space: pre-line; }
	.sign { display: flex; justify-content: space-between; margin-top: 42px; gap: 30px; }
	.sign div { flex: 1; border-top: 1px solid #999; padding-top: 5px; font-size: 11px; color: #555; text-align: center; }
	.foot { margin-top: 22px; text-align: center; font-size: 11px; color: #777; }
	.foot img { max-width: 100%; height: auto; margin-top: 8px; }
	.bar { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #ddd; padding: 9px 14px; display: flex; gap: 8px; align-items: center; }
	.bar button { font: inherit; font-size: 13px; padding: 7px 15px; border-radius: 6px; border: 1px solid #d4d0da; background: #fff; cursor: pointer; }
	.bar button.p { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 600; }
	.bar span { color: #777; font-size: 12px; margin-left: auto; }

	@media print {
		body { background: #fff; }
		.bar { display: none !important; }
		.sheet { width: auto; min-height: 0; margin: 0; padding: 0; box-shadow: none; }
		thead { display: table-header-group; }   /* repeat headers across pages */
		tr { page-break-inside: avoid; }
	}
	@page { size: A4; margin: 12mm; }
</style>
</head>
<body>

<div class="bar">
	<button class="p" onclick="window.print()"><?php esc_html_e( 'Print or save as PDF', 'wc-enterprise-erp' ); ?></button>
	<button onclick="window.close()"><?php esc_html_e( 'Close', 'wc-enterprise-erp' ); ?></button>
	<span><?php esc_html_e( 'Choose "Save as PDF" in the print dialog to send this by email.', 'wc-enterprise-erp' ); ?></span>
</div>

<div class="sheet">
	<?php if ( $lh ) : ?>
		<img class="lh" src="<?php echo esc_url( $lh ); ?>" alt="">
	<?php endif; ?>

	<div class="head">
		<div class="co">
			<?php if ( ! $lh_only ) : ?>
				<?php if ( $inv['logo'] ) : ?>
					<img class="logo" src="<?php echo esc_url( $inv['logo'] ); ?>" alt="">
				<?php endif; ?>
				<strong><?php echo esc_html( $inv['company_name'] ); ?></strong>
				<?php if ( $inv['address'] ) : ?><small><?php echo nl2br( esc_html( $inv['address'] ) ); ?></small><?php endif; ?>
				<?php if ( $inv['phone'] ) : ?><small><?php echo esc_html( $inv['phone'] ); ?></small><?php endif; ?>
				<?php if ( $inv['email'] ) : ?><small><?php echo esc_html( $inv['email'] ); ?></small><?php endif; ?>
				<?php if ( $inv['bin'] ) : ?><small><?php esc_html_e( 'BIN', 'wc-enterprise-erp' ); ?>: <?php echo esc_html( $inv['bin'] ); ?></small><?php endif; ?>
			<?php endif; ?>
		</div>
		<div>
			<div class="doctype"><?php echo esc_html( strtoupper( $doc['title'] ) ); ?></div>
			<div class="meta">
				<small><?php esc_html_e( 'No.', 'wc-enterprise-erp' ); ?> <strong><?php echo esc_html( $doc['number'] ); ?></strong></small>
				<small><?php echo esc_html( mysql2date( 'j M Y', $doc['date'] ) ); ?></small>
				<?php if ( $doc['valid'] ) : ?>
					<small><?php esc_html_e( 'Valid until', 'wc-enterprise-erp' ); ?> <?php echo esc_html( mysql2date( 'j M Y', $doc['valid'] ) ); ?></small>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="parties">
		<div class="party">
			<b><?php esc_html_e( 'Billed to', 'wc-enterprise-erp' ); ?></b>
			<strong><?php echo esc_html( $doc['to_name'] ?: __( 'Customer', 'wc-enterprise-erp' ) ); ?></strong>
			<?php if ( $doc['to_phone'] ) : ?><div><?php echo esc_html( $doc['to_phone'] ); ?></div><?php endif; ?>
			<?php if ( $doc['to_addr'] ) : ?><div><?php echo nl2br( esc_html( $doc['to_addr'] ) ); ?></div><?php endif; ?>
		</div>
	</div>

	<table>
		<thead>
			<tr>
				<?php if ( $images ) : ?><th class="thumb"></th><?php endif; ?>
				<th><?php esc_html_e( 'Description', 'wc-enterprise-erp' ); ?></th>
				<th class="n"><?php esc_html_e( 'Qty', 'wc-enterprise-erp' ); ?></th>
				<?php if ( $money ) : ?>
					<th class="n"><?php esc_html_e( 'Rate', 'wc-enterprise-erp' ); ?></th>
					<th class="n"><?php esc_html_e( 'Amount', 'wc-enterprise-erp' ); ?></th>
				<?php else : ?>
					<th class="n" style="width:90px"><?php esc_html_e( 'Received', 'wc-enterprise-erp' ); ?></th>
				<?php endif; ?>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $doc['lines'] as $line ) : ?>
				<tr>
					<?php if ( $images ) : ?>
						<td class="thumb"><?php echo wp_kses_post( self::product_image( $line['product_id'], $px ) ); ?></td>
					<?php endif; ?>
					<td><?php echo esc_html( $line['name'] ); ?></td>
					<td class="n"><?php echo esc_html( rtrim( rtrim( number_format( $line['qty'], 2 ), '0' ), '.' ) ); ?></td>
					<?php if ( $money ) : ?>
						<td class="n"><?php echo esc_html( number_format( $line['price'], 2 ) ); ?></td>
						<td class="n"><?php echo esc_html( number_format( $line['total'], 2 ) ); ?></td>
					<?php else : ?>
						<?php /* Left blank on purpose: the receiver ticks or writes
						         what actually arrived, which is the whole point of
						         handing over a challan. */ ?>
						<td class="n" style="border-left:1px solid #eceaef">&nbsp;</td>
					<?php endif; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
		<?php if ( $money ) : ?>
		<tfoot>
			<?php $span = $images ? 4 : 3; ?>
			<tr>
				<td colspan="<?php echo (int) $span; ?>" class="n"><?php esc_html_e( 'Subtotal', 'wc-enterprise-erp' ); ?></td>
				<td class="n"><?php echo esc_html( number_format( $doc['subtotal'], 2 ) ); ?></td>
			</tr>
			<?php if ( $doc['discount'] > 0 ) : ?>
				<tr>
					<td colspan="<?php echo (int) $span; ?>" class="n"><?php esc_html_e( 'Discount', 'wc-enterprise-erp' ); ?></td>
					<td class="n">− <?php echo esc_html( number_format( $doc['discount'], 2 ) ); ?></td>
				</tr>
			<?php endif; ?>
			<?php if ( $doc['tax'] > 0 ) : ?>
				<tr>
					<td colspan="<?php echo (int) $span; ?>" class="n"><?php esc_html_e( 'VAT', 'wc-enterprise-erp' ); ?></td>
					<td class="n"><?php echo esc_html( number_format( $doc['tax'], 2 ) ); ?></td>
				</tr>
			<?php endif; ?>
			<tr class="grand">
				<td colspan="<?php echo (int) $span; ?>" class="n"><?php esc_html_e( 'Total', 'wc-enterprise-erp' ); ?></td>
				<td class="n"><?php echo esc_html( number_format( $doc['total'], 2 ) ); ?></td>
			</tr>
		</tfoot>
		<?php else : ?>
		<tfoot>
			<tr class="grand">
				<td colspan="<?php echo $images ? 2 : 1; ?>" class="n"><?php esc_html_e( 'Total items', 'wc-enterprise-erp' ); ?></td>
				<td class="n"><?php
					$qty = 0;
					foreach ( $doc['lines'] as $l ) {
						$qty += (float) $l['qty'];
					}
					echo esc_html( rtrim( rtrim( number_format( $qty, 2 ), '0' ), '.' ) );
				?></td>
				<td></td>
			</tr>
		</tfoot>
		<?php endif; ?>
	</table>

	<?php if ( $doc['note'] ) : ?>
		<div class="note"><strong><?php esc_html_e( 'Note', 'wc-enterprise-erp' ); ?>:</strong> <?php echo nl2br( esc_html( $doc['note'] ) ); ?></div>
	<?php endif; ?>
	<?php if ( $inv['terms'] ) : ?>
		<div class="terms"><?php echo esc_html( $inv['terms'] ); ?></div>
	<?php endif; ?>

	<?php if ( 'yes' === $inv['signature'] ) : ?>
		<div class="sign">
			<?php if ( $money ) : ?>
				<div><?php esc_html_e( 'Customer signature', 'wc-enterprise-erp' ); ?></div>
				<div><?php esc_html_e( 'For', 'wc-enterprise-erp' ); ?> <?php echo esc_html( $inv['company_name'] ); ?></div>
			<?php else : ?>
				<div><?php esc_html_e( 'Received the above goods in good condition', 'wc-enterprise-erp' ); ?></div>
				<div><?php esc_html_e( 'Delivered by', 'wc-enterprise-erp' ); ?></div>
				<div><?php esc_html_e( 'For', 'wc-enterprise-erp' ); ?> <?php echo esc_html( $inv['company_name'] ); ?></div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<div class="foot">
		<?php echo esc_html( $inv['footer'] ); ?>
		<?php if ( $inv['footer_img'] ) : ?>
			<img src="<?php echo esc_url( $inv['footer_img'] ); ?>" alt="">
		<?php endif; ?>
	</div>
</div>
</body>
</html>
		<?php
	}
}
